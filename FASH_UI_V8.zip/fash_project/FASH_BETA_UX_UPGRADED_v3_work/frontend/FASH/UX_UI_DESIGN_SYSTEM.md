# FASH UX / UI DESIGN SYSTEM v2

## Beta design direction
**Premium • Modern • Trustworthy • Fast • Accessible**

The interface should feel like a polished marketplace with the clarity of Stripe and Apple, while keeping the density and discoverability expected from a marketplace.

## Core color palette

| Token | Hex | Use |
|---|---|---|
| Brand 950 | `#071427` | Deep navigation / premium dark areas |
| Brand 900 | `#0B1D35` | Dark surfaces |
| Brand 800 | `#12335C` | Dark accents |
| Primary | `#0F172A` | Main text and authority |
| Primary light | `#1E293B` | Secondary dark surfaces |
| Secondary / Action Blue | `#2563EB` | Primary CTAs, links, focus |
| Secondary dark | `#1D4ED8` | CTA hover |
| Secondary light | `#60A5FA` | Highlights |
| Accent Orange | `#F97316` | Deals, emphasis, marketplace energy |
| Accent soft | `#FFF7ED` | Accent backgrounds |
| Success | `#10B981` | Paid, approved, delivered |
| Success soft | `#ECFDF5` | Success backgrounds |
| Warning | `#F59E0B` | Pending / attention |
| Warning soft | `#FFFBEB` | Warning backgrounds |
| Danger | `#EF4444` | Errors, destructive actions |
| Danger soft | `#FEF2F2` | Error backgrounds |
| Info | `#0EA5E9` | Informational states |
| Background | `#F7F9FC` | App/page background |
| Surface | `#FFFFFF` | Cards and panels |
| Surface muted | `#F8FAFC` | Secondary surfaces |
| Text | `#0F172A` | Primary text |
| Text muted | `#64748B` | Supporting text |
| Border | `#E2E8F0` | Dividers and inputs |

## Typography
- Font: **Inter**
- Body: 15–16px
- Small metadata: 12–14px
- Section title: 20–24px
- Page title: 28–40px
- Hero display: 40–56px
- Avoid overly light text for essential information.

## Spacing
Use a consistent rhythm:
- 4px: micro
- 8px: tight
- 12px: compact
- 16px: standard
- 24px: section interior
- 32px: major separation
- 48px+: page sections

## Radius
- Inputs: 10–12px
- Buttons: 10–12px
- Cards: 16–20px
- Large feature panels: 20–28px
- Pills/statuses: 999px

## Shadows
Use subtle shadows by default. Heavy shadows are reserved for dropdowns and modals.

## Interaction rules
1. Every interactive control must have a visible focus state.
2. Hover movement should be subtle (1–3px maximum).
3. Avoid slow animations.
4. Buttons must communicate disabled/loading states.
5. Dropdowns and modals must sit above content with consistent layering.
6. Use confirmation for destructive actions.
7. Empty, loading and error states are required for data-driven pages.

## UX standards for each page
Every important screen should have:
- Clear primary action
- Secondary actions that do not compete visually
- Loading state
- Empty state
- Error state
- Success feedback
- Mobile behavior
- Keyboard accessibility

## Global z-index system
Recommended layers:
- Base content: 1
- Sticky content: 20
- Navbar: 1000
- Dropdowns: 1200
- Modals: 2000
- Toasts: 3000
- Critical overlays: 4000

## Beta QA checklist
- Test at 320px, 375px, 768px, 1024px and desktop.
- Tab through forms and menus.
- Test Escape to close overlays.
- Check contrast on all status badges.
- Ensure no dropdown is clipped by `overflow: hidden`.
- Verify every major API state has loading/error/empty feedback.
