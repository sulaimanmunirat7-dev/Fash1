/*========================================================
FASH MARKETPLACE
STORES PAGE
STORES.JS
========================================================*/

"use strict";


/*========================================================
STORE DATA
========================================================*/

const fashStores = [

    {
        id: "FASH-STORE-001",
        name: "FASH Tech Store",
        category: "Electronics",
        rating: 4.9,
        reviews: 328,
        products: 126,
        location: "Lagos",
        verified: true,
        icon: "fa-laptop",
        description: "Premium electronics, laptops and smart devices."
    },

    {
        id: "FASH-STORE-002",
        name: "Apple Premium Store",
        category: "Electronics",
        rating: 4.9,
        reviews: 412,
        products: 94,
        location: "Lagos",
        verified: true,
        icon: "fa-apple-whole",
        description: "Apple devices, accessories and premium technology."
    },

    {
        id: "FASH-STORE-003",
        name: "Samsung Official Store",
        category: "Electronics",
        rating: 4.9,
        reviews: 521,
        products: 118,
        location: "Lagos",
        verified: true,
        icon: "fa-mobile-screen-button",
        description: "Samsung smartphones, tablets and accessories."
    },

    {
        id: "FASH-STORE-004",
        name: "FASH Fashion Hub",
        category: "Fashion",
        rating: 4.7,
        reviews: 186,
        products: 247,
        location: "Lagos",
        verified: true,
        icon: "fa-shirt",
        description: "Modern fashion, footwear and everyday essentials."
    },

    {
        id: "FASH-STORE-005",
        name: "FASH Couture",
        category: "Fashion",
        rating: 4.7,
        reviews: 132,
        products: 164,
        location: "Abuja",
        verified: true,
        icon: "fa-scissors",
        description: "Premium clothing and contemporary African fashion."
    },

    {
        id: "FASH-STORE-006",
        name: "Glow Beauty Store",
        category: "Beauty",
        rating: 4.8,
        reviews: 145,
        products: 183,
        location: "Lagos",
        verified: true,
        icon: "fa-wand-magic-sparkles",
        description: "Skincare, cosmetics and beauty essentials."
    },

    {
        id: "FASH-STORE-007",
        name: "FASH Fragrance",
        category: "Beauty",
        rating: 4.9,
        reviews: 211,
        products: 87,
        location: "Lagos",
        verified: true,
        icon: "fa-spray-can-sparkles",
        description: "Premium perfumes and luxury fragrances."
    },

    {
        id: "FASH-STORE-008",
        name: "FASH Home",
        category: "Home & Living",
        rating: 4.7,
        reviews: 177,
        products: 205,
        location: "Lagos",
        verified: true,
        icon: "fa-house",
        description: "Furniture, lighting and stylish home products."
    },

    {
        id: "FASH-STORE-009",
        name: "FASH Fresh Market",
        category: "Groceries",
        rating: 4.6,
        reviews: 193,
        products: 312,
        location: "Lagos",
        verified: true,
        icon: "fa-basket-shopping",
        description: "Fresh groceries and everyday household essentials."
    },

    {
        id: "FASH-STORE-010",
        name: "FASH Sports",
        category: "Sports",
        rating: 4.8,
        reviews: 164,
        products: 142,
        location: "Lagos",
        verified: true,
        icon: "fa-futbol",
        description: "Sports equipment, football gear and fitness products."
    },

    {
        id: "FASH-STORE-011",
        name: "FASH Gaming",
        category: "Gaming",
        rating: 4.8,
        reviews: 236,
        products: 156,
        location: "Lagos",
        verified: true,
        icon: "fa-gamepad",
        description: "Gaming PCs, consoles, accessories and gear."
    },

    {
        id: "FASH-STORE-012",
        name: "Sony Electronics",
        category: "Electronics",
        rating: 4.8,
        reviews: 189,
        products: 73,
        location: "Lagos",
        verified: true,
        icon: "fa-tv",
        description: "Sony televisions, audio products and electronics."
    }

];


/*========================================================
CONFIG
========================================================*/

const STORES_CONFIG = {

    storesPerPage: 8,

    searchIds: [
        "storeSearch",
        "storesSearch",
        "shopSearch",
        "navbarSearch"
    ]

};


/*========================================================
STATE
========================================================*/

const storesState = {

    stores: [...fashStores],

    filteredStores: [...fashStores],

    currentPage: 1,

    searchTerm: "",

    category: "all",

    location: "all",

    sort: "popular"

};


/*========================================================
HELPERS
========================================================*/

function normalizeStoreText(value) {

    return String(value || "")
        .trim()
        .toLowerCase();

}


/*========================================================
STORE CARD
========================================================*/

function renderStoreCard(store) {

    const stars = "★".repeat(
        Math.max(1, Math.round(Number(store.rating) || 0))
    );

    return `

        <article
            class="store-card"
            data-store-id="${store.id}"
        >

            <div class="store-cover">

                <div class="store-cover-pattern"></div>

                <div class="store-logo">

                    <i class="fa-solid ${store.icon || "fa-store"}"></i>

                </div>

            </div>


            <div class="store-content">

                ${
                    store.verified
                        ? `
                            <div class="store-verified">

                                <i class="fa-solid fa-circle-check"></i>

                                Verified Store

                            </div>
                        `
                        : ""
                }


                <h4>
                    ${store.name}
                </h4>


                <div class="store-category">

                    ${store.category}

                </div>


                <div class="store-rating">

                    <span class="stars">
                        ${stars}
                    </span>

                    <strong>
                        ${Number(store.rating).toFixed(1)}
                    </strong>

                    <span>
                        (${Number(store.reviews).toLocaleString()})
                    </span>

                </div>


                <div class="store-meta">

                    <span>

                        <i class="fa-solid fa-location-dot"></i>

                        ${store.location}

                    </span>

                    <strong>

                        ${Number(store.products).toLocaleString()}
                        products

                    </strong>

                </div>


                <a
                    href="store.html?id=${encodeURIComponent(store.id)}"
                    class="visit-store-btn"
                >

                    Visit Store

                    <i class="fa-solid fa-arrow-right"></i>

                </a>

            </div>

        </article>

    `;

}


/*========================================================
FILTER STORES
========================================================*/

function applyStoreFilters() {

    const query =
        normalizeStoreText(storesState.searchTerm);


    let results = storesState.stores.filter(store => {

        const searchableText = [

            store.name,

            store.category,

            store.location,

            store.description

        ]
            .join(" ")
            .toLowerCase();


        const searchMatch =
            !query ||
            searchableText.includes(query);


        const categoryMatch =
            storesState.category === "all" ||
            normalizeStoreText(store.category) ===
            normalizeStoreText(storesState.category);


        const locationMatch =
            storesState.location === "all" ||
            normalizeStoreText(store.location) ===
            normalizeStoreText(storesState.location);


        return (
            searchMatch &&
            categoryMatch &&
            locationMatch
        );

    });


    /*====================================================
      SORT
    ====================================================*/

    switch (storesState.sort) {

        case "rating":

            results.sort(
                (a, b) =>
                    Number(b.rating) -
                    Number(a.rating)
            );

            break;


        case "products":

            results.sort(
                (a, b) =>
                    Number(b.products) -
                    Number(a.products)
            );

            break;


        case "reviews":

            results.sort(
                (a, b) =>
                    Number(b.reviews) -
                    Number(a.reviews)
            );

            break;


        case "name":

            results.sort(
                (a, b) =>
                    a.name.localeCompare(b.name)
            );

            break;


        default:

            results.sort(
                (a, b) =>
                    Number(b.rating) -
                    Number(a.rating)
            );

            break;

    }


    storesState.filteredStores = results;


    const totalPages = Math.max(
        1,
        Math.ceil(
            results.length /
            STORES_CONFIG.storesPerPage
        )
    );


    storesState.currentPage =
        Math.min(
            storesState.currentPage,
            totalPages
        );

}


/*========================================================
RENDER STORES
========================================================*/

function renderStores() {

    applyStoreFilters();


    const grid =
        document.getElementById("storesGrid");


    if (!grid) {

        return;

    }


    const total =
        storesState.filteredStores.length;


    const start =
        (storesState.currentPage - 1) *
        STORES_CONFIG.storesPerPage;


    const end =
        start +
        STORES_CONFIG.storesPerPage;


    const visibleStores =
        storesState.filteredStores.slice(
            start,
            end
        );


    if (visibleStores.length) {

        grid.innerHTML =
            visibleStores
                .map(renderStoreCard)
                .join("");

    } else {

        grid.innerHTML = "";

    }


    renderStoreResults(total);

    renderStorePagination();

    updateStoreStats();

}


/*========================================================
RESULT COUNT
========================================================*/

function renderStoreResults(total) {

    const resultElement =
        document.getElementById(
            "storeResultsCount"
        );


    if (!resultElement) {

        return;

    }


    if (!total) {

        resultElement.textContent =
            "No stores found";

        return;

    }


    const start =
        ((storesState.currentPage - 1) *
        STORES_CONFIG.storesPerPage) + 1;


    const end =
        Math.min(
            storesState.currentPage *
            STORES_CONFIG.storesPerPage,
            total
        );


    resultElement.textContent =
        `Showing ${start}–${end} of ${total} stores`;

}


/*========================================================
PAGINATION
========================================================*/

function renderStorePagination() {

    const pagination =
        document.getElementById(
            "storesPagination"
        );


    if (!pagination) {

        return;

    }


    const pages =
        Math.max(
            1,
            Math.ceil(
                storesState.filteredStores.length /
                STORES_CONFIG.storesPerPage
            )
        );


    let html = `

        <button
            type="button"
            class="store-page-btn"
            id="storesPrevPage"
            ${storesState.currentPage === 1 ? "disabled" : ""}
        >

            <i class="fa-solid fa-chevron-left"></i>

        </button>

    `;


    for (let i = 1; i <= pages; i++) {

        html += `

            <button
                type="button"
                class="store-page-btn ${
                    i === storesState.currentPage
                        ? "active"
                        : ""
                }"
                data-store-page="${i}"
            >

                ${i}

            </button>

        `;

    }


    html += `

        <button
            type="button"
            class="store-page-btn"
            id="storesNextPage"
            ${storesState.currentPage === pages ? "disabled" : ""}
        >

            <i class="fa-solid fa-chevron-right"></i>

        </button>

    `;


    pagination.innerHTML = html;

}


/*========================================================
STATS
========================================================*/

function updateStoreStats() {

    const totalStores =
        document.getElementById(
            "totalStores"
        );


    const totalProducts =
        document.getElementById(
            "totalStoreProducts"
        );


    const verifiedStores =
        document.getElementById(
            "verifiedStores"
        );


    if (totalStores) {

        totalStores.textContent =
            fashStores.length;

    }


    if (totalProducts) {

        const total =
            fashStores.reduce(
                (sum, store) =>
                    sum +
                    Number(store.products || 0),
                0
            );

        totalProducts.textContent =
            total.toLocaleString();

    }


    if (verifiedStores) {

        verifiedStores.textContent =
            fashStores.filter(
                store => store.verified
            ).length;

    }

}


/*========================================================
SEARCH
========================================================*/

function setupStoreSearch() {

    STORES_CONFIG.searchIds.forEach(id => {

        const input =
            document.getElementById(id);


        if (!input) {

            return;

        }


        input.addEventListener(
            "input",
            event => {

                const value =
                    event.target.value;


                storesState.searchTerm =
                    value;


                /*
                 * Keep the other store search
                 * boxes synchronized.
                 */

                STORES_CONFIG.searchIds.forEach(
                    otherId => {

                        const other =
                            document.getElementById(
                                otherId
                            );


                        if (
                            other &&
                            other !== event.target
                        ) {

                            other.value =
                                value;

                        }

                    }
                );


                storesState.currentPage =
                    1;


                renderStores();

            }
        );

    });

}


/*========================================================
CATEGORY FILTER
========================================================*/

function setupStoreCategoryFilter() {

    const category =
        document.getElementById(
            "storeCategoryFilter"
        );


    if (!category) {

        return;

    }


    category.addEventListener(
        "change",
        event => {

            storesState.category =
                event.target.value;


            storesState.currentPage =
                1;


            renderStores();

        }
    );

}


/*========================================================
LOCATION FILTER
========================================================*/

function setupStoreLocationFilter() {

    const location =
        document.getElementById(
            "storeLocationFilter"
        );


    if (!location) {

        return;

    }


    location.addEventListener(
        "change",
        event => {

            storesState.location =
                event.target.value;


            storesState.currentPage =
                1;


            renderStores();

        }
    );

}


/*========================================================
SORT
========================================================*/

function setupStoreSort() {

    const sort =
        document.getElementById(
            "storeSort"
        );


    if (!sort) {

        return;

    }


    sort.addEventListener(
        "change",
        event => {

            storesState.sort =
                event.target.value;


            storesState.currentPage =
                1;


            renderStores();

        }
    );

}


/*========================================================
PAGINATION EVENTS
========================================================*/

function setupStorePagination() {

    document.addEventListener(
        "click",
        event => {


            const pageButton =
                event.target.closest(
                    "[data-store-page]"
                );


            if (pageButton) {

                storesState.currentPage =
                    Number(
                        pageButton.dataset.storePage
                    );


                renderStores();

                return;

            }


            if (
                event.target.closest(
                    "#storesPrevPage"
                )
            ) {

                if (
                    storesState.currentPage > 1
                ) {

                    storesState.currentPage--;

                    renderStores();

                }

                return;

            }


            if (
                event.target.closest(
                    "#storesNextPage"
                )
            ) {

                const pages =
                    Math.max(
                        1,
                        Math.ceil(
                            storesState.filteredStores.length /
                            STORES_CONFIG.storesPerPage
                        )
                    );


                if (
                    storesState.currentPage <
                    pages
                ) {

                    storesState.currentPage++;

                    renderStores();

                }

            }

        }
    );

}


/*========================================================
SEARCH BUTTON
========================================================*/

function setupStoreSearchButton() {

    const button =
        document.getElementById(
            "storeSearchButton"
        );


    if (!button) {

        return;

    }


    button.addEventListener(
        "click",
        () => {

            const input =
                document.getElementById(
                    "storeSearch"
                );


            if (!input) {

                return;

            }


            storesState.searchTerm =
                input.value.trim();


            storesState.currentPage =
                1;


            renderStores();

        }
    );

}


/*========================================================
ENTER KEY SEARCH
========================================================*/

function setupStoreEnterSearch() {

    document.addEventListener(
        "keydown",
        event => {

            if (
                event.key !== "Enter"
            ) {

                return;

            }


            const input =
                event.target.closest(
                    "#storeSearch"
                );


            if (!input) {

                return;

            }


            storesState.searchTerm =
                input.value.trim();


            storesState.currentPage =
                1;


            renderStores();

        }
    );

}


/*========================================================
INITIALIZE
========================================================*/

function setupStoresPage() {

    if (
        !document.getElementById(
            "storesGrid"
        )
    ) {

        return;

    }


    setupStoreSearch();

    setupStoreSearchButton();

    setupStoreEnterSearch();

    setupStoreCategoryFilter();

    setupStoreLocationFilter();

    setupStoreSort();

    setupStorePagination();

    // Merge approved seller stores from PostgreSQL with FASH's curated stores.
    (async () => {
        try {
            const apiBase = window.FASH_API_BASE || "http://localhost:5000";
            const response = await fetch(`${apiBase}/api/stores`);
            if (response.ok) {
                const data = await response.json();
                const dynamicStores = (data.stores || []).map(store => ({
                    id: store.id,
                    name: store.name,
                    category: "Seller Store",
                    rating: 5,
                    reviews: 0,
                    products: Number(store.products || 0),
                    location: store.location || "Nigeria",
                    verified: true,
                    icon: "fa-store",
                    description: store.description || "Official FASH seller store.",
                    logo: store.logo_url || "",
                    sellerName: store.seller_name || ""
                }));
                const ids = new Set(fashStores.map(s => String(s.id)));
                dynamicStores.forEach(store => {
                    if (!ids.has(String(store.id))) storesState.stores.push(store);
                });
                storesState.filteredStores = [...storesState.stores];
            }
        } catch (error) {
            console.warn("Dynamic FASH stores unavailable:", error);
        }
        renderStores();
    })();


    /*
     * Public API.
     * Useful if another page wants
     * to refresh the store directory.
     */

    window.FASHStores = {

        stores: fashStores,

        state: storesState,

        refresh: renderStores,

        search: function(value) {

            storesState.searchTerm =
                String(value || "");

            storesState.currentPage =
                1;

            renderStores();

        },

        reset: function() {

            storesState.searchTerm = "";

            storesState.category = "all";

            storesState.location = "all";

            storesState.sort = "popular";

            storesState.currentPage = 1;


            const search =
                document.getElementById(
                    "storeSearch"
                );

            if (search) {

                search.value = "";

            }


            const category =
                document.getElementById(
                    "storeCategoryFilter"
                );

            if (category) {

                category.value = "all";

            }


            const location =
                document.getElementById(
                    "storeLocationFilter"
                );

            if (location) {

                location.value = "all";

            }


            const sort =
                document.getElementById(
                    "storeSort"
                );

            if (sort) {

                sort.value = "popular";

            }


            renderStores();

        }

    };

}


/*========================================================
START
========================================================*/

if (
    document.readyState === "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        setupStoresPage,
        { once: true }
    );

} else {

    setupStoresPage();

}

