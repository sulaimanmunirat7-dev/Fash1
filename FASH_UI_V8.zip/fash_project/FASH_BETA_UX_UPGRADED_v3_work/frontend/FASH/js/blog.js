"use strict";

document.addEventListener("DOMContentLoaded", () => {

    const categoryButtons =
        document.querySelectorAll(".category-btn");

    const articles =
        document.querySelectorAll(".article-card");

    const searchInput =
        document.getElementById("blogSearch");

    const noResults =
        document.getElementById("noResults");


    let selectedCategory = "all";


    /*==================================================
    FILTER ARTICLES
    ==================================================*/

    function filterArticles() {

        const search =
            searchInput.value
                .trim()
                .toLowerCase();

        let visibleArticles = 0;


        articles.forEach(article => {

            const category =
                article.dataset.category || "";

            const title =
                article.dataset.title ||
                article.textContent;

            const matchesCategory =
                selectedCategory === "all" ||
                category === selectedCategory;

            const matchesSearch =
                title
                    .toLowerCase()
                    .includes(search);


            if (
                matchesCategory &&
                matchesSearch
            ) {

                article.classList.remove(
                    "hidden"
                );

                visibleArticles++;

            } else {

                article.classList.add(
                    "hidden"
                );

            }

        });


        noResults.classList.toggle(
            "show",
            visibleArticles === 0
        );

    }


    /*==================================================
    CATEGORY BUTTONS
    ==================================================*/

    categoryButtons.forEach(button => {

        button.addEventListener(
            "click",
            () => {

                categoryButtons.forEach(
                    item => {

                        item.classList.remove(
                            "active"
                        );

                    }
                );


                button.classList.add(
                    "active"
                );


                selectedCategory =
                    button.dataset.category;


                filterArticles();

            }
        );

    });


    /*==================================================
    SEARCH
    ==================================================*/

    if (searchInput) {

        searchInput.addEventListener(
            "input",
            filterArticles
        );

    }


    /*==================================================
    READ BUTTONS
    ==================================================*/

    const readButtons =
        document.querySelectorAll(
            ".read-btn, .small-read-btn"
        );


    readButtons.forEach(button => {

        button.addEventListener(
            "click",
            () => {

                const title =
                    button.dataset.title ||
                    "this article";

                alert(
                    `"${title}" will open here when the full article system is connected.`
                );

            }
        );

    });


    /*==================================================
    NEWSLETTER
    ==================================================*/

    const newsletter =
        document.getElementById(
            "newsletterForm"
        );


    if (newsletter) {

        newsletter.addEventListener(
            "submit",
            event => {

                event.preventDefault();


                const email =
                    document.getElementById(
                        "newsletterEmail"
                    ).value.trim();


                if (!email) {
                    return;
                }


                localStorage.setItem(
                    "fash_blog_subscriber",
                    email
                );


                alert(
                    "You're subscribed to the FASH blog!"
                );


                newsletter.reset();

            }
        );

    }

});