/* FASH LIVE ORDERS SYNC */
document.addEventListener("DOMContentLoaded",async()=>{
 try{
  // BUGFIX: "fashAuthToken" is never set anywhere in the app (the real key is
  // "fash_token" / "fash_user"), so this sync silently never ran for anyone.
  if(!window.FASH_API||!localStorage.getItem("fash_user"))return;
  const d=await FASH_API.api("/api/orders");
  const orders=d.orders||[];
  localStorage.setItem("fash_orders",JSON.stringify(orders));
  localStorage.setItem("fashOrders",JSON.stringify(orders));
  window.dispatchEvent(new CustomEvent("fash:orders-updated",{detail:orders}));
 }catch(e){console.warn("Orders sync unavailable",e)}
});