/* =========================================================
   FASH HELP CENTER
   help.js
========================================================= */

document.addEventListener("DOMContentLoaded", () => {


    /* =====================================================
       FAQ ACCORDION
    ===================================================== */

    const faqItems = document.querySelectorAll(".faq-item");

    faqItems.forEach(item => {

        const question = item.querySelector(".faq-question");
        const answer = item.querySelector(".faq-answer");

        question.addEventListener("click", () => {

            const isOpen = item.classList.contains("active");


            /* Close all FAQs */

            faqItems.forEach(otherItem => {

                otherItem.classList.remove("active");

                const otherAnswer =
                    otherItem.querySelector(".faq-answer");

                otherAnswer.style.maxHeight = null;

            });


            /* Open selected FAQ */

            if (!isOpen) {

                item.classList.add("active");

                answer.style.maxHeight =
                    answer.scrollHeight + "px";

            }

        });

    });


    /* =====================================================
       SEARCH ELEMENTS
    ===================================================== */

    const searchForm =
        document.getElementById("helpSearchForm");

    const searchInput =
        document.getElementById("helpSearch");

    const searchResults =
        document.getElementById("helpSearchResults");


    if (!searchForm || !searchInput || !searchResults) {
        return;
    }


    /* =====================================================
       FAQ DATA
    ===================================================== */

    const faqData = Array.from(faqItems).map((item, index) => {

        const question =
            item.querySelector(".faq-question span").textContent.trim();

        const answer =
            item.querySelector(".faq-answer-content").textContent.trim();

        return {
            id: item.id || `faq-${index + 1}`,
            question,
            answer,
            element: item
        };

    });


    /* =====================================================
       SEARCH
    ===================================================== */

    function searchFAQs(query) {

        const searchTerm =
            query.toLowerCase().trim();


        if (!searchTerm) {

            searchResults.classList.remove("active");

            searchResults.innerHTML = "";

            return;

        }


        const results = faqData.filter(item => {

            return (
                item.question.toLowerCase().includes(searchTerm) ||
                item.answer.toLowerCase().includes(searchTerm)
            );

        });


        renderResults(results);

    }


    /* =====================================================
       RENDER RESULTS
    ===================================================== */

    function renderResults(results) {

        searchResults.innerHTML = "";


        if (results.length === 0) {

            searchResults.innerHTML = `

                <div class="no-results">

                    <i class="fa-solid fa-circle-question"></i>

                    <p>

                        No help articles found for your search.

                    </p>

                </div>

            `;

            searchResults.classList.add("active");

            return;

        }


        results.forEach(item => {

            const result = document.createElement("a");

            result.href = `#${item.id}`;

            result.className = "help-search-result";


            result.innerHTML = `

                <i class="fa-solid fa-circle-question"></i>

                <div>

                    <strong>

                        ${item.question}

                    </strong>

                </div>

            `;


            result.addEventListener("click", event => {

                event.preventDefault();

                openFAQ(item.element);

                searchResults.classList.remove("active");

                searchInput.value = "";

            });


            searchResults.appendChild(result);

        });


        searchResults.classList.add("active");

    }


    /* =====================================================
       OPEN FAQ FROM SEARCH
    ===================================================== */

    function openFAQ(item) {

        const answer =
            item.querySelector(".faq-answer");


        faqItems.forEach(otherItem => {

            otherItem.classList.remove("active");

            const otherAnswer =
                otherItem.querySelector(".faq-answer");

            otherAnswer.style.maxHeight = null;

        });


        item.classList.add("active");

        answer.style.maxHeight =
            answer.scrollHeight + "px";


        setTimeout(() => {

            item.scrollIntoView({
                behavior: "smooth",
                block: "center"
            });

        }, 100);

    }


    /* =====================================================
       LIVE SEARCH
    ===================================================== */

    searchInput.addEventListener("input", () => {

        searchFAQs(searchInput.value);

    });


    /* =====================================================
       FORM SUBMIT
    ===================================================== */

    searchForm.addEventListener("submit", event => {

        event.preventDefault();

        const query =
            searchInput.value.trim();


        if (!query) {

            searchInput.focus();

            return;

        }


        searchFAQs(query);

    });


    /* =====================================================
       CLOSE SEARCH WHEN CLICKING OUTSIDE
    ===================================================== */

    document.addEventListener("click", event => {

        if (
            !searchResults.contains(event.target) &&
            !searchForm.contains(event.target)
        ) {

            searchResults.classList.remove("active");

        }

    });


    /* =====================================================
       ESCAPE KEY
    ===================================================== */

    document.addEventListener("keydown", event => {

        if (event.key === "Escape") {

            searchResults.classList.remove("active");

            searchInput.blur();

        }

    });


    /* =====================================================
       CATEGORY LINKS
    ===================================================== */

    const categoryLinks =
        document.querySelectorAll(".help-category");


    categoryLinks.forEach(link => {

        link.addEventListener("click", event => {

            const targetID =
                link.getAttribute("href");


            if (!targetID || !targetID.startsWith("#")) {
                return;
            }


            const target =
                document.querySelector(targetID);


            if (!target) {
                return;
            }


            event.preventDefault();


            openFAQ(target);

        });

    });


    /* =====================================================
       RESIZE HANDLING
    ===================================================== */

    window.addEventListener("resize", () => {

        const openItem =
            document.querySelector(".faq-item.active");


        if (!openItem) {
            return;
        }


        const answer =
            openItem.querySelector(".faq-answer");


        answer.style.maxHeight =
            answer.scrollHeight + "px";

    });

});