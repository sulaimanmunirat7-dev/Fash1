"use strict";

document.addEventListener("DOMContentLoaded", () => {

    /*==================================================
    SCROLL REVEAL
    ==================================================*/

    const sections = document.querySelectorAll(
        ".press-section, .media-contact"
    );

    const observer = new IntersectionObserver(
        entries => {

            entries.forEach(entry => {

                if (!entry.isIntersecting) {
                    return;
                }

                entry.target.classList.add(
                    "visible"
                );

                observer.unobserve(
                    entry.target
                );

            });

        },
        {
            threshold: 0.12
        }
    );


    sections.forEach(section => {

        section.classList.add(
            "press-reveal"
        );

        observer.observe(section);

    });


    /*==================================================
    PRESS ANNOUNCEMENTS
    ==================================================*/

    const readButtons =
        document.querySelectorAll(
            ".press-read-btn"
        );


    readButtons.forEach(button => {

        button.addEventListener(
            "click",
            () => {

                const title =
                    button.dataset.title ||
                    "Press announcement";

                alert(
                    `"${title}" will open here when the full press article system is connected.`
                );

            }
        );

    });


    /*==================================================
    PRESS RESOURCES
    ==================================================*/

    const resourceButtons =
        document.querySelectorAll(
            ".resource-btn"
        );


    resourceButtons.forEach(button => {

        button.addEventListener(
            "click",
            () => {

                const resource =
                    button.dataset.resource ||
                    "Press resource";

                alert(
                    `${resource} will be available here when the FASH media resource system is connected.`
                );

            }
        );

    });


    /*==================================================
    MEDIA CONTACT
    ==================================================*/

    const contactButton =
        document.getElementById(
            "contactPress"
        );


    if (contactButton) {

        contactButton.addEventListener(
            "click",
            () => {

                window.location.href =
                    "mailto:press@fash.com?subject=FASH%20Press%20Enquiry";

            }
        );

    }

});