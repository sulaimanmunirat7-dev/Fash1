/*========================================================
FASH MARKETPLACE
WISHLIST.JS
========================================================*/

"use strict";


/*========================================================
CONFIG
========================================================*/

const WISHLIST_STORAGE_KEY = "fash_wishlist";
const CART_STORAGE_KEY = "fash_cart";


/*========================================================
GET WISHLIST
========================================================*/

function getWishlistItems() {

    try {

        const wishlist =
            JSON.parse(
                localStorage.getItem(WISHLIST_STORAGE_KEY)
            );

        return Array.isArray(wishlist)
            ? wishlist
            : [];

    } catch (error) {

        console.error(
            "Could not load wishlist:",
            error
        );

        return [];

    }

}


/*========================================================
SAVE WISHLIST
========================================================*/

function saveWishlistItems(items) {

    localStorage.setItem(
        WISHLIST_STORAGE_KEY,
        JSON.stringify(items)
    );

}


/*========================================================
GET PRODUCTS
========================================================*/

function getShopProducts() {

    /*
        shop.js exposes the products through
        window.FASHShop.products
    */

    if (
        window.FASHShop &&
        Array.isArray(window.FASHShop.products)
    ) {

        return window.FASHShop.products;

    }


    return [];

}


/*========================================================
MONEY
========================================================*/

function wishlistMoney(value) {

    return new Intl.NumberFormat(
        "en-NG",
        {
            style: "currency",
            currency: "NGN",
            maximumFractionDigits: 0
        }
    ).format(Number(value) || 0);

}


/*========================================================
ESCAPE HTML
========================================================*/

function escapeWishlistHTML(value) {

    return String(value ?? "")

        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");

}


/*========================================================
CATEGORY LABEL
========================================================*/

function wishlistCategoryLabel(category) {

    const categories = {

        gaming: "Gaming",

        electronics: "Electronics",

        phones: "Phones",

        fashion: "Fashion",

        beauty: "Beauty",

        home: "Home & Living",

        groceries: "Groceries",

        sports: "Sports"

    };


    return categories[category] || category || "Product";

}


/*========================================================
RENDER STARS
========================================================*/

function renderWishlistStars(rating) {

    const number =
        Math.max(
            0,
            Math.min(
                5,
                Math.round(Number(rating) || 0)
            )
        );


    return "★".repeat(number);

}


/*========================================================
REMOVE FROM WISHLIST
========================================================*/

function removeFromWishlist(id) {

    const wishlist = getWishlistItems();

    const products = getShopProducts();

    const product = products.find(
        item => String(item.id) === String(id)
    );

    const updatedWishlist =
        wishlist.filter(
            item => String(item) !== String(id)
        );

    saveWishlistItems(updatedWishlist);

    window.dispatchEvent(
        new CustomEvent("fash:wishlist-updated", {
            detail: {
                action: "remove",
                productId: id,
                productTitle: product
                    ? product.title
                    : ""
            }
        })
    );

    renderWishlist();

}


/*========================================================
GET CART
========================================================*/

function getWishlistCart() {

    try {

        const cart =
            JSON.parse(
                localStorage.getItem(CART_STORAGE_KEY)
            );

        return Array.isArray(cart)
            ? cart
            : [];

    } catch (error) {

        console.error(
            "Could not load cart:",
            error
        );

        return [];

    }

}


/*========================================================
SAVE CART
========================================================*/

function saveWishlistCart(cart, detail = {}) {

    localStorage.setItem(
        CART_STORAGE_KEY,
        JSON.stringify(cart)
    );

    window.dispatchEvent(
        new CustomEvent("fash:cart-updated", {
            detail
        })
    );

}


/*========================================================
ADD WISHLIST PRODUCT TO CART
========================================================*/

function addWishlistProductToCart(id) {

    const products =
        getShopProducts();


    const product =
        products.find(
            item =>
                String(item.id) === String(id)
        );


    if (!product) {

        console.warn(
            "Product not found:",
            id
        );

        return;

    }


    const cart =
        getWishlistCart();


    const existing =
        cart.find(
            item =>
                String(item.id) === String(id)
        );


    if (existing) {

        existing.quantity =
            (Number(existing.quantity) || 1) + 1;

    } else {

        cart.push({

            id: product.id,

            title: product.title,

            price: product.price,

            image: product.image,

            quantity: 1

        });

    }


    saveWishlistCart(cart, {
        action: "add",
        productId: product.id,
        productTitle: product.title
    });

    updateWishlistNavbarCounters();

    showWishlistToast(
        "Added to cart"
    );

}


/*========================================================
UPDATE NAVBAR COUNTERS
========================================================*/

function updateWishlistNavbarCounters() {

    const wishlist =
        getWishlistItems();


    const cart =
        getWishlistCart();


    const wishlistCount =
        wishlist.length;


    const cartCount =
        cart.reduce(
            (total, item) =>
                total +
                (Number(item.quantity) || 0),
            0
        );


    document
        .querySelectorAll(
            "#wishlistCount, .wishlist-count"
        )
        .forEach(
            counter => {

                counter.textContent =
                    wishlistCount;

            }
        );


    document
        .querySelectorAll(
            "#cartCount, .cart-count"
        )
        .forEach(
            counter => {

                counter.textContent =
                    cartCount;

            }
        );

}


/*========================================================
RENDER WISHLIST
========================================================*/

function renderWishlist() {

    const grid =
        document.getElementById(
            "wishlistGrid"
        );


    const empty =
        document.getElementById(
            "wishlistEmpty"
        );


    const count =
        document.getElementById(
            "wishlistPageCount"
        );


    if (!grid) {

        return;

    }


    const wishlist =
        getWishlistItems();


    const products =
        getShopProducts();


    const wishlistProducts =
        wishlist

            .map(
                id =>
                    products.find(
                        product =>
                            String(product.id) === String(id)
                    )
            )

            .filter(Boolean);


    /*----------------------------------------------
    COUNT
    ----------------------------------------------*/

    if (count) {

        count.textContent =
            wishlistProducts.length;

    }


    /*----------------------------------------------
    EMPTY STATE
    ----------------------------------------------*/

    if (!wishlistProducts.length) {

        grid.innerHTML = "";

        grid.hidden = true;

        if (empty) {

            empty.hidden = false;

        }

        return;

    }


    if (empty) {

        empty.hidden = true;

    }


    grid.hidden = false;


    /*----------------------------------------------
    PRODUCT CARDS
    ----------------------------------------------*/

    grid.innerHTML =
        wishlistProducts
            .map(renderWishlistCard)
            .join("");


    updateWishlistNavbarCounters();

}


/*========================================================
PRODUCT CARD
========================================================*/

function renderWishlistCard(product) {

    const id =
        escapeWishlistHTML(product.id);


    const title =
        escapeWishlistHTML(product.title);


    const category =
        escapeWishlistHTML(
            wishlistCategoryLabel(
                product.category
            )
        );


    const image =
        escapeWishlistHTML(
            product.image || ""
        );


    const rating =
        Number(product.rating || 0);


    const reviews =
        Number(product.reviews || 0);


    const price =
        wishlistMoney(product.price);


    const oldPrice =
        product.oldPrice
            ? wishlistMoney(product.oldPrice)
            : "";


    return `

        <article
            class="wishlist-card"
            data-product-id="${id}">


            <!-- PRODUCT IMAGE -->

            <div class="wishlist-card-media">

                ${
                    image

                    ? `

                        <img
                            src="${image}"
                            alt="${title}"
                            loading="lazy">

                    `

                    : `

                        <i
                            class="fa-solid fa-cube"
                            style="
                                font-size: 3rem;
                                color: #94a3b8;
                            ">
                        </i>

                    `
                }


                <!-- REMOVE -->

                <button
                    type="button"
                    class="wishlist-remove"
                    data-remove-wishlist="${id}"
                    aria-label="Remove from wishlist">

                    <i class="fa-solid fa-heart"></i>

                </button>

            </div>


            <!-- CONTENT -->

            <div class="wishlist-card-content">


                <span class="wishlist-card-category">

                    ${category}

                </span>


                <h3 class="wishlist-card-title">

                    ${title}

                </h3>


                <!-- RATING -->

                <div class="wishlist-card-rating">

                    <span class="wishlist-stars">

                        ${renderWishlistStars(rating)}

                    </span>

                    <strong>

                        ${rating.toFixed(1)}

                    </strong>

                    <span class="wishlist-review-count">

                        (${reviews.toLocaleString()})

                    </span>

                </div>


                <!-- PRICE -->

                <div class="wishlist-card-price">

                    <span class="wishlist-current-price">

                        ${price}

                    </span>

                    ${
                        oldPrice

                        ? `

                            <span class="wishlist-old-price">

                                ${oldPrice}

                            </span>

                        `

                        : ""
                    }

                </div>


                <!-- ACTIONS -->

                <div class="wishlist-card-actions">


                    <button
                        type="button"
                        class="wishlist-add-cart"
                        data-wishlist-cart="${id}">

                        <i class="fa-solid fa-cart-plus"></i>

                        Add to Cart

                    </button>


                    <a
                        href="product.html?id=${encodeURIComponent(product.id)}"
                        class="wishlist-view-product"
                        aria-label="View product">

                        <i class="fa-solid fa-eye"></i>

                    </a>


                </div>

            </div>

        </article>

    `;

}


/*========================================================
TOAST
========================================================*/

function showWishlistToast(message) {

    let toast =
        document.querySelector(
            ".wishlist-toast"
        );


    if (!toast) {

        toast =
            document.createElement(
                "div"
            );

        toast.className =
            "wishlist-toast";


        toast.style.cssText = `

            position: fixed;
            right: 25px;
            bottom: 25px;
            z-index: 9999;

            padding: 13px 20px;

            border-radius: 10px;

            background: #111827;
            color: #ffffff;

            font-size: 14px;
            font-weight: 700;

            box-shadow:
                0 12px 30px
                rgba(0,0,0,.18);

        `;


        document.body.appendChild(toast);

    }


    toast.textContent =
        message;


    clearTimeout(
        window.__wishlistToastTimer
    );


    window.__wishlistToastTimer =
        setTimeout(
            () => {

                toast.remove();

            },
            1800
        );

}


/*========================================================
EVENTS
========================================================*/

function setupWishlistEvents() {

    document.addEventListener(
        "click",
        function (event) {


            /*------------------------------------------
            REMOVE WISHLIST
            ------------------------------------------*/

            const removeButton =
                event.target.closest(
                    "[data-remove-wishlist]"
                );


            if (removeButton) {

                event.preventDefault();

                removeFromWishlist(
                    removeButton.dataset.removeWishlist
                );

                showWishlistToast(
                    "Removed from wishlist"
                );

                return;

            }


            /*------------------------------------------
            ADD TO CART
            ------------------------------------------*/

            const cartButton =
                event.target.closest(
                    "[data-wishlist-cart]"
                );


            if (cartButton) {

                event.preventDefault();

                addWishlistProductToCart(
                    cartButton.dataset.wishlistCart
                );

                return;

            }

        }
    );

}


/*========================================================
LISTEN FOR WISHLIST CHANGES
========================================================*/

window.addEventListener(
    "fash:wishlist-updated",
    function () {

        renderWishlist();

    }
);


/*========================================================
LISTEN FOR CART CHANGES
========================================================*/

window.addEventListener(
    "fash:cart-updated",
    function () {

        updateWishlistNavbarCounters();

    }
);


/*========================================================
INITIALIZE
========================================================*/

function setupWishlistPage() {

    setupWishlistEvents();

    updateWishlistNavbarCounters();


    /*
        shop.js must be loaded before this page
        can access FASHShop.products.
    */

    if (
        window.FASHShop &&
        Array.isArray(window.FASHShop.products)
    ) {

        renderWishlist();

    } else {

        /*
            Give shop.js a moment to initialize.
        */

        setTimeout(
            renderWishlist,
            100
        );

        setTimeout(
            renderWishlist,
            500
        );

    }

}


/*========================================================
START
========================================================*/

if (
    document.readyState === "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        setupWishlistPage,
        { once: true }
    );

} else {

    setupWishlistPage();

}

/* Navbar loads asynchronously, so refresh the wishlist badge after it arrives. */
window.addEventListener(
    "fash:navbar-ready",
    function () {
        updateWishlistNavbarCounters();
        renderWishlist();
    }
);

