/*========================================================*
 * FASH MARKETPLACE — DEALS.JS
 * PREMIUM DEALS PAGE
 *
 * Uses products from the existing shop.js
 *
 * Features:
 * - Shows every genuinely discounted product
 * - Search
 * - Category filter
 * - Sorting
 * - Pagination
 * - Add to cart
 * - Wishlist
 * - Cart counter
 * - Wishlist counter
 * - Deal statistics
 * - Store statistics
 * - Clear filters
 * - Flash countdown
 * - Navbar search synchronization
 *========================================================*/

"use strict";


/*========================================================*
 * CONFIG
 *========================================================*/

const DEAL_CONFIG = {

    productsPerPage: 8,

    currencyLocale: "en-NG",

    currency: "NGN",

    storageKeys: {

        cart: "fash_cart",

        wishlist: "fash_wishlist",

        countdown: "fash_deal_countdown"

    }

};


/*========================================================*
 * STATE
 *========================================================*/

const dealState = {

    products: [],

    filteredProducts: [],

    currentPage: 1,

    searchTerm: "",

    category: "all",

    sortBy: "discount"

};


/*========================================================*
 * CURRENCY
 *========================================================*/

function dealMoney(value) {

    return new Intl.NumberFormat(

        DEAL_CONFIG.currencyLocale,

        {

            style: "currency",

            currency: DEAL_CONFIG.currency,

            maximumFractionDigits: 0

        }

    ).format(Number(value) || 0);

}


/*========================================================*
 * ESCAPE HTML
 *========================================================*/

function dealEscape(value) {

    return String(value ?? "")

        .replaceAll("&", "&amp;")

        .replaceAll("<", "&lt;")

        .replaceAll(">", "&gt;")

        .replaceAll('"', "&quot;")

        .replaceAll("'", "&#039;");

}


/*========================================================*
 * CATEGORY LABEL
 *========================================================*/

function dealCategoryLabel(category) {

    const categories = {

        electronics: "Electronics",

        phones: "Phones",

        fashion: "Fashion",

        beauty: "Beauty",

        home: "Home & Living",

        groceries: "Groceries",

        sports: "Sports",

        gaming: "Gaming"

    };

    return categories[category] || category || "General";

}


/*========================================================*
 * GET CART
 *========================================================*/

function getDealCart() {

    try {

        return JSON.parse(

            localStorage.getItem(

                DEAL_CONFIG.storageKeys.cart

            )

        ) || [];

    }

    catch {

        return [];

    }

}


/*========================================================*
 * SAVE CART
 *========================================================*/

function saveDealCart(cart) {

    localStorage.setItem(

        DEAL_CONFIG.storageKeys.cart,

        JSON.stringify(cart)

    );

    window.dispatchEvent(

        new CustomEvent("fash:cart-updated")

    );

}


/*========================================================*
 * GET WISHLIST
 *========================================================*/

function getDealWishlist() {

    try {

        return JSON.parse(

            localStorage.getItem(

                DEAL_CONFIG.storageKeys.wishlist

            )

        ) || [];

    }

    catch {

        return [];

    }

}


/*========================================================*
 * SAVE WISHLIST
 *========================================================*/

function saveDealWishlist(list) {

    localStorage.setItem(

        DEAL_CONFIG.storageKeys.wishlist,

        JSON.stringify(list)

    );

    window.dispatchEvent(

        new CustomEvent("fash:wishlist-updated")

    );

}


/*========================================================*
 * WISHLIST CHECK
 *========================================================*/

function isDealWishlisted(id) {

    return getDealWishlist()

        .map(String)

        .includes(String(id));

}


/*========================================================*
 * UPDATE CART COUNTER
 *========================================================*/

function updateDealCartCounter() {

    const cart = getDealCart();

    const count = cart.reduce(

        (total, item) => {

            return total + (

                Number(item.quantity) || 0

            );

        },

        0

    );


    document

        .querySelectorAll(

            "#cartCount, .cart-count"

        )

        .forEach(element => {

            element.textContent = count;

        });

}


/*========================================================*
 * UPDATE WISHLIST COUNTER
 *========================================================*/

function updateDealWishlistCounter() {

    const count = getDealWishlist().length;


    document

        .querySelectorAll(

            "#wishlistCount, .wishlist-count"

        )

        .forEach(element => {

            element.textContent = count;

        });

}


/*========================================================*
 * TOGGLE WISHLIST
 *========================================================*/

function toggleDealWishlist(id) {

    let wishlist = getDealWishlist();

    const exists = wishlist

        .map(String)

        .includes(String(id));


    if (exists) {

        wishlist = wishlist.filter(

            item => String(item) !== String(id)

        );

        showDealToast("Removed from wishlist");

    }

    else {

        wishlist.push(id);

        showDealToast("Added to wishlist");

    }


    saveDealWishlist(wishlist);

    updateDealWishlistCounter();

    renderDeals();

}


/*========================================================*
 * ADD TO CART
 *========================================================*/

function addDealToCart(id) {

    const product = dealState.products.find(

        product => String(product.id) === String(id)

    );


    if (!product) {

        return;

    }


    let cart = getDealCart();


    const existing = cart.find(

        item => String(item.id) === String(id)

    );


    if (existing) {

        existing.quantity =

            (Number(existing.quantity) || 1) + 1;

    }

    else {

        cart.push({

            id: product.id,

            title: product.title,

            price: product.price,

            image: product.image || "",

            quantity: 1

        });

    }


    saveDealCart(cart);

    updateDealCartCounter();

    showDealToast("Added to cart");

}


/*========================================================*
 * TOAST
 *========================================================*/

function showDealToast(message) {

    let toast = document.querySelector(

        ".deal-toast"

    );


    if (!toast) {

        toast = document.createElement("div");

        toast.className = "deal-toast";

        document.body.appendChild(toast);

    }


    toast.textContent = message;

    toast.classList.add("show");


    clearTimeout(

        window.__fashDealToastTimer

    );


    window.__fashDealToastTimer =

        setTimeout(() => {

            toast.classList.remove("show");

        }, 1800);

}


/*========================================================*
 * CALCULATE DISCOUNT
 *========================================================*/

function getDealDiscount(product) {

    const price = Number(product.price) || 0;

    const oldPrice = Number(product.oldPrice) || 0;


    if (

        oldPrice <= price ||

        oldPrice <= 0

    ) {

        return 0;

    }


    return Math.round(

        (1 - price / oldPrice) * 100

    );

}


/*========================================================*
 * LOAD PRODUCTS FROM SHOP.JS
 *========================================================*/

function loadDealProducts() {

    let products = [];


    /*
     * First choice:
     * shop.js exposes window.FASHShop
     */

    if (

        window.FASHShop &&

        Array.isArray(window.FASHShop.products)

    ) {

        products = window.FASHShop.products;

    }


    /*
     * Second choice:
     * shopProducts may be globally available
     */

    else if (

        typeof shopProducts !== "undefined" &&

        Array.isArray(shopProducts)

    ) {

        products = shopProducts;

    }


    /*
     * Only products with a real discount
     */

    dealState.products = products.filter(

        product =>

            Number(product.oldPrice) >

            Number(product.price)

    );


    dealState.filteredProducts = [

        ...dealState.products

    ];

}


/*========================================================*
 * APPLY FILTERS
 *========================================================*/

function applyDealFilters() {

    const search =

        dealState.searchTerm

            .trim()

            .toLowerCase();


    let list = dealState.products.filter(

        product => {

            const discount =

                getDealDiscount(product);


            if (discount <= 0) {

                return false;

            }


            /*
             * SEARCH
             */

            const searchableText = [

                product.title,

                product.brand,

                product.category,

                product.subcategory,

                product.seller,

                ...(product.tags || [])

            ]

                .join(" ")

                .toLowerCase();


            const searchMatch =

                !search ||

                searchableText.includes(search);


            /*
             * CATEGORY
             */

            const categoryMatch =

                dealState.category === "all" ||

                String(product.category)

                    .toLowerCase() ===

                String(dealState.category)

                    .toLowerCase();


            return (

                searchMatch &&

                categoryMatch

            );

        }

    );


    /*
     * SORT
     */

    switch (dealState.sortBy) {


        case "discount":

            list.sort(

                (a, b) =>

                    getDealDiscount(b) -

                    getDealDiscount(a)

            );

            break;


        case "popular":

            list.sort(

                (a, b) =>

                    (Number(b.popularity) || 0) -

                    (Number(a.popularity) || 0)

            );

            break;


        case "low-high":

            list.sort(

                (a, b) =>

                    (Number(a.price) || 0) -

                    (Number(b.price) || 0)

            );

            break;


        case "high-low":

            list.sort(

                (a, b) =>

                    (Number(b.price) || 0) -

                    (Number(a.price) || 0)

            );

            break;


        case "rating":

            list.sort(

                (a, b) =>

                    (Number(b.rating) || 0) -

                    (Number(a.rating) || 0)

            );

            break;

    }


    dealState.filteredProducts = list;


    const totalPages = Math.max(

        1,

        Math.ceil(

            list.length /

            DEAL_CONFIG.productsPerPage

        )

    );


    dealState.currentPage = Math.min(

        dealState.currentPage,

        totalPages

    );

}


/*========================================================*
 * RENDER DEAL CARD
 *========================================================*/

function renderDealCard(product) {

    const discount =

        getDealDiscount(product);


    const wished =

        isDealWishlisted(product.id);


    const rating =

        Number(product.rating) || 0;


    const reviews =

        Number(product.reviews) || 0;


    const category =

        dealCategoryLabel(product.category);


    const stars =

        "★".repeat(

            Math.max(

                1,

                Math.round(rating)

            )

        );


    return `

        <article

            class="deal-product-card"

            data-product-id="${dealEscape(product.id)}"

        >

            <div class="deal-product-media">


                <span class="deal-discount-badge">

                    -${discount}% OFF

                </span>


                <button

                    type="button"

                    class="deal-wishlist-btn ${

                        wished

                            ? "is-wishlisted"

                            : ""

                    }"

                    data-deal-wishlist="${dealEscape(product.id)}"

                    aria-label="Wishlist"

                >

                    <i class="fa-${

                        wished

                            ? "solid"

                            : "regular"

                    } fa-heart"></i>

                </button>


                <div class="deal-product-placeholder">

                    <div class="deal-placeholder-icon">

                        <i class="fa-solid fa-tags"></i>

                    </div>

                    <span>

                        ${dealEscape(

                            product.brand ||

                            category

                        )}

                    </span>

                </div>


            </div>


            <div class="deal-product-content">


                <div class="deal-product-meta">

                    <span>

                        ${dealEscape(category)}

                    </span>


                    <span>

                        ${dealEscape(

                            product.location ||

                            "Nigeria"

                        )}

                    </span>

                </div>


                <h3>

                    ${dealEscape(product.title)}

                </h3>


                <div class="deal-rating">

                    <span class="deal-stars">

                        ${stars}

                    </span>


                    <strong>

                        ${rating.toFixed(1)}

                    </strong>


                    <span>

                        (${reviews.toLocaleString()})

                    </span>

                </div>


                <div class="deal-price-row">


                    <strong class="deal-current-price">

                        ${dealMoney(product.price)}

                    </strong>


                    <span class="deal-old-price">

                        ${dealMoney(product.oldPrice)}

                    </span>

                </div>


                <div class="deal-saving">

                    Save

                    ${dealMoney(

                        Number(product.oldPrice) -

                        Number(product.price)

                    )}

                </div>


                <div class="deal-product-footer">


                    <button

                        type="button"

                        class="deal-add-cart"

                        data-deal-cart="${dealEscape(product.id)}"

                    >

                        <i class="fa-solid fa-cart-plus"></i>

                        Add to Cart

                    </button>


                    <button

                        type="button"

                        class="deal-view-product"

                        data-deal-view="${dealEscape(product.id)}"

                        aria-label="View product"

                    >

                        <i class="fa-solid fa-eye"></i>

                    </button>


                </div>


            </div>

        </article>

    `;

}


/*========================================================*
 * RENDER DEALS
 *========================================================*/

function renderDeals() {

    applyDealFilters();


    const grid = document.getElementById(

        "dealProductsGrid"

    );


    const emptyState = document.getElementById(

        "dealEmptyState"

    );


    if (!grid) {

        return;

    }


    const total =

        dealState.filteredProducts.length;


    const start =

        (dealState.currentPage - 1) *

        DEAL_CONFIG.productsPerPage;


    const products =

        dealState.filteredProducts.slice(

            start,

            start + DEAL_CONFIG.productsPerPage

        );


    /*
     * EMPTY STATE
     */

    if (!products.length) {

        grid.innerHTML = "";

        if (emptyState) {

            emptyState.hidden = false;

        }

    }

    else {

        grid.innerHTML =

            products

                .map(renderDealCard)

                .join("");


        if (emptyState) {

            emptyState.hidden = true;

        }

    }


    updateDealResultCount();

    renderDealPagination();

    updateDealStats();

}


/*========================================================*
 * RESULT COUNT
 *========================================================*/

function updateDealResultCount() {

    const element = document.getElementById(

        "dealResultsCount"

    );


    if (!element) {

        return;

    }


    const total =

        dealState.filteredProducts.length;


    if (!total) {

        element.textContent =

            "No deals found";

        return;

    }


    const start =

        (dealState.currentPage - 1) *

        DEAL_CONFIG.productsPerPage + 1;


    const end = Math.min(

        dealState.currentPage *

            DEAL_CONFIG.productsPerPage,

        total

    );


    element.textContent =

        `Showing ${start}–${end} of ${total} Deals`;

}


/*========================================================*
 * DEAL STATISTICS
 *========================================================*/

function updateDealStats() {

    const dealCount =

        document.getElementById("dealCount");


    if (dealCount) {

        dealCount.textContent =

            dealState.products.length;

    }


    const stores =

        new Set(

            dealState.products

                .map(product => product.seller)

                .filter(Boolean)

        );


    const storeCount =

        document.getElementById(

            "dealStoreCount"

        );


    if (storeCount) {

        storeCount.textContent =

            stores.size;

    }

}


/*========================================================*
 * PAGINATION
 *========================================================*/

function renderDealPagination() {

    const container =

        document.getElementById(

            "dealsPagination"

        );


    if (!container) {

        return;

    }


    const pages = Math.max(

        1,

        Math.ceil(

            dealState.filteredProducts.length /

            DEAL_CONFIG.productsPerPage

        )

    );


    if (pages <= 1) {

        container.innerHTML = "";

        return;

    }


    let html = `

        <button

            type="button"

            class="deal-page-btn"

            data-deal-page="prev"

            ${

                dealState.currentPage === 1

                    ? "disabled"

                    : ""

            }

        >

            <i class="fa-solid fa-chevron-left"></i>

        </button>

    `;


    for (let i = 1; i <= pages; i++) {

        html += `

            <button

                type="button"

                class="deal-page-btn ${

                    i === dealState.currentPage

                        ? "active"

                        : ""

                }"

                data-deal-page="${i}"

            >

                ${i}

            </button>

        `;

    }


    html += `

        <button

            type="button"

            class="deal-page-btn"

            data-deal-page="next"

            ${

                dealState.currentPage === pages

                    ? "disabled"

                    : ""

            }

        >

            <i class="fa-solid fa-chevron-right"></i>

        </button>

    `;


    container.innerHTML = html;

}


/*========================================================*
 * SEARCH
 *========================================================*/

function setupDealSearch() {

    const dealSearch =

        document.getElementById(

            "dealSearch"

        );


    if (!dealSearch) {

        return;

    }


    dealSearch.addEventListener(

        "input",

        () => {

            const value =

                dealSearch.value;


            dealState.searchTerm =

                value;


            /*
             * Sync with navbar searches
             */

            [

                "navbarSearch",

                "shopSearch",

                "productSearch"

            ].forEach(id => {

                const input =

                    document.getElementById(id);


                if (input) {

                    input.value = value;

                }

            });


            dealState.currentPage = 1;

            renderDeals();

        }

    );

}


/*========================================================*
 * NAVBAR SEARCH SYNC
 *========================================================*/

function setupNavbarDealSearch() {

    const ids = [

        "navbarSearch",

        "shopSearch",

        "productSearch",

        "dealSearch"

    ];


    document.addEventListener(

        "input",

        event => {

            const input =

                event.target;


            if (!input.id ||

                !ids.includes(input.id)) {

                return;

            }


            const value =

                input.value;


            ids.forEach(id => {

                const other =

                    document.getElementById(id);


                if (

                    other &&

                    other !== input

                ) {

                    other.value = value;

                }

            });


            dealState.searchTerm = value;


            if (

                document.getElementById(

                    "dealProductsGrid"

                )

            ) {

                dealState.currentPage = 1;

                renderDeals();

            }

        }

    );

}


/*========================================================*
 * CATEGORY FILTER
 *========================================================*/

function setupDealCategory() {

    const select =

        document.getElementById(

            "dealCategoryFilter"

        );


    if (!select) {

        return;

    }


    select.addEventListener(

        "change",

        () => {

            dealState.category =

                select.value;


            dealState.currentPage = 1;

            renderDeals();

        }

    );

}


/*========================================================*
 * SORT
 *========================================================*/

function setupDealSort() {

    const select =

        document.getElementById(

            "dealSort"

        );


    if (!select) {

        return;

    }


    select.addEventListener(

        "change",

        () => {

            dealState.sortBy =

                select.value;


            dealState.currentPage = 1;

            renderDeals();

        }

    );

}


/*========================================================*
 * CLEAR FILTERS
 *========================================================*/

function clearDealFilters() {

    dealState.searchTerm = "";

    dealState.category = "all";

    dealState.sortBy = "discount";

    dealState.currentPage = 1;


    const search =

        document.getElementById(

            "dealSearch"

        );


    if (search) {

        search.value = "";

    }


    [

        "navbarSearch",

        "shopSearch",

        "productSearch"

    ].forEach(id => {

        const input =

            document.getElementById(id);


        if (input) {

            input.value = "";

        }

    });


    const category =

        document.getElementById(

            "dealCategoryFilter"

        );


    if (category) {

        category.value = "all";

    }


    const sort =

        document.getElementById(

            "dealSort"

        );


    if (sort) {

        sort.value = "discount";

    }


    renderDeals();

}


/*========================================================*
 * CLICK EVENTS
 *========================================================*/

function setupDealEvents() {

    document.addEventListener(

        "click",

        event => {


            /*
             * ADD TO CART
             */

            const cartButton =

                event.target.closest(

                    "[data-deal-cart]"

                );


            if (cartButton) {

                event.preventDefault();

                event.stopPropagation();


                addDealToCart(

                    cartButton.dataset.dealCart

                );


                return;

            }


            /*
             * WISHLIST
             */

            const wishlistButton =

                event.target.closest(

                    "[data-deal-wishlist]"

                );


            if (wishlistButton) {

                event.preventDefault();

                event.stopPropagation();


                toggleDealWishlist(

                    wishlistButton

                        .dataset

                        .dealWishlist

                );


                return;

            }


            /*
             * VIEW PRODUCT
             */

            const viewButton =

                event.target.closest(

                    "[data-deal-view]"

                );


            if (viewButton) {

                event.preventDefault();


                const id =

                    viewButton.dataset

                        .dealView;


                openDealProduct(id);

                return;

            }


            /*
             * PAGINATION
             */

            const pageButton =

                event.target.closest(

                    "[data-deal-page]"

                );


            if (pageButton) {

                event.preventDefault();


                const action =

                    pageButton.dataset

                        .dealPage;


                const pages = Math.max(

                    1,

                    Math.ceil(

                        dealState.filteredProducts.length /

                        DEAL_CONFIG.productsPerPage

                    )

                );


                if (action === "prev") {

                    if (

                        dealState.currentPage > 1

                    ) {

                        dealState.currentPage--;

                    }

                }

                else if (action === "next") {

                    if (

                        dealState.currentPage < pages

                    ) {

                        dealState.currentPage++;

                    }

                }

                else {

                    dealState.currentPage =

                        Number(action);

                }


                renderDeals();


                document

                    .getElementById(

                        "dealProducts"

                    )

                    ?.scrollIntoView({

                        behavior: "smooth",

                        block: "start"

                    });


                return;

            }


            /*
             * CLEAR FILTERS
             */

            if (

                event.target.closest(

                    "#clearDealFilters"

                )

            ) {

                clearDealFilters();

            }

        }

    );

}


/*========================================================*
 * OPEN PRODUCT
 *========================================================*/

function openDealProduct(id) {

    const product =

        dealState.products.find(

            item =>

                String(item.id) ===

                String(id)

        );


    if (!product) {

        return;

    }


    localStorage.setItem(

        "fashSelectedProduct",

        product.id

    );


    window.location.href =

        `product.html?id=${encodeURIComponent(

            product.id

        )}`;

}


/*========================================================*
 * FLASH COUNTDOWN
 *========================================================*/

function setupFlashCountdown() {

    const countdown =

        document.getElementById(

            "flashCountdown"

        );


    if (!countdown) {

        return;

    }


    let endTime =

        Number(

            localStorage.getItem(

                DEAL_CONFIG.storageKeys.countdown

            )

        );


    /*
     * Create a 12-hour countdown
     * if one doesn't already exist.
     */

    if (

        !endTime ||

        endTime <= Date.now()

    ) {

        endTime =

            Date.now() +

            (12 * 60 * 60 * 1000);


        localStorage.setItem(

            DEAL_CONFIG.storageKeys.countdown,

            String(endTime)

        );

    }


    function updateCountdown() {

        let remaining =

            endTime - Date.now();


        if (remaining <= 0) {

            endTime =

                Date.now() +

                (12 * 60 * 60 * 1000);


            localStorage.setItem(

                DEAL_CONFIG.storageKeys.countdown,

                String(endTime)

            );


            remaining =

                endTime - Date.now();

        }


        const totalSeconds =

            Math.floor(

                remaining / 1000

            );


        const hours =

            Math.floor(

                totalSeconds / 3600

            );


        const minutes =

            Math.floor(

                (totalSeconds % 3600) / 60

            );


        const seconds =

            totalSeconds % 60;


        const hourElement =

            document.getElementById(

                "flashHours"

            );


        const minuteElement =

            document.getElementById(

                "flashMinutes"

            );


        const secondElement =

            document.getElementById(

                "flashSeconds"

            );


        if (hourElement) {

            hourElement.textContent =

                String(hours).padStart(2, "0");

        }


        if (minuteElement) {

            minuteElement.textContent =

                String(minutes).padStart(2, "0");

        }


        if (secondElement) {

            secondElement.textContent =

                String(seconds).padStart(2, "0");

        }

    }


    updateCountdown();


    clearInterval(

        window.__fashDealCountdown

    );


    window.__fashDealCountdown =

        setInterval(

            updateCountdown,

            1000

        );

}


/*========================================================*
 * STORAGE UPDATES
 *========================================================*/

function setupDealStorageSync() {

    window.addEventListener(

        "storage",

        event => {

            if (

                event.key ===

                DEAL_CONFIG.storageKeys.cart

            ) {

                updateDealCartCounter();

            }


            if (

                event.key ===

                DEAL_CONFIG.storageKeys.wishlist

            ) {

                updateDealWishlistCounter();

                renderDeals();

            }

        }

    );


    window.addEventListener(

        "fash:cart-updated",

        updateDealCartCounter

    );


    window.addEventListener(

        "fash:wishlist-updated",

        () => {

            updateDealWishlistCounter();

            renderDeals();

        }

    );

}


/*========================================================*
 * INITIALIZE
 *========================================================*/

function setupDeals() {

    /*
     * Only run on Deals page
     */

    if (

        !document.getElementById(

            "dealProductsGrid"

        )

    ) {

        return;

    }


    loadDealProducts();


    setupDealSearch();

    setupNavbarDealSearch();

    setupDealCategory();

    setupDealSort();

    setupDealEvents();

    setupDealStorageSync();

    setupFlashCountdown();


    renderDeals();


    updateDealCartCounter();

    updateDealWishlistCounter();


    /*
     * Public API
     */

    window.FASHDeals = {

        products: dealState.products,

        refresh: renderDeals,

        clearFilters: clearDealFilters,

        addToCart: addDealToCart,

        toggleWishlist: toggleDealWishlist

    };

}


/*========================================================*
 * START
 *========================================================*/

if (

    document.readyState === "loading"

) {

    document.addEventListener(

        "DOMContentLoaded",

        setupDeals,

        { once: true }

    );

}

else {

    setupDeals();

}