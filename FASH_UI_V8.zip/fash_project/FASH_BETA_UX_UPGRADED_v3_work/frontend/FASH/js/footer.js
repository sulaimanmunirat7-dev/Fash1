
/* FASH shared elite footer loader */
document.addEventListener("DOMContentLoaded", function () {
    const target = document.getElementById("footer");
    if (!target) return;
    const inPages = window.location.pathname.includes("/pages/");
    const componentPath = inPages ? "../components/footer.html" : "components/footer.html";
    fetch(componentPath, {cache:"no-cache"})
      .then(r => { if(!r.ok) throw new Error("Footer failed: "+r.status); return r.text(); })
      .then(html => {
        target.innerHTML = html;
        const home = target.querySelector("[data-footer-home]");
        if (home) home.href = inPages ? "../index.html" : "index.html";
        target.querySelectorAll("a[href]").forEach(a => {
          const href=a.getAttribute("href");
          if(!href || href==="#" || /^(https?:|mailto:|tel:|javascript:)/i.test(href)) return;
          const m=href.match(/^pages\/(.+)$/i);
          if(m) a.href = inPages ? m[1] : href;
        });
        const img=target.querySelector('img[src^="assets/"]');
        if(img && inPages) img.src="../"+img.getAttribute("src");
        if(!document.getElementById("fash-footer-css")){
          const link=document.createElement("link"); link.id="fash-footer-css"; link.rel="stylesheet"; link.href=inPages?"../css/footer.css":"css/footer.css"; document.head.appendChild(link);
        }
        const form=target.querySelector(".fash-footer-form");
        form?.addEventListener("submit",e=>e.preventDefault());
        console.log("FASH elite footer loaded.");
      })
      .catch(err => console.error("FASH footer error:",err));
});
