document.addEventListener("DOMContentLoaded",async()=>{
 try{
  // BUGFIX: "fashAuthToken" is never set anywhere in the app (the real key is
  // "fash_token" / "fash_user"), so this sync silently never ran for anyone.
  if(!window.FASH_API||!localStorage.getItem("fash_user"))return;
  const d=await FASH_API.api("/api/customers"); localStorage.setItem("fash_live_customers",JSON.stringify(d.customers||[]));
 }catch(e){console.warn("Customer sync unavailable",e)}
});