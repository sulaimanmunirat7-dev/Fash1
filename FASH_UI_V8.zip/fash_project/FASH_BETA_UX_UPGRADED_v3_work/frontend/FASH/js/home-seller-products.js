(function(){
  "use strict";
  const API = window.FASH_API_BASE || "http://localhost:5000";
  const grid = document.getElementById("liveSellerProductsGrid");
  const promotedGrid = document.getElementById("fashPromotedProductsGrid");
  if (!grid && !promotedGrid) return;
  const money = v => `₦${Number(v||0).toLocaleString("en-NG")}`;
  const esc = v => String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  function renderProducts(target, products, emptyText){
    if(!target) return;
    if(!products.length){target.innerHTML=`<div class="live-products-state">${emptyText}</div>`;return;}
    target.innerHTML=products.map(p=>`<article class="live-product-card">
      <a href="pages/product.html?id=${encodeURIComponent(p.id)}" class="live-product-image"><img src="${esc(p.image_url||"assets/images/product-placeholder.jpg")}" alt="${esc(p.name)}" loading="lazy"></a>
      <div class="live-product-info"><div class="live-product-category">${esc(p.category)}</div><h3 class="live-product-title">${esc(p.name)}</h3><div class="live-product-price">${money(p.price)}</div><div class="live-product-seller">Sold by ${esc(p.seller_name||"FASH Seller")}</div></div>
    </article>`).join("");
  }
  async function load(){
    try{
      const [allRes, featuredRes] = await Promise.all([
        fetch(`${API}/api/products`,{headers:{Accept:"application/json"}}),
        fetch(`${API}/api/products/featured`,{headers:{Accept:"application/json"}})
      ]);
      if(!allRes.ok) throw new Error("Could not load seller products");
      const allData=await allRes.json();
      renderProducts(grid,(allData.products||[]).slice(0,8),"New seller products will appear here after they are approved.");
      if(featuredRes.ok){
        const featuredData=await featuredRes.json();
        renderProducts(promotedGrid,(featuredData.products||[]).slice(0,8),"No promoted products yet.");
      } else if(promotedGrid){
        promotedGrid.innerHTML='<div class="live-products-state">Featured products are temporarily unavailable.</div>';
      }
    }catch(e){
      console.warn("FASH HOME PRODUCTS:",e);
      if(grid) grid.innerHTML='<div class="live-products-state">Seller products are temporarily unavailable. Please try again later.</div>';
      if(promotedGrid) promotedGrid.innerHTML='<div class="live-products-state">Featured products are temporarily unavailable.</div>';
    }
  }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",load); else load();
})();
