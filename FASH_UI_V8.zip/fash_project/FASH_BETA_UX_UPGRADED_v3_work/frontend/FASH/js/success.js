/*==================================================
SUCCESS PAGE
PART 1
LOAD ORDER
==================================================*/

document.addEventListener("DOMContentLoaded", () => {

    /*==============================
    ELEMENTS
    ==============================*/

    const orderItems =
        document.querySelector(".order-items");

    const subtotal =
        document.getElementById("subtotal");

    const shipping =
        document.getElementById("shipping");

    const tax =
        document.getElementById("tax");

    const discount =
        document.getElementById("discount");

    const total =
        document.getElementById("total");

    const orderNumber =
        document.getElementById("order-number");

    /*==============================
    LOAD ORDER
    ==============================*/

    const order =
        JSON.parse(localStorage.getItem("lastOrder"));

    if(!order){

        window.location.href = "shop.html";

        return;

    }

    /*==============================
    GENERATE ORDER NUMBER
    ==============================*/

    const randomNumber =
        Math.floor(100000 + Math.random() * 900000);

    orderNumber.textContent =
        "#FASH-" + randomNumber;

    /*==============================
    FORMAT MONEY
    ==============================*/

    function money(value){

        return "$" + value.toFixed(2);

    }

    /*==============================
    DISPLAY PRODUCTS
    ==============================*/

    order.items.forEach(item=>{

        orderItems.innerHTML += `

        <div class="order-item">

            <img
                src="${item.image}"
                alt="${item.name}">

            <div class="order-item-info">

                <h4>

                    ${item.name}

                </h4>

                <p>

                    Qty: ${item.quantity}

                </p>

            </div>

            <div class="order-item-price">

                ${money(item.price * item.quantity)}

            </div>

        </div>

        `;

    });
    
        /*==============================
    DISPLAY TOTALS
    ==============================*/

    subtotal.textContent =
        money(order.subtotal);

    shipping.textContent =
        order.shipping === 0
        ? "FREE"
        : money(order.shipping);

    tax.textContent =
        money(order.tax);

    discount.textContent =
        "-" + money(order.discount);

    total.textContent =
        money(order.total);

    /*==============================
    CUSTOMER INFORMATION
    ==============================*/

    document.getElementById("customer-name").textContent =
        order.customer.firstName + " " + order.customer.lastName;

    document.getElementById("customer-email").textContent =
        order.customer.email;

    document.getElementById("customer-phone").textContent =
        order.customer.phone;

    document.getElementById("customer-address").textContent =
        `${order.customer.address}, ${order.customer.city}, ${order.customer.state}, ${order.customer.country}`;

    /*==============================
    TRACK ORDER
    ==============================*/

    const trackBtn =
        document.querySelector(".track-btn");

    if(trackBtn){

        trackBtn.addEventListener("click",(e)=>{

            e.preventDefault();

            alert(
                "Order tracking will be available once your order has been shipped."
            );

        });

    }

    /*==============================
    CLEANUP
    ==============================*/

    localStorage.removeItem("lastOrder");

});