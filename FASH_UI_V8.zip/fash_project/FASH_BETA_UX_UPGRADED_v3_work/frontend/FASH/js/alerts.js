/*========================================================
FASH ALERTS
INDIVIDUAL READ / DELETE
OPENING THE ALERT PAGE DOES NOT MARK ANYTHING READ.
========================================================*/

"use strict";

function formatFashAlertTime(timestamp) {

    const date = new Date(timestamp);

    if (Number.isNaN(date.getTime())) return "";

    return date.toLocaleString("en-NG", {
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "numeric",
        minute: "2-digit"
    });

}

function alertIcon(type) {

    return {
        cart: "fa-cart-shopping",
        wishlist: "fa-heart",
        deal: "fa-tags",
        order: "fa-box",
        info: "fa-circle-info"
    }[type] || "fa-circle-info";

}

function escapeFashAlert(value) {

    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");

}

function getAlertProduct(alert) {

    const products =
        window.FASHShop &&
        Array.isArray(window.FASHShop.products)
            ? window.FASHShop.products
            : [];

    return products.find(
        product =>
            String(product.id) ===
            String(alert.productId)
    ) || null;

}

function getAlertTypeName(type) {

    if (type === "cart") return "CART";
    if (type === "wishlist") return "WISHLIST";
    return "FASH ALERT";

}

function ensureAlertDetailModal() {

    let modal =
        document.getElementById("fashAlertDetailModal");

    if (modal) return modal;

    modal = document.createElement("div");

    modal.id = "fashAlertDetailModal";
    modal.className = "fash-alert-detail-modal";

    modal.innerHTML = `
        <div class="fash-alert-detail-backdrop" data-alert-close></div>

        <section
            class="fash-alert-detail-card"
            role="dialog"
            aria-modal="true"
            aria-labelledby="fashAlertDetailTitle">

            <button
                type="button"
                class="fash-alert-detail-close"
                data-alert-close
                aria-label="Close alert">
                <i class="fa-solid fa-xmark"></i>
            </button>

            <div id="fashAlertDetailIcon"
                 class="fash-alert-detail-icon"></div>

            <div class="fash-alert-detail-body">

                <span id="fashAlertDetailType"
                      class="fash-alert-detail-type"></span>

                <h2 id="fashAlertDetailTitle"></h2>

                <span id="fashAlertDetailTime"
                      class="fash-alert-detail-time"></span>

                <div id="fashAlertDetailProduct"
                     class="fash-alert-detail-product"
                     hidden></div>

                <p id="fashAlertDetailMessage"></p>

                <div id="fashAlertDetailActions"
                     class="fash-alert-detail-actions"></div>

            </div>
        </section>
    `;

    document.body.appendChild(modal);

    modal.addEventListener("click", function (event) {

        if (event.target.closest("[data-alert-close]")) {
            modal.classList.remove("show");
            return;
        }

        const action =
            event.target.closest("[data-alert-action]");

        if (!action) return;

        const value = action.dataset.alertAction;

        if (value === "mark-read") {

            const id = modal.dataset.alertId;

            if (window.FASHNotifications) {
                window.FASHNotifications.markRead(id);
            }

            renderFashNotificationsPage();
            openFashAlertDetail(id);
            return;

        }

        if (value === "delete") {

            const id = modal.dataset.alertId;

            if (window.FASHNotifications) {
                window.FASHNotifications.remove(id);
            }

            modal.classList.remove("show");
            renderFashNotificationsPage();
            return;

        }

        if (value) {
            window.location.href = value;
        }

    });

    document.addEventListener("keydown", function (event) {

        if (
            event.key === "Escape" &&
            modal.classList.contains("show")
        ) {
            modal.classList.remove("show");
        }

    });

    return modal;

}

function openFashAlertDetail(alertId) {

    const alerts =
        window.FASHNotifications
            ? window.FASHNotifications.get()
            : [];

    const alert =
        alerts.find(
            item =>
                String(item.id) ===
                String(alertId)
        );

    if (!alert) return;

    /* IMPORTANT: opening DOES NOT mark it as read. */

    const modal = ensureAlertDetailModal();

    modal.dataset.alertId = alert.id;

    const icon =
        document.getElementById("fashAlertDetailIcon");

    const type =
        document.getElementById("fashAlertDetailType");

    const title =
        document.getElementById("fashAlertDetailTitle");

    const time =
        document.getElementById("fashAlertDetailTime");

    const productBox =
        document.getElementById("fashAlertDetailProduct");

    const message =
        document.getElementById("fashAlertDetailMessage");

    const actions =
        document.getElementById("fashAlertDetailActions");

    icon.className =
        `fash-alert-detail-icon ${alert.type || "info"}`;

    icon.innerHTML =
        `<i class="fa-solid ${alertIcon(alert.type)}"></i>`;

    type.textContent =
        getAlertTypeName(alert.type);

    title.textContent =
        alert.title;

    time.textContent =
        formatFashAlertTime(alert.time);

    message.textContent =
        alert.message;

    const product = getAlertProduct(alert);

    if (product) {

        productBox.hidden = false;

        productBox.innerHTML = `
            <div class="fash-alert-product-image">
                <img
                    src="${escapeFashAlert(product.image || "../assets/images/logos/Logo.png")}"
                    alt="${escapeFashAlert(product.title)}"
                    onerror="this.src='../assets/images/logos/Logo.png'">
            </div>

            <div>
                <strong>${escapeFashAlert(product.title)}</strong>
                <span>
                    ${new Intl.NumberFormat("en-NG", {
                        style: "currency",
                        currency: "NGN",
                        maximumFractionDigits: 0
                    }).format(Number(product.price) || 0)}
                </span>
            </div>
        `;

    } else {

        productBox.hidden = true;
        productBox.innerHTML = "";

    }

    actions.innerHTML = "";

    if (!alert.read) {

        actions.innerHTML += `
            <button
                type="button"
                class="alert-detail-primary"
                data-alert-action="mark-read">
                <i class="fa-solid fa-check"></i>
                Mark as read
            </button>
        `;

    }

    actions.innerHTML += `
        <button
            type="button"
            class="alert-detail-danger"
            data-alert-action="delete">
            <i class="fa-solid fa-trash"></i>
            Delete
        </button>
    `;

    if (alert.type === "cart") {

        actions.innerHTML += `
            <button
                type="button"
                class="alert-detail-secondary"
                data-alert-action="cart.html">
                <i class="fa-solid fa-cart-shopping"></i>
                View Cart
            </button>
        `;

    }

    if (alert.type === "wishlist") {

        actions.innerHTML += `
            <button
                type="button"
                class="alert-detail-secondary"
                data-alert-action="wishlist.html">
                <i class="fa-solid fa-heart"></i>
                View Wishlist
            </button>
        `;

    }

    modal.classList.add("show");

}

function renderFashNotificationsPage() {

    const list =
        document.getElementById("alertsList");

    const empty =
        document.getElementById("alertsEmpty");

    const unreadText =
        document.getElementById("alertsUnreadText");

    if (!list) return;

    const alerts =
        window.FASHNotifications
            ? window.FASHNotifications.get()
            : [];

    const unread =
        alerts.filter(
            alert => !alert.read
        ).length;

    if (unreadText) {

        unreadText.textContent =
            unread === 1
                ? "1 unread alert"
                : `${unread} unread alerts`;

    }

    if (!alerts.length) {

        list.innerHTML = "";

        if (empty) empty.hidden = false;

        return;

    }

    if (empty) empty.hidden = true;

    list.innerHTML =
        alerts.map(function (alert) {

            return `
                <article
                    class="alert-item ${alert.read ? "read" : "unread"}"
                    data-alert-id="${escapeFashAlert(alert.id)}">

                    <div class="alert-icon ${alert.type || "info"}">
                        <i class="fa-solid ${alertIcon(alert.type)}"></i>
                    </div>

                    <div class="alert-content"
                         data-alert-open="${escapeFashAlert(alert.id)}">

                        <h4>${escapeFashAlert(alert.title)}</h4>

                        <p>${escapeFashAlert(alert.message)}</p>

                        <span class="alert-time">
                            ${formatFashAlertTime(alert.time)}
                        </span>

                    </div>

                    <div class="alert-item-actions">

                        ${
                            alert.read
                                ? `
                                <button
                                    type="button"
                                    class="alert-row-action"
                                    data-alert-action-row="unread"
                                    data-alert-id="${escapeFashAlert(alert.id)}"
                                    title="Mark as unread">
                                    <i class="fa-solid fa-envelope"></i>
                                </button>
                                `
                                : `
                                <button
                                    type="button"
                                    class="alert-row-action"
                                    data-alert-action-row="read"
                                    data-alert-id="${escapeFashAlert(alert.id)}"
                                    title="Mark as read">
                                    <i class="fa-solid fa-check"></i>
                                </button>
                                `
                        }

                        <button
                            type="button"
                            class="alert-row-action danger"
                            data-alert-action-row="delete"
                            data-alert-id="${escapeFashAlert(alert.id)}"
                            title="Delete alert">
                            <i class="fa-solid fa-trash"></i>
                        </button>

                    </div>

                    ${
                        alert.read
                            ? ""
                            : `<span class="alert-unread-dot"></span>`
                    }

                </article>
            `;

        }).join("");

}

function setupFashNotificationsPage() {

    renderFashNotificationsPage();

    const markAll =
        document.getElementById("markNotificationsRead");

    if (markAll) {

        markAll.addEventListener("click", function () {

            if (window.FASHNotifications) {
                window.FASHNotifications.markAllRead();
            }

            renderFashNotificationsPage();

        });

    }

    const clear =
        document.getElementById("clearNotifications");

    if (clear) {

        clear.addEventListener("click", function () {

            if (window.FASHNotifications) {
                window.FASHNotifications.clear();
            }

            renderFashNotificationsPage();

        });

    }

    document.addEventListener("click", function (event) {

        const rowAction =
            event.target.closest("[data-alert-action-row]");

        if (rowAction) {

            event.stopPropagation();

            const id =
                rowAction.dataset.alertId;

            const action =
                rowAction.dataset.alertActionRow;

            if (!window.FASHNotifications) return;

            if (action === "read") {
                window.FASHNotifications.markRead(id);
            }

            if (action === "unread") {
                window.FASHNotifications.markUnread(id);
            }

            if (action === "delete") {
                window.FASHNotifications.remove(id);
            }

            renderFashNotificationsPage();

            return;

        }

        const content =
            event.target.closest("[data-alert-open]");

        if (content) {

            openFashAlertDetail(
                content.dataset.alertOpen
            );

        }

    });

    window.addEventListener(
        "fash:alerts-updated",
        renderFashNotificationsPage
    );

}

if (document.readyState === "loading") {

    document.addEventListener(
        "DOMContentLoaded",
        setupFashNotificationsPage,
        { once: true }
    );

} else {

    setupFashNotificationsPage();

}


/* Keep the alert badge synchronized after the shared navbar loads. */
window.addEventListener(
    "fash:navbar-ready",
    function () {
        if (window.FASHNotifications) {
            window.FASHNotifications.refresh();
        }
        renderFashNotificationsPage();
    }
);

