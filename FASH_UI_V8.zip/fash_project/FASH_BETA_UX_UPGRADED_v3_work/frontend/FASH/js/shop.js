
window.addEventListener("fash:navbar-ready", function () {
    updateCartCounter();
    updateWishlistCounter();
});

/*========================================================
 FASH MARKETPLACE — SHOP.JS
 CLEAN PREMIUM SHOP BUILD
 Uses the existing shop.html IDs/classes.
========================================================*/
"use strict";

const SHOP_CONFIG = {
    productsPerPage: 9,
    currencyLocale: "en-NG",
    currency: "NGN",
    storageKeys: { cart: "fash_cart", wishlist: "fash_wishlist", recentlyViewed: "fash_recently_viewed" }
};

async function loadFashDatabaseProducts() {
    try {
        const apiBase = String(window.FASH_API_BASE || "http://localhost:5000").replace(/\/$/, "");
        const response = await fetch(`${apiBase}/api/products`, {
            headers: { "Accept": "application/json" }
        });
        if (!response.ok) return [];
        const data = await response.json();
        return (data.products || []).map(p => ({
            id: p.id,
            title: p.name,
            category: String(p.category || "").toLowerCase(),
            subcategory: "",
            brand: "FASH Seller",
            price: Number(p.price) || 0,
            oldPrice: null,
            rating: 0,
            reviews: 0,
            popularity: 50,
            badge: "New",
            image: p.image_url || "../assets/images/product-placeholder.jpg",
            gallery: [p.image_url || "../assets/images/product-placeholder.jpg"],
            description: p.description || "Product listed on FASH Marketplace.",
            stock: Number(p.stock) || 0,
            seller: p.seller_name || "FASH Seller",
            location: "Nigeria",
            delivery: "1–3 Days",
            featured: Boolean(p.is_featured),
            flashSale: false,
            tags: [String(p.category || "").toLowerCase()]
        }));
    } catch (error) {
        console.warn("FASH database products could not be loaded:", error);
        return [];
    }
}

const shopProducts = [

    /*====================================================
      EXISTING PRODUCT 1
    ====================================================*/

    {
        id: "FASH001",

        title: "ASUS ROG Strix G16 Gaming Laptop",

        category: "gaming",

        subcategory: "laptops",

        brand: "ASUS",

        price: 950000,

        oldPrice: 1150000,

        rating: 4.9,

        reviews: 328,

        popularity: 98,

        badge: "Best Seller",

        image: "../assets/images/products/laptop.png",

        gallery: [
            "../assets/images/products/laptop.png",
            "../assets/images/products/laptop.png"
        ],

        description:
            "High-performance ASUS ROG Strix G16 gaming laptop built for gaming, productivity and demanding applications.",

        stock: 8,

        seller: "FASH Tech Store",

        location: "Lagos",

        delivery: "1–3 Days",

        featured: true,

        flashSale: true,

        tags: [
            "gaming",
            "laptop",
            "asus",
            "computer",
            "electronics"
        ]

    },


    /*====================================================
      EXISTING PRODUCT 2
    ====================================================*/

    {
        id: "FASH002",

        title: "Apple MacBook Air M4",

        category: "electronics",

        subcategory: "laptops",

        brand: "Apple",

        price: 1850000,

        oldPrice: 2050000,

        rating: 4.9,

        reviews: 412,

        popularity: 97,

        badge: "New",

        image: "../assets/images/products/macbook.png",

        gallery: [
            "../assets/images/products/macbook.png",
            "../assets/images/products/macbook.png"
        ],

        description:
            "Apple MacBook Air powered by the M4 chip with a premium lightweight design and excellent everyday performance.",

        stock: 14,

        seller: "Apple Premium Store",

        location: "Lagos",

        delivery: "1–3 Days",

        featured: true,

        flashSale: false,

        tags: [
            "apple",
            "macbook",
            "laptop",
            "computer",
            "electronics"
        ]

    },


    /*====================================================
      EXISTING PRODUCT 3
    ====================================================*/

    {
        id: "FASH003",

        title: "Dell XPS 15",

        category: "electronics",

        subcategory: "laptops",

        brand: "Dell",

        price: 1420000,

        oldPrice: 1600000,

        rating: 4.8,

        reviews: 267,

        popularity: 94,

        badge: "Popular",

        image: "../assets/images/products/dell.png",

        gallery: [
            "../assets/images/products/dell.png",
            "../assets/images/products/dell.png"
        ],

        description:
            "Premium Dell XPS 15 laptop designed for professionals, creators and demanding everyday workloads.",

        stock: 11,

        seller: "Dell Official Store",

        location: "Lagos",

        delivery: "1–3 Days",

        featured: true,

        flashSale: false,

        tags: [
            "dell",
            "xps",
            "laptop",
            "computer",
            "electronics"
        ]

    },


    /*====================================================
      EXISTING PRODUCT 4
    ====================================================*/

    {
        id: "FASH004",

        title: "Samsung Galaxy S25 Ultra",

        category: "phones",

        subcategory: "smartphones",

        brand: "Samsung",

        price: 1350000,

        oldPrice: 1500000,

        rating: 4.9,

        reviews: 521,

        popularity: 99,

        badge: "Top Rated",

        image: "../assets/images/products/phone.png",

        gallery: [
            "../assets/images/products/phone.png",
            "../assets/images/products/phone.png"
        ],

        description:
            "Premium Samsung Galaxy smartphone with flagship performance, advanced cameras and a stunning display.",

        stock: 17,

        seller: "Samsung Official Store",

        location: "Lagos",

        delivery: "1–3 Days",

        featured: true,

        flashSale: true,

        tags: [
            "samsung",
            "galaxy",
            "phone",
            "smartphone",
            "electronics"
        ]

    },


    /*====================================================
      EXISTING PRODUCT 5
    ====================================================*/

    {
        id: "FASH005",

        title: "Premium Leather Sneakers",

        category: "fashion",

        subcategory: "shoes",

        brand: "FASH Select",

        price: 65000,

        oldPrice: 85000,

        rating: 4.7,

        reviews: 186,

        popularity: 91,

        badge: "Sale",

        image: "../assets/images/products/shoes.png",

        gallery: [
            "../assets/images/products/shoes.png",
            "../assets/images/products/shoes.png"
        ],

        description:
            "Premium everyday sneakers combining comfort, durability and a modern fashion-forward design.",

        stock: 23,

        seller: "FASH Fashion Hub",

        location: "Lagos",

        delivery: "1–3 Days",

        featured: true,

        flashSale: true,

        tags: [
            "shoes",
            "sneakers",
            "fashion",
            "men",
            "women"
        ]

    },


    /*====================================================
      EXISTING PRODUCT 6
    ====================================================*/

    {
        id: "FASH006",

        title: "Apple Watch Series",

        category: "electronics",

        subcategory: "smartwatches",

        brand: "Apple",

        price: 120000,

        oldPrice: 145000,

        rating: 4.8,

        reviews: 203,

        popularity: 93,

        badge: "Popular",

        image: "../assets/images/products/watch.png",

        gallery: [
            "../assets/images/products/watch.png",
            "../assets/images/products/watch.png"
        ],

        description:
            "Smart wearable designed to help you stay connected, active and organized throughout your day.",

        stock: 19,

        seller: "Apple Premium Store",

        location: "Lagos",

        delivery: "1–3 Days",

        featured: true,

        flashSale: false,

        tags: [
            "watch",
            "smartwatch",
            "apple",
            "wearable",
            "electronics"
        ]

    },


    /*====================================================
      NEW PRODUCT 7
      CATEGORY: BEAUTY
    ====================================================*/

    {
        id: "FASH007",

        title: "Luxury Glow Skincare Set",

        category: "beauty",

        subcategory: "skincare",

        brand: "Glow Beauty",

        price: 48000,

        oldPrice: 62000,

        rating: 4.8,

        reviews: 145,

        popularity: 88,

        badge: "Trending",

        image: "../assets/images/products/skincare.png",

        gallery: [
            "../assets/images/products/skincare.png"
        ],

        description:
            "Complete skincare collection designed for a simple and refreshing daily beauty routine.",

        stock: 31,

        seller: "Glow Beauty Store",

        location: "Lagos",

        delivery: "1–3 Days",

        featured: false,

        flashSale: true,

        tags: [
            "beauty",
            "skincare",
            "glow",
            "cosmetics"
        ]

    },


    /*====================================================
      NEW PRODUCT 8
      CATEGORY: HOME
    ====================================================*/

    {
        id: "FASH008",

        title: "Modern Luxury Sofa",

        category: "home",

        subcategory: "furniture",

        brand: "FASH Home",

        price: 385000,

        oldPrice: 450000,

        rating: 4.7,

        reviews: 94,

        popularity: 86,

        badge: "Featured",

        image: "../assets/images/products/sofa.png",

        gallery: [
            "../assets/images/products/sofa.png"
        ],

        description:
            "Modern premium sofa designed to bring comfort and contemporary style into your living space.",

        stock: 6,

        seller: "FASH Home",

        location: "Lagos",

        delivery: "3–7 Days",

        featured: true,

        flashSale: false,

        tags: [
            "home",
            "sofa",
            "furniture",
            "living room"
        ]

    },


    /*====================================================
      NEW PRODUCT 9
      CATEGORY: GROCERIES
    ====================================================*/

    {
        id: "FASH009",

        title: "Premium Family Grocery Box",

        category: "groceries",

        subcategory: "food",

        brand: "FASH Fresh",

        price: 75000,

        oldPrice: 89000,

        rating: 4.6,

        reviews: 117,

        popularity: 82,

        badge: "Value Pack",

        image: "../assets/images/products/groceries.png",

        gallery: [
            "../assets/images/products/groceries.png"
        ],

        description:
            "A convenient family grocery selection containing everyday essentials for your home.",

        stock: 40,

        seller: "FASH Fresh Market",

        location: "Lagos",

        delivery: "Same Day",

        featured: false,

        flashSale: true,

        tags: [
            "groceries",
            "food",
            "family",
            "fresh"
        ]

    },


    /*====================================================
      NEW PRODUCT 10
      CATEGORY: SPORTS
    ====================================================*/

    {
        id: "FASH010",

        title: "Professional Football Boots",

        category: "sports",

        subcategory: "football",

        brand: "FASH Sport",

        price: 78000,

        oldPrice: 95000,

        rating: 4.8,

        reviews: 164,

        popularity: 90,

        badge: "Best Seller",

        image: "../assets/images/products/football-boots.png",

        gallery: [
            "../assets/images/products/football-boots.png"
        ],

        description:
            "Professional football boots designed for grip, speed, comfort and control on the pitch.",

        stock: 18,

        seller: "FASH Sports",

        location: "Lagos",

        delivery: "1–3 Days",

        featured: true,

        flashSale: true,

        tags: [
            "sports",
            "football",
            "boots",
            "soccer"
        ]

    },


    /*====================================================
      NEW PRODUCT 11
      CATEGORY: GAMING
    ====================================================*/

    {
        id: "FASH011",

        title: "Wireless Gaming Headset",

        category: "gaming",

        subcategory: "accessories",

        brand: "FASH Gaming",

        price: 95000,

        oldPrice: 120000,

        rating: 4.8,

        reviews: 236,

        popularity: 95,

        badge: "Gamer Pick",

        image: "../assets/images/products/gaming-headset.png",

        gallery: [
            "../assets/images/products/gaming-headset.png"
        ],

        description:
            "Immersive wireless gaming headset with comfortable ear cushions and clear gaming audio.",

        stock: 25,

        seller: "FASH Gaming",

        location: "Lagos",

        delivery: "1–3 Days",

        featured: true,

        flashSale: false,

        tags: [
            "gaming",
            "headset",
            "gaming accessories",
            "wireless"
        ]

    },


    /*====================================================
      NEW PRODUCT 12
      CATEGORY: ELECTRONICS
    ====================================================*/

    {
        id: "FASH012",

        title: "Sony 4K Smart Television",

        category: "electronics",

        subcategory: "televisions",

        brand: "Sony",

        price: 680000,

        oldPrice: 790000,

        rating: 4.8,

        reviews: 189,

        popularity: 92,

        badge: "Hot Deal",

        image: "../assets/images/products/tv.png",

        gallery: [
            "../assets/images/products/tv.png"
        ],

        description:
            "Large 4K smart television with vibrant picture quality and a premium entertainment experience.",

        stock: 9,

        seller: "Sony Electronics",

        location: "Lagos",

        delivery: "2–5 Days",

        featured: true,

        flashSale: true,

        tags: [
            "electronics",
            "television",
            "tv",
            "sony",
            "4k"
        ]

    },


    /*====================================================
      NEW PRODUCT 13
      CATEGORY: FASHION
    ====================================================*/

    {
        id: "FASH013",

        title: "Premium Men's Native Outfit",

        category: "fashion",

        subcategory: "men",

        brand: "FASH Couture",

        price: 85000,

        oldPrice: 105000,

        rating: 4.7,

        reviews: 132,

        popularity: 84,

        badge: "New",

        image: "../assets/images/products/native-wear.png",

        gallery: [
            "../assets/images/products/native-wear.png"
        ],

        description:
            "Elegant premium native outfit combining traditional style with a modern tailored finish.",

        stock: 15,

        seller: "FASH Couture",

        location: "Lagos",

        delivery: "2–4 Days",

        featured: false,

        flashSale: false,

        tags: [
            "fashion",
            "men",
            "native",
            "clothing"
        ]

    },


    /*====================================================
      NEW PRODUCT 14
      CATEGORY: PHONES
    ====================================================*/

    {
        id: "FASH014",

        title: "Google Pixel Pro Smartphone",

        category: "phones",

        subcategory: "smartphones",

        brand: "Google",

        price: 920000,

        oldPrice: 1050000,

        rating: 4.8,

        reviews: 176,

        popularity: 89,

        badge: "New",

        image: "../assets/images/products/pixel.png",

        gallery: [
            "../assets/images/products/pixel.png"
        ],

        description:
            "Premium Google Pixel smartphone with powerful performance and advanced camera technology.",

        stock: 12,

        seller: "FASH Mobile",

        location: "Lagos",

        delivery: "1–3 Days",

        featured: true,

        flashSale: false,

        tags: [
            "google",
            "pixel",
            "phone",
            "smartphone"
        ]

    },


    /*====================================================
      NEW PRODUCT 15
      CATEGORY: BEAUTY
    ====================================================*/

    {
        id: "FASH015",

        title: "Luxury Perfume Collection",

        category: "beauty",

        subcategory: "perfumes",

        brand: "FASH Fragrance",

        price: 72000,

        oldPrice: 90000,

        rating: 4.9,

        reviews: 211,

        popularity: 96,

        badge: "Top Rated",

        image: "../assets/images/products/perfume.png",

        gallery: [
            "../assets/images/products/perfume.png"
        ],

        description:
            "Premium fragrance collection created for an elegant and long-lasting signature scent.",

        stock: 27,

        seller: "FASH Fragrance",

        location: "Lagos",

        delivery: "1–3 Days",

        featured: false,

        flashSale: true,

        tags: [
            "beauty",
            "perfume",
            "fragrance",
            "cosmetics"
        ]

    },


    /*====================================================
      NEW PRODUCT 16
      CATEGORY: HOME
    ====================================================*/

    {
        id: "FASH016",

        title: "Smart LED Floor Lamp",

        category: "home",

        subcategory: "lighting",

        brand: "FASH Home",

        price: 56000,

        oldPrice: 70000,

        rating: 4.6,

        reviews: 83,

        popularity: 79,

        badge: "Smart Home",

        image: "../assets/images/products/floor-lamp.png",

        gallery: [
            "../assets/images/products/floor-lamp.png"
        ],

        description:
            "Modern smart LED floor lamp designed to add stylish ambient lighting to your home.",

        stock: 21,

        seller: "FASH Home",

        location: "Lagos",

        delivery: "2–5 Days",

        featured: false,

        flashSale: false,

        tags: [
            "home",
            "lamp",
            "lighting",
            "smart home"
        ]

    },


    /*====================================================
      NEW PRODUCT 17
      CATEGORY: SPORTS
    ====================================================*/

    {
        id: "FASH017",

        title: "Adjustable Home Gym Set",

        category: "sports",

        subcategory: "fitness",

        brand: "FASH Sport",

        price: 145000,

        oldPrice: 175000,

        rating: 4.7,

        reviews: 102,

        popularity: 87,

        badge: "Fitness Pick",

        image: "../assets/images/products/home-gym.png",

        gallery: [
            "../assets/images/products/home-gym.png"
        ],

        description:
            "Versatile home gym equipment set designed for strength training and everyday fitness.",

        stock: 10,

        seller: "FASH Sports",

        location: "Lagos",

        delivery: "3–7 Days",

        featured: false,

        flashSale: false,

        tags: [
            "sports",
            "fitness",
            "gym",
            "workout"
        ]

    },


    /*====================================================
      NEW PRODUCT 18
      CATEGORY: GROCERIES
    ====================================================*/

    {
        id: "FASH018",

        title: "Premium Organic Cooking Essentials",

        category: "groceries",

        subcategory: "cooking",

        brand: "FASH Fresh",

        price: 42000,

        oldPrice: 51000,

        rating: 4.7,

        reviews: 76,

        popularity: 81,

        badge: "Fresh",

        image: "../assets/images/products/cooking-essentials.png",

        gallery: [
            "../assets/images/products/cooking-essentials.png"
        ],

        description:
            "Carefully selected everyday cooking essentials for convenient family meals.",

        stock: 35,

        seller: "FASH Fresh Market",

        location: "Lagos",

        delivery: "Same Day",

        featured: false,

        flashSale: true,

        tags: [
            "groceries",
            "cooking",
            "food",
            "organic"
        ]

    }

];

const shopState = {
    products: [...shopProducts], filteredProducts: [...shopProducts], currentPage: 1,
    searchTerm: "", selectedCategories: [], selectedBrands: [], minRating: 0,
    maxPrice: Math.max(...shopProducts.map(p => Number(p.price) || 0)), sortBy: "popular", view: "grid"
};

function money(value) { return new Intl.NumberFormat(SHOP_CONFIG.currencyLocale,{style:"currency",currency:SHOP_CONFIG.currency,maximumFractionDigits:0}).format(Number(value)||0); }
function escapeHTML(value) { return String(value ?? "").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;"); }
function categoryLabel(category) { const map={gaming:"Gaming",electronics:"Electronics",phones:"Phones",fashion:"Fashion",beauty:"Beauty",home:"Home & Living",groceries:"Groceries",sports:"Sports"}; return map[category]||category; }
function categoryMatches(product,label) { const c=String(product.category||"").toLowerCase(), l=String(label||"").toLowerCase(); if(l==="home & living"||l==="home") return c==="home"; return c===l; }
function getWishlist(){try{return JSON.parse(localStorage.getItem(SHOP_CONFIG.storageKeys.wishlist))||[]}catch{return[]}}
function saveWishlist(items){
    localStorage.setItem(
        SHOP_CONFIG.storageKeys.wishlist,
        JSON.stringify(items)
    );
}
function getCart(){try{return JSON.parse(localStorage.getItem(SHOP_CONFIG.storageKeys.cart))||[]}catch{return[]}}
function saveCart(items, detail = {}) {
    localStorage.setItem(
        SHOP_CONFIG.storageKeys.cart,
        JSON.stringify(items)
    );
    window.dispatchEvent(
        new CustomEvent("fash:cart-updated", { detail })
    );
}
function isWishlisted(id){return getWishlist().map(String).includes(String(id));}
function toggleWishlist(id){
        const product = shopProducts.find(x => String(x.id) === String(id));
        let list = getWishlist();
        const exists = list.map(String).includes(String(id));
        list = exists
            ? list.filter(x => String(x) !== String(id))
            : [...list, id];

        saveWishlist(list);
        updateWishlistCounter();

        // Immediately update every visible heart for this product so the click
        // always gives the customer clear feedback.
        document.querySelectorAll(`[data-wishlist-toggle="${String(id).replace(/"/g, '\\"')}"]`).forEach(button => {
            button.classList.toggle("is-wishlisted", !exists);
            const icon = button.querySelector("i");
            if (icon) icon.className = `fa-${!exists ? "solid" : "regular"} fa-heart`;
            button.setAttribute("aria-pressed", String(!exists));
        });

        showShopToast(exists ? "Removed from Saved Items" : "Added to Saved Items");

        window.dispatchEvent(new CustomEvent("fash:wishlist-updated", {
            detail: {
                action: exists ? "remove" : "add",
                productId: id,
                productTitle: product ? product.title : ""
            }
        }));

    }
function addToCart(id){
    const p=shopProducts.find(x=>String(x.id)===String(id));
    if(!p)return;
    const cart=getCart();
    const e=cart.find(x=>String(x.id)===String(id));
    if(e)e.quantity=(e.quantity||1)+1;
    else cart.push({id:p.id,title:p.title,price:p.price,image:p.image,quantity:1});
    saveCart(cart,{action:"add",productId:p.id,productTitle:p.title});
    updateCartCounter();
    showShopToast("Added to cart");
}
function updateCartCounter(){const n=getCart().reduce((a,x)=>a+(Number(x.quantity)||0),0);document.querySelectorAll("#cartCount,.cart-count").forEach(e=>e.textContent=n);} function updateWishlistCounter(){const n=getWishlist().length;document.querySelectorAll("#wishlistCount,.wishlist-count").forEach(e=>e.textContent=n);}
function showShopToast(message){let t=document.querySelector(".shop-toast");if(!t){t=document.createElement("div");t.className="shop-toast";document.body.appendChild(t)}t.textContent=message;t.classList.add("show");clearTimeout(window.__fashToastTimer);window.__fashToastTimer=setTimeout(()=>t.classList.remove("show"),1800);}

function applyShopFilters(){
    const q=shopState.searchTerm.trim().toLowerCase();
    let list=shopState.products.filter(p=>{
        const text=[p.title,p.brand,p.category,p.subcategory,...(p.tags||[])].join(" ").toLowerCase();
        const searchOK=!q||text.includes(q);
        const catOK=!shopState.selectedCategories.length||shopState.selectedCategories.some(c=>categoryMatches(p,c));
        const brandOK=!shopState.selectedBrands.length||shopState.selectedBrands.some(b=>String(p.brand).toLowerCase()===String(b).toLowerCase());
        const ratingOK=Number(p.rating)>=shopState.minRating;
        const priceOK=Number(p.price)<=shopState.maxPrice;
        return searchOK&&catOK&&brandOK&&ratingOK&&priceOK;
    });
    switch(shopState.sortBy){case"newest":list.sort((a,b)=>Number(b.id.replace(/\D/g,""))-Number(a.id.replace(/\D/g,"")));break;case"low-high":list.sort((a,b)=>a.price-b.price);break;case"high-low":list.sort((a,b)=>b.price-a.price);break;case"rating":list.sort((a,b)=>b.rating-a.rating);break;default:list.sort((a,b)=>b.popularity-a.popularity)}
    shopState.filteredProducts=list;
    shopState.currentPage=Math.min(shopState.currentPage,Math.max(1,Math.ceil(list.length/SHOP_CONFIG.productsPerPage)));
}

function renderShopProduct(p){
    const wished=isWishlisted(p.id), discount=p.oldPrice>p.price?Math.round((1-p.price/p.oldPrice)*100):0;
    const icons={fashion:"fa-shirt",beauty:"fa-wand-magic-sparkles",sports:"fa-futbol",home:"fa-house",groceries:"fa-basket-shopping",phones:"fa-mobile-screen-button",gaming:"fa-gamepad",electronics:"fa-cube"};
    return `<article class="product-card premium-card" data-product-id="${escapeHTML(p.id)}">
      <div class="product-media"><div class="product-orb"></div><span class="product-badge">${escapeHTML(p.badge||"Featured")}</span>${discount?`<span class="discount-badge">-${discount}%</span>`:""}
      <button type="button" class="quick-view top-quick" data-quick-view="${escapeHTML(p.id)}" aria-label="Quick view"><i class="fa-solid fa-eye"></i></button>
      <button type="button" class="wishlist-btn ${wished?"is-wishlisted":""}" data-wishlist-toggle="${escapeHTML(p.id)}" aria-label="Wishlist"><i class="fa-${wished?"solid":"regular"} fa-heart"></i></button>
      <div class="product-placeholder"><div class="placeholder-icon"><i class="fa-solid ${icons[p.category]||"fa-cube"}"></i></div><span>${escapeHTML(p.brand||categoryLabel(p.category))}</span></div></div>
      <div class="product-content"><div class="product-meta"><span>${escapeHTML(categoryLabel(p.category))}</span><span>${escapeHTML(p.location||"Nigeria")}</span></div>
      <h4>${escapeHTML(p.title)}</h4><div class="product-rating"><span class="stars">${"★".repeat(Math.max(1,Math.round(p.rating||0)))}</span><strong>${Number(p.rating||0).toFixed(1)}</strong><span>(${Number(p.reviews||0).toLocaleString()})</span></div>
      <div class="product-price"><span class="current-price">${money(p.price)}</span>${p.oldPrice?`<span class="old-price">${money(p.oldPrice)}</span>`:""}</div>
      <div class="product-footer"><button type="button" class="btn-primary add-to-cart" data-add-to-cart="${escapeHTML(p.id)}"><i class="fa-solid fa-cart-plus"></i> Add to Cart</button><button type="button" class="quick-view" data-quick-view="${escapeHTML(p.id)}" aria-label="Quick view"><i class="fa-solid fa-eye"></i></button></div></div></article>`;
}
function renderShop(){applyShopFilters();const grid=document.getElementById("shopProducts");if(!grid)return;const start=(shopState.currentPage-1)*SHOP_CONFIG.productsPerPage,items=shopState.filteredProducts.slice(start,start+SHOP_CONFIG.productsPerPage);grid.classList.toggle("list-view",shopState.view==="list");grid.innerHTML=items.length?items.map(renderShopProduct).join(""):`<div class="shop-empty"><i class="fa-solid fa-box-open"></i><h3>No products found</h3><p>Try clearing a filter or searching for another product.</p><button type="button" id="emptyClearFilters">Clear Filters</button></div>`;updateShopCounters();renderPagination();}
function updateShopCounters(){const total=shopState.filteredProducts.length,start=total?((shopState.currentPage-1)*SHOP_CONFIG.productsPerPage)+1:0,end=Math.min(shopState.currentPage*SHOP_CONFIG.productsPerPage,total),text=total?`Showing ${start}–${end} of ${total} Products`:"No products found";const r=document.getElementById("resultsCount"),c=document.getElementById("productCount");if(r)r.textContent=text;if(c)c.textContent=shopProducts.length;}
function renderPagination(){const box=document.querySelector(".pagination");if(!box)return;const pages=Math.max(1,Math.ceil(shopState.filteredProducts.length/SHOP_CONFIG.productsPerPage));let nums="";for(let i=1;i<=pages;i++)nums+=`<button class="page-btn ${i===shopState.currentPage?"active":""}" data-page="${i}">${i}</button>`;box.innerHTML=`<button class="page-btn" id="prevPage" ${shopState.currentPage===1?"disabled":""}><i class="fa-solid fa-chevron-left"></i></button>${nums}<button class="page-btn" id="nextPage" ${shopState.currentPage===pages?"disabled":""}><i class="fa-solid fa-chevron-right"></i></button>`;}

function setupFilters(){

document.querySelectorAll('.filter-group input[type="checkbox"]').forEach(input=>input.addEventListener("change",()=>{
const group=input.closest(".filter-group"),
heading=group?.querySelector("h4")?.textContent.trim().toLowerCase();

if(heading==="categories"){
shopState.selectedCategories=[...group.querySelectorAll('input[type="checkbox"]:checked')].map(x=>x.value);
}

if(heading==="brands"){
shopState.selectedBrands=[...group.querySelectorAll('input[type="checkbox"]:checked')].map(x=>x.value);
}

shopState.currentPage=1;
renderShop();
}));


document.querySelectorAll('.filter-group input[type="radio"]').forEach(input=>input.addEventListener("change",()=>{
const label=input.parentElement?.textContent||"";

shopState.minRating=
label.includes("⭐⭐⭐⭐⭐")&&!label.includes("Up")
?5
:label.includes("⭐⭐⭐⭐")
?4
:3;

shopState.currentPage=1;
renderShop();
}));


/*==================================================
PRICE RANGE
==================================================*/

const range=document.getElementById("priceRange");
const value=document.getElementById("priceValue");

if(!range){
return;
}


/*
Calculate the actual maximum price from
the products instead of trusting a restored
browser slider value.
*/

const actualMaxPrice=Math.max(
...shopProducts.map(p=>Number(p.price)||0)
);


/*
Set the real slider limits.
*/

range.min="0";
range.max=String(actualMaxPrice);


/*
IMPORTANT:
Always start the Shop with the slider
at the actual maximum price.
*/

range.value=String(actualMaxPrice);

shopState.maxPrice=actualMaxPrice;

if(value){
value.textContent=money(actualMaxPrice);
}


/*
Slider movement.
*/

range.addEventListener("input",()=>{

shopState.maxPrice=Number(range.value);

if(value){
value.textContent=money(shopState.maxPrice);
}

shopState.currentPage=1;
renderShop();

});


/*
Prevent the browser from restoring an old
slider value after refresh/back-forward.
*/

window.addEventListener("pageshow",()=>{

const max=Number(range.max);

range.value=String(max);
shopState.maxPrice=max;

if(value){
value.textContent=money(max);
}

shopState.currentPage=1;
renderShop();

});

}

function setupSearch(){const ids=["navbarSearch","shopSearch","productSearch"];
/*==================================================
CATEGORY FILTER NAVIGATION
Scroll to the products section when a category is
chosen from the Categories dropdown/navbar.
==================================================*/

function scrollToShopProducts() {

    const productsSection =
        document.getElementById("shopProducts") ||
        document.getElementById("products") ||
        document.querySelector(".products-section") ||
        document.querySelector(".shop-products");

    if (!productsSection) return;

    setTimeout(function () {

        productsSection.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });

    }, 80);

}


document.addEventListener("input",function(event){const input=event.target;if(!ids.includes(input.id))return;const value=input.value;ids.forEach(id=>{const other=document.getElementById(id);if(other&&other!==input)other.value=value;});shopState.searchTerm=value.trim();shopState.currentPage=1;renderShop();});}
function setupSort(){const s=document.getElementById("sortProducts");if(!s)return;s.value=shopState.sortBy;s.addEventListener("change",()=>{shopState.sortBy=s.value;shopState.currentPage=1;renderShop();});}
function clearFilters(){shopState.selectedCategories=[];shopState.selectedBrands=[];shopState.minRating=0;shopState.searchTerm="";const range=document.getElementById("priceRange");if(range){
range.value=range.max;
shopState.maxPrice=Number(range.max);
const priceValue=document.getElementById("priceValue");
if(priceValue)priceValue.textContent=money(shopState.maxPrice);
}["navbarSearch","shopSearch","productSearch"].forEach(id=>{const e=document.getElementById(id);if(e)e.value=""});document.querySelectorAll('.filter-group input').forEach(i=>i.checked=false);shopState.currentPage=1;renderShop();}
function openQuickView(id){const p=shopProducts.find(x=>String(x.id)===String(id));if(!p)return;let m=document.querySelector(".shop-quick-modal");if(!m){m=document.createElement("div");m.className="shop-quick-modal";m.innerHTML=`<div class="shop-quick-backdrop"></div><div class="shop-quick-panel"><button class="shop-quick-close" aria-label="Close"><i class="fa-solid fa-xmark"></i></button><div class="quick-placeholder"><i class="fa-solid fa-cube"></i></div><div class="quick-info"><span class="product-category"></span><h2></h2><div class="quick-rating"></div><div class="quick-price"></div><p></p><button class="btn-primary quick-cart"></button></div></div>`;document.body.appendChild(m);m.addEventListener("click",e=>{if(e.target.closest(".shop-quick-close,.shop-quick-backdrop"))m.classList.remove("show");const b=e.target.closest(".quick-cart");if(b)addToCart(b.dataset.id);});}m.querySelector(".product-category").textContent=categoryLabel(p.category);m.querySelector("h2").textContent=p.title;m.querySelector(".quick-rating").textContent=`★★★★★ ${Number(p.rating).toFixed(1)} · ${Number(p.reviews).toLocaleString()} reviews`;m.querySelector(".quick-price").textContent=money(p.price);m.querySelector("p").textContent=p.description||"Premium product from FASH Marketplace.";const b=m.querySelector(".quick-cart");b.dataset.id=p.id;b.innerHTML='<i class="fa-solid fa-cart-plus"></i> Add to Cart';m.classList.add("show");}
// Capture-phase wishlist handler: works even when another script stops click propagation.
document.addEventListener("click", function(e){
    const button = e.target.closest("[data-wishlist-toggle]");
    if(!button) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    toggleWishlist(button.dataset.wishlistToggle);
}, true);

function setupEvents(){document.addEventListener("click",e=>{const page=e.target.closest("[data-page]");if(page){shopState.currentPage=Number(page.dataset.page);renderShop();return}if(e.target.closest("#prevPage")){if(shopState.currentPage>1)shopState.currentPage--;renderShop();return}if(e.target.closest("#nextPage")){const pages=Math.ceil(shopState.filteredProducts.length/SHOP_CONFIG.productsPerPage);if(shopState.currentPage<pages)shopState.currentPage++;renderShop();return}const w=e.target.closest("[data-wishlist-toggle]");if(w){e.stopPropagation();toggleWishlist(w.dataset.wishlistToggle);return}const c=e.target.closest("[data-add-to-cart]");if(c){e.stopPropagation();addToCart(c.dataset.addToCart);return}const q=e.target.closest("[data-quick-view]");if(q){e.stopPropagation();openQuickView(q.dataset.quickView);return}if(e.target.closest("#clearFilters,#emptyClearFilters")){clearFilters();return}if(e.target.closest("#gridView")){shopState.view="grid";document.getElementById("gridView")?.classList.add("active");document.getElementById("listView")?.classList.remove("active");renderShop();return}if(e.target.closest("#listView")){shopState.view="list";document.getElementById("listView")?.classList.add("active");document.getElementById("gridView")?.classList.remove("active");renderShop();return}const card=e.target.closest(".product-card");if(card&&!e.target.closest("button")){const id=card.dataset.productId;localStorage.setItem("fashSelectedProduct",id);window.location.href=`product.html?id=${encodeURIComponent(id)}`;}});}
async function bootstrapDatabaseProducts() {
    const databaseProducts = await loadFashDatabaseProducts();
    if (databaseProducts.length) {
        const existingIds = new Set(shopProducts.map(p => String(p.id)));
        databaseProducts.reverse().forEach(p => {
            if (!existingIds.has(String(p.id))) shopProducts.unshift(p);
        });
    }

    // Always rebuild the shop state after the database request so newly
    // created seller products are included in filters, search and pagination.
    shopState.products = [...shopProducts];
    shopState.filteredProducts = [...shopProducts];
    shopState.maxPrice = Math.max(0, ...shopProducts.map(p => Number(p.price) || 0));
    shopState.currentPage = 1;
    renderShop();
}

function setupShop(){

    /*
    Make the real product database available
    on every page, including wishlist.html.
    */

    window.FASHShop = {
        products: shopProducts,
        refresh: renderShop,
        clearFilters,
        addToCart,
        toggleWishlist,
        isWishlisted
    };

    /*
    Only run the actual shop-page setup
    when we are on shop.html.
    */

    if(!document.getElementById("shopProducts")){

        updateCartCounter();
        updateWishlistCounter();

        return;
    }


    setupFilters();
    setupSearch();
    setupSort();
    setupEvents();


    const params =
        new URLSearchParams(
            window.location.search
        );


    const urlSearch =
        params.get("search");


    const urlCategory =
        params.get("category");


    if(urlSearch){

        shopState.searchTerm =
            urlSearch;

    }


    if(urlCategory){

        /*
         * Category links from the Categories dropdown arrive as:
         * shop.html?category=electronics
         *
         * Apply the filter AND visually select the matching
         * category checkbox so the user can see the active filter.
         */
        shopState.selectedCategories =
            [urlCategory];

        const categoryGroup =
            [...document.querySelectorAll(
                '.filter-group'
            )].find(function (group) {

                return (
                    group.querySelector("h4")
                        ?.textContent
                        .trim()
                        .toLowerCase() === "categories"
                );

            });

        if(categoryGroup){

            categoryGroup
                .querySelectorAll(
                    'input[type="checkbox"]'
                )
                .forEach(function (input) {

                    input.checked =
                        String(input.value).toLowerCase() ===
                        String(urlCategory).toLowerCase();

                });

        }

    }


    ["shopSearch","productSearch"].forEach(id => {

        const e =
            document.getElementById(id);

        if(e && urlSearch){

            e.value =
                urlSearch;

        }

    });


    bootstrapDatabaseProducts();

    updateCartCounter();

    updateWishlistCounter();

}
if(document.readyState==="loading"){

    document.addEventListener(
        "DOMContentLoaded",
        setupShop,
        {once:true}
    );

}else{

    setupShop();

}
