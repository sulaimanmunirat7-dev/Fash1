/*========================================================
FASH MARKETPLACE
CONTACT PAGE
CONTACT.JS
========================================================*/

"use strict";


/*========================================================
CONTACT FORM
========================================================*/

function setupContactForm() {

    const form = document.getElementById("contactForm");

    if (!form) {
        return;
    }


    const successMessage =
        document.getElementById("contactSuccess");


    form.addEventListener("submit", function (event) {

        event.preventDefault();


        /*----------------------------------------------
        GET FORM VALUES
        ----------------------------------------------*/

        const name =
            document.getElementById("contactName")?.value.trim();

        const email =
            document.getElementById("contactEmail")?.value.trim();

        const subject =
            document.getElementById("contactSubject")?.value;

        const order =
            document.getElementById("contactOrder")?.value.trim();

        const message =
            document.getElementById("contactMessage")?.value.trim();


        /*----------------------------------------------
        BASIC VALIDATION
        ----------------------------------------------*/

        if (!name || !email || !subject || !message) {

            showContactMessage(
                "Please complete all required fields.",
                "error"
            );

            return;
        }


        /*----------------------------------------------
        EMAIL VALIDATION
        ----------------------------------------------*/

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(email)) {

            showContactMessage(
                "Please enter a valid email address.",
                "error"
            );

            return;
        }


        /*----------------------------------------------
        CREATE MESSAGE OBJECT
        ----------------------------------------------*/

        const contactMessage = {

            id:
                "MSG-" +
                Date.now(),

            name: name,

            email: email,

            subject: subject,

            order:
                order || "",

            message: message,

            date:
                new Date().toISOString(),

            status:
                "new"

        };


        /*----------------------------------------------
        SAVE MESSAGE LOCALLY
        ----------------------------------------------*/

        try {

            const existingMessages =
                JSON.parse(
                    localStorage.getItem(
                        "fash_contact_messages"
                    )
                ) || [];


            existingMessages.push(contactMessage);


            localStorage.setItem(
                "fash_contact_messages",
                JSON.stringify(existingMessages)
            );

        } catch (error) {

            console.error(
                "Unable to save contact message:",
                error
            );

        }


        /*----------------------------------------------
        SUCCESS
        ----------------------------------------------*/

        if (successMessage) {

            successMessage.hidden = false;

            successMessage.innerHTML = `

                <i class="fa-solid fa-circle-check"></i>

                <span>
                    Thanks ${escapeContactHTML(name)}!
                    Your message has been sent successfully.
                </span>

            `;

        }


        /*----------------------------------------------
        CLEAR FORM
        ----------------------------------------------*/

        form.reset();


        /*----------------------------------------------
        HIDE SUCCESS AFTER A WHILE
        ----------------------------------------------*/

        setTimeout(function () {

            if (successMessage) {

                successMessage.hidden = true;

            }

        }, 6000);

    });

}


/*========================================================
CONTACT MESSAGE
========================================================*/

function showContactMessage(message, type) {

    const successMessage =
        document.getElementById("contactSuccess");


    if (!successMessage) {
        return;
    }


    successMessage.hidden = false;


    if (type === "error") {

        successMessage.style.background =
            "#fef3f2";

        successMessage.style.color =
            "#b42318";

        successMessage.innerHTML = `

            <i class="fa-solid fa-circle-exclamation"></i>

            <span>
                ${escapeContactHTML(message)}
            </span>

        `;

    } else {

        successMessage.style.background =
            "#ecfdf3";

        successMessage.style.color =
            "#027a48";

        successMessage.innerHTML = `

            <i class="fa-solid fa-circle-check"></i>

            <span>
                ${escapeContactHTML(message)}
            </span>

        `;

    }

}


/*========================================================
ESCAPE HTML
========================================================*/

function escapeContactHTML(value) {

    return String(value ?? "")

        .replaceAll("&", "&amp;")

        .replaceAll("<", "&lt;")

        .replaceAll(">", "&gt;")

        .replaceAll('"', "&quot;")

        .replaceAll("'", "&#039;");

}


/*========================================================
CONTACT PAGE INITIALIZATION
========================================================*/

function setupContactPage() {

    setupContactForm();

}


/*========================================================
START
========================================================*/

if (document.readyState === "loading") {

    document.addEventListener(
        "DOMContentLoaded",
        setupContactPage,
        { once: true }
    );

} else {

    setupContactPage();

}