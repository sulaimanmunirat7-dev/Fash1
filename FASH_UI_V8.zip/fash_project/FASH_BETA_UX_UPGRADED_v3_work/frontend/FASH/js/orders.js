/*==================================================
FASH MARKETPLACE
ORDERS JAVASCRIPT
==================================================*/

"use strict";


/*==================================================
GET ORDERS
==================================================*/

function getFashOrders() {

    try {

        const storedOrders =
            localStorage.getItem("fash_orders");

        if (!storedOrders) {
            return [];
        }

        const orders =
            JSON.parse(storedOrders);

        return Array.isArray(orders)
            ? orders
            : [];

    } catch (error) {

        console.error(
            "Unable to load FASH orders:",
            error
        );

        return [];

    }

}


/*==================================================
FORMAT PRICE
==================================================*/

function formatOrderPrice(value) {

    return new Intl.NumberFormat(
        "en-NG",
        {
            style: "currency",
            currency: "NGN",
            maximumFractionDigits: 0
        }
    ).format(
        Number(value) || 0
    );

}


/*==================================================
FORMAT DATE
==================================================*/

function formatOrderDate(dateValue) {

    if (!dateValue) {
        return "Date unavailable";
    }

    const date =
        new Date(dateValue);

    if (Number.isNaN(date.getTime())) {
        return "Date unavailable";
    }

    return date.toLocaleDateString(
        "en-NG",
        {
            day: "numeric",
            month: "short",
            year: "numeric"
        }
    );

}


/*==================================================
PRODUCT HELPERS
==================================================*/

function getOrderProductName(product) {

    return (
        product.name ||
        product.title ||
        product.productName ||
        "Product"
    );

}


function getOrderProductImage(product) {

    return (
        product.image ||
        product.imageUrl ||
        product.thumbnail ||
        "../assets/images/logos/Logo.png"
    );

}


function getOrderProductPrice(product) {

    return Number(
        product.price ||
        product.currentPrice ||
        0
    );

}


function getOrderProductQuantity(product) {

    const quantity =
        Number(
            product.quantity ||
            product.qty ||
            1
        );

    return quantity > 0
        ? quantity
        : 1;

}


/*==================================================
ESCAPE HTML
==================================================*/

function escapeOrderHTML(value) {

    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


/*==================================================
ORDER STATUS
==================================================*/

function getOrderStatus(order) {

    return (
        order.status ||
        "processing"
    );

}


function getOrderStatusLabel(status) {

    const labels = {

        processing: "Processing",

        confirmed: "Confirmed",

        completed: "Completed",

        cancelled: "Cancelled",

        pending: "Pending"

    };

    return (
        labels[status] ||
        "Processing"
    );

}


/*==================================================
RENDER ONE PRODUCT
==================================================*/

function renderOrderProduct(product) {

    const name =
        escapeOrderHTML(
            getOrderProductName(product)
        );

    const image =
        escapeOrderHTML(
            getOrderProductImage(product)
        );

    const price =
        getOrderProductPrice(product);

    const quantity =
        getOrderProductQuantity(product);


    return `

        <div class="order-product">

            <div class="order-product-image">

                <img
                    src="${image}"
                    alt="${name}"
                    loading="lazy">

            </div>


            <div class="order-product-info">

                <h3>
                    ${name}
                </h3>

                <span>
                    Quantity: ${quantity}
                </span>

            </div>


            <strong class="order-product-price">

                ${formatOrderPrice(
                    price * quantity
                )}

            </strong>

        </div>

    `;

}


/*==================================================
RENDER ONE ORDER
==================================================*/

function renderOrder(order) {

    const orderId =
        escapeOrderHTML(
            order.id ||
            "FASH-ORDER"
        );


    const status =
        getOrderStatus(order);


    const statusLabel =
        getOrderStatusLabel(status);


    const products =
        Array.isArray(order.items)
            ? order.items
            : [];


    const total =
        Number(order.total) || 0;


    const paymentMethod =
        order.paymentMethod === "pay-later"
            ? "Pay Later"
            : "Test Payment";


    return `

        <article
            class="order-card"
            data-order-id="${orderId}">


            <!--======================================
            ORDER HEADER
            =======================================-->

            <header class="order-card-header">

                <div class="order-information">


                    <div>

                        <span>
                            Order
                        </span>

                        <strong>
                            ${orderId}
                        </strong>

                    </div>


                    <div>

                        <span>
                            Date
                        </span>

                        <strong>
                            ${formatOrderDate(
                                order.createdAt
                            )}
                        </strong>

                    </div>


                    <div>

                        <span>
                            Payment
                        </span>

                        <strong>
                            ${paymentMethod}
                        </strong>

                    </div>


                </div>


                <span class="order-status">

                    <i class="fa-solid fa-circle"></i>

                    ${statusLabel}

                </span>

            </header>



            <!--======================================
            PRODUCTS
            =======================================-->

            <div class="order-card-body">

                <div class="order-products">

                    ${
                        products.length
                            ? products
                                .map(
                                    renderOrderProduct
                                )
                                .join("")
                            : `
                                <div class="order-product">

                                    <div class="order-product-info">

                                        <h3>
                                            No product information available
                                        </h3>

                                    </div>

                                </div>
                            `
                    }

                </div>

            </div>



            <!--======================================
            FOOTER
            =======================================-->

            <footer class="order-card-footer">


                <div class="order-total">

                    <span>
                        Order Total
                    </span>

                    <strong>
                        ${formatOrderPrice(total)}
                    </strong>

                </div>


                <div class="order-actions">

                    <button
                        type="button"
                        class="view-order-button"
                        data-order-id="${orderId}">

                        <i class="fa-solid fa-eye"></i>

                        View Order

                    </button>

                    ${
                        (
                            String(status).toLowerCase() === "processing" ||
                            String(status).toLowerCase() === "confirmed"
                        )
                        ? `
                            <button
                                type="button"
                                class="cancel-order-button"
                                data-order-id="${orderId}">

                                <i class="fa-solid fa-xmark"></i>

                                Cancel Order

                            </button>
                        `
                        : ""
                    }

                </div>


            </footer>


        </article>

    `;

}


let currentOrderFilter = "all";

function getFilteredOrders(orders) {

    return orders.filter(order => {

        const status =
            String(order.status || "processing").toLowerCase();

        if (currentOrderFilter === "active") {
            return (
                status === "processing" ||
                status === "confirmed" ||
                status === "pending"
            );
        }

        if (currentOrderFilter === "completed") {
            return status === "completed";
        }

        if (currentOrderFilter === "cancelled") {
            return status === "cancelled";
        }

        return true;
    });
}

/*==================================================
RENDER ORDERS
==================================================*/

function renderOrders() {

    const allOrders = getFashOrders();
    const orders = getFilteredOrders(allOrders);

    const ordersList = document.getElementById("ordersList");
    const emptyState = document.getElementById("ordersEmpty");
    const countElement = document.getElementById("ordersCount");

    if (!ordersList) return;

    if (countElement) {
        countElement.textContent =
            `${orders.length} ${
                orders.length === 1 ? "order" : "orders"
            }`;
    }

    if (!orders.length) {
        ordersList.innerHTML = "";
        if (emptyState) emptyState.hidden = false;
        return;
    }

    if (emptyState) emptyState.hidden = true;

    ordersList.innerHTML =
        orders.map(renderOrder).join("");

    setupViewOrderButtons();
    setupCancelOrderButtons();
}

/*==================================================
VIEW ORDER
==================================================*/

function setupViewOrderButtons() {

    const buttons =
        document.querySelectorAll(
            ".view-order-button"
        );


    buttons.forEach(
        button => {

            button.addEventListener(
                "click",
                () => {

                    const orderId =
                        button.dataset.orderId;


                    const orders =
                        getFashOrders();


                    const order =
                        orders.find(
                            item =>
                                String(item.id) ===
                                String(orderId)
                        );


                    if (!order) {

                        alert(
                            "Order could not be found."
                        );

                        return;

                    }


                    showOrderDetails(
                        order
                    );

                }
            );

        }
    );

}


/*==================================================
ORDER DETAILS
==================================================*/

function showOrderDetails(order) {

    const products =
        Array.isArray(order.items)
            ? order.items
            : [];


    const productText =
        products
            .map(
                product => {

                    const name =
                        getOrderProductName(
                            product
                        );

                    const quantity =
                        getOrderProductQuantity(
                            product
                        );

                    return `${name} × ${quantity}`;

                }
            )
            .join("\n");


    const customer =
        order.customer || {};


    alert(

        `Order: ${order.id}\n\n` +

        `Date: ${
            formatOrderDate(
                order.createdAt
            )
        }\n` +

        `Status: ${
            getOrderStatusLabel(
                getOrderStatus(order)
            )
        }\n\n` +

        `Products:\n${productText}\n\n` +

        `Total: ${
            formatOrderPrice(
                order.total
            )
        }\n\n` +

        `Customer: ${
            customer.firstName || ""
        } ${
            customer.lastName || ""
        }`

    );

}




/*==================================================
CANCEL ORDER
==================================================*/

function cancelFashOrder(orderId) {

    const orders = getFashOrders();

    const index = orders.findIndex(
        order => String(order.id) === String(orderId)
    );

    if (index === -1) {
        alert("Order could not be found.");
        return;
    }

    const order = orders[index];

    const status =
        String(order.status || "processing").toLowerCase();

    if (status !== "processing" && status !== "confirmed") {
        alert("This order can no longer be cancelled.");
        return;
    }

    const confirmed = window.confirm(
        `Cancel order ${order.id}?\n\nThis action cannot be undone.`
    );

    if (!confirmed) return;

    order.status = "cancelled";
    order.cancelledAt = new Date().toISOString();

    localStorage.setItem(
        "fash_orders",
        JSON.stringify(orders)
    );

    renderOrders();
    setupOrderTabs();

}


/*==================================================
CANCEL ORDER BUTTONS
==================================================*/

function setupCancelOrderButtons() {

    document
        .querySelectorAll(".cancel-order-button")
        .forEach(button => {

            button.addEventListener("click", () => {

                cancelFashOrder(
                    button.dataset.orderId
                );

            });

        });

}

function setupOrderTabs() {

    const tabs = document.querySelectorAll(".orders-tab");

    tabs.forEach(tab => {

        tab.addEventListener("click", () => {

            currentOrderFilter =
                tab.dataset.orderFilter || "all";

            tabs.forEach(item =>
                item.classList.remove("active")
            );

            tab.classList.add("active");

            renderOrders();
        });

    });
}

/*==================================================
LISTEN FOR NEW ORDERS
==================================================*/

window.addEventListener(
    "storage",
    event => {

        if (
            event.key ===
            "fash_orders"
        ) {

            renderOrders();

        }

    }
);


/*==================================================
INITIALIZE
==================================================*/

function initializeOrders() {

    renderOrders();

}


if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        initializeOrders,
        { once: true }
    );

} else {

    initializeOrders();

}