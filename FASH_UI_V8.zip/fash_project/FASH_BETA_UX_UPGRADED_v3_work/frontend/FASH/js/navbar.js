
/* FASH v6.4.2 customer account menu */
function buildFashAccountMenu(user) {
  const loggedIn = !!user;

  const rawName = loggedIn
    ? String(
        user.full_name ||
        user.fullName ||
        user.name ||
        user.first_name ||
        user.firstName ||
        user.username ||
        "there"
      ).trim()
    : "Guest";

  const firstName = rawName.split(/\s+/)[0] || "there";
  const isNewSignup = loggedIn && sessionStorage.getItem("fashNewSignup") === "1";
  const greeting = !loggedIn
    ? "Hello, Guest"
    : (isNewSignup ? `Welcome, ${firstName}` : `Welcome back, ${firstName}`);

  const seller = loggedIn && (
    user.is_seller === true ||
    user.isSeller === true ||
    user.role === "seller" ||
    user.role === "approved_seller" ||
    user.seller_status === "approved" ||
    user.sellerStatus === "approved"
  );

  if (isNewSignup) {
    sessionStorage.removeItem("fashNewSignup");
  }

  if (!loggedIn) {
    return `
      <div class="fash-account-menu fash-account-menu--guest" role="menu" aria-label="Account">
        <div class="fash-account-guest-copy">
          <strong>Hello, Guest</strong>
          <span>Sign in to manage your account</span>
        </div>
        <a href="register.html" class="fash-account-guest-cta" role="menuitem">Create account</a>
        <a href="login.html" class="fash-account-guest-login" role="menuitem">Already have an account? Sign in</a>
      </div>`;
  }

  return `
    <div class="fash-account-menu fash-account-menu--member" role="menu" aria-label="Account">
      <a class="fash-account-summary fash-account-summary-link" href="account.html" role="menuitem">
        <div class="fash-account-avatar" aria-hidden="true">${firstName.charAt(0).toUpperCase()}</div>
        <div class="fash-account-user-copy">
          <strong>${greeting}</strong>
          <span>${user.email || "Manage your account"}</span>
        </div>
        <span class="fash-account-chevron" aria-hidden="true">›</span>
      </a>

      <div class="fash-account-links">
        <a href="orders.html" role="menuitem">My Orders</a>
        <a href="wishlist.html" role="menuitem">Saved Items</a>
        <a href="notifications.html" role="menuitem">Notifications</a>
      </div>

      ${seller ? `
        <div class="fash-account-seller">
          <a href="seller-dashboard.html" role="menuitem">Seller Dashboard <span>›</span></a>
        </div>` : ""}

      <div class="fash-account-footer">
        <a href="settings.html" role="menuitem">Account Settings</a>
        <button type="button" class="fash-account-signout" role="menuitem">Sign out</button>
      </div>
    </div>`;
}

/*==================================================
FASH NAVBAR
DYNAMIC NAVBAR LOADER
==================================================*/

document.addEventListener("DOMContentLoaded", function () {

    const navbar = document.getElementById("navbar");

    if (!navbar) {
        return;
    }


    /*==================================================
    DETECT LOCATION
    ==================================================*/

    const isPagesFolder =
        window.location.pathname.includes("/pages/");


    const navbarPath =
        isPagesFolder
            ? "../components/navbar.html"
            : "components/navbar.html";


    /*==================================================
    LOAD NAVBAR
    ==================================================*/

    fetch(navbarPath)

        .then(function (response) {

            if (!response.ok) {
                throw new Error(
                    "Navbar failed to load: " +
                    response.status
                );
            }

            return response.text();

        })

        .then(function (data) {

            navbar.innerHTML = data;



            /* Fix all navbar paths */
            fixNavbarPaths(isPagesFolder);


            /* Set active navigation */
            setActiveNavigation();


            /* Setup navbar search */
            setupNavbarSearch();
            if (window.FASHSmartSearch) window.FASHSmartSearch.attach(document.getElementById("navbarSearch"));

            // Navbar HTML now exists, so update the badges immediately.
            updateFashNavbarCounters();

            setTimeout(updateFashNavbarCounters, 50);
            setTimeout(updateFashNavbarCounters, 250);

            window.dispatchEvent(
                new CustomEvent("fash:navbar-ready")
            );

            /*
             * Final refresh after the event so cart,
             * wishlist and alerts all use persisted
             * localStorage values on every page.
             */
            setTimeout(function () {
                updateFashNavbarCounters();
            }, 10);


            console.log(
                "FASH Navbar loaded successfully."
            );

        })

        .catch(function (error) {

            console.error(
                "FASH Navbar Error:",
                error
            );

        });

});


/*==================================================
FIX NAVBAR PATHS
==================================================*/


// v5.1 safe account greeting helper
function getFashAccountGreeting(user) {
  if (!user) return "Hello, Guest";
  const rawName = String(user.name || user.first_name || user.username || "there").trim();
  const firstName = rawName.split(/\s+/)[0] || "there";
  const isNewSignup = sessionStorage.getItem("fashNewSignup") === "1";
  if (isNewSignup) {
    sessionStorage.removeItem("fashNewSignup");
    return `Welcome, ${firstName}`;
  }
  return `Welcome back, ${firstName}`;
}


function fixNavbarPaths(isPagesFolder) {

    /*
     * components/navbar.html is shared by the root page and /pages/.
     * The old code only rewrote a small list of links, which left
     * Become a Seller and Account pointing to ../pages/... from the
     * root index.html. That produces "Cannot GET /pages/..." or a
     * browser file-path error.
     *
     * Rewrite every internal FASH page link relative to the page
     * currently displaying the navbar.
     */

    const pagePrefix = isPagesFolder ? "" : "pages/";

    document.querySelectorAll("#navbar a[href]").forEach(function (link) {

        const original = link.getAttribute("href");
        if (!original) return;

        if (
            original === "#" ||
            original.startsWith("#") ||
            /^(https?:|mailto:|tel:|javascript:)/i.test(original)
        ) {
            return;
        }

        const parts = original.split("?");
        const path = parts[0];
        const query = parts.length > 1 ? "?" + parts.slice(1).join("?") : "";

        const match = path.match(/(?:\.\.\/)*pages\/([^/]+\.html)$/i) ||
                      path.match(/(?:\.\.\/)*([^/]+\.html)$/i);

        if (!match) return;

        const file = match[1];

        if (file === "index.html") {
            link.href = isPagesFolder ? "../index.html" : "index.html";
        } else {
            link.href = isPagesFolder
                ? file + query
                : pagePrefix + file + query;
        }

    });

    /*
     * Account should never point at an invalid ../pages/register.html
     * path from index.html. Keep the intended FASH behaviour:
     * logged-out users go to Register; logged-in users go to the
     * appropriate dashboard.
     */

    const accountRoot = document.querySelector("#navAccount");
    if (accountRoot) {
        let session = null;
        try { session = JSON.parse(localStorage.getItem("fashCurrentUser") || "null"); } catch (_) {}
        const registerUrl = isPagesFolder ? "register.html" : "pages/register.html";
        const loginUrl = isPagesFolder ? "login.html" : "pages/login.html";

        const name = session?.name || session?.fullName || "Guest";
        const nameEl = accountRoot.querySelector("#navAccountName");
        const labelEl = accountRoot.querySelector(".account-trigger-label");
        const trigger = accountRoot.querySelector(".account-trigger");
        const dropdown = accountRoot.querySelector(".account-dropdown");

        if (nameEl) nameEl.textContent = session ? name : "Guest";
        if (labelEl) labelEl.textContent = session ? `Welcome back, ${name.split(/\s+/)[0]}` : "Account";

        // Guests are sent directly to registration instead of seeing the
        // logged-in account menu.
        if (!session) {
            dropdown?.setAttribute("hidden", "hidden");
            trigger?.addEventListener("click", () => {
                window.location.href = registerUrl;
            });
        } else {
            dropdown?.removeAttribute("hidden");
            const accountHeader = accountRoot.querySelector('[data-account-option="account-header"]');
            if (accountHeader) accountHeader.href = isPagesFolder ? "account.html" : "pages/account.html";

            const account = accountRoot.querySelector('[data-account-option="account"]');
            const seller = accountRoot.querySelector('[data-account-option="seller"]');
            if (account) account.href = isPagesFolder ? "account.html" : "pages/account.html";
            if (seller) seller.hidden = !(session.role === "seller" || session.sellerStatus || session.sellerApplication);

            trigger?.addEventListener("click", (event) => {
                event.preventDefault();
                event.stopPropagation();
                const open = accountRoot.classList.toggle("open");
                trigger.setAttribute("aria-expanded", String(open));
            });

            document.addEventListener("click", (event) => {
                if (!accountRoot.contains(event.target)) {
                    accountRoot.classList.remove("open");
                    trigger?.setAttribute("aria-expanded", "false");
                }
            });

            document.addEventListener("keydown", (event) => {
                if (event.key === "Escape") {
                    accountRoot.classList.remove("open");
                    trigger?.setAttribute("aria-expanded", "false");
                }
            });
        }

        syncFashAccountFromBackend(accountRoot, isPagesFolder);
        accountRoot.querySelector("[data-fash-logout]")?.addEventListener("click", () => {
            if (window.FASH_API?.clearSession) window.FASH_API.clearSession();
            else {
                localStorage.removeItem("fashAuthToken");
                localStorage.removeItem("fashCurrentUser");
            }
            window.location.href = isPagesFolder ? "shop.html" : "pages/shop.html";
        });
    }

    /* Become Seller must always resolve correctly. */

    document.querySelectorAll(
        '#navbar a[href*="become-seller.html"]'
    ).forEach(function (link) {
        link.href = isPagesFolder
            ? "become-seller.html"
            : "pages/become-seller.html";
    });

}


/*==================================================
ACCOUNT — BACKEND SOURCE OF TRUTH
==================================================*/
async function syncFashAccountFromBackend(accountRoot, isPagesFolder) {
    // BUGFIX: this used to read localStorage.getItem("fashAuthToken"), a key
    // nothing in the app ever writes to (the real token is stored under
    // "fash_token" by api-client.js). Because that check always failed, this
    // function returned immediately for every user, so the navbar never
    // synced account state from the backend and could keep showing a guest
    // state even for a logged-in customer.
    const token = localStorage.getItem("fash_token");
    if (!token && !localStorage.getItem("fash_user")) return;
    try {
        const base = window.FASH_API_BASE || "http://localhost:5000";
        const response = await fetch(`${base}/api/auth/me`, {
            headers: token ? { Authorization: `Bearer ${token}` } : {},
            credentials: "include"
        });
        if (!response.ok) return;
        const payload = await response.json();
        const user = payload?.user || payload;
        if (!user?.id) return;

        const status = String(user.seller_status || "none").toLowerCase();
        const approvedSeller = status === "approved" || user.role === "seller";
        const session = {
            id: user.id,
            name: user.full_name || "",
            fullName: user.full_name || "",
            email: user.email || "",
            role: user.role || "customer",
            sellerStatus: status,
            emailVerified: user.email_verified ?? false
        };
        localStorage.setItem("fashCurrentUser", JSON.stringify(session));

        const name = user.full_name || "Guest";
        accountRoot.querySelector(".account-dropdown")?.removeAttribute("hidden");
        const nameEl = accountRoot.querySelector("#navAccountName");
        const labelEl = accountRoot.querySelector(".account-trigger-label");
        if (nameEl) nameEl.textContent = name;
        if (labelEl) labelEl.textContent = `Welcome back, ${name.split(/\s+/)[0] || "Account"}`;
        const trigger = accountRoot.querySelector(".account-trigger");
        if (trigger && !trigger.dataset.authMenuBound) {
            trigger.dataset.authMenuBound = "1";
            trigger.onclick = (event) => {
                event.preventDefault();
                const open = accountRoot.classList.toggle("open");
                trigger.setAttribute("aria-expanded", String(open));
            };
        }

        const account = accountRoot.querySelector('[data-account-option="account"]');
        const seller = accountRoot.querySelector('[data-account-option="seller"]');
        const customize = accountRoot.querySelector('[data-account-option="customize-store"]');
        const addProduct = accountRoot.querySelector('[data-account-option="add-product"]');
        const becomeSeller = accountRoot.querySelector('[data-account-option="become-seller"]');
        if (account) account.href = isPagesFolder ? "account.html" : "pages/account.html";
        if (seller) seller.hidden = !approvedSeller;
        if (customize) customize.hidden = !approvedSeller;
        if (addProduct) addProduct.hidden = !approvedSeller;
        if (becomeSeller) becomeSeller.hidden = approvedSeller || ["pending","under_review","changes_requested"].includes(status);
    } catch (error) {
        console.debug("FASH account refresh skipped:", error);
    }
}

/*==================================================
ACTIVE NAVIGATION
==================================================*/

function setActiveNavigation() {

    let currentPage =
        window.location.pathname
            .split("/")
            .pop();


    if (
        !currentPage ||
        currentPage === ""
    ) {

        currentPage = "index.html";

    }


    /* Remove previous active classes */

    document
        .querySelectorAll(
            "#navbar .nav-menu a"
        )
        .forEach(function (link) {

            link.classList.remove(
                "active"
            );

        });


    /* Add correct active class */

    document
        .querySelectorAll(
            "#navbar .nav-menu > li > a"
        )
        .forEach(function (link) {

            const href =
                link.getAttribute("href");


            if (!href) {
                return;
            }


            if (
                currentPage === "index.html" &&
                href.includes("index.html")
            ) {

                link.classList.add(
                    "active"
                );

            }


            else if (
                currentPage === "shop.html" &&
                href.includes("shop.html")
            ) {

                link.classList.add(
                    "active"
                );

            }


            else if (
                currentPage === "categories.html" &&
                href.includes("categories.html")
            ) {

                link.classList.add(
                    "active"
                );

            }


            else if (
                currentPage === "stores.html" &&
                href.includes("stores.html")
            ) {

                link.classList.add(
                    "active"
                );

            }


            else if (
                currentPage === "deals.html" &&
                href.includes("deals.html")
            ) {

                link.classList.add(
                    "active"
                );

            }


            else if (
                currentPage === "contact.html" &&
                href.includes("contact.html")
            ) {

                link.classList.add(
                    "active"
                );

            }

        });

}


/*==================================================
NAVBAR SEARCH
==================================================*/

function setupNavbarSearch() {

    const searchBox =
        document.querySelector(
            "#navbar .search-box"
        );


    if (!searchBox) {
        return;
    }


    const input =
        searchBox.querySelector(
            "input"
        );


    const button =
        searchBox.querySelector(
            "button"
        );


    if (!input) {
        return;
    }


    /*==========================================
    ENTER KEY
    ==========================================*/

    input.addEventListener(
        "keydown",
        function (event) {

            if (
                event.key === "Enter"
            ) {

                if (window.FASHSmartSearch) window.FASHSmartSearch.go(input.value); else performNavbarSearch(input.value);

            }

        }
    );


    /*==========================================
    SEARCH BUTTON
    ==========================================*/

    if (button) {

        button.addEventListener(
            "click",
            function () {

                if (window.FASHSmartSearch) window.FASHSmartSearch.go(input.value); else performNavbarSearch(input.value);

            }
        );

    }

}


/*==================================================
PERFORM NAVBAR SEARCH
==================================================*/

function performNavbarSearch(value) {

    const searchTerm =
        value.trim();


    if (!searchTerm) {
        return;
    }


    /*
    If already on Shop,
    update the Shop search boxes.
    */

    if (
        window.location.pathname
            .includes("/pages/shop.html")
    ) {

        const shopSearch =
            document.getElementById(
                "shopSearch"
            );


        const productSearch =
            document.getElementById(
                "productSearch"
            );


        if (shopSearch) {
            shopSearch.value =
                searchTerm;

            shopSearch.dispatchEvent(
                new Event(
                    "input",
                    {
                        bubbles: true
                    }
                )
            );

        }


        if (
            productSearch &&
            productSearch !== shopSearch
        ) {

            productSearch.value =
                searchTerm;

        }


        return;

    }


    /*
    From index.html or another page,
    open Shop with the search term.
    */

    const shopPath =
        window.location.pathname
            .includes("/pages/")
            ? "shop.html"
            : "pages/shop.html";


    window.location.href =
        shopPath +
        "?search=" +
        encodeURIComponent(
            searchTerm
        );

}
/*========================================================
FASH MARKETPLACE
NAVBAR.JS
CART + WISHLIST PERSISTENCE
========================================================*/

"use strict";


/*========================================================
STORAGE KEYS
========================================================*/

const FASH_STORAGE = {
    cart: "fash_cart",
    legacyCart: "cart",
    wishlist: "fash_wishlist"
};


/*========================================================
GET CART
========================================================*/

function getFashCart() {
    try {
        const saved = JSON.parse(localStorage.getItem(FASH_STORAGE.cart));
        if (Array.isArray(saved)) return saved;

        const legacy = JSON.parse(localStorage.getItem(FASH_STORAGE.legacyCart));
        if (Array.isArray(legacy)) {
            localStorage.setItem(FASH_STORAGE.cart, JSON.stringify(legacy));
            return legacy;
        }
    } catch (error) {
        console.error("FASH cart could not be loaded:", error);
    }
    return [];
}


/*========================================================
GET WISHLIST
========================================================*/

function getFashWishlist() {

    try {

        const wishlist =
            JSON.parse(
                localStorage.getItem(
                    FASH_STORAGE.wishlist
                )
            );

        return Array.isArray(wishlist)
            ? wishlist
            : [];

    } catch (error) {

        console.error(
            "FASH wishlist could not be loaded:",
            error
        );

        return [];

    }

}


/*========================================================
UPDATE CART COUNTER
========================================================*/

function updateFashCartCounter() {

    const cart = getFashCart();


    /*
        Count total quantities.

        Example:

        Product A = quantity 2
        Product B = quantity 1

        Counter = 3
    */

    const total = cart.reduce(

        function (sum, item) {

            return sum +
                (Number(item.quantity) || 0);

        },

        0

    );


    document
        .querySelectorAll(
            "#cartCount, .cart-count"
        )
        .forEach(function (counter) {

            counter.textContent = total;

            /*
                Keep counter visible only
                when there is something inside.
            */

            counter.style.display = "flex";
            counter.hidden = false;

        });

}


/*========================================================
UPDATE WISHLIST COUNTER
========================================================*/

function updateFashWishlistCounter() {

    const wishlist =
        getFashWishlist();


    /*
        Wishlist stores product IDs.

        Therefore each ID = 1 wishlist item.
    */

    const total =
        wishlist.length;


    document
        .querySelectorAll(
            "#wishlistCount, .wishlist-count"
        )
        .forEach(function (counter) {

            counter.textContent = total;


            counter.style.display = "flex";
            counter.hidden = false;

        });

}


/*========================================================
UPDATE BOTH COUNTERS
========================================================*/

function updateFashNavbarCounters() {

    updateFashCartCounter();

    updateFashWishlistCounter();

    /*
     * Notifications are stored in the same localStorage database.
     * Recalculate the unread count every time the navbar loads
     * so the badge survives page-to-page navigation.
     */
    if (typeof updateFashNotificationsCounter === "function") {
        updateFashNotificationsCounter();
    }

}


/*========================================================
LISTEN FOR SHOP.JS UPDATES
========================================================*/

window.addEventListener(
    "fash:cart-updated",
    function () {

        updateFashCartCounter();

    }
);


window.addEventListener(
    "fash:wishlist-updated",
    function () {

        updateFashWishlistCounter();

    }
);


/*========================================================
LISTEN FOR STORAGE CHANGES
========================================================
This also helps if another page/tab changes
the cart or wishlist.
========================================================*/

window.addEventListener(
    "storage",
    function (event) {

        if (
            event.key === FASH_STORAGE.cart ||
            event.key === FASH_STORAGE.wishlist
        ) {

            updateFashNavbarCounters();

        }

    }
);








/*========================================================
FASH ALERT SYSTEM
ONE EVENT = ONE ALERT
INDIVIDUAL READ STATE
GMAIL-STYLE DETAIL VIEW
========================================================*/

const FASH_ALERT_STORAGE = "fash_alerts";

function getFashNotifications() {

    try {

        const saved =
            JSON.parse(
                localStorage.getItem(FASH_ALERT_STORAGE)
            );

        return Array.isArray(saved) ? saved : [];

    } catch {

        return [];

    }

}

function saveFashNotifications(alerts) {

    localStorage.setItem(
        FASH_ALERT_STORAGE,
        JSON.stringify(alerts.slice(0, 50))
    );

}

function updateFashNotificationsCounter() {

    const unread =
        getFashNotifications()
            .filter(alert => !alert.read)
            .length;

    document
        .querySelectorAll("#alertsCount, .alerts-count")
        .forEach(counter => {

            counter.textContent = unread;
            counter.style.display = "flex";
            counter.hidden = false;

        });

}

function addFashAlert(
    type,
    title,
    message,
    extra = {}
) {

    const alerts = getFashNotifications();

    alerts.unshift({

        id:
            "ALERT-" +
            Date.now() +
            "-" +
            Math.random()
                .toString(36)
                .slice(2, 7),

        type: type || "info",

        title: title || "FASH Update",

        message: message || "",

        productId:
            extra.productId || "",

        productTitle:
            extra.productTitle || "",

        action:
            extra.action || "",

        time: Date.now(),

        read: false

    });

    saveFashNotifications(alerts);

    updateFashNotificationsCounter();

    window.dispatchEvent(
        new CustomEvent("fash:alerts-updated")
    );

}

function markFashAlertRead(id) {

    const alerts = getFashNotifications();

    const updated = alerts.map(alert => {

        if (String(alert.id) !== String(id)) {
            return alert;
        }

        return {
            ...alert,
            read: true
        };

    });

    saveFashNotifications(updated);
    updateFashNotificationsCounter();

    window.dispatchEvent(
        new CustomEvent("fash:alerts-updated")
    );

}

function markFashAlertUnread(id) {

    const alerts = getFashNotifications();

    saveFashNotifications(
        alerts.map(alert =>
            String(alert.id) === String(id)
                ? { ...alert, read: false }
                : alert
        )
    );

    updateFashNotificationsCounter();

    window.dispatchEvent(
        new CustomEvent("fash:alerts-updated")
    );

}

function removeFashAlert(id) {

    const alerts =
        getFashNotifications().filter(
            alert =>
                String(alert.id) !== String(id)
        );

    saveFashNotifications(alerts);

    updateFashNotificationsCounter();

    window.dispatchEvent(
        new CustomEvent("fash:alerts-updated")
    );

}

function markAllFashNotificationsRead() {

    saveFashNotifications(
        getFashNotifications().map(alert => ({
            ...alert,
            read: true
        }))
    );

    updateFashNotificationsCounter();

    window.dispatchEvent(
        new CustomEvent("fash:alerts-updated")
    );

}

function clearFashNotifications() {

    localStorage.removeItem(
        FASH_ALERT_STORAGE
    );

    updateFashNotificationsCounter();

    window.dispatchEvent(
        new CustomEvent("fash:alerts-updated")
    );

}

window.FASHNotifications = {

    get: getFashNotifications,

    add: addFashAlert,

    markRead: markFashAlertRead,

    markUnread: markFashAlertUnread,

    remove: removeFashAlert,

    markAllRead: markAllFashNotificationsRead,

    clear: clearFashNotifications,

    refresh: updateFashNotificationsCounter

};


/*========================================================
CART — EXACTLY ONE ALERT PER ADD / REMOVE / CLEAR
Quantity changes do NOT create alerts.
========================================================*/

window.addEventListener(
    "fash:cart-updated",
    function (event) {

        const detail =
            event.detail || {};

        if (
            !detail.action ||
            detail.action === "quantity"
        ) {
            updateFashNotificationsCounter();
            return;
        }

        if (detail.action === "add") {

            addFashAlert(
                "cart",
                "Product added to cart",
                detail.productTitle
                    ? `"${detail.productTitle}" was added to your cart.`
                    : "A product was added to your cart.",
                detail
            );

            return;

        }

        if (detail.action === "remove") {

            addFashAlert(
                "cart",
                "Product removed from cart",
                detail.productTitle
                    ? `"${detail.productTitle}" was removed from your cart.`
                    : "A product was removed from your cart.",
                detail
            );

            return;

        }

        if (detail.action === "clear") {

            addFashAlert(
                "cart",
                "Cart cleared",
                "Your cart was cleared.",
                detail
            );

        }

    }
);


/*========================================================
WISHLIST — EXACTLY ONE ALERT PER ADD / REMOVE
========================================================*/

window.addEventListener(
    "fash:wishlist-updated",
    function (event) {

        const detail =
            event.detail || {};

        if (!detail.action) {

            updateFashNotificationsCounter();
            return;

        }

        if (detail.action === "add") {

            addFashAlert(
                "wishlist",
                "Product added to wishlist",
                detail.productTitle
                    ? `"${detail.productTitle}" was added to your wishlist.`
                    : "A product was added to your wishlist.",
                detail
            );

            return;

        }

        if (detail.action === "remove") {

            addFashAlert(
                "wishlist",
                "Product removed from wishlist",
                detail.productTitle
                    ? `"${detail.productTitle}" was removed from your wishlist.`
                    : "A product was removed from your wishlist.",
                detail
            );

        }

    }
);


/*========================================================
KEEP COUNTER SYNCHRONIZED
========================================================*/

window.addEventListener(
    "storage",
    function (event) {

        if (
            event.key === FASH_ALERT_STORAGE ||
            event.key === "fash_cart" ||
            event.key === "fash_wishlist"
        ) {

            updateFashNavbarCounters();
            updateFashNotificationsCounter();

        }

    }
);

window.addEventListener(
    "fash:alerts-updated",
    updateFashNotificationsCounter
);


/* Initial persisted-state refresh for direct page navigation. */
if (document.readyState !== "loading") {
    setTimeout(function () {
        updateFashNavbarCounters();
    }, 0);
}




document.addEventListener("fash:navbar-ready", async function(){
  const root=document.getElementById("navAccount"); if(!root) return;
  let u=null; try{u=JSON.parse(localStorage.getItem("fashCurrentUser")||"null")}catch{}
  const account=root.querySelector('[data-account-option="account"]');
  const seller=root.querySelector('[data-account-option="seller"]');
  const store=root.querySelector('[data-account-option="customize-store"]');
  const add=root.querySelector('[data-account-option="add-product"]');
  if(account) account.href=u ? "account.html" : "register.html";
  const isSeller=!!u && ["approved"].includes(String(u.seller_status||"").toLowerCase());
  [seller,store,add].forEach(x=>{if(x)x.hidden=!isSeller});
  if(u){
    const n=document.getElementById("navAccountName"); if(n)n.textContent=u.full_name||u.name||"Guest";
    const l=root.querySelector(".account-trigger-label"); if(l)l.textContent=`Welcome back, ${(u.full_name||u.name||"").split(" ")[0]}`;
  }
});

window.buildFashAccountMenu = window.buildFashAccountMenu || buildFashAccountMenu;
