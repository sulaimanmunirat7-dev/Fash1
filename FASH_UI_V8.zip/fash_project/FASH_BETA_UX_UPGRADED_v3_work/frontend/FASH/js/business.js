/* =====================================================
   FASH BUSINESS PAGE JAVASCRIPT
   Marketplace Business System
===================================================== */


document.addEventListener("DOMContentLoaded",()=>{


const searchInput =
document.getElementById("businessSearch");


const businessContainer =
document.getElementById("businessContainer");


const trendingContainer =
document.getElementById("trendingBusinesses");


const categoryButtons =
document.querySelectorAll(".category");





/* ================= BUSINESS DATABASE ================= */


const businesses=[

{
name:"Nova Fashion",
category:"Fashion",
followers:"25K",
location:"Lagos",
rating:"4.9",
image:"images/business-fashion.jpg",
logo:"images/logo-fashion.png",
verified:true
},


{
name:"Tech Empire",
category:"Electronics",
followers:"18K",
location:"Abuja",
rating:"4.8",
image:"images/business-tech.jpg",
logo:"images/logo-tech.png",
verified:true
},


{
name:"Fresh Foods",
category:"Food",
followers:"12K",
location:"Port Harcourt",
rating:"4.7",
image:"images/business-food.jpg",
logo:"images/logo-food.png",
verified:true
},


{
name:"Urban Beauty",
category:"Beauty",
followers:"30K",
location:"Lagos",
rating:"5.0",
image:"images/business-beauty.jpg",
logo:"images/logo-beauty.png",
verified:true
}


];







let activeCategory="All";

let searchTerm="";







/* ================= CREATE CARD ================= */


function createBusinessCard(business){


const following =
localStorage.getItem(
`follow-${business.name}`
)==="true";



return `


<article class="business-card">


<div class="business-cover">

<img src="${business.image}"
alt="${business.name}">

</div>



<div class="business-profile">


<img src="${business.logo}"
class="business-logo"
alt="${business.name} logo">



<h3>

${business.name}

${business.verified ?

`
<span class="verified">

<i class="fa-solid fa-circle-check"></i>

</span>

`

:""}

</h3>




<p>

${business.category}

</p>





<div class="business-rating">

⭐ ${business.rating}

<span>
Reviews
</span>

</div>





<div class="business-details">


<span>

<i class="fa-solid fa-users"></i>

${business.followers}

</span>



<span>

<i class="fa-solid fa-location-dot"></i>

${business.location}

</span>



</div>






<button 
class="follow-btn ${following?"following":""}"
data-business="${business.name}">


${following?

`
<i class="fa-solid fa-check"></i>
Following
`

:

`
<i class="fa-solid fa-user-plus"></i>
Follow
`

}



</button>





</div>


</article>



`;

}








/* ================= DISPLAY BUSINESSES ================= */


function renderBusinesses(){


let filtered =
businesses.filter(business=>{


const matchesSearch =

business.name
.toLowerCase()
.includes(searchTerm)

||

business.category
.toLowerCase()
.includes(searchTerm);



const matchesCategory =

activeCategory==="All"

||

business.category===activeCategory;



return matchesSearch && matchesCategory;



});



businessContainer.innerHTML="";



filtered.forEach(business=>{


businessContainer.innerHTML +=
createBusinessCard(business);


});



attachFollowEvents();


}









/* ================= TRENDING ================= */


function loadTrending(){



trendingContainer.innerHTML="";



businesses.forEach(business=>{


trendingContainer.innerHTML +=
createBusinessCard(business);


});



attachFollowEvents();



}









/* ================= FOLLOW SYSTEM ================= */


function attachFollowEvents(){



const buttons =
document.querySelectorAll(".follow-btn");



buttons.forEach(button=>{



button.onclick=()=>{



const name =
button.dataset.business;



const isFollowing =
button.classList.contains("following");





if(isFollowing){


localStorage.removeItem(
`follow-${name}`
);



button.classList.remove(
"following"
);



button.innerHTML=

`
<i class="fa-solid fa-user-plus"></i>
Follow
`;



button.style.background="";



}



else{


localStorage.setItem(
`follow-${name}`,
"true"
);



button.classList.add(
"following"
);



button.innerHTML=

`
<i class="fa-solid fa-check"></i>
Following
`;



button.style.background=
"var(--success)";


}



};



});



}









/* ================= SEARCH ================= */


searchInput.addEventListener(
"input",
()=>{


searchTerm =
searchInput.value
.toLowerCase();



renderBusinesses();



});









/* ================= CATEGORY ================= */


categoryButtons.forEach(button=>{


button.addEventListener(
"click",
()=>{


categoryButtons.forEach(btn=>

btn.classList.remove("active")

);



button.classList.add("active");



activeCategory =
button.textContent.trim();



renderBusinesses();



});



});









/* ================= START ================= */


renderBusinesses();


loadTrending();



});