"use strict";

document.addEventListener("DOMContentLoaded", () => {

    const viewDocs =
        document.getElementById("viewDocs");

    const developerContact =
        document.getElementById("developerContact");

    const ctaDeveloper =
        document.getElementById("ctaDeveloper");

    const footerYear =
        document.getElementById("footerYear");

    const cardLinks =
        document.querySelectorAll(".card-link");


    /*==================================================
    VIEW DOCUMENTATION
    ==================================================*/

    if (viewDocs) {

        viewDocs.addEventListener("click", () => {

            window.location.href =
                "../pages/developer-docs.html";

        });

    }


    /*==================================================
    CONTACT DEVELOPERS
    ==================================================*/

    if (developerContact) {

        developerContact.addEventListener("click", () => {

            window.location.href =
                "mailto:developers@fash.com?subject=FASH%20Developer%20Enquiry";

        });

    }


    /*==================================================
    DEVELOPER CARD LINKS
    ==================================================*/

    cardLinks.forEach((link) => {

        link.addEventListener("click", () => {

            const action =
                link.dataset.action;

            if (action === "api") {

                window.location.href =
                    "../pages/developer-docs.html#api";

            }

            else if (action === "tools") {

                window.location.href =
                    "../pages/developer-docs.html#tools";

            }

            else if (action === "docs") {

                window.location.href =
                    "../pages/developer-docs.html";

            }

            else if (action === "web") {

                window.location.href =
                    "../pages/developer-docs.html#web";

            }

        });

    });


    /*==================================================
    CTA
    ==================================================*/

    if (ctaDeveloper) {

        ctaDeveloper.addEventListener("click", () => {

            window.location.href =
                "mailto:developers@fash.com?subject=FASH%20Developer%20Enquiry";

        });

    }


    /*==================================================
    FOOTER YEAR
    ==================================================*/

    if (footerYear) {

        footerYear.textContent =
            `© ${new Date().getFullYear()} FASH. All rights reserved.`;

    }

});