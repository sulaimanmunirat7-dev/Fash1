/*==================================================
FASH PRODUCT DETAILS
PART 3 — REAL PRODUCT DATA
==================================================*/

"use strict";


/*==================================================
GET PRODUCT ID
==================================================*/

function getProductIdFromURL() {

    const params = new URLSearchParams(
        window.location.search
    );

    return params.get("id");

}


/*==================================================
GET PRODUCTS
==================================================*/

function getFashProducts() {

    /*
     * Use the products already loaded by shop.js.
     */

    if (
        window.FASHShop &&
        Array.isArray(window.FASHShop.products)
    ) {
        return window.FASHShop.products;
    }


    /*
     * Fallback to localStorage if the shop
     * has already saved the products there.
     */

    const possibleKeys = [
        "fash_products",
        "FASH_products",
        "products"
    ];

    for (const key of possibleKeys) {

        try {

            const data =
                JSON.parse(
                    localStorage.getItem(key)
                );

            if (Array.isArray(data)) {
                return data;
            }

        } catch (error) {

            console.warn(
                "Could not read products from:",
                key
            );

        }

    }


    return [];

}


/*==================================================
FIND PRODUCT
==================================================*/

function findFashProduct(productId) {

    const products =
        getFashProducts();

    return products.find(
        product =>
            String(product.id) ===
            String(productId)
    );

}


/*==================================================
CURRENCY
==================================================*/

function formatFashPrice(value) {

    const number =
        Number(value) || 0;

    return new Intl.NumberFormat(
        "en-NG",
        {
            style: "currency",
            currency: "NGN",
            maximumFractionDigits: 0
        }
    ).format(number);

}


/*==================================================
DISCOUNT
==================================================*/

function calculateDiscount(product) {

    const price =
        Number(product.price) || 0;

    const oldPrice =
        Number(
            product.oldPrice ||
            product.originalPrice ||
            product.previousPrice ||
            0
        );

    if (
        !oldPrice ||
        oldPrice <= price
    ) {
        return 0;
    }

    return Math.round(
        ((oldPrice - price) / oldPrice) * 100
    );

}


/*==================================================
PRODUCT IMAGE
==================================================*/

function getProductImage(product) {

    return (
        product.image ||
        product.imageUrl ||
        product.thumbnail ||
        "../assets/images/logos/Logo.png"
    );

}


/*==================================================
PRODUCT DESCRIPTION
==================================================*/

function getProductDescription(product) {

    return (
        product.description ||
        product.desc ||
        "No description is available for this product yet."
    );

}


/*==================================================
SELLER
==================================================*/

function getProductSeller(product) {

    return (
        product.seller ||
        product.sellerName ||
        product.store ||
        product.storeName ||
        "FASH Seller"
    );

}


/*==================================================
RATING
==================================================*/

function getProductRating(product) {

    return Number(
        product.rating ||
        product.stars ||
        0
    );

}


function getProductReviews(product) {

    return Number(
        product.reviews ||
        product.reviewCount ||
        0
    );

}


/*==================================================
RENDER PRODUCT
==================================================*/

function renderFashProduct(product) {

    if (!product) return;


    /* Image */

    const image =
        document.getElementById(
            "productImage"
        );

    if (image) {

        image.src =
            getProductImage(product);

        image.alt =
            product.title ||
            product.name ||
            "Product";

    }


    /* Category */

    const category =
        document.getElementById(
            "productCategory"
        );

    if (category) {

        category.textContent =
            product.category ||
            "Product";

    }


    /* Title */

    const title =
        document.getElementById(
            "productTitle"
        );

    if (title) {

        title.textContent =
            product.title ||
            product.name ||
            "Product";

    }


    /* Rating */

    const rating =
        getProductRating(product);

    const ratingElement =
        document.getElementById(
            "productRating"
        );

    if (ratingElement) {

        ratingElement.textContent =
            rating.toFixed(1);

    }


    /* Reviews */

    const reviews =
        getProductReviews(product);

    const reviewsElement =
        document.getElementById(
            "productReviews"
        );

    if (reviewsElement) {

        reviewsElement.textContent =
            `${reviews} review${reviews === 1 ? "" : "s"}`;

    }


    /* Stars */

    renderFashStars(rating);


    /* Price */

    const price =
        document.getElementById(
            "productPrice"
        );

    if (price) {

        price.textContent =
            formatFashPrice(
                product.price
            );

    }


    /* Old Price */

    const oldPriceValue =
        Number(
            product.oldPrice ||
            product.originalPrice ||
            product.previousPrice ||
            0
        );

    const oldPrice =
        document.getElementById(
            "productOldPrice"
        );

    if (oldPrice) {

        if (oldPriceValue > Number(product.price || 0)) {

            oldPrice.textContent =
                formatFashPrice(
                    oldPriceValue
                );

            oldPrice.style.display =
                "inline";

        } else {

            oldPrice.style.display =
                "none";

        }

    }


    /* Discount */

    const discount =
        calculateDiscount(product);

    const discountElement =
        document.getElementById(
            "productDiscount"
        );

    if (discountElement) {

        if (discount > 0) {

            discountElement.textContent =
                `${discount}% OFF`;

            discountElement.style.display =
                "inline-flex";

        } else {

            discountElement.style.display =
                "none";

        }

    }


    /* Description */

    const description =
        document.getElementById(
            "productDescription"
        );

    if (description) {

        description.textContent =
            getProductDescription(product);

    }


    /* Seller */

    const seller =
        document.getElementById(
            "productSeller"
        );

    if (seller) {

        seller.textContent =
            getProductSeller(product);

    }


    /* Seller link */

    const sellerLink =
        document.getElementById(
            "sellerStoreLink"
        );

    if (
        sellerLink &&
        product.storeId
    ) {

        sellerLink.href =
            `stores.html?id=${encodeURIComponent(
                product.storeId
            )}`;

    }


    /* Stock */

    renderFashStock(product);

}


/*==================================================
STARS
==================================================*/

function renderFashStars(rating) {

    const stars =
        document.getElementById(
            "productStars"
        );

    if (!stars) return;


    stars.innerHTML = "";


    for (
        let i = 1;
        i <= 5;
        i++
    ) {

        const icon =
            document.createElement("i");

        icon.className =
            i <= Math.round(rating)
                ? "fa-solid fa-star"
                : "fa-regular fa-star";

        stars.appendChild(icon);

    }

}


/*==================================================
STOCK
==================================================*/

function renderFashStock(product) {

    const stock =
        document.getElementById(
            "productStock"
        );

    if (!stock) return;


    const quantity =
        Number(
            product.stock ??
            product.quantity ??
            1
        );


    if (quantity <= 0) {

        stock.innerHTML = `
            <i class="fa-solid fa-circle-xmark"></i>
            Out of Stock
        `;

        stock.classList.add(
            "out-of-stock"
        );

        return;

    }


    stock.innerHTML = `
        <i class="fa-solid fa-circle-check"></i>
        In Stock
    `;

}


/*==================================================
QUANTITY
==================================================*/

let fashProductQuantity = 1;


function setupFashQuantity(product) {

    const quantity =
        document.getElementById(
            "productQuantity"
        );

    const minus =
        document.getElementById(
            "quantityMinus"
        );

    const plus =
        document.getElementById(
            "quantityPlus"
        );

    if (
        !quantity ||
        !minus ||
        !plus
    ) {
        return;
    }


    const stock =
        Number(
            product.stock ??
            product.quantity ??
            99
        );


    function updateQuantity() {

        quantity.textContent =
            fashProductQuantity;

    }


    minus.addEventListener(
        "click",
        function () {

            if (
                fashProductQuantity > 1
            ) {

                fashProductQuantity--;

                updateQuantity();

            }

        }
    );


    plus.addEventListener(
        "click",
        function () {

            if (
                fashProductQuantity < stock
            ) {

                fashProductQuantity++;

                updateQuantity();

            }

        }
    );


    updateQuantity();

}


/*==================================================
ADD TO CART
==================================================*/

function setupFashAddToCart(product) {

    const button = document.getElementById("addToCartButton");
    if (!button) return;

    button.addEventListener("click", function () {

        const quantity = Math.max(1, Number(fashProductQuantity) || 1);

        /* Use the SAME cart system as Shop.
           It expects the product ID, not the whole object. */
        if (window.FASHShop && typeof window.FASHShop.addToCart === "function") {

            for (let i = 0; i < quantity; i++) {
                window.FASHShop.addToCart(product.id);
            }

        } else if (typeof window.addToCart === "function") {

            for (let i = 0; i < quantity; i++) {
                window.addToCart(product.id);
            }

        } else {
            console.warn("FASH cart system is not available.");
            return;
        }

        button.innerHTML = `
            <i class="fa-solid fa-check"></i>
            Added to Cart
        `;

        setTimeout(function () {
            button.innerHTML = `
                <i class="fa-solid fa-cart-shopping"></i>
                Add to Cart
            `;
        }, 1500);

    });

}


/*==================================================
WISHLIST
==================================================*/

function setupFashWishlist(product) {

    const button = document.getElementById("addToWishlistButton");
    if (!button || !product || product.id == null) return;

    const key = "fash_wishlist";
    const productId = String(product.id);
    button.dataset.wishlistToggle = productId;

    function readWishlist() {
        try {
            const list = JSON.parse(localStorage.getItem(key)) || [];
            return Array.isArray(list) ? list : [];
        } catch {
            return [];
        }
    }

    function isSaved() {
        if (window.FASHShop && typeof window.FASHShop.isWishlisted === "function") {
            return window.FASHShop.isWishlisted(productId);
        }
        return readWishlist().map(String).includes(productId);
    }

    function updateButton() {
        const saved = isSaved();
        button.innerHTML = saved
            ? '<i class="fa-solid fa-heart"></i>'
            : '<i class="fa-regular fa-heart"></i>';
        button.classList.toggle("active", saved);
        button.classList.toggle("is-wishlisted", saved);
        button.setAttribute("aria-pressed", String(saved));
        button.setAttribute("aria-label", saved ? "Remove from Saved Items" : "Add to Saved Items");
    }

    button.addEventListener("click", function (event) {
        event.preventDefault();
        event.stopPropagation();

        if (window.FASHShop && typeof window.FASHShop.toggleWishlist === "function") {
            window.FASHShop.toggleWishlist(productId);
        } else {
            const list = readWishlist();
            const exists = list.map(String).includes(productId);
            const next = exists
                ? list.filter(item => String(item) !== productId)
                : [...list, product.id];
            localStorage.setItem(key, JSON.stringify(next));
            window.dispatchEvent(new CustomEvent("fash:wishlist-updated", {
                detail: { action: exists ? "remove" : "add", productId: product.id, productTitle: product.title || "" }
            }));
        }
        updateButton();
    });

    window.addEventListener("fash:wishlist-updated", function (event) {
        const changed = event.detail && event.detail.productId;
        if (changed == null || String(changed) === productId) updateButton();
    });

    window.addEventListener("storage", function (event) {
        if (event.key === key) updateButton();
    });

    updateButton();
}


/*==================================================
RELATED PRODUCTS
==================================================*/

function renderRelatedFashProducts(product) {

    const grid = document.getElementById("relatedProductsGrid");
    if (!grid) return;

    const products = getFashProducts();

    if (!products.length) {
        grid.innerHTML = "";
        return;
    }

    /*
     * Prefer products from the same category, then fill the
     * remaining spaces with other products so the section
     * never looks empty.
     */
    const sameCategory = products.filter(item =>
        String(item.id) !== String(product.id) &&
        String(item.category || "").toLowerCase() ===
        String(product.category || "").toLowerCase()
    );

    const otherProducts = products.filter(item =>
        String(item.id) !== String(product.id) &&
        !sameCategory.some(x => String(x.id) === String(item.id))
    );

    const related = [...sameCategory, ...otherProducts].slice(0, 4);

    grid.innerHTML = related.map(item => {

        const title = item.title || item.name || "Product";
        const price = Number(item.price) || 0;
        const oldPrice = Number(item.oldPrice) || 0;
        const discount = oldPrice > price
            ? Math.round((1 - price / oldPrice) * 100)
            : 0;
        const rating = Number(item.rating) || 0;
        const reviews = Number(item.reviews) || 0;
        const image = getProductImage(item);
        const category = item.category || "Product";
        const badge = item.badge || (discount ? "Sale" : "Featured");

        return `
            <article
                class="related-product-card"
                data-related-product="${String(item.id).replace(/"/g, '&quot;')}">

                <a
                    href="product.html?id=${encodeURIComponent(item.id)}"
                    class="related-product-link"
                    aria-label="View ${title}">

                    <div class="related-product-image">

                        <span class="related-product-badge">
                            ${badge}
                        </span>

                        ${discount ? `
                            <span class="related-discount-badge">
                                -${discount}%
                            </span>
                        ` : ""}

                        <img
                            src="${image}"
                            alt="${title.replace(/"/g, '&quot;')}"
                            loading="lazy">

                    </div>

                    <div class="related-product-content">

                        <span class="related-product-category">
                            ${category}
                        </span>

                        <h3>
                            ${title}
                        </h3>

                        <div class="related-product-rating">
                            <span class="related-stars">
                                ${"★".repeat(Math.max(0, Math.min(5, Math.round(rating))))}
                            </span>
                            <strong>${rating.toFixed(1)}</strong>
                            <span>(${reviews.toLocaleString()})</span>
                        </div>

                        <div class="related-product-price">
                            <strong>
                                ${formatFashPrice(price)}
                            </strong>

                            ${oldPrice > price ? `
                                <del>
                                    ${formatFashPrice(oldPrice)}
                                </del>
                            ` : ""}
                        </div>

                    </div>

                </a>

                <div class="related-product-actions">

                    <button
                        type="button"
                        class="related-add-cart"
                        data-related-cart="${String(item.id).replace(/"/g, '&quot;')}">

                        <i class="fa-solid fa-cart-plus"></i>
                        Add to Cart

                    </button>

                    <button
                        type="button"
                        class="related-wishlist"
                        data-related-wishlist="${String(item.id).replace(/"/g, '&quot;')}"
                        aria-label="Add to wishlist">

                        <i class="fa-regular fa-heart"></i>

                    </button>

                </div>

            </article>
        `;

    }).join("");

    /* Related-product cart buttons */
    grid.querySelectorAll("[data-related-cart]").forEach(button => {

        button.addEventListener("click", event => {

            event.preventDefault();
            event.stopPropagation();

            const id = button.dataset.relatedCart;

            if (window.FASHShop && typeof window.FASHShop.addToCart === "function") {
                window.FASHShop.addToCart(id);
            }

            button.innerHTML = `
                <i class="fa-solid fa-check"></i>
                Added
            `;

            setTimeout(() => {
                button.innerHTML = `
                    <i class="fa-solid fa-cart-plus"></i>
                    Add to Cart
                `;
            }, 1200);

        });

    });

    /* Related-product wishlist buttons */
    grid.querySelectorAll("[data-related-wishlist]").forEach(button => {

        button.addEventListener("click", event => {

            event.preventDefault();
            event.stopPropagation();

            const id = button.dataset.relatedWishlist;

            if (window.FASHShop && typeof window.FASHShop.toggleWishlist === "function") {
                window.FASHShop.toggleWishlist(id);
            }

            const active = button.classList.toggle("active");

            button.innerHTML = active
                ? `<i class="fa-solid fa-heart"></i>`
                : `<i class="fa-regular fa-heart"></i>`;

        });

    });

}

/*==================================================
PAGE INITIALIZATION
==================================================*/

function initializeFashProductPage() {

    const productId =
        getProductIdFromURL();


    if (!productId) {

        console.warn(
            "No product ID was supplied."
        );

        return;

    }


    const product =
        findFashProduct(productId);


    if (!product) {

        console.warn(
            "Product not found:",
            productId
        );

        const title =
            document.getElementById(
                "productTitle"
            );

        if (title) {

            title.textContent =
                "Product not found";

        }

        return;

    }


    renderFashProduct(
        product
    );


    setupFashQuantity(
        product
    );


    setupFashAddToCart(
        product
    );


    setupFashWishlist(
        product
    );


    renderRelatedFashProducts(
        product
    );

}


/*==================================================
START
==================================================*/

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        initializeFashProductPage,
        { once: true }
    );

} else {

    initializeFashProductPage();

}