/* FASH v6.7 Customer Data — Cart & Wishlist persistence */
(function () {
  "use strict";

  function list(payload, keys) {
    if (Array.isArray(payload)) return payload;
    for (const key of keys) if (payload && Array.isArray(payload[key])) return payload[key];
    return [];
  }

  async function getCart() {
    if (!window.FASH_API?.getCart) throw new Error("Cart API is unavailable");
    return window.FASH_API.getCart();
  }

  async function addToCart(productId, quantity = 1) {
    return window.FASH_API.addCartItem(productId, quantity);
  }

  async function updateCart(itemId, quantity) {
    return window.FASH_API.updateCartItem(itemId, quantity);
  }

  async function removeFromCart(itemId) {
    return window.FASH_API.removeCartItem(itemId);
  }

  async function getWishlist() {
    if (!window.FASH_API?.getWishlist) throw new Error("Wishlist API is unavailable");
    return window.FASH_API.getWishlist();
  }

  async function saveItem(productId) {
    return window.FASH_API.addWishlistItem(productId);
  }

  async function removeSavedItem(productId) {
    return window.FASH_API.removeWishlistItem(productId);
  }

  window.FASH_CUSTOMER_DATA = {
    list,
    getCart, addToCart, updateCart, removeFromCart,
    getWishlist, saveItem, removeSavedItem
  };
})();
