/* FASH v6.8 — Orders, Checkout & Returns */
(function () {
  "use strict";

  function api() {
    if (!window.FASH_API) throw new Error("FASH API client is unavailable");
    return window.FASH_API;
  }

  window.FASH_CHECKOUT = {
    createOrder(payload) {
      return api().post("/api/orders", payload || {});
    },

    getOrders() {
      return api().get("/api/orders");
    },

    getOrder(orderId) {
      return api().get(`/api/orders/${encodeURIComponent(orderId)}`);
    },

    requestReturn(orderId, payload) {
      return api().post(
        `/api/orders/${encodeURIComponent(orderId)}/returns`,
        payload || {}
      );
    }
  };
})();
