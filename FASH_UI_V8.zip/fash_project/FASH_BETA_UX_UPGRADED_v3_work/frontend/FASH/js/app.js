/*==================================================
FASH
HOMEPAGE APPLICATION
==================================================*/

"use strict";


/*==================================================
APP
==================================================*/

const App = {

    init(){

        console.log("FASH App Started");

    }

};


/*==================================================
START APPLICATION
==================================================*/

document.addEventListener("DOMContentLoaded", () => {

    App.init();

});
/*==================================================
NAVIGATION
==================================================*/

const Navigation = {

    init(){

        this.activeLink();

        this.navbarScroll();

        this.smoothScroll();


    },


    /*==================================================
    ACTIVE NAVIGATION LINK
    ==================================================*/

    activeLink(){

        const currentPage =
            window.location.pathname
                .split("/")
                .pop() || "index.html";


        const links =
            document.querySelectorAll(
                ".nav-menu a"
            );


        links.forEach(link => {

            link.classList.remove("active");


            const href =
                link.getAttribute("href");


            if(!href) return;


            const linkPage =
                href.split("/").pop();


            if(
                linkPage === currentPage
            ){

                link.classList.add("active");

            }

        });

    },


    /*==================================================
    NAVBAR SCROLL
    ==================================================*/

    navbarScroll(){

        const navbar =
            document.querySelector(".navbar");


        if(!navbar) return;


        const handleScroll = () => {

            if(window.scrollY > 40){

                navbar.classList.add(
                    "navbar-scrolled"
                );

            }else{

                navbar.classList.remove(
                    "navbar-scrolled"
                );

            }

        };


        handleScroll();


        window.addEventListener(
            "scroll",
            handleScroll,
            {
                passive:true
            }
        );

    },


    /*==================================================
    SMOOTH SCROLL
    ==================================================*/

    smoothScroll(){

        const links =
            document.querySelectorAll(
                'a[href^="#"]'
            );


        links.forEach(link => {

            link.addEventListener(
                "click",
                event => {

                    const targetId =
                        link.getAttribute("href");


                    if(
                        !targetId ||
                        targetId === "#"
                    ){

                        return;

                    }


                    const target =
                        document.querySelector(
                            targetId
                        );


                    if(!target) return;


                    event.preventDefault();


                    target.scrollIntoView({

                        behavior:"smooth",

                        block:"start"

                    });

                }
            );

        });

    }

};


/*==================================================
START NAVIGATION
==================================================*/

Navigation.init();
/*==================================================
HERO
==================================================*/

const Hero = {

    init(){

        this.counter();

        this.floatingCards();

        this.mouseEffect();

        this.scrollButton();

    },


    /*==================================================
    HERO COUNTERS
    ==================================================*/

    counter(){

        const counters =
            document.querySelectorAll(".counter");

        if(!counters.length) return;


        const hero =
            document.querySelector(".hero");


        const startCounters = () => {

            counters.forEach(counter => {

                const target =
                    Number(
                        counter.dataset.target
                    );


                if(!Number.isFinite(target)){
                    return;
                }


                const duration = 1800;

                const startTime =
                    performance.now();


                const animate = currentTime => {

                    const elapsed =
                        currentTime - startTime;


                    const progress =
                        Math.min(
                            elapsed / duration,
                            1
                        );


                    /*
                    Smooth ease-out
                    */

                    const eased =
                        1 -
                        Math.pow(
                            1 - progress,
                            3
                        );


                    const value =
                        Math.floor(
                            target * eased
                        );


                    counter.textContent =
                        value.toLocaleString();


                    if(progress < 1){

                        requestAnimationFrame(
                            animate
                        );

                    }else{

                        counter.textContent =
                            target.toLocaleString();

                    }

                };


                requestAnimationFrame(
                    animate
                );

            });

        };


        /*
        Start when Hero enters
        the screen.
        */

        if(!hero){

            startCounters();

            return;

        }


        const observer =
            new IntersectionObserver(

                entries => {

                    entries.forEach(entry => {

                        if(entry.isIntersecting){

                            startCounters();

                            observer.disconnect();

                        }

                    });

                },

                {
                    threshold:0.3
                }

            );


        observer.observe(hero);

    },


    /*==================================================
    FLOATING PRODUCT CARDS
    ==================================================*/

    floatingCards(){

        const cards =
            document.querySelectorAll(
                ".floating-card"
            );


        if(!cards.length) return;


        cards.forEach((card,index) => {

            const distance =
                6 + (index * 2);


            const duration =
                2800 + (index * 350);


            card.animate(

                [

                    {
                        transform:
                            "translateY(0)"
                    },

                    {
                        transform:
                            `translateY(-${distance}px)`
                    },

                    {
                        transform:
                            "translateY(0)"
                    }

                ],

                {

                    duration:duration,

                    iterations:Infinity,

                    easing:"ease-in-out"

                }

            );

        });

    },


    /*==================================================
    HERO MOUSE EFFECT
    ==================================================*/

    mouseEffect(){

        const hero =
            document.querySelector(".hero");


        const image =
            document.querySelector(
                ".hero-main-image"
            );


        if(!hero || !image) return;


        /*
        Don't run the mouse effect
        on touch devices.
        */

        if(
            window.matchMedia(
                "(pointer: coarse)"
            ).matches
        ){

            return;

        }


        hero.addEventListener(
            "mousemove",
            event => {

                const rect =
                    hero.getBoundingClientRect();


                const x =
                    event.clientX -
                    rect.left;


                const y =
                    event.clientY -
                    rect.top;


                const moveX =
                    (x / rect.width - 0.5) *
                    12;


                const moveY =
                    (y / rect.height - 0.5) *
                    12;


                image.style.transform =
                    `translate(${moveX}px, ${moveY}px)`;

            }
        );


        hero.addEventListener(
            "mouseleave",
            () => {

                image.style.transform =
                    "translate(0, 0)";

            }
        );

    },


    /*==================================================
    HERO SCROLL BUTTON
    ==================================================*/

    scrollButton(){

        const button =
            document.querySelector(
                ".scroll-down a"
            );


        if(!button) return;


        button.addEventListener(
            "click",
            event => {

                const categories =
                    document.querySelector(
                        "#categories"
                    );


                if(!categories) return;


                event.preventDefault();


                categories.scrollIntoView({

                    behavior:"smooth",

                    block:"start"

                });

            }
        );

    }

};


/*==================================================
START HERO
==================================================*/

Hero.init();
/*==================================================
FEATURED PRODUCT
==================================================*/

const FeaturedProduct = {

    products: [

        {
            title: "ASUS ROG Strix G16 Gaming Laptop",
            category: "Electronics",
            price: "₦950,000",
            oldPrice: "₦1,150,000",
            save: "Save ₦200,000",
            discount: "-20%",
            rating: "4.8",
            reviews: "245 Reviews",
            sold: "1,287 Sold",

            description:
                "Experience desktop-level performance with the ASUS ROG Strix G16. Powered by Intel Core i7, RTX 4060 graphics, 16GB RAM and a 1TB SSD, it's built for gaming, programming and professional work.",

            specs: [
                "Intel Core i7",
                "RTX 4060",
                "16GB RAM",
                "1TB SSD",
                "165Hz Display"
            ],

            stock: "In Stock",
            remaining: "Only 8 Left",
            viewing: "43 Viewing",
            shipping: "Ships from Lagos",
            delivery: "Delivery in 1–3 Days",

            images: [
                "assets/images/products/laptop.png",
                "assets/images/products/laptop2.png",
                "assets/images/products/laptop3.png",
                "assets/images/products/laptop4.png"
            ]
        },


        {
            title: "iPhone 16 Pro Max",
            category: "Phones",
            price: "₦2,150,000",
            oldPrice: "₦2,350,000",
            save: "Save ₦200,000",
            discount: "-9%",
            rating: "4.9",
            reviews: "524 Reviews",
            sold: "2,110 Sold",

            description:
                "Apple's flagship smartphone featuring powerful performance, a premium titanium design and a professional camera system.",

            specs: [
                "A18 Pro",
                "512GB",
                "48MP Camera",
                "6.9 OLED",
                "5G"
            ],

            stock: "In Stock",
            remaining: "Only 12 Left",
            viewing: "67 Viewing",
            shipping: "Ships from Lagos",
            delivery: "Delivery in 1–3 Days",

            images: [
                "assets/images/products/phone.png",
                "assets/images/products/phone2.png",
                "assets/images/products/phone3.png",
                "assets/images/products/phone4.png"
            ]
        },


        {
            title: "Nike Air Max 2026",
            category: "Fashion",
            price: "₦85,000",
            oldPrice: "₦120,000",
            save: "Save ₦35,000",
            discount: "-29%",
            rating: "4.7",
            reviews: "840 Reviews",
            sold: "5,320 Sold",

            description:
                "Premium sneakers built for comfort, style and all-day performance.",

            specs: [
                "Air Max",
                "Lightweight",
                "Breathable",
                "Rubber Sole",
                "Unisex"
            ],

            stock: "In Stock",
            remaining: "Only 15 Left",
            viewing: "38 Viewing",
            shipping: "Ships from Lagos",
            delivery: "Delivery in 1–3 Days",

            images: [
                "assets/images/products/shoes.png",
                "assets/images/products/shoes2.png",
                "assets/images/products/shoes3.png",
                "assets/images/products/shoes4.png"
            ]
        }

    ],


    currentProduct: 0,
    currentImage: 0,
    autoPlayTimer: null,


    /*==================================================
    INITIALIZE
    ==================================================*/

    init(){

        const section =
            document.querySelector(
                ".featured-container"
            );

        if(!section) return;

        this.cacheElements();

        this.loadProduct(0);

        this.setupGallery();

        this.setupNavigation();

        this.setupActions();

        this.startAutoPlay();

    },


    /*==================================================
    CACHE ELEMENTS
    ==================================================*/

    cacheElements(){

        this.mainImage =
            document.getElementById(
                "featuredMainImage"
            );

        this.title =
            document.getElementById(
                "featuredTitle"
            );

        this.category =
            document.querySelector(
                ".product-category"
            );

        this.currentPrice =
            document.querySelector(
                ".current-price"
            );

        this.oldPrice =
            document.querySelector(
                ".old-price"
            );

        this.savePrice =
            document.querySelector(
                ".save-price"
            );

        this.description =
            document.querySelector(
                ".product-description"
            );

        this.specs =
            document.querySelector(
                ".product-specs"
            );

        this.rating =
            document.querySelector(
                ".product-rating"
            );

        this.status =
            document.querySelector(
                ".product-status"
            );

        this.delivery =
            document.querySelector(
                ".delivery-info"
            );

        this.discount =
            document.querySelector(
                ".discount-badge"
            );

        this.nextButton =
            document.getElementById(
                "featuredNext"
            );

        this.previousButton =
            document.getElementById(
                "featuredPrev"
            );

        this.thumbnails =
            document.querySelectorAll(
                ".gallery-item"
            );

    },


    /*==================================================
    LOAD PRODUCT
    ==================================================*/

    loadProduct(index){

        const product =
            this.products[index];

        if(!product) return;

        this.currentProduct = index;

        this.currentImage = 0;


        if(this.title){

            this.title.textContent =
                product.title;

        }


        if(this.category){

            this.category.textContent =
                product.category;

        }


        if(this.currentPrice){

            this.currentPrice.textContent =
                product.price;

        }


        if(this.oldPrice){

            this.oldPrice.textContent =
                product.oldPrice;

        }


        if(this.savePrice){

            this.savePrice.textContent =
                product.save;

        }


        if(this.description){

            this.description.textContent =
                product.description;

        }


        if(this.discount){

            this.discount.textContent =
                product.discount;

        }


        if(this.mainImage){

            this.mainImage.src =
                product.images[0];

            this.mainImage.alt =
                product.title;

        }


        this.updateRating(product);

        this.updateSpecs(product.specs);

        this.updateStatus(product);

        this.updateDelivery(product);

        this.updateThumbnails(product);

    },


    /*==================================================
    RATING
    ==================================================*/

    updateRating(product){

        if(!this.rating) return;

        const spans =
            this.rating.querySelectorAll(
                "span"
            );

        if(spans[0]){

            spans[0].textContent =
                product.rating;

        }

        if(spans[1]){

            spans[1].textContent =
                `(${product.reviews})`;

        }

        if(spans[2]){

            spans[2].textContent =
                `• ${product.sold}`;

        }

    },


    /*==================================================
    SPECIFICATIONS
    ==================================================*/

    updateSpecs(specifications){

        if(!this.specs) return;

        this.specs.innerHTML = "";

        specifications.forEach(spec => {

            const item =
                document.createElement("span");

            item.textContent = spec;

            this.specs.appendChild(item);

        });

    },


    /*==================================================
    STATUS
    ==================================================*/

    updateStatus(product){

        if(!this.status) return;

        const items =
            this.status.querySelectorAll(
                "div"
            );

        if(items[0]){

            items[0].innerHTML = `
                <i class="fa-solid fa-circle-check"></i>
                ${product.stock}
            `;

        }

        if(items[1]){

            items[1].innerHTML = `
                <i class="fa-solid fa-fire"></i>
                ${product.remaining}
            `;

        }

        if(items[2]){

            items[2].innerHTML = `
                <i class="fa-solid fa-eye"></i>
                ${product.viewing}
            `;

        }

    },


    /*==================================================
    DELIVERY
    ==================================================*/

    updateDelivery(product){

        if(!this.delivery) return;

        const items =
            this.delivery.querySelectorAll(
                "div"
            );

        if(items[0]){

            items[0].innerHTML = `
                <i class="fa-solid fa-location-dot"></i>
                ${product.shipping}
            `;

        }

        if(items[1]){

            items[1].innerHTML = `
                <i class="fa-solid fa-truck-fast"></i>
                ${product.delivery}
            `;

        }

    },


    /*==================================================
    GALLERY
    ==================================================*/

    setupGallery(){

        if(!this.thumbnails.length) return;

        this.thumbnails.forEach(
            (thumbnail, index) => {

                thumbnail.addEventListener(
                    "click",
                    () => {

                        this.changeImage(index);

                    }
                );

            }
        );

    },


    /*==================================================
    CHANGE IMAGE
    ==================================================*/

    changeImage(index){

        const product =
            this.products[
                this.currentProduct
            ];

        if(!product) return;

        if(!product.images[index]) return;

        this.currentImage = index;


        if(this.mainImage){

            this.mainImage.style.opacity = "0";

            setTimeout(() => {

                this.mainImage.src =
                    product.images[index];

                this.mainImage.style.opacity =
                    "1";

            }, 150);

        }


        this.thumbnails.forEach(
            (thumbnail, thumbnailIndex) => {

                thumbnail.classList.toggle(
                    "active",
                    thumbnailIndex === index
                );

            }
        );

    },


    /*==================================================
    UPDATE THUMBNAILS
    ==================================================*/

    updateThumbnails(product){

        this.thumbnails.forEach(
            (thumbnail, index) => {

                const image =
                    thumbnail.querySelector(
                        "img"
                    );

                if(!image) return;

                if(product.images[index]){

                    image.src =
                        product.images[index];

                    image.alt =
                        product.title;

                }

                thumbnail.classList.toggle(
                    "active",
                    index === 0
                );

            }
        );

    },


    /*==================================================
    NEXT / PREVIOUS
    ==================================================*/

    setupNavigation(){

        if(this.nextButton){

            this.nextButton.addEventListener(
                "click",
                () => {

                    this.next();

                }
            );

        }


        if(this.previousButton){

            this.previousButton.addEventListener(
                "click",
                () => {

                    this.previous();

                }
            );

        }

    },


    next(){

        this.currentProduct++;

        if(
            this.currentProduct >=
            this.products.length
        ){

            this.currentProduct = 0;

        }

        this.loadProduct(
            this.currentProduct
        );

        this.restartAutoPlay();

    },


    previous(){

        this.currentProduct--;

        if(this.currentProduct < 0){

            this.currentProduct =
                this.products.length - 1;

        }

        this.loadProduct(
            this.currentProduct
        );

        this.restartAutoPlay();

    },


    /*==================================================
    AUTO PLAY
    ==================================================*/

    startAutoPlay(){

        if(this.products.length <= 1){

            return;

        }

        this.autoPlayTimer =
            setInterval(() => {

                this.next();

            }, 7000);

    },


    restartAutoPlay(){

        clearInterval(
            this.autoPlayTimer
        );

        this.startAutoPlay();

    },


    /*==================================================
    PRODUCT ACTIONS
    ==================================================*/

    setupActions(){

        const addButton =
            document.querySelector(
                ".featured-actions .btn-primary"
            );

        const buyButton =
            document.querySelector(
                ".featured-actions .btn-buy"
            );

        const wishlistButton =
            document.querySelector(
                ".featured-actions .btn-wishlist"
            );


        if(addButton){

            addButton.addEventListener(
                "click",
                () => {

                    const product =
                        this.products[
                            this.currentProduct
                        ];

                    const original =
                        addButton.innerHTML;

                    addButton.innerHTML = `
                        <i class="fa-solid fa-check"></i>
                        Added to Cart
                    `;

                    addButton.classList.add(
                        "added"
                    );


                    setTimeout(() => {

                        addButton.innerHTML =
                            original;

                        addButton.classList.remove(
                            "added"
                        );

                    }, 1500);


                    console.log(
                        "Added:",
                        product.title
                    );

                }
            );

        }


        if(buyButton){

            buyButton.addEventListener(
                "click",
                () => {

                    const product =
                        this.products[
                            this.currentProduct
                        ];

                    console.log(
                        "Buy Now:",
                        product.title
                    );

                }
            );

        }


        if(wishlistButton){

            wishlistButton.addEventListener(
                "click",
                () => {

                    wishlistButton.classList.toggle(
                        "active"
                    );

                    const icon =
                        wishlistButton.querySelector(
                            "i"
                        );

                    if(icon){

                        icon.classList.toggle(
                            "fa-regular"
                        );

                        icon.classList.toggle(
                            "fa-solid"
                        );

                    }

                }
            );

        }

    }

};


/*==================================================
START FEATURED PRODUCT
==================================================*/

FeaturedProduct.init();
/*==================================================
CATEGORIES
==================================================*/

const Categories = {

    init(){

        this.setupCards();

        this.setupNavigation();

    },


    /*==================================================
    CATEGORY CARDS
    ==================================================*/

    setupCards(){

        const cards =
            document.querySelectorAll(
                ".category-card"
            );

        if(!cards.length) return;


        cards.forEach(card => {

            card.addEventListener(
                "click",
                () => {

                    const category =
                        card.dataset.category;

                    if(!category) return;


                    /*
                    Save selected category
                    so the Shop page can
                    use it later.
                    */

                    localStorage.setItem(
                        "fashSelectedCategory",
                        category
                    );

                }
            );


            /*
            Small premium hover effect
            */

            card.addEventListener(
                "mouseenter",
                () => {

                    card.classList.add(
                        "category-hover"
                    );

                }
            );


            card.addEventListener(
                "mouseleave",
                () => {

                    card.classList.remove(
                        "category-hover"
                    );

                }
            );

        });

    },


    /*==================================================
    CATEGORY NAVIGATION
    ==================================================*/

    setupNavigation(){

        const container =
            document.querySelector(
                ".categories-grid"
            );

        const next =
            document.getElementById(
                "categoriesNext"
            );

        const previous =
            document.getElementById(
                "categoriesPrev"
            );


        /*
        If your homepage doesn't have
        category navigation buttons,
        simply stop here.
        */

        if(
            !container ||
            !next ||
            !previous
        ){

            return;

        }


        next.addEventListener(
            "click",
            () => {

                container.scrollBy({

                    left: 320,

                    behavior: "smooth"

                });

            }
        );


        previous.addEventListener(
            "click",
            () => {

                container.scrollBy({

                    left: -320,

                    behavior: "smooth"

                });

            }
        );

    }

};


/*==================================================
START CATEGORIES
==================================================*/

Categories.init();
/*==================================================
FLASH SALE
==================================================*/

const FlashSale = {

    endTime: null,

    timer: null,


    /*==================================================
    INITIALIZE
    ==================================================*/

    init(){

        const section =
            document.querySelector(
                ".flash-sale"
            );

        if(!section) return;

        this.setupCountdown();

        this.setupProducts();

    },


    /*==================================================
    COUNTDOWN
    ==================================================*/

    setupCountdown(){

        const days =
            document.getElementById(
                "days"
            );

        const hours =
            document.getElementById(
                "hours"
            );

        const minutes =
            document.getElementById(
                "minutes"
            );

        const seconds =
            document.getElementById(
                "seconds"
            );


        if(
            !days ||
            !hours ||
            !minutes ||
            !seconds
        ){

            return;

        }


        /*
        Get the saved ending time.
        This means refreshing the page
        won't reset the countdown.
        */

        const savedEnd =
            localStorage.getItem(
                "fashFlashSaleEnd"
            );


        if(savedEnd){

            this.endTime =
                Number(savedEnd);

        }else{

            /*
            Start a 24-hour sale.
            */

            this.endTime =
                Date.now() +
                (24 * 60 * 60 * 1000);


            localStorage.setItem(
                "fashFlashSaleEnd",
                this.endTime
            );

        }


        const update = () => {

            const now =
                Date.now();


            let remaining =
                this.endTime - now;


            /*
            When the sale ends,
            automatically start another
            24-hour sale.
            */

            if(remaining <= 0){

                this.endTime =
                    Date.now() +
                    (24 * 60 * 60 * 1000);


                localStorage.setItem(
                    "fashFlashSaleEnd",
                    this.endTime
                );


                remaining =
                    this.endTime - Date.now();

            }


            const totalSeconds =
                Math.floor(
                    remaining / 1000
                );


            const dayValue =
                Math.floor(
                    totalSeconds / 86400
                );


            const hourValue =
                Math.floor(
                    (totalSeconds % 86400) /
                    3600
                );


            const minuteValue =
                Math.floor(
                    (totalSeconds % 3600) /
                    60
                );


            const secondValue =
                totalSeconds % 60;


            days.textContent =
                String(
                    dayValue
                ).padStart(2,"0");


            hours.textContent =
                String(
                    hourValue
                ).padStart(2,"0");


            minutes.textContent =
                String(
                    minuteValue
                ).padStart(2,"0");


            seconds.textContent =
                String(
                    secondValue
                ).padStart(2,"0");

        };


        update();


        clearInterval(
            this.timer
        );


        this.timer =
            setInterval(
                update,
                1000
            );

    },


    /*==================================================
    FLASH SALE PRODUCTS
    ==================================================*/

    setupProducts(){

        const cards =
            document.querySelectorAll(
                ".flash-product-card"
            );


        if(!cards.length) return;


        cards.forEach(card => {

            this.setupCartButton(
                card
            );

            this.setupWishlist(
                card
            );

        });

    },


    /*==================================================
    ADD TO CART
    ==================================================*/

    setupCartButton(card){

        const button =
            card.querySelector(
                ".add-to-cart"
            );


        if(!button) return;


        button.addEventListener(
            "click",
            event => {

                event.preventDefault();

                event.stopPropagation();


                const original =
                    button.innerHTML;


                button.classList.add(
                    "added"
                );


                button.innerHTML = `
                    <i class="fa-solid fa-check"></i>
                    Added to Cart
                `;


                setTimeout(() => {

                    button.innerHTML =
                        original;

                    button.classList.remove(
                        "added"
                    );

                },1500);

            }
        );

    },


    /*==================================================
    WISHLIST
    ==================================================*/

    setupWishlist(card){

        const button =
            card.querySelector(
                ".wishlist"
            );


        if(!button) return;


        button.addEventListener(
            "click",
            event => {

                event.preventDefault();

                event.stopPropagation();


                button.classList.toggle(
                    "active"
                );


                const icon =
                    button.querySelector(
                        "i"
                    );


                if(!icon) return;


                icon.classList.toggle(
                    "fa-regular"
                );


                icon.classList.toggle(
                    "fa-solid"
                );

            }
        );

    }

};


/*==================================================
START FLASH SALE
==================================================*/

FlashSale.init();
/*==================================================
PRODUCT SHOWCASE
==================================================*/

const ProductShowcase = {

    init(){

        this.setupCards();

        this.setupCartButtons();

        this.setupWishlistButtons();

    },


    /*==================================================
    PRODUCT CARDS
    ==================================================*/

    setupCards(){

        const cards =
            document.querySelectorAll(
                ".product-card"
            );


        if(!cards.length) return;


        cards.forEach(card => {

            card.addEventListener(
                "mouseenter",
                () => {

                    card.classList.add(
                        "product-hover"
                    );

                }
            );


            card.addEventListener(
                "mouseleave",
                () => {

                    card.classList.remove(
                        "product-hover"
                    );

                }
            );

        });

    },


    /*==================================================
    ADD TO CART
    ==================================================*/

    setupCartButtons(){

        const buttons =
            document.querySelectorAll(
                ".product-card .add-to-cart"
            );


        if(!buttons.length) return;


        buttons.forEach(button => {

            button.addEventListener(
                "click",
                event => {

                    event.preventDefault();

                    event.stopPropagation();


                    const card =
                        button.closest(
                            ".product-card"
                        );


                    const productName =
                        card?.querySelector(
                            ".product-name, h3, h4"
                        )?.textContent ||
                        "Product";


                    const original =
                        button.innerHTML;


                    button.classList.add(
                        "added"
                    );


                    button.innerHTML = `
                        <i class="fa-solid fa-check"></i>
                        Added
                    `;


                    console.log(
                        `${productName} added to cart`
                    );


                    setTimeout(() => {

                        button.innerHTML =
                            original;

                        button.classList.remove(
                            "added"
                        );

                    },1500);

                }
            );

        });

    },


    /*==================================================
    WISHLIST
    ==================================================*/

    setupWishlistButtons(){

        const buttons =
            document.querySelectorAll(
                ".product-card .wishlist"
            );


        if(!buttons.length) return;


        buttons.forEach(button => {

            button.addEventListener(
                "click",
                event => {

                    event.preventDefault();

                    event.stopPropagation();


                    button.classList.toggle(
                        "active"
                    );


                    const icon =
                        button.querySelector(
                            "i"
                        );


                    if(!icon) return;


                    icon.classList.toggle(
                        "fa-regular"
                    );


                    icon.classList.toggle(
                        "fa-solid"
                    );


                    const card =
                        button.closest(
                            ".product-card"
                        );


                    const productName =
                        card?.querySelector(
                            ".product-name, h3, h4"
                        )?.textContent ||
                        "Product";


                    if(
                        button.classList.contains(
                            "active"
                        )
                    ){

                        console.log(
                            `${productName} added to wishlist`
                        );

                    }else{

                        console.log(
                            `${productName} removed from wishlist`
                        );

                    }

                }
            );

        });

    }

};


/*==================================================
START PRODUCT SHOWCASE
==================================================*/

ProductShowcase.init();
/*==================================================
NEWSLETTER
==================================================*/

const Newsletter = {

    init(){

        this.setupForm();

    },


    /*==================================================
    NEWSLETTER FORM
    ==================================================*/

    setupForm(){

        const form =
            document.querySelector(
                ".newsletter-form"
            );

        if(!form) return;


        const input =
            form.querySelector(
                'input[type="email"]'
            );

        const button =
            form.querySelector(
                'button[type="submit"], button'
            );


        if(!input || !button) return;


        form.addEventListener(
            "submit",
            event => {

                event.preventDefault();


                const email =
                    input.value.trim();


                /*======================================
                VALIDATE EMAIL
                ======================================*/

                if(!this.validEmail(email)){

                    this.showMessage(
                        form,
                        "Please enter a valid email address.",
                        "error"
                    );

                    input.focus();

                    return;

                }


                /*======================================
                SUCCESS
                ======================================*/

                const original =
                    button.innerHTML;


                button.disabled = true;


                button.innerHTML = `
                    <i class="fa-solid fa-spinner fa-spin"></i>
                    Subscribing...
                `;


                setTimeout(() => {

                    button.innerHTML = `
                        <i class="fa-solid fa-check"></i>
                        Subscribed
                    `;


                    this.showMessage(
                        form,
                        "You're subscribed! Welcome to FASH.",
                        "success"
                    );


                    input.value = "";


                    setTimeout(() => {

                        button.innerHTML =
                            original;

                        button.disabled = false;

                    },2500);


                },1000);

            }
        );

    },


    /*==================================================
    EMAIL VALIDATION
    ==================================================*/

    validEmail(email){

        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/
            .test(email);

    },


    /*==================================================
    MESSAGE
    ==================================================*/

    showMessage(
        form,
        message,
        type
    ){

        let messageElement =
            form.querySelector(
                ".newsletter-message"
            );


        /*
        Create message element
        if it doesn't exist.
        */

        if(!messageElement){

            messageElement =
                document.createElement(
                    "div"
                );

            messageElement.className =
                "newsletter-message";


            form.appendChild(
                messageElement
            );

        }


        messageElement.textContent =
            message;


        messageElement.className =
            `newsletter-message ${type}`;


        /*
        Remove the message after
        a few seconds.
        */

        setTimeout(() => {

            messageElement.classList.add(
                "hide"
            );

        },4000);

    }

};


/*==================================================
START NEWSLETTER
==================================================*/

Newsletter.init();
/*==================================================
SCROLL & REVEAL
==================================================*/

const ScrollEffects = {

    observer: null,


    /*==================================================
    INITIALIZE
    ==================================================*/

    init(){

        this.prepareElements();

        this.observeElements();

        this.backToTop();

    },


    /*==================================================
    PREPARE ELEMENTS
    ==================================================*/

    prepareElements(){

        const elements =
            document.querySelectorAll(
                ".section-header, " +
                ".category-card, " +
                ".flash-product-card, " +
                ".product-card, " +
                ".featured-container, " +
                ".newsletter"
            );


        if(!elements.length) return;


        elements.forEach(element => {

            /*
            Don't overwrite an existing
            animation class.
            */

            if(
                !element.classList.contains(
                    "scroll-reveal"
                )
            ){

                element.classList.add(
                    "scroll-reveal"
                );

            }

        });

    },


    /*==================================================
    INTERSECTION OBSERVER
    ==================================================*/

    observeElements(){

        const elements =
            document.querySelectorAll(
                ".scroll-reveal"
            );


        if(!elements.length) return;


        /*
        Fallback for browsers that
        don't support IntersectionObserver.
        */

        if(
            !("IntersectionObserver" in window)
        ){

            elements.forEach(element => {

                element.classList.add(
                    "reveal-active"
                );

            });

            return;

        }


        this.observer =
            new IntersectionObserver(
                entries => {

                    entries.forEach(entry => {

                        if(
                            entry.isIntersecting
                        ){

                            entry.target.classList.add(
                                "reveal-active"
                            );


                            this.observer.unobserve(
                                entry.target
                            );

                        }

                    });

                },
                {
                    threshold:0.12,

                    rootMargin:
                        "0px 0px -50px 0px"

                }
            );


        elements.forEach(element => {

            this.observer.observe(
                element
            );

        });

    },


    /*==================================================
    BACK TO TOP
    ==================================================*/

    backToTop(){

        let button =
            document.querySelector(
                "#backToTop"
            );


        /*
        If the button already exists
        in your HTML, use it.
        */

        if(!button){

            return;

        }


        const updateButton = () => {

            if(
                window.scrollY > 500
            ){

                button.classList.add(
                    "show"
                );

            }else{

                button.classList.remove(
                    "show"
                );

            }

        };


        updateButton();


        window.addEventListener(
            "scroll",
            updateButton,
            {
                passive:true
            }
        );


        button.addEventListener(
            "click",
            () => {

                window.scrollTo({

                    top:0,

                    behavior:"smooth"

                });

            }
        );

    }

};


/*==================================================
START SCROLL EFFECTS
==================================================*/

ScrollEffects.init();
/*==================================================
HOMEPAGE UTILITIES
==================================================*/

const HomepageUtilities = {

    init(){

        this.lazyImages();

        this.externalLinks();

        this.imageFallback();

    },


    /*==================================================
    LAZY LOAD IMAGES
    ==================================================*/

    lazyImages(){

        const images =
            document.querySelectorAll(
                "img[data-src]"
            );

        if(!images.length) return;


        if(
            !("IntersectionObserver" in window)
        ){

            images.forEach(image => {

                image.src =
                    image.dataset.src;

            });

            return;

        }


        const observer =
            new IntersectionObserver(
                entries => {

                    entries.forEach(entry => {

                        if(
                            !entry.isIntersecting
                        ){

                            return;

                        }


                        const image =
                            entry.target;


                        image.src =
                            image.dataset.src;


                        image.removeAttribute(
                            "data-src"
                        );


                        observer.unobserve(
                            image
                        );

                    });

                },
                {
                    rootMargin:"150px"

                }
            );


        images.forEach(image => {

            observer.observe(image);

        });

    },


    /*==================================================
    EXTERNAL LINKS
    ==================================================*/

    externalLinks(){

        const links =
            document.querySelectorAll(
                'a[target="_blank"]'
            );


        links.forEach(link => {

            const rel =
                link.getAttribute("rel") || "";


            if(
                !rel.includes("noopener")
            ){

                link.setAttribute(
                    "rel",
                    `${rel} noopener noreferrer`.trim()
                );

            }

        });

    },


    /*==================================================
    IMAGE FALLBACK
    ==================================================*/

    imageFallback(){

        const images =
            document.querySelectorAll(
                "img"
            );


        if(!images.length) return;


        images.forEach(image => {

            image.addEventListener(
                "error",
                () => {

                    /*
                    Prevent an infinite
                    error loop.
                    */

                    if(
                        image.dataset.fallback
                    ){

                        return;

                    }


                    image.dataset.fallback =
                        "true";


                    image.style.objectFit =
                        "contain";


                    image.style.opacity =
                        "0.5";


                    /*
                    Keep the broken image
                    from repeatedly trying
                    to load.
                    */

                    image.removeAttribute(
                        "src"
                    );

                }
            );

        });

    }

};


/*==================================================
START HOMEPAGE UTILITIES
==================================================*/

HomepageUtilities.init();
/*==================================================
CART SYSTEM
==================================================*/

const Cart = {

    items: [],


    /*==================================================
    INITIALIZE
    ==================================================*/

    init(){

        this.load();

        this.updateCount();

        this.setupButtons();

    },


    /*==================================================
    LOAD CART
    ==================================================*/

    load(){

        try{

            const saved =
                localStorage.getItem(
                    "fashCart"
                );


            if(saved){

                this.items =
                    JSON.parse(saved);

            }

        }catch(error){

            console.error(
                "Unable to load cart:",
                error
            );

            this.items = [];

        }

    },


    /*==================================================
    SAVE CART
    ==================================================*/

    save(){

        localStorage.setItem(
            "fashCart",
            JSON.stringify(
                this.items
            )
        );

    },


    /*==================================================
    ADD PRODUCT
    ==================================================*/

    add(product){

        if(!product) return;


        /*
        Create a simple unique ID
        from the product information.
        */

        const id =
            product.id ||
            product.title;


        const existing =
            this.items.find(
                item => item.id === id
            );


        if(existing){

            existing.quantity += 1;

        }else{

            this.items.push({

                id:id,

                title:
                    product.title ||
                    "Product",

                price:
                    product.price ||
                    "₦0",

                image:
                    product.image ||
                    "",

                quantity:1

            });

        }


        this.save();

        this.updateCount();

        this.showNotification(
            product.title ||
            "Product"
        );

    },


    /*==================================================
    REMOVE PRODUCT
    ==================================================*/

    remove(id){

        this.items =
            this.items.filter(
                item =>
                    item.id !== id
            );


        this.save();

        this.updateCount();

    },


    /*==================================================
    CLEAR CART
    ==================================================*/

    clear(){

        this.items = [];

        this.save();

        this.updateCount();

    },


    /*==================================================
    CART COUNT
    ==================================================*/

    updateCount(){

        const count =
            this.items.reduce(
                (total, item) =>
                    total +
                    Number(item.quantity || 0),
                0
            );


        /*
        Supports several common
        cart-count class names.
        */

        const counters =
            document.querySelectorAll(
                ".cart-count, " +
                "#cartCount, " +
                "[data-cart-count]"
            );


        counters.forEach(counter => {

            counter.textContent =
                count;

            counter.classList.toggle(
                "empty",
                count === 0
            );

        });

    },


    /*==================================================
    CONNECT ADD-TO-CART BUTTONS
    ==================================================*/

    setupButtons(){

        /*
        Featured Product
        */

        const featuredButton =
            document.querySelector(
                ".featured-actions .btn-primary"
            );


        if(featuredButton){

            featuredButton.addEventListener(
                "click",
                () => {

                    if(
                        typeof FeaturedProduct ===
                        "undefined"
                    ){

                        return;

                    }


                    const product =
                        FeaturedProduct.products[
                            FeaturedProduct.currentProduct
                        ];


                    if(!product) return;


                    this.add({

                        title:
                            product.title,

                        price:
                            product.price,

                        image:
                            product.images?.[0]

                    });

                }
            );

        }


        /*
        Flash Sale products
        */

        const flashButtons =
            document.querySelectorAll(
                ".flash-product-card .add-to-cart"
            );


        flashButtons.forEach(button => {

            button.addEventListener(
                "click",
                event => {

                    event.preventDefault();

                    event.stopPropagation();


                    const card =
                        button.closest(
                            ".flash-product-card"
                        );


                    if(!card) return;


                    const product =
                        this.getCardProduct(
                            card
                        );


                    this.add(product);

                }
            );

        });


        /*
        Normal product cards
        */

        const productButtons =
            document.querySelectorAll(
                ".product-card .add-to-cart"
            );


        productButtons.forEach(button => {

            button.addEventListener(
                "click",
                event => {

                    event.preventDefault();

                    event.stopPropagation();


                    const card =
                        button.closest(
                            ".product-card"
                        );


                    if(!card) return;


                    const product =
                        this.getCardProduct(
                            card
                        );


                    this.add(product);

                }
            );

        });

    },


    /*==================================================
    GET PRODUCT FROM CARD
    ==================================================*/

    getCardProduct(card){

        const titleElement =
            card.querySelector(
                ".product-name, " +
                ".product-title, " +
                "h3, h4"
            );


        const priceElement =
            card.querySelector(
                ".current-price, " +
                ".product-price, " +
                ".price"
            );


        const imageElement =
            card.querySelector(
                "img"
            );


        return {

            title:
                titleElement?.textContent.trim()
                || "Product",

            price:
                priceElement?.textContent.trim()
                || "₦0",

            image:
                imageElement?.src
                || ""

        };

    },


    /*==================================================
    CART NOTIFICATION
    ==================================================*/

    showNotification(productName){

        let notification =
            document.querySelector(
                ".cart-notification"
            );


        if(!notification){

            notification =
                document.createElement(
                    "div"
                );


            notification.className =
                "cart-notification";


            document.body.appendChild(
                notification
            );

        }


        notification.innerHTML = `
            <i class="fa-solid fa-circle-check"></i>
            <span>
                ${productName} added to cart
            </span>
        `;


        notification.classList.add(
            "show"
        );


        clearTimeout(
            this.notificationTimer
        );


        this.notificationTimer =
            setTimeout(() => {

                notification.classList.remove(
                    "show"
                );

            },2500);

    }

};


/*==================================================
START CART
==================================================*/

Cart.init();
/*==================================================
WISHLIST SYSTEM
==================================================*/

const Wishlist = {

    items: [],


    /*==================================================
    INITIALIZE
    ==================================================*/

    init(){

        this.load();

        this.updateCount();

        this.setupButtons();

    },


    /*==================================================
    LOAD WISHLIST
    ==================================================*/

    load(){

        try{

            const saved =
                localStorage.getItem(
                    "fashWishlist"
                );


            if(saved){

                this.items =
                    JSON.parse(saved);

            }

        }catch(error){

            console.error(
                "Unable to load wishlist:",
                error
            );

            this.items = [];

        }

    },


    /*==================================================
    SAVE WISHLIST
    ==================================================*/

    save(){

        localStorage.setItem(
            "fashWishlist",
            JSON.stringify(
                this.items
            )
        );

    },


    /*==================================================
    ADD / REMOVE
    ==================================================*/

    toggle(product){

        if(!product) return;


        const id =
            product.id ||
            product.title;


        const existing =
            this.items.find(
                item => item.id === id
            );


        if(existing){

            this.items =
                this.items.filter(
                    item =>
                        item.id !== id
                );

        }else{

            this.items.push({

                id:id,

                title:
                    product.title ||
                    "Product",

                price:
                    product.price ||
                    "₦0",

                image:
                    product.image ||
                    ""

            });

        }


        this.save();

        this.updateCount();

        return !existing;

    },


    /*==================================================
    COUNT
    ==================================================*/

    updateCount(){

        const counters =
            document.querySelectorAll(
                ".wishlist-count, " +
                "#wishlistCount, " +
                "[data-wishlist-count]"
            );


        counters.forEach(counter => {

            counter.textContent =
                this.items.length;

            counter.classList.toggle(
                "empty",
                this.items.length === 0
            );

        });

    },


    /*==================================================
    SET BUTTON STATE
    ==================================================*/

    setButtonState(button, active){

        if(!button) return;


        button.classList.toggle(
            "active",
            active
        );


        const icon =
            button.querySelector("i");


        if(!icon) return;


        icon.classList.toggle(
            "fa-regular",
            !active
        );


        icon.classList.toggle(
            "fa-solid",
            active
        );

    },


    /*==================================================
    SETUP WISHLIST BUTTONS
    ==================================================*/

    setupButtons(){

        const buttons =
            document.querySelectorAll(
                ".wishlist, " +
                ".btn-wishlist"
            );


        if(!buttons.length) return;


        buttons.forEach(button => {

            /*
            Prevent this button from
            being initialized twice.
            */

            if(
                button.dataset.wishlistReady ===
                "true"
            ){

                return;

            }


            button.dataset.wishlistReady =
                "true";


            button.addEventListener(
                "click",
                event => {

                    event.preventDefault();

                    event.stopPropagation();


                    const product =
                        this.getProduct(
                            button
                        );


                    if(!product) return;


                    const active =
                        this.toggle(
                            product
                        );


                    this.setButtonState(
                        button,
                        active
                    );


                    this.showNotification(
                        active,
                        product.title
                    );

                }
            );


            /*
            Set the correct state
            when the page loads.
            */

            const product =
                this.getProduct(
                    button
                );


            if(product){

                const id =
                    product.id ||
                    product.title;


                const active =
                    this.items.some(
                        item =>
                            item.id === id
                    );


                this.setButtonState(
                    button,
                    active
                );

            }

        });

    },


    /*==================================================
    GET PRODUCT
    ==================================================*/

    getProduct(button){

        /*
        FEATURED PRODUCT
        */

        if(
            button.classList.contains(
                "btn-wishlist"
            ) &&
            typeof FeaturedProduct !==
            "undefined"
        ){

            const product =
                FeaturedProduct.products[
                    FeaturedProduct.currentProduct
                ];


            if(product){

                return {

                    id:product.title,

                    title:product.title,

                    price:product.price,

                    image:
                        product.images?.[0] ||
                        ""

                };

            }

        }


        /*
        PRODUCT CARD
        */

        const card =
            button.closest(
                ".product-card, " +
                ".flash-product-card"
            );


        if(!card) return null;


        const title =
            card.querySelector(
                ".product-name, " +
                ".product-title, " +
                "h3, h4"
            );


        const price =
            card.querySelector(
                ".current-price, " +
                ".product-price, " +
                ".price"
            );


        const image =
            card.querySelector(
                "img"
            );


        return {

            id:
                title?.textContent.trim()
                || "Product",

            title:
                title?.textContent.trim()
                || "Product",

            price:
                price?.textContent.trim()
                || "₦0",

            image:
                image?.src
                || ""

        };

    },


    /*==================================================
    NOTIFICATION
    ==================================================*/

    showNotification(
        added,
        productName
    ){

        let notification =
            document.querySelector(
                ".wishlist-notification"
            );


        if(!notification){

            notification =
                document.createElement(
                    "div"
                );


            notification.className =
                "wishlist-notification";


            document.body.appendChild(
                notification
            );

        }


        notification.innerHTML = added
            ? `
                <i class="fa-solid fa-heart"></i>
                <span>
                    ${productName} added to wishlist
                </span>
            `
            : `
                <i class="fa-regular fa-heart"></i>
                <span>
                    ${productName} removed from wishlist
                </span>
            `;


        notification.classList.add(
            "show"
        );


        clearTimeout(
            this.notificationTimer
        );


        this.notificationTimer =
            setTimeout(() => {

                notification.classList.remove(
                    "show"
                );

            },2200);

    }

};


/*==================================================
START WISHLIST
==================================================*/

Wishlist.init();
/*==================================================
SEARCH SYSTEM
==================================================*/

const SearchSystem = {

    init(){

        this.setupSearch();

    },


    /*==================================================
    SETUP SEARCH
    ==================================================*/

    setupSearch(){

        const forms =
            document.querySelectorAll(
                ".search-form"
            );


        if(!forms.length) return;


        forms.forEach(form => {

            const input =
                form.querySelector(
                    'input[type="search"], input[type="text"]'
                );


            if(!input) return;


            form.addEventListener(
                "submit",
                event => {

                    event.preventDefault();


                    const query =
                        input.value.trim();


                    if(!query){

                        input.focus();

                        return;

                    }


                    this.search(
                        query
                    );

                }
            );

        });

    },


    /*==================================================
    SEARCH
    ==================================================*/

    search(query){

        /*
        Save the search term so
        shop.html can use it.
        */

        localStorage.setItem(
            "fashSearchQuery",
            query
        );


        /*
        Send the user to the
        Shop page.
        */

        const shopPage =
            window.location.pathname.includes(
                "/pages/"
            )
                ? "shop.html"
                : "pages/shop.html";


        window.location.href =
            `${shopPage}?search=${encodeURIComponent(query)}`;

    }

};


/*==================================================
START SEARCH
==================================================*/

SearchSystem.init();
/*==================================================
MOBILE NAVIGATION
==================================================*/

const MobileNavigation = {

    init(){

        this.cacheElements();

        if(!this.menu || !this.toggle){
            return;
        }

        this.setupToggle();

        this.setupLinks();

        this.setupOutsideClick();

        this.setupEscape();

        this.setupResize();

    },


    /*==================================================
    CACHE ELEMENTS
    ==================================================*/

    cacheElements(){

        this.toggle =
            document.querySelector(
                ".mobile-menu-toggle, " +
                "#mobileMenuToggle, " +
                ".menu-toggle"
            );


        this.menu =
            document.querySelector(
                ".nav-menu"
            );


        this.overlay =
            document.querySelector(
                ".mobile-menu-overlay"
            );

    },


    /*==================================================
    OPEN / CLOSE MENU
    ==================================================*/

    open(){

        this.menu.classList.add(
            "mobile-open"
        );


        this.toggle.classList.add(
            "active"
        );


        document.body.classList.add(
            "menu-open"
        );


        this.toggle.setAttribute(
            "aria-expanded",
            "true"
        );


        if(this.overlay){

            this.overlay.classList.add(
                "show"
            );

        }

    },


    close(){

        this.menu.classList.remove(
            "mobile-open"
        );


        this.toggle.classList.remove(
            "active"
        );


        document.body.classList.remove(
            "menu-open"
        );


        this.toggle.setAttribute(
            "aria-expanded",
            "false"
        );


        if(this.overlay){

            this.overlay.classList.remove(
                "show"
            );

        }

    },


    /*==================================================
    TOGGLE BUTTON
    ==================================================*/

    setupToggle(){

        this.toggle.addEventListener(
            "click",
            event => {

                event.preventDefault();

                event.stopPropagation();


                const isOpen =
                    this.menu.classList.contains(
                        "mobile-open"
                    );


                if(isOpen){

                    this.close();

                }else{

                    this.open();

                }

            }
        );


        this.toggle.setAttribute(
            "aria-expanded",
            "false"
        );

    },


    /*==================================================
    NAVIGATION LINKS
    ==================================================*/

    setupLinks(){

        const links =
            this.menu.querySelectorAll(
                "a"
            );


        links.forEach(link => {

            link.addEventListener(
                "click",
                () => {

                    this.close();

                }
            );

        });

    },


    /*==================================================
    CLICK OUTSIDE
    ==================================================*/

    setupOutsideClick(){

        document.addEventListener(
            "click",
            event => {

                if(
                    !this.menu.classList.contains(
                        "mobile-open"
                    )
                ){

                    return;

                }


                if(
                    this.menu.contains(
                        event.target
                    ) ||
                    this.toggle.contains(
                        event.target
                    )
                ){

                    return;

                }


                this.close();

            }
        );


        if(this.overlay){

            this.overlay.addEventListener(
                "click",
                () => {

                    this.close();

                }
            );

        }

    },


    /*==================================================
    ESC KEY
    ==================================================*/

    setupEscape(){

        document.addEventListener(
            "keydown",
            event => {

                if(
                    event.key === "Escape"
                ){

                    this.close();

                }

            }
        );

    },


    /*==================================================
    WINDOW RESIZE
    ==================================================*/

    setupResize(){

        window.addEventListener(
            "resize",
            () => {

                /*
                Close the mobile menu
                when returning to desktop.
                */

                if(
                    window.innerWidth > 900
                ){

                    this.close();

                }

            }
        );

    }

};


/*==================================================
START MOBILE NAVIGATION
==================================================*/

MobileNavigation.init();
/*==================================================
FASH HOMEPAGE
FINAL CONTROLLER
==================================================*/

const FASHHomepage = {

    /*==================================================
    INITIALIZE
    ==================================================*/

    init(){

        this.markHomepage();

        this.setupSmoothScroll();

        this.setupScrollDown();

        this.setupPageReady();

    },


    /*==================================================
    IDENTIFY HOMEPAGE
    ==================================================*/

    markHomepage(){

        const currentPage =
            window.location.pathname
                .split("/")
                .pop();


        if(
            currentPage === "" ||
            currentPage === "index.html"
        ){

            document.body.classList.add(
                "fash-homepage"
            );

        }

    },


    /*==================================================
    SMOOTH SCROLL
    ==================================================*/

    setupSmoothScroll(){

        const links =
            document.querySelectorAll(
                'a[href^="#"]'
            );


        links.forEach(link => {

            link.addEventListener(
                "click",
                event => {

                    const href =
                        link.getAttribute(
                            "href"
                        );


                    if(
                        !href ||
                        href === "#"
                    ){

                        return;

                    }


                    const target =
                        document.querySelector(
                            href
                        );


                    if(!target){

                        return;

                    }


                    event.preventDefault();


                    target.scrollIntoView({

                        behavior:"smooth",

                        block:"start"

                    });

                }
            );

        });

    },


    /*==================================================
    HERO SCROLL BUTTON
    ==================================================*/

    setupScrollDown(){

        const button =
            document.querySelector(
                ".scroll-down a"
            );


        if(!button) return;


        button.addEventListener(
            "click",
            event => {

                const target =
                    document.querySelector(
                        "#categories"
                    );


                if(!target){

                    return;

                }


                event.preventDefault();


                target.scrollIntoView({

                    behavior:"smooth",

                    block:"start"

                });

            }
        );

    },


    /*==================================================
    PAGE READY
    ==================================================*/

    setupPageReady(){

        window.addEventListener(
            "load",
            () => {

                document.body.classList.add(
                    "page-loaded"
                );

            }
        );

    }

};


/*==================================================
START FASH HOMEPAGE
==================================================*/

FASHHomepage.init();