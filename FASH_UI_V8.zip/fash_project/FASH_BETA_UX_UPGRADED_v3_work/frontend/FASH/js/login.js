/* =========================================================
   FASH — CUSTOMER LOGIN
   login.js
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    /* =====================================================
       ELEMENTS
    ===================================================== */

    const loginForm =
        document.getElementById("loginForm");

    const emailInput =
        document.getElementById("email");

    const passwordInput =
        document.getElementById("password");

    const rememberMe =
        document.getElementById("rememberMe");

    const passwordToggle =
        document.getElementById("passwordToggle");

    const loginButton =
        document.getElementById("loginButton");

    const buttonText =
        loginButton?.querySelector(".button-text");

    const buttonLoader =
        loginButton?.querySelector(".button-loader");

    const emailError =
        document.getElementById("emailError");

    const passwordError =
        document.getElementById("passwordError");

    const formMessage =
        document.getElementById("formMessage");

    const googleLogin =
        document.getElementById("googleLogin");

    const appleLogin =
        document.getElementById("appleLogin");


    /* =====================================================
       STORAGE KEYS
    ===================================================== */

    const USERS_KEY = "fashUsers";
    const SESSION_KEY = "fashCurrentUser";
    const REMEMBER_KEY = "fashRememberedEmail";


    /* =====================================================
       INITIALISE
    ===================================================== */

    init();


    function init() {

        loadRememberedEmail();

        bindEvents();

    }


    /* =====================================================
       EVENTS
    ===================================================== */

    function bindEvents() {

        /* ---------------------------------------------
           LOGIN
        --------------------------------------------- */

        loginForm?.addEventListener(
            "submit",
            handleLogin
        );


        /* ---------------------------------------------
           PASSWORD TOGGLE
        --------------------------------------------- */

        passwordToggle?.addEventListener(
            "click",
            togglePassword
        );


        /* ---------------------------------------------
           REAL-TIME VALIDATION
        --------------------------------------------- */

        emailInput?.addEventListener(
            "input",
            () => {

                clearFieldError(
                    emailInput,
                    emailError
                );

                hideFormMessage();

            }
        );


        passwordInput?.addEventListener(
            "input",
            () => {

                clearFieldError(
                    passwordInput,
                    passwordError
                );

                hideFormMessage();

            }
        );


        /* ---------------------------------------------
           GOOGLE
        --------------------------------------------- */

        googleLogin?.addEventListener(
            "click",
            handleGoogleLogin
        );


        /* ---------------------------------------------
           APPLE
        --------------------------------------------- */

        appleLogin?.addEventListener(
            "click",
            handleAppleLogin
        );

    }


    /* =====================================================
       LOGIN
    ===================================================== */

    async function handleLogin(event) {
        event.preventDefault();
        clearErrors();
        hideFormMessage();

        const email = emailInput?.value.trim().toLowerCase() || "";
        const password = passwordInput?.value || "";

        if (!validateLogin(email, password)) return;

        setLoading(true);

        try {
            const data = await FASH_API.api("/api/auth/login", {
                method: "POST",
                body: JSON.stringify({ email, password })
            });

            FASH_API.saveSession(data.user, data.token);

            if (rememberMe?.checked) {
                localStorage.setItem(REMEMBER_KEY, email);
            } else {
                localStorage.removeItem(REMEMBER_KEY);
            }

            localStorage.setItem("fashWelcomeMessage", `Welcome back to FASH, ${data.user.full_name || "FASH shopper"}!`); localStorage.setItem("fashWelcomeAlert", JSON.stringify({title:"Welcome back to FASH",message:`Welcome back, ${data.user.full_name || "FASH shopper"}!`,type:"info",createdAt:Date.now()}));
            showFormMessage(`Welcome back, ${data.user.full_name || "FASH shopper"}!`, "success");
            await delay(500);
            redirectAfterLogin(data.user);

        } catch (error) {
            console.error("FASH API login error:", error);
            showFormMessage(error.message || "Invalid email or password.", "error");
        } finally {
            setLoading(false);
        }
    }

    /* =====================================================
       VALIDATION
    ===================================================== */

    function validateLogin(
        email,
        password
    ) {

        let valid = true;


        /* ---------------------------------------------
           EMAIL
        --------------------------------------------- */

        if (!email) {

            showFieldError(
                emailInput,
                emailError,
                "Please enter your email address."
            );

            valid = false;

        } else if (!isValidEmail(email)) {

            showFieldError(
                emailInput,
                emailError,
                "Please enter a valid email address."
            );

            valid = false;

        }


        /* ---------------------------------------------
           PASSWORD
        --------------------------------------------- */

        if (!password) {

            showFieldError(
                passwordInput,
                passwordError,
                "Please enter your password."
            );

            valid = false;

        }


        return valid;
    }


    /* =====================================================
       PASSWORD TOGGLE
    ===================================================== */

    function togglePassword() {

        if (!passwordInput) return;


        const isPassword =
            passwordInput.type === "password";


        passwordInput.type =
            isPassword
                ? "text"
                : "password";


        const icon =
            passwordToggle?.querySelector("i");


        if (icon) {

            icon.className =
                isPassword
                    ? "fa-regular fa-eye-slash"
                    : "fa-regular fa-eye";

        }


        passwordToggle?.setAttribute(
            "aria-label",
            isPassword
                ? "Hide password"
                : "Show password"
        );

    }


    /* =====================================================
       GET USERS
    ===================================================== */

    function getUsers() {

        /*
         * Main FASH user storage.
         */

        const possibleKeys = [

            USERS_KEY,

            "fash_users",

            "fashUsersData",

            "users"

        ];


        for (const key of possibleKeys) {

            const raw =
                localStorage.getItem(key);


            if (!raw) continue;


            try {

                const parsed =
                    JSON.parse(raw);


                if (Array.isArray(parsed)) {

                    return parsed;

                }

            } catch (error) {

                console.warn(
                    `FASH: Could not read ${key}`,
                    error
                );

            }

        }


        return [];

    }


    /* =====================================================
       CHECK PASSWORD
    ===================================================== */

    function checkPassword(
        user,
        password
    ) {

        /*
         * Current frontend/demo authentication.
         *
         * If the user object contains a plain `password`
         * field, compare it directly.
         *
         * A real production FASH backend should NEVER
         * store plaintext passwords in localStorage.
         */

        if (
            typeof user.password === "string"
        ) {

            return (
                user.password === password
            );

        }


        /*
         * Some registration systems may use
         * `passwordHash`. This simple frontend
         * version cannot securely verify a real
         * server-side password hash.
         */

        if (user.passwordHash) {

            console.warn(
                "FASH: passwordHash detected. Use backend authentication for production."
            );

            return false;
        }


        return false;

    }


    /* =====================================================
       CREATE SESSION USER
    ===================================================== */

    function createSessionUser(user) {

        return {

            id:
                user.id ||
                `USER-${Date.now()}`,

            name:
                user.name ||
                user.fullName ||
                user.username ||
                "FASH User",

            email:
                user.email || "",

            phone:
                user.phone || "",

            avatar:
                user.avatar ||
                user.profileImage ||
                "",

            role:
                user.role ||
                "customer",

            status:
                user.status ||
                "active",

            sellerStatus:
                user.sellerStatus ||
                "",

            sellerApplication:
                Boolean(user.sellerApplication),

            sellerApplicationId:
                user.sellerApplicationId ||
                "",

            loginAt:
                new Date().toISOString()

        };

    }


    /* =====================================================
       UPDATE LAST LOGIN
    ===================================================== */

    function updateLastLogin(
        userId
    ) {

        const users =
            getUsers();


        const index =
            users.findIndex(
                user =>
                    String(user.id) ===
                    String(userId)
            );


        if (index === -1) {
            return;
        }


        users[index].lastLogin =
            new Date().toISOString();


        /*
         * Save only if the users array
         * came from the main storage.
         */

        localStorage.setItem(
            USERS_KEY,
            JSON.stringify(users)
        );

    }


    /* =====================================================
       REMEMBERED EMAIL
    ===================================================== */

    function loadRememberedEmail() {

        if (!emailInput) return;


        const remembered =
            localStorage.getItem(
                REMEMBER_KEY
            );


        if (!remembered) return;


        emailInput.value =
            remembered;


        if (rememberMe) {

            rememberMe.checked =
                true;

        }

    }


    /* =====================================================
       REDIRECT
    ===================================================== */

    function redirectAfterLogin(sessionUser) {

        /*
         * If the user previously tried to access
         * a protected page, return them there.
         */

        const redirect =
            sessionStorage.getItem(
                "fashLoginRedirect"
            );


        if (redirect) {

            sessionStorage.removeItem(
                "fashLoginRedirect"
            );


            window.location.href =
                redirect;

            return;
        }

        // BUGFIX: this used to re-read localStorage.getItem("fashCurrentUser"),
        // a key nothing in the app ever writes to (FASH_API.saveSession stores the
        // logged-in user under "fash_user"). That mismatch meant sessionUser was
        // always null, so admins/sellers logging in from the customer login page
        // always landed on the generic shop page instead of their dashboard.
        // The caller now passes the user object it already has from the login
        // response, so no localStorage lookup is needed here at all.

        if (sessionUser?.role === "admin") {
            window.location.href = "../admin/admin.html";
            return;
        }

        if (sessionUser?.role === "seller" || sessionUser?.sellerApplication) {
            window.location.href = "../seller/dashboard.html";
            return;
        }

        localStorage.setItem(
            "fashWelcomeMessage",
            `Welcome back, ${sessionUser?.name || "FASH shopper"}!`
        );

        window.location.href =
            "shop.html";

    }


    /* =====================================================
       GOOGLE LOGIN
    ===================================================== */

    function handleGoogleLogin() {

        showFormMessage(
            "Google sign-in will be available when FASH authentication is connected to a backend.",
            "error"
        );

    }


    /* =====================================================
       APPLE LOGIN
    ===================================================== */

    function handleAppleLogin() {

        showFormMessage(
            "Apple sign-in will be available when FASH authentication is connected to a backend.",
            "error"
        );

    }


    /* =====================================================
       SHOW FIELD ERROR
    ===================================================== */

    function showFieldError(
        input,
        errorElement,
        message
    ) {

        if (input) {

            input.closest(
                ".form-group"
            )?.classList.add(
                "has-error"
            );

        }


        if (errorElement) {

            errorElement.textContent =
                message;

        }

    }


    /* =====================================================
       CLEAR FIELD ERROR
    ===================================================== */

    function clearFieldError(
        input,
        errorElement
    ) {

        input?.closest(
            ".form-group"
        )?.classList.remove(
            "has-error"
        );


        if (errorElement) {

            errorElement.textContent =
                "";

        }

    }


    /* =====================================================
       CLEAR ALL ERRORS
    ===================================================== */

    function clearErrors() {

        clearFieldError(
            emailInput,
            emailError
        );

        clearFieldError(
            passwordInput,
            passwordError
        );

    }


    /* =====================================================
       FORM MESSAGE
    ===================================================== */

    function showFormMessage(
        message,
        type
    ) {

        if (!formMessage) return;


        formMessage.textContent =
            message;


        formMessage.className =
            `form-message ${type}`;


        formMessage.hidden =
            false;

    }


    /* =====================================================
       HIDE FORM MESSAGE
    ===================================================== */

    function hideFormMessage() {

        if (!formMessage) return;


        formMessage.hidden =
            true;

        formMessage.textContent =
            "";

        formMessage.className =
            "form-message";

    }


    /* =====================================================
       LOADING STATE
    ===================================================== */

    function setLoading(
        loading
    ) {

        if (!loginButton) return;


        loginButton.disabled =
            loading;


        if (buttonText) {

            buttonText.hidden =
                loading;

        }


        if (buttonLoader) {

            buttonLoader.hidden =
                !loading;

        }

    }


    /* =====================================================
       EMAIL VALIDATION
    ===================================================== */

    function isValidEmail(email) {

        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/
            .test(email);

    }


    /* =====================================================
       DELAY
    ===================================================== */

    function delay(
        milliseconds
    ) {

        return new Promise(
            resolve =>
                setTimeout(
                    resolve,
                    milliseconds
                )
        );

    }

});