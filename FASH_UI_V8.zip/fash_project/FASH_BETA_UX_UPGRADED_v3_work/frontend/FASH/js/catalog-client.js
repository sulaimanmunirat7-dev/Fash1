/* FASH v6.6 Catalog Client */
(function () {
  "use strict";
  function normaliseList(payload) {
    if (Array.isArray(payload)) return payload;
    return payload && (payload.products || payload.items || payload.data || payload.results) || [];
  }
  function normaliseProduct(p) {
    return {
      id: p.id || p.product_id || p.productId,
      name: p.name || p.title || "Untitled product",
      price: p.price ?? p.amount ?? p.sale_price ?? "",
      image: p.image || p.image_url || p.imageUrl || (Array.isArray(p.images) ? (p.images[0]?.url || p.images[0]) : ""),
      category: p.category || p.category_name || "",
      raw: p
    };
  }
  function formatPrice(value) {
    const n=Number(value);
    if (!Number.isFinite(n)) return value == null ? "" : String(value);
    return new Intl.NumberFormat("en-NG",{style:"currency",currency:"NGN",maximumFractionDigits:0}).format(n);
  }
  async function loadProducts(params={}) {
    if (!window.FASH_API?.getProducts) throw new Error("FASH API client is unavailable");
    return normaliseList(await window.FASH_API.getProducts(params)).map(normaliseProduct);
  }
  async function loadCategories() {
    if (!window.FASH_API?.getCategories) throw new Error("FASH API client is unavailable");
    const data=await window.FASH_API.getCategories();
    return Array.isArray(data) ? data : (data.categories || data.items || data.data || []);
  }
  window.FASH_CATALOG={normaliseList,normaliseProduct,formatPrice,loadProducts,loadCategories};
})();
