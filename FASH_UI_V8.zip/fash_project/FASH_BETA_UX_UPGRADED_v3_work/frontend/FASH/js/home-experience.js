document.addEventListener("DOMContentLoaded", () => {
    const loader = document.getElementById("fashLoadingScreen");
    const cookies = document.getElementById("fashCookieConsent");
    const accept = document.getElementById("acceptFashCookies");

    const finishLoading = () => {
        if (!loader) return;
        loader.classList.add("is-hidden");
        setTimeout(() => loader.remove(), 450);
    };

    setTimeout(finishLoading, 900);

    if (cookies && !localStorage.getItem("fashCookiesAccepted")) {
        setTimeout(() => {
            cookies.hidden = false;
            requestAnimationFrame(() => cookies.classList.add("is-visible"));
        }, 1100);
    }

    if (accept) {
        accept.addEventListener("click", () => {
            localStorage.setItem("fashCookiesAccepted", "true");
            if (cookies) {
                cookies.classList.remove("is-visible");
                setTimeout(() => { cookies.hidden = true; }, 300);
            }
        });
    }
});
