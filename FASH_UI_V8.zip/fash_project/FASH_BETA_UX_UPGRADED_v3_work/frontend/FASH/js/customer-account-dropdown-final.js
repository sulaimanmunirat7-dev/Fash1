
(function(){
"use strict";
function getUser(){
 try{return window.currentUser||JSON.parse(localStorage.getItem("fash_user")||localStorage.getItem("user")||"null")}catch(e){return null}
}
function goGuest(){ window.location.href="register.html"; }
function build(){
 const trigger=document.querySelector("#navAccount,.nav-account,.account-trigger,[data-account-trigger]");
 if(!trigger || trigger.dataset.fashAccountBound)return;
 trigger.dataset.fashAccountBound="1";
 trigger.addEventListener("click",function(e){
   e.preventDefault(); e.stopPropagation();
   const user=getUser();
   if(!user){goGuest();return;}
   let menu=document.querySelector("#accountMenu,.account-menu,.account-dropdown,[data-account-menu]");
   if(!menu){
     menu=document.createElement("div"); menu.className="account-dropdown"; menu.id="accountMenu";
     menu.innerHTML=`<div style="padding:16px 18px;border-bottom:1px solid #e2e8f0"><strong>${String(user.name||user.full_name||"My Account").replace(/[&<>"']/g,"")}</strong><div style="font-size:12px;color:#64748b;margin-top:4px">FASH Account</div></div>
     <a href="account.html">My Account</a><a href="account.html#orders">My Orders</a><a href="account.html#wishlist">Wishlist</a><a href="account.html#stores">Followed Stores</a><a href="account.html#reviews">My Reviews</a><a href="account.html#settings">Settings</a>
     ${user.seller_status==="approved"||user.sellerStatus==="approved"?'<a href="seller-dashboard.html">Seller Dashboard</a>':''}
     <button type="button" data-fash-logout>Log out</button>`;
     trigger.parentElement.appendChild(menu);
   }
   menu.hidden=!menu.hidden;
 });
 document.addEventListener("click",e=>{
   const menu=document.querySelector("#accountMenu,.account-menu,.account-dropdown,[data-account-menu]");
   if(menu && !e.target.closest("#navAccount,.nav-account,.account-trigger,[data-account-trigger],#accountMenu,.account-menu,.account-dropdown,[data-account-menu]")) menu.hidden=true;
 });
}
document.addEventListener("DOMContentLoaded",build);
})();
