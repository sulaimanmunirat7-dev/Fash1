document.addEventListener("DOMContentLoaded",()=>console.log("FASH Terms ready"));
