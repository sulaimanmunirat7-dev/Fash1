"use strict";

document.addEventListener("DOMContentLoaded", () => {

    const startAdvertising =
        document.getElementById("startAdvertising");

    const advertisingInfo =
        document.getElementById("advertisingInfo");

    const ctaAdvertise =
        document.getElementById("ctaAdvertise");

    const footerYear =
        document.getElementById("footerYear");


    /*==================================================
    START ADVERTISING
    ==================================================*/

    if (startAdvertising) {

        startAdvertising.addEventListener("click", () => {

            window.location.href =
                "../pages/advertising-request.html";

        });

    }


    /*==================================================
    LEARN MORE
    ==================================================*/

    if (advertisingInfo) {

        advertisingInfo.addEventListener("click", () => {

            const benefitsSection =
                document.querySelector(".advert-section");

            if (benefitsSection) {

                benefitsSection.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });

            }

        });

    }


    /*==================================================
    CTA
    ==================================================*/

    if (ctaAdvertise) {

        ctaAdvertise.addEventListener("click", () => {

            window.location.href =
                "../pages/advertising-request.html";

        });

    }


    /*==================================================
    FOOTER YEAR
    ==================================================*/

    if (footerYear) {

        footerYear.textContent =
            `© ${new Date().getFullYear()} FASH. All rights reserved.`;

    }

});