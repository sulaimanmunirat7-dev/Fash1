/* FASH v6.3 Customer Feature Backend Services */
(function () {
  "use strict";

  if (!window.FASH_API) {
    console.error("FASH_API is required before customer-api.js");
    return;
  }

  async function tryCandidates(candidates, options) {
    let lastError;
    for (const path of candidates) {
      try {
        return await window.FASH_API.request(path, options);
      } catch (error) {
        lastError = error;
        if (error.status !== 404) throw error;
      }
    }
    throw lastError || new Error("Backend endpoint unavailable");
  }

  function withQuery(path, params) {
    const query = new URLSearchParams();
    Object.entries(params || {}).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== "") query.set(key, value);
    });
    const suffix = query.toString();
    return suffix ? `${path}?${suffix}` : path;
  }

  function normalizeList(data) {
    if (Array.isArray(data)) return data;
    if (Array.isArray(data?.items)) return data.items;
    if (Array.isArray(data?.data)) return data.data;
    if (Array.isArray(data?.products)) return data.products;
    if (Array.isArray(data?.orders)) return data.orders;
    if (Array.isArray(data?.results)) return data.results;
    return [];
  }

  const CustomerAPI = {
    products: {
      async list(params) {
        const paths = [
          withQuery("/api/products", params),
          withQuery("/api/catalog/products", params)
        ];
        const data = await tryCandidates(paths, { method: "GET" });
        return { raw: data, items: normalizeList(data) };
      },
      async search(query, params) {
        const q = { ...(params || {}), q: query, search: query };
        const paths = [
          withQuery("/api/products/search", q),
          withQuery("/api/search", q),
          withQuery("/api/products", q)
        ];
        const data = await tryCandidates(paths, { method: "GET" });
        return { raw: data, items: normalizeList(data) };
      },
      async get(id) {
        return tryCandidates([
          `/api/products/${encodeURIComponent(id)}`,
          `/api/catalog/products/${encodeURIComponent(id)}`
        ], { method: "GET" });
      },
      async categories() {
        const data = await tryCandidates([
          "/api/categories",
          "/api/product-categories"
        ], { method: "GET" });
        return { raw: data, items: normalizeList(data) };
      }
    },

    cart: {
      async get() {
        return tryCandidates(["/api/cart", "/api/cart/me"], { method: "GET" });
      },
      async add(item) {
        return tryCandidates(["/api/cart/items", "/api/cart"], {
          method: "POST",
          body: JSON.stringify(item || {})
        });
      },
      async update(itemId, payload) {
        return tryCandidates([
          `/api/cart/items/${encodeURIComponent(itemId)}`,
          `/api/cart/${encodeURIComponent(itemId)}`
        ], {
          method: "PATCH",
          body: JSON.stringify(payload || {})
        });
      },
      async remove(itemId) {
        return tryCandidates([
          `/api/cart/items/${encodeURIComponent(itemId)}`,
          `/api/cart/${encodeURIComponent(itemId)}`
        ], { method: "DELETE" });
      },
      async clear() {
        return tryCandidates(["/api/cart", "/api/cart/clear"], { method: "DELETE" });
      }
    },

    orders: {
      async list(params) {
        const paths = [
          withQuery("/api/orders", params),
          withQuery("/api/orders/me", params)
        ];
        const data = await tryCandidates(paths, { method: "GET" });
        return { raw: data, items: normalizeList(data) };
      },
      async get(id) {
        return tryCandidates([
          `/api/orders/${encodeURIComponent(id)}`
        ], { method: "GET" });
      },
      async create(payload) {
        return tryCandidates(["/api/orders", "/api/checkout/orders"], {
          method: "POST",
          body: JSON.stringify(payload || {})
        });
      }
    },

    wishlist: {
      async get() {
        return tryCandidates(["/api/wishlist", "/api/wishlists/me"], { method: "GET" });
      },
      async add(productId) {
        return tryCandidates(["/api/wishlist/items", "/api/wishlist"], {
          method: "POST",
          body: JSON.stringify({ product_id: productId, productId })
        });
      },
      async remove(productId) {
        return tryCandidates([
          `/api/wishlist/items/${encodeURIComponent(productId)}`,
          `/api/wishlist/${encodeURIComponent(productId)}`
        ], { method: "DELETE" });
      }
    },

    notifications: {
      async list(params) {
        const data = await tryCandidates([
          withQuery("/api/notifications", params),
          withQuery("/api/alerts", params)
        ], { method: "GET" });
        return { raw: data, items: normalizeList(data) };
      },
      async markRead(id) {
        return tryCandidates([
          `/api/notifications/${encodeURIComponent(id)}/read`,
          `/api/notifications/${encodeURIComponent(id)}`
        ], { method: "PATCH", body: JSON.stringify({ read: true }) });
      }
    }
  };

  window.FASH_CUSTOMER_API = CustomerAPI;
})();
