"use strict";

document.addEventListener("DOMContentLoaded", () => {

    const startSelling =
        document.getElementById("startSelling");

    const ctaStartSelling =
        document.getElementById("ctaStartSelling");

    const footerYear =
        document.getElementById("footerYear");


    /*==================================================
    START SELLING
    ==================================================*/

    if (startSelling) {

        startSelling.addEventListener("click", () => {

            window.location.href =
                "../pages/become-seller.html";

        });

    }


    /*==================================================
    CTA START SELLING
    ==================================================*/

    if (ctaStartSelling) {

        ctaStartSelling.addEventListener("click", () => {

            window.location.href =
                "../pages/become-seller.html";

        });

    }


    /*==================================================
    FOOTER YEAR
    ==================================================*/

    if (footerYear) {

        footerYear.textContent =
            `© ${new Date().getFullYear()} FASH. All rights reserved.`;

    }

});