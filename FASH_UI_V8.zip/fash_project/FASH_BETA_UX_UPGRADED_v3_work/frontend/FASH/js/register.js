/* =========================================================
   FASH — REGISTER
   Account Registration System
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    /* =====================================================
       ELEMENTS
    ===================================================== */

    const form = document.getElementById("registerForm");

    const fullName = document.getElementById("fullName");
    const email = document.getElementById("email");
    const phone = document.getElementById("phone");
    const password = document.getElementById("password");
    const confirmPassword = document.getElementById("confirmPassword");
    const terms = document.getElementById("terms");

    const registerButton =
        document.getElementById("registerButton");

    const buttonText =
        registerButton?.querySelector(".button-text");

    const buttonLoader =
        registerButton?.querySelector(".button-loader");

    const togglePassword =
        document.getElementById("togglePassword");

    const toggleConfirmPassword =
        document.getElementById("toggleConfirmPassword");

    const googleRegister =
        document.getElementById("googleRegister");

    const appleRegister =
        document.getElementById("appleRegister");

    const toastElement =
        document.getElementById("authToast");

    const toastMessage =
        document.getElementById("toastMessage");

    const toastIcon =
        document.getElementById("toastIcon");


    /* =====================================================
       STORAGE
    ===================================================== */

    const USERS_KEY = "fashUsers";

    const SESSION_KEY = "fashCurrentUser";


    /* =====================================================
       SAFETY CHECK
    ===================================================== */

    if (!form) {
        console.warn(
            "FASH Register: registerForm was not found."
        );

        return;
    }


    /* =====================================================
       PASSWORD VISIBILITY
    ===================================================== */

    setupPasswordToggle(
        togglePassword,
        password
    );

    setupPasswordToggle(
        toggleConfirmPassword,
        confirmPassword
    );


    function setupPasswordToggle(button, input) {

        if (!button || !input) return;

        button.addEventListener(
            "click",
            () => {

                const showing =
                    input.type === "text";

                input.type =
                    showing
                        ? "password"
                        : "text";

                const icon =
                    button.querySelector("i");

                if (icon) {

                    icon.className =
                        showing
                            ? "fa-solid fa-eye"
                            : "fa-solid fa-eye-slash";
                }

                button.setAttribute(
                    "aria-label",
                    showing
                        ? "Show password"
                        : "Hide password"
                );
            }
        );
    }


    /* =====================================================
       REAL-TIME VALIDATION
    ===================================================== */

    fullName?.addEventListener(
        "blur",
        () => validateFullName()
    );

    email?.addEventListener(
        "blur",
        () => validateEmail()
    );

    phone?.addEventListener(
        "blur",
        () => validatePhone()
    );

    password?.addEventListener(
        "input",
        () => {

            if (password.value) {
                validatePassword();
            }

            if (confirmPassword?.value) {
                validateConfirmPassword();
            }
        }
    );

    confirmPassword?.addEventListener(
        "input",
        () => {

            if (confirmPassword.value) {
                validateConfirmPassword();
            }
        }
    );

    terms?.addEventListener(
        "change",
        () => validateTerms()
    );


    /* =====================================================
       FORM SUBMISSION
    ===================================================== */

    form.addEventListener(
        "submit",
        handleSubmit
    );


    async function handleSubmit(event) {
        event.preventDefault();
        clearAllErrors();

        const isValid =
            validateFullName() &&
            validateEmail() &&
            validatePhone() &&
            validatePassword() &&
            validateConfirmPassword() &&
            validateTerms();

        if (!isValid) {
            document.querySelector(".input-wrapper.input-error input, input.input-error")?.focus();
            return;
        }

        setLoading(true);

        try {
            const data = await FASH_API.api("/api/auth/register", {
                method: "POST",
                body: JSON.stringify({
                    fullName: fullName.value.trim(),
                    email: email.value.trim().toLowerCase(),
                    password: password.value
                })
            });

            FASH_API.saveSession(data.user, data.token);
            localStorage.setItem("fashWelcomeMessage", `Welcome to FASH, ${data.user.full_name}!`);
            localStorage.setItem("fashWelcomeAlert", JSON.stringify({title:"Welcome to FASH",message:`Welcome to FASH, ${data.user.full_name}!`,type:"info",createdAt:Date.now()}));

            showToast("Account created successfully!", "success");

            setTimeout(() => {
                window.location.href = "shop.html";
            }, 700);

        } catch (error) {
            console.error("FASH registration error:", error);

            if (error.status === 409) {
                setError(email, error.message);
                email.focus();
            } else {
                showToast(error.message || "Registration failed.", "error");
            }
        } finally {
            setLoading(false);
        }
    }

    /* =====================================================
       FULL NAME VALIDATION
    ===================================================== */

    function validateFullName() {

        const value =
            fullName?.value.trim() || "";

        if (!value) {

            setError(
                fullName,
                "Please enter your full name."
            );

            return false;
        }


        if (value.length < 2) {

            setError(
                fullName,
                "Your name must contain at least 2 characters."
            );

            return false;
        }


        if (!/[a-zA-Z]/.test(value)) {

            setError(
                fullName,
                "Please enter a valid name."
            );

            return false;
        }


        setSuccess(fullName);

        return true;
    }


    /* =====================================================
       EMAIL VALIDATION
    ===================================================== */

    function validateEmail() {

        const value =
            email?.value.trim() || "";

        if (!value) {

            setError(
                email,
                "Please enter your email address."
            );

            return false;
        }


        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;


        if (!emailPattern.test(value)) {

            setError(
                email,
                "Please enter a valid email address."
            );

            return false;
        }


        setSuccess(email);

        return true;
    }


    /* =====================================================
       PHONE VALIDATION
    ===================================================== */

    function validatePhone() {

        const value =
            phone?.value.trim() || "";


        /*
         * Phone is optional in the current form.
         */

        if (!value) {

            clearFieldState(phone);

            return true;
        }


        const digits =
            value.replace(/\D/g, "");


        if (
            digits.length < 7 ||
            digits.length > 15
        ) {

            setError(
                phone,
                "Please enter a valid phone number."
            );

            return false;
        }


        setSuccess(phone);

        return true;
    }


    /* =====================================================
       PASSWORD VALIDATION
    ===================================================== */

    function validatePassword() {

        const value =
            password?.value || "";


        if (!value) {

            setError(
                password,
                "Please create a password."
            );

            return false;
        }


        if (value.length < 8) {

            setError(
                password,
                "Password must be at least 8 characters."
            );

            return false;
        }


        if (!/[A-Z]/.test(value)) {

            setError(
                password,
                "Password must contain an uppercase letter."
            );

            return false;
        }


        if (!/[a-z]/.test(value)) {

            setError(
                password,
                "Password must contain a lowercase letter."
            );

            return false;
        }


        if (!/[0-9]/.test(value)) {

            setError(
                password,
                "Password must contain a number."
            );

            return false;
        }


        setSuccess(password);

        return true;
    }


    /* =====================================================
       CONFIRM PASSWORD
    ===================================================== */

    function validateConfirmPassword() {

        const value =
            confirmPassword?.value || "";


        if (!value) {

            setError(
                confirmPassword,
                "Please confirm your password."
            );

            return false;
        }


        if (
            value !==
            password?.value
        ) {

            setError(
                confirmPassword,
                "Passwords do not match."
            );

            return false;
        }


        setSuccess(confirmPassword);

        return true;
    }


    /* =====================================================
       TERMS
    ===================================================== */

    function validateTerms() {

        if (!terms?.checked) {

            const error =
                document.getElementById(
                    "termsError"
                );

            if (error) {

                error.textContent =
                    "You must agree to the Terms of Service and Privacy Policy.";
            }

            return false;
        }


        const error =
            document.getElementById(
                "termsError"
            );

        if (error) {
            error.textContent = "";
        }


        return true;
    }


    /* =====================================================
       ERROR
    ===================================================== */

    function setError(
        input,
        message
    ) {

        if (!input) return;


        const wrapper =
            input.closest(
                ".input-wrapper"
            );


        if (wrapper) {

            wrapper.classList.remove(
                "input-success"
            );

            wrapper.classList.add(
                "input-error"
            );
        }


        const error =
            document.getElementById(
                `${input.id}Error`
            );


        if (error) {

            error.textContent =
                message;
        }
    }


    /* =====================================================
       SUCCESS
    ===================================================== */

    function setSuccess(input) {

        if (!input) return;


        const wrapper =
            input.closest(
                ".input-wrapper"
            );


        if (wrapper) {

            wrapper.classList.remove(
                "input-error"
            );

            wrapper.classList.add(
                "input-success"
            );
        }


        const error =
            document.getElementById(
                `${input.id}Error`
            );


        if (error) {

            error.textContent = "";
        }
    }


    /* =====================================================
       CLEAR FIELD
    ===================================================== */

    function clearFieldState(input) {

        if (!input) return;


        const wrapper =
            input.closest(
                ".input-wrapper"
            );


        wrapper?.classList.remove(
            "input-error",
            "input-success"
        );


        const error =
            document.getElementById(
                `${input.id}Error`
            );


        if (error) {

            error.textContent = "";
        }
    }


    /* =====================================================
       CLEAR ERRORS
    ===================================================== */

    function clearAllErrors() {

        [
            fullName,
            email,
            phone,
            password,
            confirmPassword
        ].forEach(
            clearFieldState
        );


        const termsError =
            document.getElementById(
                "termsError"
            );

        if (termsError) {

            termsError.textContent = "";
        }
    }


    /* =====================================================
       USERS
    ===================================================== */

    function getUsers() {

        try {

            const raw =
                localStorage.getItem(
                    USERS_KEY
                );


            if (!raw) {
                return [];
            }


            const users =
                JSON.parse(raw);


            return Array.isArray(users)
                ? users
                : [];

        } catch (error) {

            console.warn(
                "FASH: Unable to read users.",
                error
            );

            return [];
        }
    }


    function saveUsers(users) {

        try {

            localStorage.setItem(
                USERS_KEY,
                JSON.stringify(users)
            );

        } catch (error) {

            console.error(
                "FASH: Unable to save user.",
                error
            );

            showToast(
                "Unable to create your account. Please try again.",
                "error"
            );
        }
    }


    /* =====================================================
       USER ID
    ===================================================== */

    function generateUserId() {

        return (
            "USR-" +
            Date.now() +
            "-" +
            Math.random()
                .toString(36)
                .slice(2, 8)
                .toUpperCase()
        );
    }


    /* =====================================================
       LOADING
    ===================================================== */

    function setLoading(loading) {

        if (!registerButton) return;


        registerButton.disabled =
            loading;


        if (buttonText) {

            buttonText.hidden =
                loading;
        }


        const arrow =
            registerButton.querySelector(
                ".fa-arrow-right"
            );


        if (arrow) {

            arrow.hidden =
                loading;
        }


        if (buttonLoader) {

            buttonLoader.hidden =
                !loading;
        }
    }


    /* =====================================================
       TOAST
    ===================================================== */

    function showToast(
        message,
        type = "success"
    ) {

        if (!toastElement) return;


        if (toastMessage) {

            toastMessage.textContent =
                message;
        }


        if (toastIcon) {

            toastIcon.className =
                type === "error"
                    ? "fa-solid fa-circle-exclamation"
                    : "fa-solid fa-circle-check";
        }


        toastElement.hidden =
            false;


        clearTimeout(
            showToast.timer
        );


        showToast.timer =
            setTimeout(
                () => {

                    toastElement.hidden =
                        true;

                },
                3500
            );
    }


    /* =====================================================
       SOCIAL BUTTONS
    ===================================================== */

    googleRegister?.addEventListener(
        "click",
        () => {

            showToast(
                "Google registration will be available soon.",
                "success"
            );
        }
    );


    appleRegister?.addEventListener(
        "click",
        () => {

            showToast(
                "Apple registration will be available soon.",
                "success"
            );
        }
    );


    /* =====================================================
       UTILITY
    ===================================================== */

    function delay(milliseconds) {

        return new Promise(
            resolve =>
                setTimeout(
                    resolve,
                    milliseconds
                )
        );
    }

});