/* FASH welcome message */
document.addEventListener("DOMContentLoaded", () => {
    const message = localStorage.getItem("fashWelcomeMessage");
    if (!message) return;
    localStorage.removeItem("fashWelcomeMessage");
    const box = document.createElement("div");
    box.className = "fash-welcome-toast";
    box.innerHTML = `<i class="fa-solid fa-circle-check"></i><span>${escapeWelcome(message)}</span>`;
    document.body.appendChild(box);
    requestAnimationFrame(() => box.classList.add("show"));
    setTimeout(() => { box.classList.remove("show"); setTimeout(() => box.remove(), 300); }, 4200);
    function escapeWelcome(value) { const div=document.createElement("div"); div.textContent=value; return div.innerHTML; }
});
