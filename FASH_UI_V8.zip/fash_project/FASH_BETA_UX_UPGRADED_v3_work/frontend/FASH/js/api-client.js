/* FASH v6.2 Backend API Client */
(function () {
  "use strict";

  const configuredBase =
    (window.FASH_CONFIG && window.FASH_CONFIG.API_BASE_URL) ||
    localStorage.getItem("FASH_API_BASE_URL");

  const isLocal = /^(localhost|127\.0\.0\.1)$/i.test(window.location.hostname);
  const defaultBase = isLocal
    ? `${window.location.protocol}//${window.location.hostname}:5000`
    : "";

  const API_BASE_URL = String(configuredBase || defaultBase).replace(/\/+$/, "");

  function getToken() {
    return localStorage.getItem("fash_token") || sessionStorage.getItem("fash_token") || "";
  }

  function setToken(token, remember) {
    if (!token) return;
    const store = remember === false ? sessionStorage : localStorage;
    store.setItem("fash_token", token);
  }

  function clearToken() {
    localStorage.removeItem("fash_token");
    sessionStorage.removeItem("fash_token");
    localStorage.removeItem("fash_user");
    sessionStorage.removeItem("fash_user");
  }

  async function request(path, options) {
    const opts = options || {};
    const headers = new Headers(opts.headers || {});
    const token = getToken();

    if (token && !headers.has("Authorization")) {
      headers.set("Authorization", `Bearer ${token}`);
    }

    if (opts.body && !(opts.body instanceof FormData) && !headers.has("Content-Type")) {
      headers.set("Content-Type", "application/json");
    }

    const response = await fetch(`${API_BASE_URL}${path}`, {
      ...opts,
      headers,
      credentials: "include"
    });

    const contentType = response.headers.get("content-type") || "";
    const data = contentType.includes("application/json")
      ? await response.json().catch(() => ({}))
      : await response.text().catch(() => "");

    if (!response.ok) {
      const message =
        (data && typeof data === "object" && (data.message || data.error)) ||
        `Request failed (${response.status})`;
      const error = new Error(message);
      error.status = response.status;
      error.data = data;
      throw error;
    }

    return data;
  }

  const api = {
    baseUrl: API_BASE_URL,
    request,
    get(path, options) {
      return request(path, { ...(options || {}), method: "GET" });
    },
    post(path, body, options) {
      return request(path, {
        ...(options || {}),
        method: "POST",
        body: body instanceof FormData ? body : JSON.stringify(body || {})
      });
    },
    patch(path, body, options) {
      return request(path, {
        ...(options || {}),
        method: "PATCH",
        body: body instanceof FormData ? body : JSON.stringify(body || {})
      });
    },
    put(path, body, options) {
      return request(path, {
        ...(options || {}),
        method: "PUT",
        body: body instanceof FormData ? body : JSON.stringify(body || {})
      });
    },
    delete(path, options) {
      return request(path, { ...(options || {}), method: "DELETE" });
    },

    async getCurrentUser() {
      // Try the existing common auth endpoints without assuming one exact backend shape.
      const candidates = ["/api/auth/me", "/api/me"];
      let lastError;
      for (const path of candidates) {
        try {
          return await request(path);
        } catch (error) {
          lastError = error;
          if (error.status !== 404) throw error;
        }
      }
      throw lastError || new Error("Current user endpoint is unavailable");
    },

    async login(credentials) {
      const data = await request("/api/auth/login", {
        method: "POST",
        body: JSON.stringify(credentials || {})
      });
      const token = data.token || data.accessToken || (data.data && data.data.token);
      const user = data.user || (data.data && data.data.user) || null;
      if (token) setToken(token, credentials && credentials.remember);
      if (user) localStorage.setItem("fash_user", JSON.stringify(user));
      return data;
    },

    async register(payload) {
      const data = await request("/api/auth/register", {
        method: "POST",
        body: JSON.stringify(payload || {})
      });
      const token = data.token || data.accessToken || (data.data && data.data.token);
      const user = data.user || (data.data && data.data.user) || null;
      if (token) setToken(token, true);
      if (user) localStorage.setItem("fash_user", JSON.stringify(user));
      sessionStorage.setItem("fashNewSignup", "1");
      return data;
    },

    async restoreSession() {
      try {
        const data = await this.getCurrentUser();
        const user = data && data.user ? data.user : data;
        if (user) {
          localStorage.setItem("fash_user", JSON.stringify(user));
          sessionStorage.removeItem("fash_user");
          window.dispatchEvent(new CustomEvent("fash:session-restored", { detail: { user } }));
          return user;
        }
      } catch (error) {
        if (error && error.status === 401) clearToken();
      }
      return null;
    },

    // BUGFIX: login.js, register.js, admin/login.js and seller/login.js all call
    // FASH_API.saveSession(user, token) / FASH_API.clearSession() after a login or
    // registration request. Neither method existed on this object, so every one of
    // those calls threw a TypeError immediately after a *successful* backend login,
    // landing in the caller's catch block and showing the user a false
    // "invalid email or password" / "registration failed" message even though the
    // account was created and the auth cookie was already set. Adding the two
    // methods here (matching the storage keys used by login()/register()/getToken())
    // fixes login, registration, seller login and admin login all at once.
    saveSession(user, token) {
      if (token) setToken(token, true);
      if (user) localStorage.setItem("fash_user", JSON.stringify(user));
    },

    clearSession() {
      clearToken();
    },

    async logout() {
      try {
        await request("/api/auth/logout", { method: "POST" });
      } catch (_) {
        // Always clear local state even if the network is already unavailable.
      }
      clearToken();
      window.dispatchEvent(new CustomEvent("fash:logout"));
    },

    getProducts(params = {}) {
      const query = new URLSearchParams();
      Object.entries(params || {}).forEach(([key, value]) => {
        if (value !== undefined && value !== null && String(value).trim() !== "") query.set(key, value);
      });
      return request(`/api/products${query.toString() ? `?${query}` : ""}`);
    },
    getProduct(productId) { return request(`/api/products/${encodeURIComponent(productId)}`); },
    getCategories() { return request("/api/categories"); },
    searchProducts(query, params = {}) { return this.getProducts({ ...params, q: query }); },

    getCart(){return request("/api/cart");},
    addCartItem(product_id,quantity=1){return request("/api/cart/items",{method:"POST",body:JSON.stringify({product_id,quantity})});},
    updateCartItem(itemId,quantity){return request(`/api/cart/items/${itemId}`,{method:"PATCH",body:JSON.stringify({quantity})});},
    removeCartItem(itemId){return request(`/api/cart/items/${itemId}`,{method:"DELETE"});},
    getWishlist(){return request("/api/wishlist");},
    addWishlistItem(product_id){return request("/api/wishlist/items",{method:"POST",body:JSON.stringify({product_id})});},
    removeWishlistItem(productId){return request(`/api/wishlist/items/${productId}`,{method:"DELETE"});},
  };

  // Backward-compatible callable alias. Older FASH pages use FASH_API.api(path, options).
  // Keep the modern helper object while supporting those pages so login and other flows do not break.
  api.api = request;
  window.FASH_API = api;
})();
