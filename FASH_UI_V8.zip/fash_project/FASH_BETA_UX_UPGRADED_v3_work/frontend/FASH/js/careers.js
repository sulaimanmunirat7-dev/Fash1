"use strict";

document.addEventListener("DOMContentLoaded", () => {

    /*==================================================
    SCROLL REVEAL
    ==================================================*/

    const sections = document.querySelectorAll(
        ".careers-section, .application-section"
    );

    const observer = new IntersectionObserver(
        entries => {

            entries.forEach(entry => {

                if (!entry.isIntersecting) {
                    return;
                }

                entry.target.classList.add(
                    "visible"
                );

                observer.unobserve(
                    entry.target
                );

            });

        },
        {
            threshold: 0.12
        }
    );

    sections.forEach(section => {

        section.classList.add(
            "career-reveal"
        );

        observer.observe(section);

    });


    /*==================================================
    JOB APPLICATION BUTTONS
    ==================================================*/

    const applyButtons =
        document.querySelectorAll(
            ".apply-btn"
        );

    applyButtons.forEach(button => {

        button.addEventListener(
            "click",
            () => {

                const job =
                    button.dataset.job ||
                    "FASH position";

                const application =
                    document.getElementById(
                        "application"
                    );

                if (application) {

                    application.scrollIntoView({
                        behavior: "smooth"
                    });

                }

                setTimeout(() => {

                    alert(
                        `You're interested in the ${job} position. Application functionality can be connected here.`
                    );

                }, 500);

            }
        );

    });


    /*==================================================
    GENERAL APPLICATION
    ==================================================*/

    const generalButton =
        document.getElementById(
            "generalApplication"
        );

    if (generalButton) {

        generalButton.addEventListener(
            "click",
            () => {

                alert(
                    "General applications will be available soon."
                );

            }
        );

    }

});