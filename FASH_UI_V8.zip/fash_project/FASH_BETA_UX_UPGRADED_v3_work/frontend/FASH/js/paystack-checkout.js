/**
 * FASH Paystack Checkout (Nigeria / NGN)
 * Requires: backend /api/checkout/initialize + /api/checkout/verify/:reference
 * and Paystack public key from /api/payments/public-key
 */
(function () {
  const API_BASE = window.FASH_API_BASE || "";

  function formatNgn(amount) {
    return "₦" + Number(amount).toLocaleString("en-NG", { maximumFractionDigits: 0 });
  }

  async function api(path, options = {}) {
    const res = await fetch(API_BASE + path, {
      credentials: "include",
      headers: { "Content-Type": "application/json", ...(options.headers || {}) },
      ...options,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || data.message || "Request failed");
    return data;
  }

  async function loadPaystackScript() {
    if (window.PaystackPop) return;
    await new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = "https://js.paystack.co/v1/inline.js";
      s.onload = resolve;
      s.onerror = () => reject(new Error("Could not load Paystack"));
      document.head.appendChild(s);
    });
  }

  async function startPaystackCheckout() {
    const btn = document.getElementById("fash-pay-btn") || document.querySelector("[data-fash-pay]");
    if (btn) {
      btn.disabled = true;
      btn.textContent = "Preparing payment…";
    }
    try {
      await loadPaystackScript();
      const init = await api("/api/checkout/initialize", { method: "POST", body: "{}" });
      const { publicKey } = await api("/api/payments/public-key");

      if (!publicKey || publicKey.includes("xxxx")) {
        throw new Error("Paystack public key is not configured on the server");
      }

      const handler = window.PaystackPop.setup({
        key: publicKey,
        email: init.email || undefined,
        amount: Math.round(Number(init.amount) * 100), // kobo
        currency: init.currency || "NGN",
        ref: init.reference,
        callback: function (response) {
          verifyAndRedirect(response.reference);
        },
        onClose: function () {
          if (btn) {
            btn.disabled = false;
            btn.textContent = "Pay with Paystack";
          }
        },
      });
      handler.openIframe();
    } catch (err) {
      alert(err.message || "Could not start payment");
      if (btn) {
        btn.disabled = false;
        btn.textContent = "Pay with Paystack";
      }
    }
  }

  async function verifyAndRedirect(reference) {
    try {
      const result = await api("/api/checkout/verify/" + encodeURIComponent(reference));
      if (result.success) {
        window.location.href = "/pages/success.html?ref=" + encodeURIComponent(reference);
      } else {
        alert("Payment could not be confirmed");
      }
    } catch (err) {
      alert(err.message || "Verification failed");
    }
  }

  // Auto-bind
  document.addEventListener("DOMContentLoaded", () => {
    const btn = document.getElementById("fash-pay-btn") || document.querySelector("[data-fash-pay]");
    if (btn) btn.addEventListener("click", (e) => { e.preventDefault(); startPaystackCheckout(); });
  });

  window.FashPaystack = { start: startPaystackCheckout, formatNgn, verify: verifyAndRedirect };
})();
