/* FASH v7.0 — Customer Experience Session & QA Layer */
(function () {
  "use strict";

  const state = {
    booted: false,
    user: null
  };

  function safeJson(value) {
    try { return JSON.parse(value); } catch (_) { return null; }
  }

  function getStoredUser() {
    return safeJson(
      localStorage.getItem("fash_user") ||
      sessionStorage.getItem("fash_user") ||
      "null"
    );
  }

  function setUser(user) {
    state.user = user || null;
    if (user) {
      localStorage.setItem("fash_user", JSON.stringify(user));
      document.documentElement.classList.add("fash-authenticated");
      document.documentElement.classList.remove("fash-guest");
    } else {
      localStorage.removeItem("fash_user");
      sessionStorage.removeItem("fash_user");
      document.documentElement.classList.remove("fash-authenticated");
      document.documentElement.classList.add("fash-guest");
    }
  }

  function emit(name, detail) {
    window.dispatchEvent(new CustomEvent(name, { detail }));
  }

  async function restoreSession() {
    const api = window.FASH_API;
    if (!api || typeof api.restoreSession !== "function") {
      setUser(getStoredUser());
      return state.user;
    }

    const user = await api.restoreSession();
    setUser(user || getStoredUser());
    return state.user;
  }

  function updateAccountLabels() {
    const user = state.user;
    const name = user && (user.full_name || user.name || user.first_name);

    document.querySelectorAll("[data-fash-account-greeting]").forEach((el) => {
      el.textContent = name ? `Hello, ${name}` : "Hello, Guest";
    });

    document.querySelectorAll("[data-fash-account-name]").forEach((el) => {
      el.textContent = name || "Guest";
    });
  }

  function runFrontendChecks() {
    const results = {
      apiClient: Boolean(window.FASH_API),
      catalogClient: Boolean(window.FASH_CATALOG),
      customerData: Boolean(window.FASH_CUSTOMER_DATA),
      checkout: Boolean(window.FASH_CHECKOUT),
      account: Boolean(window.FASH_ACCOUNT),
      navbar: Boolean(document.querySelector("nav, .navbar, .site-header, header"))
    };

    window.FASH_CUSTOMER_QA_RESULTS = results;
    return results;
  }

  async function boot() {
    if (state.booted) return state.user;
    state.booted = true;

    setUser(getStoredUser());

    try {
      await restoreSession();
    } catch (_) {
      setUser(getStoredUser());
    }

    updateAccountLabels();
    runFrontendChecks();
    emit("fash:customer-ready", {
      user: state.user,
      checks: window.FASH_CUSTOMER_QA_RESULTS
    });

    return state.user;
  }

  window.FASH_CUSTOMER_EXPERIENCE = {
    boot,
    restoreSession,
    getUser: () => state.user,
    isAuthenticated: () => Boolean(state.user),
    runFrontendChecks
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();
