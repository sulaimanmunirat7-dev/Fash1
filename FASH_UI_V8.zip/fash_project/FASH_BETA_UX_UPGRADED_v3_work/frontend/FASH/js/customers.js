document.addEventListener("DOMContentLoaded",()=>console.log("FASH Seller Customers ready"));
