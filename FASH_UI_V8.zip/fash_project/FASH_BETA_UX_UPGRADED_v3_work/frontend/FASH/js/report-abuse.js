"use strict";

document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("reportForm");
    const description = document.getElementById("description");
    const characterCount = document.getElementById("characterCount");

    const evidence = document.getElementById("evidence");
    const fileName = document.getElementById("fileName");

    const successMessage =
        document.getElementById("reportSuccess");

    const newReport =
        document.getElementById("newReport");

    const contactSupport =
        document.getElementById("contactSupport");

    const footerYear =
        document.getElementById("footerYear");


    /*==================================================
    CHARACTER COUNT
    ==================================================*/

    if (description && characterCount) {

        description.addEventListener("input", () => {

            characterCount.textContent =
                description.value.length;

        });

    }


    /*==================================================
    FILE UPLOAD
    ==================================================*/

    if (evidence && fileName) {

        evidence.addEventListener("change", () => {

            const file = evidence.files[0];

            if (!file) {

                fileName.textContent = "";

                return;
            }


            const maxSize =
                10 * 1024 * 1024;


            if (file.size > maxSize) {

                alert(
                    "This file is too large. Please choose a file smaller than 10MB."
                );

                evidence.value = "";

                fileName.textContent = "";

                return;
            }


            fileName.textContent =
                `Selected: ${file.name}`;

        });

    }


    /*==================================================
    SUBMIT REPORT
    ==================================================*/

    if (form && successMessage) {

        form.addEventListener("submit", (event) => {

            event.preventDefault();


            if (!form.checkValidity()) {

                form.reportValidity();

                return;

            }


            const submitButton =
                form.querySelector(".submit-report");


            if (submitButton) {

                submitButton.disabled = true;

                submitButton.textContent =
                    "Submitting...";

            }


            /*
             * DEMO SUBMISSION
             *
             * This currently displays the success message
             * locally. Connect this section to your backend
             * when FASH has a real reporting system.
             */

            setTimeout(() => {

                form.style.display = "none";

                successMessage.classList.add("show");

                successMessage.scrollIntoView({
                    behavior: "smooth",
                    block: "center"
                });

            }, 700);

        });

    }


    /*==================================================
    SUBMIT ANOTHER REPORT
    ==================================================*/

    if (newReport && form && successMessage) {

        newReport.addEventListener("click", () => {

            form.reset();

            if (characterCount) {
                characterCount.textContent = "0";
            }

            if (fileName) {
                fileName.textContent = "";
            }

            const submitButton =
                form.querySelector(".submit-report");

            if (submitButton) {

                submitButton.disabled = false;

                submitButton.textContent =
                    "Submit report →";

            }


            successMessage.classList.remove("show");

            form.style.display = "block";

            form.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });

        });

    }


    /*==================================================
    CONTACT SUPPORT
    ==================================================*/

    if (contactSupport) {

        contactSupport.addEventListener("click", () => {

            window.location.href =
                "mailto:support@fash.com?subject=FASH%20Support";

        });

    }


    /*==================================================
    CURRENT YEAR
    ==================================================*/

    if (footerYear) {

        footerYear.textContent =
            `© ${new Date().getFullYear()} FASH. All rights reserved.`;

    }

});