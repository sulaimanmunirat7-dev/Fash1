/* FASH v6.3 Customer Feature Bridge */
(function () {
  "use strict";

  function productIdFromElement(el) {
    return el?.dataset?.productId || el?.dataset?.id || el?.getAttribute("data-product-id");
  }

  function cartPayloadFromElement(el) {
    const productId = productIdFromElement(el);
    const card = el.closest("[data-product-id], .product-card, .product-detail");
    const quantityInput = card?.querySelector("[name=quantity], .quantity input, [data-quantity]");
    const quantity = Number(quantityInput?.value || quantityInput?.dataset?.quantity || 1);
    return {
      product_id: productId,
      productId,
      quantity: Number.isFinite(quantity) && quantity > 0 ? quantity : 1
    };
  }

  document.addEventListener("click", async (event) => {
    const add = event.target.closest("[data-add-to-cart], .add-to-cart, .btn-add-cart");
    if (add && window.FASH_CUSTOMER_API) {
      event.preventDefault();
      if (!productIdFromElement(add)) return;
      const oldText = add.textContent;
      add.disabled = true;
      add.textContent = "Adding…";
      try {
        await window.FASH_CUSTOMER_API.cart.add(cartPayloadFromElement(add));
        window.dispatchEvent(new CustomEvent("fash:cart-updated"));
        add.textContent = "Added to cart";
      } catch (error) {
        console.error("Cart add failed:", error);
        alert(error.message || "Could not add this item to your cart.");
        add.textContent = oldText;
      } finally {
        add.disabled = false;
      }
    }

    const save = event.target.closest("[data-add-to-wishlist], .wishlist-btn, .save-item");
    if (save && window.FASH_CUSTOMER_API) {
      event.preventDefault();
      const productId = productIdFromElement(save);
      if (!productId) return;
      try {
        await window.FASH_CUSTOMER_API.wishlist.add(productId);
        save.classList.add("is-saved");
        window.dispatchEvent(new CustomEvent("fash:wishlist-updated"));
      } catch (error) {
        console.error("Wishlist save failed:", error);
        alert(error.message || "Could not save this item.");
      }
    }
  });

  document.addEventListener("submit", async (event) => {
    const form = event.target;
    if (!window.FASH_CUSTOMER_API) return;

    if (form.matches("[data-fash-search], .search-form, form[action*='search']")) {
      const input = form.querySelector("[name=q], [name=search], input[type=search], input[type=text]");
      const query = input?.value?.trim();
      if (!query) return;
      event.preventDefault();
      const target = form.dataset.resultsTarget;
      if (target) {
        const container = document.querySelector(target);
        if (container) container.dataset.loading = "true";
        try {
          const result = await window.FASH_CUSTOMER_API.products.search(query);
          window.dispatchEvent(new CustomEvent("fash:search-results", { detail: result }));
          if (container) container.dataset.loading = "false";
        } catch (error) {
          if (container) container.dataset.loading = "false";
          alert(error.message || "Search failed.");
        }
      }
    }
  });
})();
