/*==================================================
FASH CATEGORIES
==================================================*/

document.addEventListener("DOMContentLoaded", function () {

    const page = document.querySelector(".categories-page");

    if (!page) {
        return;
    }

    const categorySearch = document.getElementById("categorySearch");
    const categorySearchButton = document.getElementById("categorySearchButton");

    function openShopWithSearch() {
        if (!categorySearch) {
            return;
        }

        const value = categorySearch.value.trim();

        if (!value) {
            window.location.href = "shop.html";
            return;
        }

        window.location.href =
            "shop.html?search=" + encodeURIComponent(value);
    }

    if (categorySearchButton) {
        categorySearchButton.addEventListener("click", openShopWithSearch);
    }

    if (categorySearch) {
        categorySearch.addEventListener("keydown", function (event) {
            if (event.key === "Enter") {
                event.preventDefault();
                openShopWithSearch();
            }
        });
    }

    document.querySelectorAll("[data-category-link]").forEach(function (button) {
        button.addEventListener("click", function () {
            const category = button.dataset.categoryLink;

            if (!category) {
                return;
            }

            window.location.href =
                "shop.html?category=" + encodeURIComponent(category);
        });
    });

    document.querySelectorAll(".category-card").forEach(function (card) {
        card.addEventListener("mouseenter", function () {
            card.classList.add("is-hovered");
        });

        card.addEventListener("mouseleave", function () {
            card.classList.remove("is-hovered");
        });
    });

    console.log("FASH Categories loaded successfully.");
});
