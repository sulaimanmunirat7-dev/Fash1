/* FASH v6 Account & Navigation QA helpers */
(function () {
  "use strict";

  window.FASH_NAV_QA = {
    greeting(user, mode) {
      if (!user) return "Hello, Guest";
      const raw = String(user.name || user.first_name || user.username || "there").trim();
      const name = raw.split(/\s+/)[0] || "there";
      return mode === "signup" ? `Welcome, ${name}` : `Welcome back, ${name}`;
    },

    isSeller(user) {
      if (!user) return false;
      return Boolean(
        user.is_seller === true ||
        user.isSeller === true ||
        user.role === "seller" ||
        user.role === "approved_seller" ||
        user.seller_status === "approved" ||
        user.sellerStatus === "approved"
      );
    },

    closeMenus() {
      document.querySelectorAll(
        ".account-dropdown.show, .account-menu.show, .user-dropdown.show, " +
        ".account-dropdown.open, .account-menu.open, .user-dropdown.open"
      ).forEach((el) => {
        el.classList.remove("show", "open");
        el.setAttribute("aria-hidden", "true");
      });
    },

    init() {
      document.addEventListener("keydown", (event) => {
        if (event.key === "Escape") this.closeMenus();
      });

      document.addEventListener("click", (event) => {
        const inAccount = event.target.closest(
          ".account-dropdown, .account-menu, .user-dropdown, .account-popover, [data-account-menu], .account-btn, .account-button"
        );
        if (!inAccount) this.closeMenus();
      });
    }
  };

  document.addEventListener("DOMContentLoaded", () => window.FASH_NAV_QA.init());
})();
