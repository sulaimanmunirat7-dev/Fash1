/*==================================================
FASH MARKETPLACE
CHECKOUT JAVASCRIPT
==================================================*/

"use strict";


/*==================================================
CART STORAGE
==================================================*/

const FASH_CART_KEYS = [
    "fash_cart",
    "FASH_cart",
    "cart"
];


function getCheckoutCart() {

    for (const key of FASH_CART_KEYS) {

        try {

            const stored =
                localStorage.getItem(key);

            if (!stored) continue;

            const cart =
                JSON.parse(stored);

            if (Array.isArray(cart)) {
                return cart;
            }

        } catch (error) {

            console.warn(
                `Could not read cart key: ${key}`,
                error
            );

        }

    }

    return [];

}


/*==================================================
SAVE CART
==================================================*/

function saveCheckoutCart(cart) {

    /*
     * Keep the main FASH cart key as the source
     * of truth.
     */

    localStorage.setItem(
        "fash_cart",
        JSON.stringify(cart)
    );


    /*
     * Tell the rest of the site that the cart
     * changed.
     */

    window.dispatchEvent(
        new CustomEvent(
            "fash:cart-updated"
        )
    );

}


/*==================================================
PRICE FORMAT
==================================================*/

function formatCheckoutPrice(value) {

    const amount =
        Number(value) || 0;

    return new Intl.NumberFormat(
        "en-NG",
        {
            style: "currency",
            currency: "NGN",
            maximumFractionDigits: 0
        }
    ).format(amount);

}


/*==================================================
PRODUCT HELPERS
==================================================*/

function checkoutProductName(product) {

    return (
        product.name ||
        product.title ||
        product.productName ||
        "Product"
    );

}


function checkoutProductImage(product) {

    return (
        product.image ||
        product.imageUrl ||
        product.thumbnail ||
        "../assets/images/logos/Logo.png"
    );

}


function checkoutProductPrice(product) {

    return Number(
        product.price ||
        product.currentPrice ||
        0
    );

}


function checkoutProductOldPrice(product) {

    return Number(
        product.oldPrice ||
        product.originalPrice ||
        product.previousPrice ||
        0
    );

}


function checkoutProductQuantity(product) {

    const quantity =
        Number(
            product.quantity ||
            product.qty ||
            1
        );

    return quantity > 0
        ? quantity
        : 1;

}


/*==================================================
CALCULATE SUBTOTAL
==================================================*/

function calculateCheckoutSubtotal(cart) {

    return cart.reduce(
        (total, product) => {

            const price =
                checkoutProductPrice(product);

            const quantity =
                checkoutProductQuantity(product);

            return total +
                (price * quantity);

        },
        0
    );

}


/*==================================================
CALCULATE DISCOUNT
==================================================*/

function calculateCheckoutDiscount(cart) {

    return cart.reduce(
        (total, product) => {

            const price =
                checkoutProductPrice(product);

            const oldPrice =
                checkoutProductOldPrice(product);

            const quantity =
                checkoutProductQuantity(product);


            if (
                oldPrice > price &&
                price > 0
            ) {

                return total +
                    ((oldPrice - price) * quantity);

            }


            return total;

        },
        0
    );

}


/*==================================================
TOTAL QUANTITY
==================================================*/

function calculateCheckoutItemCount(cart) {

    return cart.reduce(
        (total, product) => {

            return total +
                checkoutProductQuantity(product);

        },
        0
    );

}


/*==================================================
RENDER CART ITEMS
==================================================*/

function renderCheckoutProducts(cart) {

    const container =
        document.getElementById(
            "checkoutProducts"
        );

    if (!container) return;


    if (!cart.length) {

        container.innerHTML = `

            <div class="checkout-empty">

                <i class="fa-solid fa-cart-shopping"></i>

                <h3>
                    Your cart is empty
                </h3>

                <p>
                    Add products to your cart before checkout.
                </p>

            </div>

        `;

        return;

    }


    container.innerHTML =
        cart.map(
            product => {

                const name =
                    checkoutProductName(product);

                const image =
                    checkoutProductImage(product);

                const price =
                    checkoutProductPrice(product);

                const quantity =
                    checkoutProductQuantity(product);


                return `

                    <div
                        class="checkout-product"
                        data-product-id="${product.id ?? ""}">

                        <div class="checkout-product-image">

                            <img
                                src="${image}"
                                alt="${name}">

                        </div>


                        <div class="checkout-product-info">

                            <h3>
                                ${name}
                            </h3>

                            <span>
                                Qty: ${quantity}
                            </span>

                        </div>


                        <strong class="checkout-product-price">

                            ${formatCheckoutPrice(
                                price * quantity
                            )}

                        </strong>

                    </div>

                `;

            }
        ).join("");

}


/*==================================================
UPDATE SUMMARY
==================================================*/

function updateCheckoutSummary(cart) {

    const itemCount =
        calculateCheckoutItemCount(cart);

    const subtotal =
        calculateCheckoutSubtotal(cart);

    const discount =
        calculateCheckoutDiscount(cart);

    const total =
        subtotal;


    const countElement =
        document.getElementById(
            "checkoutItemCount"
        );

    const subtotalElement =
        document.getElementById(
            "checkoutSubtotal"
        );

    const discountElement =
        document.getElementById(
            "checkoutDiscount"
        );

    const totalElement =
        document.getElementById(
            "checkoutTotal"
        );


    if (countElement) {

        countElement.textContent =
            `${itemCount} ${
                itemCount === 1
                    ? "item"
                    : "items"
            }`;

    }


    if (subtotalElement) {

        subtotalElement.textContent =
            formatCheckoutPrice(
                subtotal
            );

    }


    if (discountElement) {

        discountElement.textContent =
            `-${formatCheckoutPrice(
                discount
            )}`;

    }


    if (totalElement) {

        totalElement.textContent =
            formatCheckoutPrice(
                total
            );

    }

}


/*==================================================
RENDER CHECKOUT
==================================================*/

function renderCheckout() {

    const cart =
        getCheckoutCart();


    renderCheckoutProducts(
        cart
    );


    updateCheckoutSummary(
        cart
    );


    return cart;

}


/*==================================================
VALIDATE CUSTOMER INFORMATION
==================================================*/

function validateCheckoutForm() {

    const firstName =
        document.getElementById(
            "checkoutFirstName"
        );

    const lastName =
        document.getElementById(
            "checkoutLastName"
        );

    const email =
        document.getElementById(
            "checkoutEmail"
        );

    const phone =
        document.getElementById(
            "checkoutPhone"
        );


    const fields = [
        firstName,
        lastName,
        email,
        phone
    ];


    for (const field of fields) {

        if (
            !field ||
            !field.value.trim()
        ) {

            if (field) {

                field.focus();

            }

            return false;

        }

    }


    if (
        email &&
        !email.checkValidity()
    ) {

        email.focus();

        return false;

    }


    return true;

}


/*==================================================
GET CUSTOMER INFORMATION
==================================================*/

function getCustomerInformation() {

    return {

        firstName:
            document
                .getElementById(
                    "checkoutFirstName"
                )
                ?.value
                .trim() || "",

        lastName:
            document
                .getElementById(
                    "checkoutLastName"
                )
                ?.value
                .trim() || "",

        email:
            document
                .getElementById(
                    "checkoutEmail"
                )
                ?.value
                .trim() || "",

        phone:
            document
                .getElementById(
                    "checkoutPhone"
                )
                ?.value
                .trim() || "",

        notes:
            document
                .getElementById(
                    "checkoutNotes"
                )
                ?.value
                .trim() || ""

    };

}


/*==================================================
PAYMENT METHOD
==================================================*/

function getPaymentMethod() {

    const selected =
        document.querySelector(
            'input[name="paymentMethod"]:checked'
        );


    return selected
        ? selected.value
        : "test";

}


/*==================================================
CREATE ORDER
==================================================*/

function createFashOrder(
    cart,
    customer,
    paymentMethod
) {

    const subtotal =
        calculateCheckoutSubtotal(
            cart
        );

    const discount =
        calculateCheckoutDiscount(
            cart
        );


    const order = {

        id:
            `FASH-${Date.now()}`,

        createdAt:
            new Date().toISOString(),

        status:
            "processing",

        paymentMethod,

        customer,

        items:
            cart.map(
                product => ({
                    ...product,
                    quantity:
                        checkoutProductQuantity(
                            product
                        )
                })
            ),

        subtotal,

        discount,

        total:
            subtotal

    };


    let orders = [];


    try {

        orders =
            JSON.parse(
                localStorage.getItem(
                    "fash_orders"
                )
            ) || [];

    } catch {

        orders = [];

    }


    orders.unshift(
        order
    );


    localStorage.setItem(
        "fash_orders",
        JSON.stringify(orders)
    );


    return order;

}


/*==================================================
CLEAR CART
==================================================*/

function clearCheckoutCart() {

    localStorage.setItem(
        "fash_cart",
        JSON.stringify([])
    );


    /*
     * Clear possible old cart keys too,
     * so old data doesn't come back.
     */

    localStorage.removeItem(
        "FASH_cart"
    );

    localStorage.removeItem(
        "cart"
    );


    window.dispatchEvent(
        new CustomEvent(
            "fash:cart-updated"
        )
    );

}


/*==================================================
ORDER SUCCESS
==================================================*/

function showCheckoutSuccess(order) {

    const main =
        document.querySelector(
            ".checkout-page"
        );

    if (!main) return;


    main.innerHTML = `

        <section
            class="checkout-success">

            <div
                class="checkout-success-card">

                <div class="checkout-success-icon">

                    <i class="fa-solid fa-check"></i>

                </div>


                <span class="checkout-eyebrow">

                    ORDER CONFIRMED

                </span>


                <h1>

                    Thank you for your order!

                </h1>


                <p>

                    Your order has been placed successfully.

                </p>


                <div class="checkout-order-number">

                    <span>
                        Order Number
                    </span>

                    <strong>
                        ${order.id}
                    </strong>

                </div>


                <div class="checkout-success-actions">

                    <a
                        href="shop.html"
                        class="checkout-success-button">

                        Continue Shopping

                    </a>

                    <a
                        href="orders.html"
                        class="checkout-success-secondary">

                        View Orders

                    </a>

                </div>

            </div>

        </section>

    `;

}


/*==================================================
PLACE ORDER
==================================================*/

function setupPlaceOrder() {

    const button =
        document.getElementById(
            "placeOrderButton"
        );

    if (!button) return;


    button.addEventListener(
        "click",
        function () {

            const cart =
                getCheckoutCart();


            /*
             * Prevent empty orders.
             */

            if (!cart.length) {

                alert(
                    "Your cart is empty."
                );

                return;

            }


            /*
             * Validate customer details.
             */

            if (
                !validateCheckoutForm()
            ) {

                alert(
                    "Please complete your customer information."
                );

                return;

            }


            const customer =
                getCustomerInformation();


            const paymentMethod =
                getPaymentMethod();


            /*
             * Disable button while processing.
             */

            button.disabled =
                true;

            button.innerHTML = `

                <i class="fa-solid fa-spinner fa-spin"></i>

                Processing Order...

            `;


            /*
             * Demo/test processing.
             */

            setTimeout(async function () {
                    try {
                        let order;
                        // BUGFIX: this used to check localStorage.getItem("fashToken"),
                        // a key nothing in the app ever sets (the real session token is
                        // stored under "fash_token", and the logged-in user under
                        // "fash_user", both by api-client.js). Because that check always
                        // failed, every logged-in customer's checkout silently skipped the
                        // real POST /api/orders call and fabricated a fake, unsaved local
                        // order object instead — showing a "success" screen for an order
                        // that was never written to the database. Checking "fash_user"
                        // (set on successful login/register) fixes that for real customers
                        // while still letting guest checkout fall back to the demo order.
                        if (window.FASH_API && localStorage.getItem("fash_user")) {
                            const data = await FASH_API.api("/api/orders", {
                                method: "POST",
                                body: JSON.stringify({
                                    items: cart.map(p => ({
                                        productId: p.id,
                                        quantity: checkoutProductQuantity(p)
                                    }))
                                })
                            });
                            order = createFashOrder(cart, customer, paymentMethod);
                            order.backendId = data.order?.id || null;
                        } else {
                            order = createFashOrder(cart, customer, paymentMethod);
                        }
                        clearCheckoutCart();
                        showCheckoutSuccess(order);
                    } catch (error) {
                        alert(error.message || "Could not place order. Please try again.");
                        button.disabled = false;
                        button.innerHTML = "Place Order";
                    }
                }, 300);

        }
    );

}


/*==================================================
LISTEN FOR CART CHANGES
==================================================*/

window.addEventListener(
    "fash:cart-updated",
    function () {

        /*
         * If checkout is still visible,
         * immediately refresh it.
         */

        if (
            document.getElementById(
                "checkoutProducts"
            )
        ) {

            renderCheckout();

        }

    }
);


/*==================================================
INITIALIZE
==================================================*/

function initializeCheckout() {

    renderCheckout();

    setupPlaceOrder();

}


if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        initializeCheckout,
        { once: true }
    );

} else {

    initializeCheckout();

}