/* FASH ADMIN LOGIN — BACKEND AUTH */
(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("adminLoginForm");
    const email = document.getElementById("adminEmail");
    const password = document.getElementById("adminPassword");
    const button = document.getElementById("adminLoginButton");
    const message = document.getElementById("message");

    form?.addEventListener("submit", async (event) => {
      event.preventDefault();

      const loginEmail = email.value.trim().toLowerCase();
      const loginPassword = password.value;

      if (!loginEmail || !loginPassword) return;

      button.disabled = true;
      button.textContent = "Signing in...";
      showMessage("", "");

      try {
        const data = await FASH_API.api("/api/auth/login", {
          method: "POST",
          body: JSON.stringify({
            email: loginEmail,
            password: loginPassword
          })
        });

        if (!data.user || data.user.role !== "admin") {
          FASH_API.clearSession();
          throw new Error("This account does not have administrator access.");
        }

        FASH_API.saveSession(data.user, data.token);
        showMessage("Login successful. Opening admin dashboard...", "success");

        setTimeout(() => {
          window.location.href = "./admin.html";
        }, 300);
      } catch (error) {
        console.error("ADMIN LOGIN ERROR:", error);
        showMessage(error.message || "Invalid email or password.", "error");
      } finally {
        button.disabled = false;
        button.textContent = "Sign in as Admin";
      }
    });

    function showMessage(text, type) {
      message.textContent = text;
      message.className = type || "";
    }
  });
})();
