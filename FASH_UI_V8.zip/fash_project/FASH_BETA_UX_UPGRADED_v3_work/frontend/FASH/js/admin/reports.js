/* =========================================================
   FASH ADMIN — REPORTS
   reports.js
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    /* =====================================================
       STORAGE KEYS
    ===================================================== */

    const ORDERS_KEY = "fash_admin_orders";
    const PRODUCTS_KEY = "fash_admin_products";
    const SELLERS_KEY = "fash_admin_sellers";
    const CUSTOMERS_KEY = "fash_admin_customers";
    const RETURNS_KEY = "fash_admin_returns";


    /* =====================================================
       ELEMENTS
    ===================================================== */

    const reportPeriod =
        document.getElementById("reportPeriod");

    const salesMetric =
        document.getElementById("salesMetric");

    const refreshBtn =
        document.getElementById("refreshReportsBtn");

    const exportBtn =
        document.getElementById("exportReportBtn");

    const notificationBtn =
        document.getElementById("notificationBtn");


    /* =====================================================
       STAT ELEMENTS
    ===================================================== */

    const totalRevenue =
        document.getElementById("totalRevenue");

    const totalOrders =
        document.getElementById("totalOrders");

    const activeCustomers =
        document.getElementById("activeCustomers");

    const returnRate =
        document.getElementById("returnRate");

    const processingOrders =
        document.getElementById("processingOrders");

    const shippedOrders =
        document.getElementById("shippedOrders");

    const deliveredOrders =
        document.getElementById("deliveredOrders");

    const cancelledOrders =
        document.getElementById("cancelledOrders");

    const newCustomers =
        document.getElementById("newCustomers");

    const returningCustomers =
        document.getElementById("returningCustomers");

    const averageOrderValue =
        document.getElementById("averageOrderValue");

    const returnedOrders =
        document.getElementById("returnedOrders");

    const refundValue =
        document.getElementById("refundValue");

    const topProducts =
        document.getElementById("topProducts");

    const categoryPerformance =
        document.getElementById(
            "categoryPerformance"
        );

    const sellerReportBody =
        document.getElementById(
            "sellerReportBody"
        );

    const reportLastUpdated =
        document.getElementById(
            "reportLastUpdated"
        );


    /* =====================================================
       CHARTS
    ===================================================== */

    let salesChart = null;

    let orderStatusChart = null;


    /* =====================================================
       DATA
    ===================================================== */

    let orders = loadData(
        ORDERS_KEY,
        []
    );

    let products = loadData(
        PRODUCTS_KEY,
        []
    );

    let sellers = loadData(
        SELLERS_KEY,
        []
    );

    let customers = loadData(
        CUSTOMERS_KEY,
        []
    );

    let returns = loadData(
        RETURNS_KEY,
        []
    );


    /* =====================================================
       DEMO DATA FALLBACK
    ===================================================== */

    if (!orders.length) {

        orders = createDemoOrders();

    }

    if (!products.length) {

        products = createDemoProducts();

    }

    if (!sellers.length) {

        sellers = createDemoSellers();

    }

    if (!customers.length) {

        customers = createDemoCustomers();

    }

    if (!returns.length) {

        returns = createDemoReturns();

    }


    /* =====================================================
       INITIAL RENDER
    ===================================================== */

    renderReports();


    /* =====================================================
       PERIOD CHANGE
    ===================================================== */

    reportPeriod.addEventListener(
        "change",
        () => {

            renderReports();

            showToast(
                "Report period updated.",
                "success"
            );

        }
    );


    /* =====================================================
       SALES METRIC CHANGE
    ===================================================== */

    salesMetric.addEventListener(
        "change",
        () => {

            renderSalesChart();

        }
    );


    /* =====================================================
       REFRESH
    ===================================================== */

    refreshBtn.addEventListener(
        "click",
        () => {

            orders =
                loadData(
                    ORDERS_KEY,
                    []
                );

            products =
                loadData(
                    PRODUCTS_KEY,
                    []
                );

            sellers =
                loadData(
                    SELLERS_KEY,
                    []
                );

            customers =
                loadData(
                    CUSTOMERS_KEY,
                    []
                );

            returns =
                loadData(
                    RETURNS_KEY,
                    []
                );


            if (!orders.length)
                orders = createDemoOrders();

            if (!products.length)
                products = createDemoProducts();

            if (!sellers.length)
                sellers = createDemoSellers();

            if (!customers.length)
                customers = createDemoCustomers();

            if (!returns.length)
                returns = createDemoReturns();


            renderReports();


            showToast(
                "Reports refreshed successfully.",
                "success"
            );

        }
    );


    /* =====================================================
       NOTIFICATION
    ===================================================== */

    if (notificationBtn) {

        notificationBtn.addEventListener(
            "click",
            () => {

                const pending =
                    returns.filter(
                        item =>
                            normalizeStatus(
                                item.status
                            ) === "pending"
                    ).length;


                if (pending > 0) {

                    showToast(
                        `${pending} return request${pending === 1 ? "" : "s"} require attention.`,
                        "warning"
                    );

                } else {

                    showToast(
                        "No urgent report notifications.",
                        "success"
                    );

                }

            }
        );

    }


    /* =====================================================
       EXPORT
    ===================================================== */

    exportBtn.addEventListener(
        "click",
        exportReport
    );


    /* =====================================================
       MAIN RENDER
    ===================================================== */

    function renderReports() {

        const days =
            Number(reportPeriod.value) || 30;


        const filteredOrders =
            filterByPeriod(
                orders,
                days
            );


        const filteredReturns =
            filterByPeriod(
                returns,
                days
            );


        const filteredCustomers =
            filterByPeriod(
                customers,
                days
            );


        renderStatistics(
            filteredOrders,
            filteredReturns,
            filteredCustomers
        );


        renderSalesChart(
            filteredOrders
        );


        renderOrderStatus(
            filteredOrders
        );


        renderTopProducts(
            filteredOrders,
            products
        );


        renderCategories(
            filteredOrders,
            products
        );


        renderSellers(
            filteredOrders,
            sellers
        );


        renderCustomerActivity(
            filteredOrders,
            filteredCustomers
        );


        renderReturns(
            filteredOrders,
            filteredReturns
        );


        updateLastUpdated();

    }


    /* =====================================================
       STATISTICS
    ===================================================== */

    function renderStatistics(
        filteredOrders,
        filteredReturns,
        filteredCustomers
    ) {

        const revenue =
            filteredOrders.reduce(
                (
                    sum,
                    order
                ) =>
                    sum +
                    getOrderAmount(order),
                0
            );


        const orderCount =
            filteredOrders.length;


        const customerIds =
            new Set();


        filteredOrders.forEach(
            order => {

                const id =
                    getCustomerId(order);

                if (id) {
                    customerIds.add(id);
                }

            }
        );


        const activeCount =
            customerIds.size ||
            filteredCustomers.length;


        const returnedCount =
            filteredReturns.length;


        const rate =
            orderCount > 0
                ? (
                    returnedCount /
                    orderCount
                ) * 100
                : 0;


        totalRevenue.textContent =
            formatCurrency(revenue);


        totalOrders.textContent =
            formatNumber(orderCount);


        activeCustomers.textContent =
            formatNumber(activeCount);


        returnRate.textContent =
            `${rate.toFixed(1)}%`;

    }


    /* =====================================================
       SALES CHART
    ===================================================== */

    function renderSalesChart(
        filteredOrders = null
    ) {

        if (!filteredOrders) {

            filteredOrders =
                filterByPeriod(
                    orders,
                    Number(reportPeriod.value)
                );

        }


        const labels =
            getDateLabels(
                Number(reportPeriod.value)
            );


        const metric =
            salesMetric.value;


        const values =
            labels.map(
                label => {

                    const matching =
                        filteredOrders.filter(
                            order =>
                                formatDateKey(
                                    getOrderDate(order)
                                ) === label
                        );


                    if (
                        metric === "orders"
                    ) {

                        return matching.length;

                    }


                    return matching.reduce(
                        (
                            sum,
                            order
                        ) =>
                            sum +
                            getOrderAmount(order),
                        0
                    );

                }
            );


        const displayLabels =
            labels.map(
                date =>
                    formatChartDate(date)
            );


        const ctx =
            document.getElementById(
                "salesChart"
            );


        if (!ctx) return;


        if (salesChart) {

            salesChart.destroy();

        }


        salesChart =
            new Chart(
                ctx,
                {

                    type: "line",

                    data: {

                        labels:
                            displayLabels,

                        datasets: [

                            {

                                label:
                                    metric === "orders"
                                        ? "Orders"
                                        : "Revenue",

                                data:
                                    values,

                                borderColor:
                                    "#1463ff",

                                backgroundColor:
                                    "rgba(20, 99, 255, 0.10)",

                                borderWidth: 2,

                                fill: true,

                                tension: 0.4,

                                pointRadius: 2,

                                pointHoverRadius: 5

                            }

                        ]

                    },

                    options: {

                        responsive: true,

                        maintainAspectRatio: false,

                        interaction: {

                            intersect: false,

                            mode: "index"

                        },

                        plugins: {

                            legend: {

                                display: false

                            },

                            tooltip: {

                                callbacks: {

                                    label:
                                        context => {

                                            const value =
                                                context.raw;

                                            if (
                                                metric ===
                                                "orders"
                                            ) {

                                                return `${value} orders`;

                                            }

                                            return formatCurrency(
                                                value
                                            );

                                        }

                                }

                            }

                        },

                        scales: {

                            x: {

                                grid: {

                                    display: false

                                },

                                ticks: {

                                    color:
                                        "#98a2b3",

                                    font: {

                                        size: 8

                                    },

                                    maxTicksLimit: 8

                                }

                            },

                            y: {

                                beginAtZero: true,

                                grid: {

                                    color:
                                        "#f2f4f7"

                                },

                                ticks: {

                                    color:
                                        "#98a2b3",

                                    font: {

                                        size: 8

                                    },

                                    callback:
                                        value => {

                                            if (
                                                metric ===
                                                "orders"
                                            ) {

                                                return value;

                                            }

                                            return formatCompactCurrency(
                                                value
                                            );

                                        }

                                }

                            }

                        }

                    }

                }
            );

    }


    /* =====================================================
       ORDER STATUS CHART
    ===================================================== */

    function renderOrderStatus(
        filteredOrders
    ) {

        const counts = {

            processing: 0,

            shipped: 0,

            delivered: 0,

            cancelled: 0

        };


        filteredOrders.forEach(
            order => {

                const status =
                    normalizeStatus(
                        order.status
                    );


                if (
                    status === "processing" ||
                    status === "pending"
                ) {

                    counts.processing++;

                } else if (
                    status === "shipped"
                ) {

                    counts.shipped++;

                } else if (
                    status === "delivered" ||
                    status === "completed"
                ) {

                    counts.delivered++;

                } else if (
                    status === "cancelled" ||
                    status === "canceled"
                ) {

                    counts.cancelled++;

                }

            }
        );


        processingOrders.textContent =
            counts.processing;


        shippedOrders.textContent =
            counts.shipped;


        deliveredOrders.textContent =
            counts.delivered;


        cancelledOrders.textContent =
            counts.cancelled;


        const ctx =
            document.getElementById(
                "orderStatusChart"
            );


        if (!ctx) return;


        if (orderStatusChart) {

            orderStatusChart.destroy();

        }


        orderStatusChart =
            new Chart(
                ctx,
                {

                    type: "doughnut",

                    data: {

                        labels: [

                            "Processing",
                            "Shipped",
                            "Delivered",
                            "Cancelled"

                        ],

                        datasets: [

                            {

                                data: [

                                    counts.processing,
                                    counts.shipped,
                                    counts.delivered,
                                    counts.cancelled

                                ],

                                backgroundColor: [

                                    "#f59e0b",
                                    "#1463ff",
                                    "#16a34a",
                                    "#dc2626"

                                ],

                                borderWidth: 0,

                                hoverOffset: 4

                            }

                        ]

                    },

                    options: {

                        responsive: true,

                        maintainAspectRatio: false,

                        cutout: "72%",

                        plugins: {

                            legend: {

                                display: false

                            }

                        }

                    }

                }
            );

    }


    /* =====================================================
       TOP PRODUCTS
    ===================================================== */

    function renderTopProducts(
        filteredOrders,
        productList
    ) {

        const productMap = {};


        filteredOrders.forEach(
            order => {

                const productName =
                    getProductName(order);


                if (!productName)
                    return;


                if (!productMap[productName]) {

                    productMap[productName] = {

                        name:
                            productName,

                        units: 0,

                        revenue: 0

                    };

                }


                productMap[productName].units +=
                    getOrderQuantity(order);


                productMap[productName].revenue +=
                    getOrderAmount(order);

            }
        );


        let top =
            Object.values(
                productMap
            );


        top.sort(
            (
                a,
                b
            ) =>
                b.revenue -
                a.revenue
        );


        top =
            top.slice(
                0,
                5
            );


        if (!top.length) {

            topProducts.innerHTML =
                emptyMessage(
                    "No product sales available yet."
                );

            return;

        }


        topProducts.innerHTML =
            top
                .map(
                    (
                        item,
                        index
                    ) => {

                        const product =
                            productList.find(
                                product =>
                                    normalize(
                                        product.name
                                    ) ===
                                    normalize(
                                        item.name
                                    )
                            );


                        const image =
                            product?.image ||
                            product?.imageUrl ||
                            "";


                        return `

                            <div class="product-report-row">

                                <span class="product-rank">
                                    ${index + 1}
                                </span>


                                <div class="product-report-image">

                                    ${
                                        image
                                            ? `
                                                <img
                                                    src="${escapeHTML(image)}"
                                                    alt=""
                                                >
                                            `
                                            : `
                                                <i class="fa-solid fa-box"></i>
                                            `
                                    }

                                </div>


                                <div class="product-report-info">

                                    <strong>
                                        ${escapeHTML(item.name)}
                                    </strong>

                                    <span>
                                        ${formatNumber(item.units)}
                                        units sold
                                    </span>

                                </div>


                                <div class="product-report-sales">

                                    <strong>
                                        ${formatCurrency(item.revenue)}
                                    </strong>

                                    <span>
                                        Revenue
                                    </span>

                                </div>

                            </div>

                        `;

                    }
                )
                .join("");

    }


    /* =====================================================
       CATEGORIES
    ===================================================== */

    function renderCategories(
        filteredOrders,
        productList
    ) {

        const categoryMap = {};


        filteredOrders.forEach(
            order => {

                const productName =
                    getProductName(order);


                const product =
                    productList.find(
                        item =>
                            normalize(
                                item.name
                            ) ===
                            normalize(
                                productName
                            )
                    );


                const category =
                    product?.category ||
                    order.category ||
                    "Other";


                categoryMap[category] =
                    (
                        categoryMap[category] ||
                        0
                    ) +
                    getOrderAmount(order);

            }
        );


        let categories =
            Object.entries(
                categoryMap
            )
                .map(
                    (
                        [name, value]
                    ) => ({
                        name,
                        value
                    })
                );


        categories.sort(
            (
                a,
                b
            ) =>
                b.value -
                a.value
        );


        categories =
            categories.slice(
                0,
                5
            );


        if (!categories.length) {

            categoryPerformance.innerHTML =
                emptyMessage(
                    "No category sales available yet."
                );

            return;

        }


        const highest =
            categories[0].value;


        categoryPerformance.innerHTML =
            categories
                .map(
                    item => {

                        const percentage =
                            highest > 0
                                ? (
                                    item.value /
                                    highest
                                ) * 100
                                : 0;


                        return `

                            <div class="category-row">

                                <div class="category-row-header">

                                    <span>
                                        ${escapeHTML(item.name)}
                                    </span>

                                    <strong>
                                        ${formatCurrency(item.value)}
                                    </strong>

                                </div>


                                <div class="category-progress">

                                    <span
                                        style="width:${Math.max(
                                            4,
                                            percentage
                                        )}%"
                                    ></span>

                                </div>

                            </div>

                        `;

                    }
                )
                .join("");

    }


    /* =====================================================
       SELLERS
    ===================================================== */

    function renderSellers(
        filteredOrders,
        sellerList
    ) {

        const sellerMap = {};


        filteredOrders.forEach(
            order => {

                const seller =
                    getSellerName(order);


                if (!seller)
                    return;


                if (!sellerMap[seller]) {

                    sellerMap[seller] = {

                        name:
                            seller,

                        orders: 0,

                        revenue: 0,

                        units: 0,

                        returns: 0

                    };

                }


                sellerMap[seller].orders++;

                sellerMap[seller].revenue +=
                    getOrderAmount(order);

                sellerMap[seller].units +=
                    getOrderQuantity(order);

            }
        );


        returns.forEach(
            returnItem => {

                const seller =
                    returnItem.seller ||
                    returnItem.sellerName;


                if (
                    seller &&
                    sellerMap[seller]
                ) {

                    sellerMap[seller].returns++;

                }

            }
        );


        let list =
            Object.values(
                sellerMap
            );


        list.sort(
            (
                a,
                b
            ) =>
                b.revenue -
                a.revenue
        );


        list =
            list.slice(
                0,
                7
            );


        if (!list.length) {

            sellerReportBody.innerHTML =
                `
                    <tr>
                        <td
                            colspan="6"
                            style="
                                text-align:center;
                                padding:30px;
                                color:#98a2b3;
                            "
                        >
                            No seller performance data available yet.
                        </td>
                    </tr>
                `;

            return;

        }


        const highestRevenue =
            list[0].revenue || 1;


        sellerReportBody.innerHTML =
            list
                .map(
                    item => {

                        const sellerRecord =
                            sellerList.find(
                                seller =>
                                    normalize(
                                        seller.name
                                    ) ===
                                    normalize(
                                        item.name
                                    )
                            );


                        const email =
                            sellerRecord?.email ||
                            "";


                        const rate =
                            item.orders > 0
                                ? (
                                    item.returns /
                                    item.orders
                                ) * 100
                                : 0;


                        const performance =
                            (
                                item.revenue /
                                highestRevenue
                            ) * 100;


                        return `

                            <tr>

                                <td>

                                    <div class="seller-info">

                                        <div class="seller-avatar">

                                            ${getInitials(
                                                item.name
                                            )}

                                        </div>


                                        <div>

                                            <strong>
                                                ${escapeHTML(
                                                    item.name
                                                )}
                                            </strong>

                                            <span>
                                                ${escapeHTML(
                                                    email
                                                )}
                                            </span>

                                        </div>

                                    </div>

                                </td>


                                <td>

                                    <span class="seller-number">
                                        ${formatNumber(
                                            item.orders
                                        )}
                                    </span>

                                </td>


                                <td>

                                    <span class="seller-revenue">
                                        ${formatCurrency(
                                            item.revenue
                                        )}
                                    </span>

                                </td>


                                <td>

                                    ${formatNumber(
                                        item.units
                                    )}

                                </td>


                                <td>

                                    ${rate.toFixed(1)}%

                                </td>


                                <td>

                                    <div class="performance-bar">

                                        <span
                                            style="
                                                width:${Math.max(
                                                    4,
                                                    performance
                                                )}%;
                                            "
                                        ></span>

                                    </div>

                                </td>

                            </tr>

                        `;

                    }
                )
                .join("");

    }


    /* =====================================================
       CUSTOMER ACTIVITY
    ===================================================== */

    function renderCustomerActivity(
        filteredOrders,
        filteredCustomers
    ) {

        const customerOrderMap = {};


        filteredOrders.forEach(
            order => {

                const id =
                    getCustomerId(order);


                if (!id)
                    return;


                customerOrderMap[id] =
                    (
                        customerOrderMap[id] ||
                        0
                    ) + 1;

            }
        );


        let newCount = 0;

        let returningCount = 0;


        Object.values(
            customerOrderMap
        ).forEach(
            count => {

                if (count > 1) {

                    returningCount++;

                } else {

                    newCount++;

                }

            }
        );


        if (
            !newCount &&
            !returningCount
        ) {

            newCount =
                filteredCustomers.length;

        }


        const revenue =
            filteredOrders.reduce(
                (
                    sum,
                    order
                ) =>
                    sum +
                    getOrderAmount(order),
                0
            );


        const average =
            filteredOrders.length
                ? revenue /
                    filteredOrders.length
                : 0;


        newCustomers.textContent =
            formatNumber(newCount);


        returningCustomers.textContent =
            formatNumber(returningCount);


        averageOrderValue.textContent =
            formatCurrency(average);

    }


    /* =====================================================
       RETURNS
    ===================================================== */

    function renderReturns(
        filteredOrders,
        filteredReturns
    ) {

        const count =
            filteredReturns.length;


        const refund =
            filteredReturns
                .filter(
                    item =>
                        normalizeStatus(
                            item.status
                        ) === "refunded"
                )
                .reduce(
                    (
                        sum,
                        item
                    ) =>
                        sum +
                        Number(
                            item.amount ||
                            item.refunded ||
                            0
                        ),
                    0
                );


        returnedOrders.textContent =
            formatNumber(count);


        refundValue.textContent =
            formatCurrency(refund);

    }


    /* =====================================================
       EXPORT REPORT
    ===================================================== */

    function exportReport() {

        const days =
            Number(reportPeriod.value);


        const filteredOrders =
            filterByPeriod(
                orders,
                days
            );


        const rows = [

            [
                "FASH ADMIN REPORT",
                ""
            ],

            [
                "Reporting Period",
                `Last ${days} days`
            ],

            [
                "",
                ""
            ],

            [
                "ORDER ID",
                "CUSTOMER",
                "PRODUCT",
                "SELLER",
                "STATUS",
                "AMOUNT",
                "DATE"
            ]

        ];


        filteredOrders.forEach(
            order => {

                rows.push([

                    getOrderId(order),

                    getCustomerName(order),

                    getProductName(order),

                    getSellerName(order),

                    normalizeStatus(
                        order.status
                    ),

                    getOrderAmount(order),

                    formatDate(
                        getOrderDate(order)
                    )

                ]);

            }
        );


        const csv =
            rows
                .map(
                    row =>
                        row
                            .map(
                                value =>
                                    `"${String(
                                        value ?? ""
                                    )
                                        .replace(
                                            /"/g,
                                            '""'
                                        )}"`
                            )
                            .join(",")
                )
                .join("\n");


        const blob =
            new Blob(
                [csv],
                {
                    type:
                        "text/csv;charset=utf-8;"
                }
            );


        const url =
            URL.createObjectURL(blob);


        const link =
            document.createElement("a");


        link.href = url;


        link.download =
            `fash-report-${Date.now()}.csv`;


        document.body.appendChild(
            link
        );


        link.click();


        link.remove();


        URL.revokeObjectURL(
            url
        );


        showToast(
            "Report exported successfully.",
            "success"
        );

    }


    /* =====================================================
       FILTER BY PERIOD
    ===================================================== */

    function filterByPeriod(
        data,
        days
    ) {

        const now =
            new Date();


        const cutoff =
            new Date(
                now
            );


        cutoff.setDate(
            cutoff.getDate() -
            days
        );


        return data.filter(
            item => {

                const date =
                    getItemDate(item);


                if (!date)
                    return true;


                return date >= cutoff;

            }
        );

    }


    /* =====================================================
       DATE LABELS
    ===================================================== */

    function getDateLabels(
        days
    ) {

        const labels = [];


        const today =
            new Date();


        const count =
            Math.min(
                days,
                30
            );


        for (
            let i = count - 1;
            i >= 0;
            i--
        ) {

            const date =
                new Date(
                    today
                );


            date.setDate(
                date.getDate() -
                i
            );


            labels.push(
                formatDateKey(date)
            );

        }


        return labels;

    }


    /* =====================================================
       FORMAT DATE KEY
    ===================================================== */

    function formatDateKey(
        date
    ) {

        const d =
            new Date(date);


        if (
            Number.isNaN(
                d.getTime()
            )
        ) {

            return "";

        }


        const year =
            d.getFullYear();


        const month =
            String(
                d.getMonth() + 1
            )
                .padStart(
                    2,
                    "0"
                );


        const day =
            String(
                d.getDate()
            )
                .padStart(
                    2,
                    "0"
                );


        return `${year}-${month}-${day}`;

    }


    /* =====================================================
       CHART DATE
    ===================================================== */

    function formatChartDate(
        value
    ) {

        const date =
            new Date(
                `${value}T00:00:00`
            );


        return date.toLocaleDateString(
            "en-NG",
            {
                day: "numeric",
                month: "short"
            }
        );

    }


    /* =====================================================
       GET ORDER DATE
    ===================================================== */

    function getOrderDate(
        order
    ) {

        return (
            order.date ||
            order.createdAt ||
            order.created_at ||
            order.orderDate ||
            order.created
        );

    }


    /* =====================================================
       GET ITEM DATE
    ===================================================== */

    function getItemDate(
        item
    ) {

        const raw =
            getOrderDate(item) ||
            item.returnDate ||
            item.date;


        if (!raw)
            return null;


        const date =
            new Date(raw);


        if (
            Number.isNaN(
                date.getTime()
            )
        ) {

            return null;

        }


        return date;

    }


    /* =====================================================
       ORDER AMOUNT
    ===================================================== */

    function getOrderAmount(
        order
    ) {

        return Number(

            order.total ??
            order.totalAmount ??
            order.amount ??
            order.price ??
            order.grandTotal ??
            0

        ) || 0;

    }


    /* =====================================================
       ORDER QUANTITY
    ===================================================== */

    function getOrderQuantity(
        order
    ) {

        return Number(

            order.quantity ??
            order.qty ??
            order.itemsCount ??
            1

        ) || 1;

    }


    /* =====================================================
       ORDER ID
    ===================================================== */

    function getOrderId(
        order
    ) {

        return (
            order.id ||
            order.orderId ||
            order.orderNumber ||
            "—"
        );

    }


    /* =====================================================
       PRODUCT NAME
    ===================================================== */

    function getProductName(
        order
    ) {

        return (
            order.product ||
            order.productName ||
            order.name ||
            order.itemName ||
            (
                Array.isArray(order.items) &&
                order.items[0]
                    ? (
                        order.items[0].name ||
                        order.items[0].productName
                    )
                    : ""
            ) ||
            "Unknown Product"
        );

    }


    /* =====================================================
       CUSTOMER NAME
    ===================================================== */

    function getCustomerName(
        order
    ) {

        return (
            order.customer ||
            order.customerName ||
            order.name ||
            "Customer"
        );

    }


    /* =====================================================
       CUSTOMER ID
    ===================================================== */

    function getCustomerId(
        order
    ) {

        return (
            order.customerId ||
            order.customerEmail ||
            order.email ||
            getCustomerName(order)
        );

    }


    /* =====================================================
       SELLER NAME
    ===================================================== */

    function getSellerName(
        order
    ) {

        return (
            order.seller ||
            order.sellerName ||
            order.vendor ||
            order.vendorName ||
            "Marketplace"
        );

    }


    /* =====================================================
       NORMALIZE STATUS
    ===================================================== */

    function normalizeStatus(
        status
    ) {

        return String(
            status || ""
        )
            .toLowerCase()
            .trim()
            .replace(
                /[\s_]+/g,
                "-"
            );

    }


    /* =====================================================
       NORMALIZE STRING
    ===================================================== */

    function normalize(
        value
    ) {

        return String(
            value || ""
        )
            .toLowerCase()
            .trim();

    }


    /* =====================================================
       FORMAT CURRENCY
    ===================================================== */

    function formatCurrency(
        amount
    ) {

        return new Intl.NumberFormat(
            "en-NG",
            {
                style: "currency",
                currency: "NGN",
                maximumFractionDigits: 0
            }
        ).format(
            Number(amount) || 0
        );

    }


    /* =====================================================
       COMPACT CURRENCY
    ===================================================== */

    function formatCompactCurrency(
        amount
    ) {

        amount =
            Number(amount) || 0;


        if (amount >= 1000000) {

            return `₦${(
                amount / 1000000
            ).toFixed(1)}M`;

        }


        if (amount >= 1000) {

            return `₦${(
                amount / 1000
            ).toFixed(0)}K`;

        }


        return `₦${amount}`;

    }


    /* =====================================================
       FORMAT NUMBER
    ===================================================== */

    function formatNumber(
        number
    ) {

        return new Intl.NumberFormat(
            "en-NG"
        ).format(
            Number(number) || 0
        );

    }


    /* =====================================================
       FORMAT DATE
    ===================================================== */

    function formatDate(
        date
    ) {

        if (!date)
            return "—";


        const parsed =
            new Date(date);


        if (
            Number.isNaN(
                parsed.getTime()
            )
        ) {

            return "—";

        }


        return parsed.toLocaleDateString(
            "en-NG",
            {
                day: "2-digit",
                month: "short",
                year: "numeric"
            }
        );

    }


    /* =====================================================
       INITIALS
    ===================================================== */

    function getInitials(
        name
    ) {

        return String(
            name || "FASH"
        )
            .split(" ")
            .filter(Boolean)
            .slice(0, 2)
            .map(
                word =>
                    word
                        .charAt(0)
                        .toUpperCase()
            )
            .join("");

    }


    /* =====================================================
       EMPTY MESSAGE
    ===================================================== */

    function emptyMessage(
        message
    ) {

        return `

            <div
                style="
                    padding:28px 10px;
                    text-align:center;
                    color:#98a2b3;
                    font-size:9px;
                "
            >

                ${escapeHTML(message)}

            </div>

        `;

    }


    /* =====================================================
       ESCAPE HTML
    ===================================================== */

    function escapeHTML(
        value
    ) {

        return String(
            value ?? ""
        )
            .replace(
                /&/g,
                "&amp;"
            )
            .replace(
                /</g,
                "&lt;"
            )
            .replace(
                />/g,
                "&gt;"
            )
            .replace(
                /"/g,
                "&quot;"
            )
            .replace(
                /'/g,
                "&#039;"
            );

    }


    /* =====================================================
       UPDATE TIMESTAMP
    ===================================================== */

    function updateLastUpdated() {

        reportLastUpdated.textContent =
            `Report generated ${new Date().toLocaleTimeString(
                "en-NG",
                {
                    hour: "2-digit",
                    minute: "2-digit"
                }
            )}`;

    }


    /* =====================================================
       TOAST
    ===================================================== */

    function showToast(
        message,
        type = "success"
    ) {

        const toast =
            document.getElementById(
                "fashToast"
            );

        const toastMessage =
            document.getElementById(
                "fashToastMessage"
            );


        if (!toast)
            return;


        toastMessage.textContent =
            message;


        toast.className =
            `fash-toast ${type}`;


        toast.hidden = false;


        clearTimeout(
            window.fashToastTimeout
        );


        window.fashToastTimeout =
            setTimeout(
                () => {

                    toast.hidden = true;

                },
                3000
            );

    }


    /* =====================================================
       LOAD LOCAL STORAGE
    ===================================================== */

    function loadData(
        key,
        fallback
    ) {

        try {

            const saved =
                localStorage.getItem(key);


            if (!saved)
                return fallback;


            const parsed =
                JSON.parse(saved);


            return Array.isArray(parsed)
                ? parsed
                : fallback;

        } catch (error) {

            console.warn(
                `FASH Reports could not read ${key}`,
                error
            );


            return fallback;

        }

    }


    /* =====================================================
       DEMO ORDERS
    ===================================================== */

    function createDemoOrders() {

        const names = [

            "Nike Air Max 270",
            "Samsung Galaxy A55",
            "Apple AirPods Pro",
            "Adidas Hoodie",
            "FASH Classic Sneakers"

        ];


        const statuses = [

            "delivered",
            "delivered",
            "shipped",
            "processing",
            "delivered"

        ];


        const sellers = [

            "Urban Kicks",
            "Tech World NG",
            "Apple Hub",
            "Style House",
            "FASH Store"

        ];


        const result = [];


        for (
            let i = 0;
            i < 25;
            i++
        ) {

            const date =
                new Date();


            date.setDate(
                date.getDate() -
                (i % 20)
            );


            result.push({

                id:
                    `FASH-${58291 - i}`,

                orderId:
                    `FASH-${58291 - i}`,

                customer:
                    `Customer ${i + 1}`,

                customerId:
                    `customer-${i + 1}`,

                product:
                    names[
                        i % names.length
                    ],

                seller:
                    sellers[
                        i % sellers.length
                    ],

                quantity:
                    (i % 4) + 1,

                total:
                    45000 +
                    (i * 12500),

                amount:
                    45000 +
                    (i * 12500),

                status:
                    statuses[
                        i % statuses.length
                    ],

                date:
                    date.toISOString()

            });

        }


        return result;

    }


    /* =====================================================
       DEMO PRODUCTS
    ===================================================== */

    function createDemoProducts() {

        return [

            {
                name:
                    "Nike Air Max 270",

                category:
                    "Fashion",

                image:
                    ""
            },

            {
                name:
                    "Samsung Galaxy A55",

                category:
                    "Electronics",

                image:
                    ""
            },

            {
                name:
                    "Apple AirPods Pro",

                category:
                    "Electronics",

                image:
                    ""
            },

            {
                name:
                    "Adidas Hoodie",

                category:
                    "Fashion",

                image:
                    ""
            },

            {
                name:
                    "FASH Classic Sneakers",

                category:
                    "Fashion",

                image:
                    ""
            }

        ];

    }


    /* =====================================================
       DEMO SELLERS
    ===================================================== */

    function createDemoSellers() {

        return [

            {
                name:
                    "Urban Kicks",

                email:
                    "urban@example.com"
            },

            {
                name:
                    "Tech World NG",

                email:
                    "tech@example.com"
            },

            {
                name:
                    "Apple Hub",

                email:
                    "apple@example.com"
            },

            {
                name:
                    "Style House",

                email:
                    "style@example.com"
            },

            {
                name:
                    "FASH Store",

                email:
                    "store@example.com"
            }

        ];

    }


    /* =====================================================
       DEMO CUSTOMERS
    ===================================================== */

    function createDemoCustomers() {

        return Array.from(
            {
                length: 20
            },
            (
                _,
                index
            ) => ({

                id:
                    `customer-${index + 1}`,

                name:
                    `Customer ${index + 1}`,

                createdAt:
                    new Date().toISOString()

            })
        );

    }


    /* =====================================================
       DEMO RETURNS
    ===================================================== */

    function createDemoReturns() {

        return [

            {
                id:
                    "RET-1001",

                order:
                    "FASH-58291",

                customer:
                    "Customer 1",

                product:
                    "Nike Air Max 270",

                amount:
                    185000,

                status:
                    "pending",

                date:
                    new Date().toISOString()

            },

            {
                id:
                    "RET-1002",

                order:
                    "FASH-58274",

                customer:
                    "Customer 2",

                product:
                    "Samsung Galaxy A55",

                amount:
                    485000,

                status:
                    "refunded",

                date:
                    new Date().toISOString()

            }

        ];

    }

});