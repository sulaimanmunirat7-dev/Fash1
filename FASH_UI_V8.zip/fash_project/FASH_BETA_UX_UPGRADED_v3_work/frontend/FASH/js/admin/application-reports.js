(()=>{
  const $=id=>document.getElementById(id);
  let chart=null;
  const esc=v=>String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const labels=[['total','Total'],['approved','Approved'],['pending','Pending'],['rejected','Rejected'],['changes_requested','Changes requested']];
  async function load(){
    const period=$('applicationReportPeriod')?.value||'1m';
    const stats=$('applicationReportStats');
    if(!stats) return;
    try{
      const api=window.FASH_API;
      if(!api?.api) throw new Error('API client unavailable');
      const data=await api.api(`/api/admin/analytics/applications?period=${encodeURIComponent(period)}`);
      const values=data||{};
      stats.innerHTML=labels.map(([key,label])=>`<div class="application-report-stat"><span>${esc(label)}</span><strong>${Number(values[key]||0).toLocaleString()}</strong></div>`).join('');
      const canvas=$('applicationReportChart');
      if(!canvas||!window.Chart) return;
      const series=Array.isArray(data?.trend)?data.trend:[];
      const chartLabels=series.map(x=>x.day||x.date||'');
      const chartValues=series.map(x=>Number(x.applications||x.count||0));
      if(chart) chart.destroy();
      chart=new Chart(canvas,{type:'line',data:{labels:chartLabels,datasets:[{label:'Applications',data:chartValues,borderColor:'#2563eb',backgroundColor:'rgba(37,99,235,.10)',fill:true,tension:.35}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{precision:0}}}}});
    }catch(err){console.error('APPLICATION REPORT',err);}
  }
  document.addEventListener('DOMContentLoaded',()=>{$('applicationReportPeriod')?.addEventListener('change',load);load();});
})();
