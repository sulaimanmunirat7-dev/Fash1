/* FASH ADMIN ACCESS GUARD */
(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", async () => {
    try {
      const data = await FASH_API.api("/api/auth/me");
      const user = data.user;

      if (!user || user.role !== "admin") {
        throw new Error("Administrator access required");
      }

      localStorage.setItem("fashCurrentUser", JSON.stringify({
        id: user.id,
        name: user.full_name,
        fullName: user.full_name,
        email: user.email,
        role: user.role,
        sellerStatus: user.seller_status,
        emailVerified: user.email_verified
      }));

      document.querySelectorAll(".profile-info h4, .admin-profile-info h4").forEach(el => {
        el.textContent = user.full_name || "FASH Admin";
      });

      document.querySelectorAll("[data-user-email]").forEach(el => {
        el.textContent = user.email || "";
      });
    } catch (error) {
      console.error("ADMIN ACCESS ERROR:", error);
      FASH_API.clearSession();
      window.location.href = "./login.html";
    }
  });
})();
