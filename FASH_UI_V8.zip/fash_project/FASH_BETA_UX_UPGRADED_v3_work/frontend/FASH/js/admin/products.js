/* =========================================================
   FASH ADMIN — PRODUCTS
   Marketplace Product Management
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    /* =====================================================
       ELEMENTS
    ====================================================== */

    const productsTableBody =
        document.getElementById("productsTableBody");

    const productRows = Array.from(
        document.querySelectorAll(
            "#productsTableBody tr"
        )
    );

    const productSearch =
        document.getElementById("productSearch");

    const categoryFilter =
        document.getElementById("categoryFilter");

    const sellerFilter =
        document.getElementById("sellerFilter");

    const productStatusFilter =
        document.getElementById("productStatusFilter");

    const selectAllProducts =
        document.getElementById("selectAllProducts");

    const productsEmpty =
        document.getElementById("productsEmpty");

    const paginationText =
        document.getElementById("paginationText");


    /* =====================================================
       MODALS
    ====================================================== */

    const productTypeModal =
        document.getElementById("productTypeModal");

    const productFormModal =
        document.getElementById("productFormModal");

    const rejectModal =
        document.getElementById("rejectModal");

    const reviewModal =
        document.getElementById("reviewModal");


    /* =====================================================
       BUTTONS
    ====================================================== */

    const addProductBtn =
        document.getElementById("addProductBtn");

    const closeProductTypeModal =
        document.getElementById(
            "closeProductTypeModal"
        );

    const closeProductFormModal =
        document.getElementById(
            "closeProductFormModal"
        );

    const cancelProduct =
        document.getElementById(
            "cancelProduct"
        );

    const closeRejectModal =
        document.getElementById(
            "closeRejectModal"
        );

    const cancelReject =
        document.getElementById(
            "cancelReject"
        );

    const closeReviewModal =
        document.getElementById(
            "closeReviewModal"
        );

    const closeReviewBottom =
        document.getElementById(
            "closeReviewBottom"
        );

    const reviewApproveBtn =
        document.getElementById(
            "reviewApproveBtn"
        );

    const reviewRejectBtn =
        document.getElementById(
            "reviewRejectBtn"
        );


    /* =====================================================
       FORMS
    ====================================================== */

    const productForm =
        document.getElementById("productForm");

    const rejectForm =
        document.getElementById("rejectForm");


    /* =====================================================
       FORM FIELDS
    ====================================================== */

    const productName =
        document.getElementById(
            "productName"
        );

    const productSKU =
        document.getElementById(
            "productSKU"
        );

    const productPrice =
        document.getElementById(
            "productPrice"
        );

    const productCategory =
        document.getElementById(
            "productCategory"
        );

    const productStock =
        document.getElementById(
            "productStock"
        );

    const productSeller =
        document.getElementById(
            "productSeller"
        );

    const productDescription =
        document.getElementById(
            "productDescription"
        );

    const sellerField =
        document.getElementById(
            "sellerField"
        );

    const formOwnerLabel =
        document.getElementById(
            "formOwnerLabel"
        );


    /* =====================================================
       REVIEW FIELDS
    ====================================================== */

    const reviewProductName =
        document.getElementById(
            "reviewProductName"
        );

    const reviewProductSeller =
        document.getElementById(
            "reviewProductSeller"
        );

    const reviewSKU =
        document.getElementById(
            "reviewSKU"
        );

    const reviewCategory =
        document.getElementById(
            "reviewCategory"
        );

    const reviewPrice =
        document.getElementById(
            "reviewPrice"
        );

    const reviewStock =
        document.getElementById(
            "reviewStock"
        );


    /* =====================================================
       REJECTION STATE
    ====================================================== */

    let selectedProductRow = null;
    let selectedProductId = null;


    /* =====================================================
       LOCAL STORAGE
    ====================================================== */

    const STORAGE_KEY =
        "fash_admin_products";


    function getProducts() {

        try {

            const saved =
                localStorage.getItem(
                    STORAGE_KEY
                );

            return saved
                ? JSON.parse(saved)
                : [];

        } catch (error) {

            console.error(
                "Unable to load products:",
                error
            );

            return [];

        }

    }


    function saveProducts(products) {

        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify(products)
        );

    }


    /* =====================================================
       MODAL FUNCTIONS
    ====================================================== */

    function openModal(modal) {

        if (!modal) return;

        modal.classList.add("show");

        document.body.style.overflow =
            "hidden";

    }


    function closeModal(modal) {

        if (!modal) return;

        modal.classList.remove("show");

        const openModalStillExists =
            document.querySelector(
                ".product-modal.show"
            );

        if (!openModalStillExists) {

            document.body.style.overflow =
                "";

        }

    }


    /* =====================================================
       ADD PRODUCT
    ====================================================== */

    if (addProductBtn) {

        addProductBtn.addEventListener(
            "click",
            () => {

                openModal(
                    productTypeModal
                );

            }
        );

    }


    if (closeProductTypeModal) {

        closeProductTypeModal.addEventListener(
            "click",
            () => {

                closeModal(
                    productTypeModal
                );

            }
        );

    }


    if (closeProductFormModal) {

        closeProductFormModal.addEventListener(
            "click",
            () => {

                closeModal(
                    productFormModal
                );

            }
        );

    }


    if (cancelProduct) {

        cancelProduct.addEventListener(
            "click",
            () => {

                closeModal(
                    productFormModal
                );

            }
        );

    }


    /* =====================================================
       PRODUCT TYPE
    ====================================================== */

    const productTypeOptions =
        document.querySelectorAll(
            ".product-type-option"
        );


    productTypeOptions.forEach(option => {

        option.addEventListener(
            "click",
            () => {

                const type =
                    option.dataset.productType;

                closeModal(
                    productTypeModal
                );

                if (type === "seller") {

                    formOwnerLabel.textContent =
                        "SELLER PRODUCT";

                    sellerField.style.display =
                        "block";

                    productSeller.required =
                        true;

                } else {

                    formOwnerLabel.textContent =
                        "FASH PRODUCT";

                    sellerField.style.display =
                        "none";

                    productSeller.required =
                        false;

                    productSeller.value =
                        "";

                }

                openModal(
                    productFormModal
                );

            }
        );

    });


    /* =====================================================
       CREATE PRODUCT
    ====================================================== */

    if (productForm) {

        productForm.addEventListener(
            "submit",
            event => {

                event.preventDefault();


                const name =
                    productName.value.trim();

                const sku =
                    productSKU.value.trim();

                const price =
                    Number(
                        productPrice.value
                    );

                const category =
                    productCategory.value;

                const stock =
                    Number(
                        productStock.value
                    );

                const seller =
                    productSeller.value;


                if (!name || !sku) {

                    alert(
                        "Please enter the product name and SKU."
                    );

                    return;

                }


                if (!category) {

                    alert(
                        "Please select a category."
                    );

                    return;

                }


                if (
                    Number.isNaN(price) ||
                    price < 0
                ) {

                    alert(
                        "Please enter a valid price."
                    );

                    return;

                }


                if (
                    Number.isNaN(stock) ||
                    stock < 0
                ) {

                    alert(
                        "Please enter a valid stock quantity."
                    );

                    return;

                }


                const isSellerProduct =
                    sellerField.style.display !==
                    "none";


                if (
                    isSellerProduct &&
                    !seller
                ) {

                    alert(
                        "Please select the seller."
                    );

                    return;

                }


                const products =
                    getProducts();


                const product = {

                    id:
                        sku.toUpperCase(),

                    name,

                    sku:
                        sku.toUpperCase(),

                    category,

                    price,

                    stock,

                    seller:
                        isSellerProduct
                            ? seller
                            : "fash",

                    owner:
                        isSellerProduct
                            ? "seller"
                            : "fash",

                    status:
                        isSellerProduct
                            ? "pending"
                            : "active",

                    description:
                        productDescription.value.trim(),

                    submitted:
                        new Date().toISOString(),

                    rejectionReason:
                        ""

                };


                const existing =
                    products.find(
                        item =>
                            item.sku ===
                            product.sku
                    );


                if (existing) {

                    alert(
                        "A product with this SKU already exists."
                    );

                    return;

                }


                products.push(product);

                saveProducts(products);


                addProductToTable(product);


                closeModal(
                    productFormModal
                );


                productForm.reset();


                updateCounts();


                alert(
                    isSellerProduct
                        ? "Seller product created and sent for review."
                        : "FASH product created successfully."
                );

            }
        );

    }


    /* =====================================================
       ADD PRODUCT TO TABLE
    ====================================================== */

    function addProductToTable(product) {

        if (!productsTableBody) return;


        const row =
            document.createElement("tr");


        row.dataset.productId =
            product.id;

        row.dataset.category =
            product.category;

        row.dataset.status =
            product.status;

        row.dataset.owner =
            product.owner;

        row.dataset.seller =
            product.seller;

        row.dataset.price =
            product.price;

        row.dataset.stock =
            product.stock;


        const sellerName =
            formatSellerName(
                product.seller
            );


        const categoryName =
            formatCategory(
                product.category
            );


        const statusLabel =
            formatStatus(
                product.status
            );


        const productIcon =
            getCategoryIcon(
                product.category
            );


        row.innerHTML = `

            <td>

                <input
                    type="checkbox"
                    class="product-checkbox"
                >

            </td>


            <td>

                <div class="product-info">

                    <div class="product-image blue-product">

                        <i class="${productIcon}"></i>

                    </div>

                    <div>

                        <strong>
                            ${escapeHTML(product.name)}
                        </strong>

                        <span>
                            ${escapeHTML(categoryName)}
                        </span>

                    </div>

                </div>

            </td>


            <td>
                ${escapeHTML(product.sku)}
            </td>


            <td>
                ${escapeHTML(sellerName)}
            </td>


            <td>
                ${escapeHTML(categoryName)}
            </td>


            <td>

                <strong>
                    ₦${formatNumber(product.price)}
                </strong>

            </td>


            <td>

                ${
                    product.stock === 0
                        ? `<span class="stock-zero">0</span>`
                        : product.stock
                }

            </td>


            <td>

                <span class="product-status ${product.status}">
                    ${statusLabel}
                </span>

            </td>


            <td>
                Just now
            </td>


            <td>

                <button
                    class="product-action"
                    data-product="${escapeHTML(product.id)}"
                >

                    <i class="fa-solid fa-ellipsis"></i>

                </button>

            </td>

        `;


        productsTableBody.prepend(row);

        attachRowEvents(row);

        applyFilters();

    }


    /* =====================================================
       ROW EVENTS
    ====================================================== */

    function attachRowEvents(row) {

        const actionButton =
            row.querySelector(
                ".product-action"
            );


        if (actionButton) {

            actionButton.addEventListener(
                "click",
                event => {

                    event.stopPropagation();

                    selectedProductRow =
                        row;

                    selectedProductId =
                        row.dataset.productId;

                    openProductMenu(
                        actionButton
                    );

                }
            );

        }

    }


    productRows.forEach(
        attachRowEvents
    );


    /* =====================================================
       ACTION MENU
    ====================================================== */

    const productMenu =
        document.getElementById(
            "productMenu"
        );


    function openProductMenu(button) {

        if (!productMenu) return;


        productMenu.classList.add(
            "show"
        );


        const rect =
            button.getBoundingClientRect();


        const menuWidth =
            185;


        let left =
            rect.right -
            menuWidth;

        let top =
            rect.bottom + 6;


        if (
            left < 10
        ) {

            left = 10;

        }


        if (
            left + menuWidth >
            window.innerWidth - 10
        ) {

            left =
                window.innerWidth -
                menuWidth -
                10;

        }


        if (
            top + 220 >
            window.innerHeight
        ) {

            top =
                rect.top -
                220;

        }


        productMenu.style.left =
            `${left}px`;

        productMenu.style.top =
            `${top}px`;

    }


    /* =====================================================
       ACTION MENU CLICK
    ====================================================== */

    if (productMenu) {

        productMenu
            .querySelectorAll("button")
            .forEach(button => {

                button.addEventListener(
                    "click",
                    () => {

                        const action =
                            button.dataset.action;


                        handleProductAction(
                            action,
                            selectedProductRow
                        );


                        productMenu.classList.remove(
                            "show"
                        );

                    }
                );

            });

    }


    /* =====================================================
       PRODUCT ACTIONS
    ====================================================== */

    function handleProductAction(
        action,
        row
    ) {

        if (!row) return;


        switch (action) {

            case "view":

                openReview(row);

                break;


            case "edit":

                editProduct(row);

                break;


            case "approve":

                approveProduct(row);

                break;


            case "reject":

                openRejectModal(row);

                break;


            case "suspend":

                suspendProduct(row);

                break;

        }

    }


    /* =====================================================
       VIEW / REVIEW
    ====================================================== */

    function openReview(row) {

        const product =
            getProductFromRow(row);


        if (!product) return;


        reviewProductName.textContent =
            product.name;


        reviewProductSeller.textContent =
            `Seller: ${formatSellerName(product.seller)}`;


        reviewSKU.textContent =
            product.sku;


        reviewCategory.textContent =
            formatCategory(
                product.category
            );


        reviewPrice.textContent =
            `₦${formatNumber(product.price)}`;


        reviewStock.textContent =
            product.stock;


        selectedProductRow =
            row;


        selectedProductId =
            product.id;


        openModal(
            reviewModal
        );

    }


    /* =====================================================
       APPROVE FROM REVIEW
    ====================================================== */

    if (reviewApproveBtn) {

        reviewApproveBtn.addEventListener(
            "click",
            () => {

                if (!selectedProductRow)
                    return;


                approveProduct(
                    selectedProductRow
                );


                closeModal(
                    reviewModal
                );

            }
        );

    }


    /* =====================================================
       REJECT FROM REVIEW
    ====================================================== */

    if (reviewRejectBtn) {

        reviewRejectBtn.addEventListener(
            "click",
            () => {

                closeModal(
                    reviewModal
                );


                if (
                    selectedProductRow
                ) {

                    openRejectModal(
                        selectedProductRow
                    );

                }

            }
        );

    }


    /* =====================================================
       APPROVE PRODUCT
    ====================================================== */

    function approveProduct(row) {

        if (!row) return;


        const productId =
            row.dataset.productId;


        const products =
            getProducts();


        let product =
            products.find(
                item =>
                    item.id ===
                    productId
            );


        if (!product) {

            product =
                getProductFromRow(row);

        }


        if (!product) return;


        product.status =
            "active";

        product.rejectionReason =
            "";


        saveProducts(products);


        updateRowStatus(
            row,
            "active"
        );


        updateCounts();


        showToast(
            "Product approved successfully.",
            "success"
        );

    }


    /* =====================================================
       REJECT PRODUCT MODAL
    ====================================================== */

    if (closeRejectModal) {

        closeRejectModal.addEventListener(
            "click",
            () => {

                closeModal(
                    rejectModal
                );

            }
        );

    }


    if (cancelReject) {

        cancelReject.addEventListener(
            "click",
            () => {

                closeModal(
                    rejectModal
                );

            }
        );

    }


    function openRejectModal(row) {

        selectedProductRow =
            row;

        selectedProductId =
            row.dataset.productId;

        openModal(
            rejectModal
        );

    }


    /* =====================================================
       REJECT SUBMIT
    ====================================================== */

    if (rejectForm) {

        rejectForm.addEventListener(
            "submit",
            event => {

                event.preventDefault();


                if (
                    !selectedProductRow
                ) return;


                const reason =
                    document.getElementById(
                        "rejectionReason"
                    ).value;


                const message =
                    document.getElementById(
                        "rejectionMessage"
                    ).value.trim();


                if (!reason) {

                    alert(
                        "Please select a rejection reason."
                    );

                    return;

                }


                const products =
                    getProducts();


                const product =
                    products.find(
                        item =>
                            item.id ===
                            selectedProductId
                    );


                if (product) {

                    product.status =
                        "rejected";

                    product.rejectionReason =
                        message
                            ? `${reason}: ${message}`
                            : reason;

                }


                saveProducts(products);


                updateRowStatus(
                    selectedProductRow,
                    "rejected"
                );


                updateCounts();


                closeModal(
                    rejectModal
                );


                rejectForm.reset();


                showToast(
                    "Product rejected. Seller can now make corrections.",
                    "error"
                );

            }
        );

    }


    /* =====================================================
       SUSPEND PRODUCT
    ====================================================== */

    function suspendProduct(row) {

        if (!row) return;


        const productId =
            row.dataset.productId;


        const confirmed =
            confirm(
                "Are you sure you want to suspend this product?"
            );


        if (!confirmed)
            return;


        const products =
            getProducts();


        const product =
            products.find(
                item =>
                    item.id ===
                    productId
            );


        if (product) {

            product.status =
                "suspended";

        }


        saveProducts(products);


        updateRowStatus(
            row,
            "suspended"
        );


        updateCounts();


        showToast(
            "Product suspended.",
            "error"
        );

    }


    /* =====================================================
       EDIT PRODUCT
    ====================================================== */

    function editProduct(row) {

        const product =
            getProductFromRow(row);


        if (!product) return;


        productName.value =
            product.name;


        productSKU.value =
            product.sku;


        productPrice.value =
            product.price;


        productCategory.value =
            product.category;


        productStock.value =
            product.stock;


        productDescription.value =
            product.description || "";


        if (
            product.owner ===
            "seller"
        ) {

            formOwnerLabel.textContent =
                "SELLER PRODUCT";

            sellerField.style.display =
                "block";

            productSeller.required =
                true;

            productSeller.value =
                product.seller;

        } else {

            formOwnerLabel.textContent =
                "FASH PRODUCT";

            sellerField.style.display =
                "none";

            productSeller.required =
                false;

        }


        openModal(
            productFormModal
        );

    }


    /* =====================================================
       UPDATE ROW STATUS
    ====================================================== */

    function updateRowStatus(
        row,
        status
    ) {

        if (!row) return;


        row.dataset.status =
            status;


        const statusElement =
            row.querySelector(
                ".product-status"
            );


        if (!statusElement)
            return;


        statusElement.className =
            `product-status ${status}`;


        statusElement.textContent =
            formatStatus(status);

    }


    /* =====================================================
       FILTERS
    ====================================================== */

    const productTabs =
        document.querySelectorAll(
            ".product-tab"
        );


    productTabs.forEach(tab => {

        tab.addEventListener(
            "click",
            () => {

                productTabs.forEach(
                    item =>
                        item.classList.remove(
                            "active"
                        )
                );


                tab.classList.add(
                    "active"
                );


                const tabType =
                    tab.dataset.tab;


                if (
                    tabType === "all"
                ) {

                    productStatusFilter.value =
                        "all";

                } else if (
                    tabType === "seller"
                ) {

                    productStatusFilter.value =
                        "all";

                } else if (
                    tabType === "fash"
                ) {

                    productStatusFilter.value =
                        "all";

                } else {

                    productStatusFilter.value =
                        tabType;

                }


                applyFilters(
                    tabType
                );

            }
        );

    });


    function applyFilters(
        activeTab = "all"
    ) {

        const search =
            productSearch
                ? productSearch.value
                    .trim()
                    .toLowerCase()
                : "";


        const category =
            categoryFilter
                ? categoryFilter.value
                : "all";


        const seller =
            sellerFilter
                ? sellerFilter.value
                : "all";


        const status =
            productStatusFilter
                ? productStatusFilter.value
                : "all";


        let visible =
            0;


        const rows =
            Array.from(
                document.querySelectorAll(
                    "#productsTableBody tr"
                )
            );


        rows.forEach(row => {

            const text =
                row.textContent
                    .toLowerCase();


            const rowCategory =
                row.dataset.category;


            const rowSeller =
                row.dataset.seller;


            const rowStatus =
                row.dataset.status;


            const rowOwner =
                row.dataset.owner;


            const matchesSearch =
                !search ||
                text.includes(search);


            const matchesCategory =
                category === "all" ||
                rowCategory === category;


            const matchesSeller =
                seller === "all" ||
                rowSeller === seller;


            const matchesStatus =
                status === "all" ||
                rowStatus === status;


            let matchesTab =
                true;


            if (
                activeTab ===
                "seller"
            ) {

                matchesTab =
                    rowOwner ===
                    "seller";

            }


            if (
                activeTab ===
                "fash"
            ) {

                matchesTab =
                    rowOwner ===
                    "fash";

            }


            const shouldShow =
                matchesSearch &&
                matchesCategory &&
                matchesSeller &&
                matchesStatus &&
                matchesTab;


            row.style.display =
                shouldShow
                    ? ""
                    : "none";


            if (shouldShow) {

                visible++;

            }

        });


        if (productsEmpty) {

            productsEmpty.hidden =
                visible !== 0;

        }


        if (paginationText) {

            paginationText.textContent =
                visible === 0
                    ? "No products found"
                    : `Showing ${visible} product${visible === 1 ? "" : "s"}`;

        }

    }


    if (productSearch) {

        productSearch.addEventListener(
            "input",
            () => applyFilters()
        );

    }


    if (categoryFilter) {

        categoryFilter.addEventListener(
            "change",
            () => applyFilters()
        );

    }


    if (sellerFilter) {

        sellerFilter.addEventListener(
            "change",
            () => applyFilters()
        );

    }


    if (productStatusFilter) {

        productStatusFilter.addEventListener(
            "change",
            () => applyFilters()
        );

    }


    /* =====================================================
       SELECT ALL
    ====================================================== */

    if (selectAllProducts) {

        selectAllProducts.addEventListener(
            "change",
            () => {

                const visibleCheckboxes =
                    document.querySelectorAll(
                        "#productsTableBody tr:not([style*='display: none']) .product-checkbox"
                    );


                visibleCheckboxes.forEach(
                    checkbox => {

                        checkbox.checked =
                            selectAllProducts.checked;

                    }
                );

            }
        );

    }


    /* =====================================================
       CLOSE MENU WHEN CLICKING OUTSIDE
    ====================================================== */

    document.addEventListener(
        "click",
        event => {

            if (
                productMenu &&
                !productMenu.contains(
                    event.target
                ) &&
                !event.target.closest(
                    ".product-action"
                )
            ) {

                productMenu.classList.remove(
                    "show"
                );

            }

        }
    );


    /* =====================================================
       CLOSE MODALS BY OVERLAY
    ====================================================== */

    document
        .querySelectorAll(
            ".product-modal .modal-overlay"
        )
        .forEach(overlay => {

            overlay.addEventListener(
                "click",
                () => {

                    const modal =
                        overlay.closest(
                            ".product-modal"
                        );

                    closeModal(modal);

                }
            );

        });


    /* =====================================================
       ESCAPE KEY
    ====================================================== */

    document.addEventListener(
        "keydown",
        event => {

            if (
                event.key ===
                "Escape"
            ) {

                document
                    .querySelectorAll(
                        ".product-modal.show"
                    )
                    .forEach(
                        closeModal
                    );


                if (productMenu) {

                    productMenu.classList.remove(
                        "show"
                    );

                }

            }

        }
    );


    /* =====================================================
       NOTIFICATION
    ====================================================== */

    const notificationBtn =
        document.getElementById(
            "notificationBtn"
        );


    if (notificationBtn) {

        notificationBtn.addEventListener(
            "click",
            () => {

                showToast(
                    "You have 328 products waiting for review.",
                    "info"
                );

            }
        );

    }


    /* =====================================================
       LOGOUT
    ====================================================== */

    const logoutBtn =
        document.getElementById(
            "logoutBtn"
        );


    if (logoutBtn) {

        logoutBtn.addEventListener(
            "click",
            event => {

                event.preventDefault();


                const confirmed =
                    confirm(
                        "Are you sure you want to logout?"
                    );


                if (confirmed) {

                    localStorage.removeItem(
                        "fash_admin_session"
                    );


                    window.location.href =
                        "../index.html";

                }

            }
        );

    }


    /* =====================================================
       HELPERS
    ====================================================== */

    function getProductFromRow(row) {

        if (!row) return null;


        const id =
            row.dataset.productId;


        const products =
            getProducts();


        const saved =
            products.find(
                product =>
                    product.id === id
            );


        if (saved)
            return saved;


        const cells =
            row.querySelectorAll("td");


        return {

            id,

            name:
                cells[1]
                    ?.querySelector(
                        "strong"
                    )
                    ?.textContent
                    .trim() || "",

            sku:
                cells[2]
                    ?.textContent
                    .trim() || "",

            seller:
                row.dataset.seller,

            category:
                row.dataset.category,

            price:
                Number(
                    row.dataset.price
                ),

            stock:
                Number(
                    row.dataset.stock
                ),

            status:
                row.dataset.status,

            owner:
                row.dataset.owner,

            description:
                ""

        };

    }


    function updateCounts() {

        const rows =
            document.querySelectorAll(
                "#productsTableBody tr"
            );


        let pending = 0;
        let active = 0;
        let out = 0;
        let total = rows.length;


        rows.forEach(row => {

            switch (
                row.dataset.status
            ) {

                case "pending":
                    pending++;
                    break;

                case "active":
                    active++;
                    break;

                case "out":
                    out++;
                    break;

            }

        });


        const totalElement =
            document.getElementById(
                "totalProducts"
            );

        const pendingElement =
            document.getElementById(
                "pendingProducts"
            );

        const activeElement =
            document.getElementById(
                "activeProducts"
            );

        const outElement =
            document.getElementById(
                "outOfStockProducts"
            );


        if (totalElement) {

            totalElement.textContent =
                formatNumber(total);

        }


        if (pendingElement) {

            pendingElement.textContent =
                formatNumber(pending);

        }


        if (activeElement) {

            activeElement.textContent =
                formatNumber(active);

        }


        if (outElement) {

            outElement.textContent =
                formatNumber(out);

        }

    }


    function formatNumber(number) {

        return Number(number || 0)
            .toLocaleString(
                "en-NG"
            );

    }


    function formatSellerName(
        seller
    ) {

        const names = {

            "urban-style":
                "Urban Style",

            "tech-world":
                "Tech World",

            "glow-store":
                "Glow Store",

            "home-hub":
                "Home Hub",

            "smart-store":
                "Smart Store",

            "sport-zone":
                "Sport Zone",

            "fash":
                "FASH"

        };


        return (
            names[seller] ||
            seller ||
            "Unknown Seller"
        );

    }


    function formatCategory(
        category
    ) {

        const categories = {

            fashion:
                "Fashion",

            electronics:
                "Electronics",

            beauty:
                "Beauty",

            home:
                "Home & Living",

            sports:
                "Sports",

            phones:
                "Phones & Tablets"

        };


        return (
            categories[category] ||
            category ||
            "Other"
        );

    }


    function formatStatus(
        status
    ) {

        const statuses = {

            pending:
                "Pending Review",

            active:
                "Active",

            rejected:
                "Rejected",

            out:
                "Out of Stock",

            suspended:
                "Suspended"

        };


        return (
            statuses[status] ||
            status
        );

    }


    function getCategoryIcon(
        category
    ) {

        const icons = {

            fashion:
                "fa-solid fa-shirt",

            electronics:
                "fa-solid fa-laptop",

            beauty:
                "fa-solid fa-spray-can-sparkles",

            home:
                "fa-solid fa-couch",

            sports:
                "fa-solid fa-futbol",

            phones:
                "fa-solid fa-mobile-screen-button"

        };


        return (
            icons[category] ||
            "fa-solid fa-box"
        );

    }


    function escapeHTML(
        value
    ) {

        return String(value)
            .replace(
                /&/g,
                "&amp;"
            )
            .replace(
                /</g,
                "&lt;"
            )
            .replace(
                />/g,
                "&gt;"
            )
            .replace(
                /"/g,
                "&quot;"
            )
            .replace(
                /'/g,
                "&#039;"
            );

    }


    /* =====================================================
       TOAST
    ====================================================== */

    function showToast(
        message,
        type = "info"
    ) {

        const existing =
            document.querySelector(
                ".fash-toast"
            );


        if (existing) {

            existing.remove();

        }


        const toast =
            document.createElement(
                "div"
            );


        toast.className =
            `fash-toast ${type}`;


        const icon =
            type === "success"
                ? "fa-circle-check"
                : type === "error"
                    ? "fa-circle-xmark"
                    : "fa-circle-info";


        toast.innerHTML = `

            <i class="fa-solid ${icon}"></i>

            <span>
                ${escapeHTML(message)}
            </span>

        `;


        document.body.appendChild(
            toast
        );


        requestAnimationFrame(() => {

            toast.classList.add(
                "show"
            );

        });


        setTimeout(() => {

            toast.classList.remove(
                "show"
            );


            setTimeout(() => {

                toast.remove();

            }, 250);

        }, 3500);

    }


    /* =====================================================
       TOAST STYLES
       Injected so the CSS file doesn't need another block.
    ====================================================== */

    const toastStyle =
        document.createElement(
            "style"
        );


    toastStyle.textContent = `

        .fash-toast {

            position: fixed;

            right: 25px;

            bottom: 25px;

            z-index: 5000;

            min-width: 280px;

            max-width: 420px;

            padding: 14px 17px;

            border-radius: 11px;

            background: #ffffff;

            border: 1px solid #e7eaf0;

            box-shadow:
                0 15px 40px
                rgba(16, 24, 40, .14);

            display: flex;

            align-items: center;

            gap: 10px;

            color: #344054;

            font-size: 12px;

            font-weight: 650;

            opacity: 0;

            transform:
                translateY(12px);

            pointer-events: none;

            transition:
                .25s ease;

        }


        .fash-toast.show {

            opacity: 1;

            transform:
                translateY(0);

        }


        .fash-toast i {

            font-size: 17px;

        }


        .fash-toast.success i {

            color: #16a34a;

        }


        .fash-toast.error i {

            color: #dc2626;

        }


        .fash-toast.info i {

            color: #1463ff;

        }

    `;


    document.head.appendChild(
        toastStyle
    );


    /* =====================================================
       INITIALIZE
    ====================================================== */

    applyFilters();

    updateCounts();

});