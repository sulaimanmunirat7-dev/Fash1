document.addEventListener("DOMContentLoaded", () => {

    const menuItems = document.querySelectorAll(".settings-menu-item");
    const sections = document.querySelectorAll(".settings-section");

    const saveButton = document.getElementById("saveSettingsBtn");
    const resetButton = document.getElementById("resetSettingsBtn");

    const toast = document.getElementById("settingsToast");
    const toastMessage = document.getElementById("settingsToastMessage");


    /* =========================================================
       SETTINGS NAVIGATION
    ========================================================= */

    menuItems.forEach(item => {

        item.addEventListener("click", () => {

            const target = item.dataset.settingsSection;

            menuItems.forEach(menu => {
                menu.classList.remove("active");
            });

            sections.forEach(section => {
                section.classList.remove("active");
            });

            item.classList.add("active");

            const targetSection =
                document.getElementById(`settings-${target}`);

            if (targetSection) {
                targetSection.classList.add("active");
            }

            // Keep the page at its current position.
            // Do NOT use window.scrollTo(0, 0).
        });

    });


    /* =========================================================
       SETTINGS STORAGE
    ========================================================= */

    const settingIds = [

        "platformName",
        "supportEmail",
        "platformDescription",

        "allowNewSellers",
        "allowNewProducts",
        "maintenanceMode",

        "autoOrderConfirmation",
        "orderCancellationTime",

        "onlinePayments",
        "currency",

        "customerRegistration",
        "emailVerification",

        "sellerApproval",
        "productApproval",

        "sellerApplicationNotifications",
        "productNotifications",
        "returnNotifications",

        "sessionTimeout"

    ];


    function getSettings() {

        const settings = {};

        settingIds.forEach(id => {

            const element = document.getElementById(id);

            if (!element) return;

            if (element.type === "checkbox") {
                settings[id] = element.checked;
            } else {
                settings[id] = element.value;
            }

        });

        return settings;
    }


    function loadSettings() {

        const saved =
            localStorage.getItem("fash_admin_settings");

        if (!saved) return;

        let settings;

        try {
            settings = JSON.parse(saved);
        } catch {
            return;
        }

        settingIds.forEach(id => {

            const element = document.getElementById(id);

            if (!element || settings[id] === undefined) {
                return;
            }

            if (element.type === "checkbox") {
                element.checked = Boolean(settings[id]);
            } else {
                element.value = settings[id];
            }

        });

    }


    function saveSettings() {

        const settings = getSettings();

        localStorage.setItem(
            "fash_admin_settings",
            JSON.stringify(settings)
        );

        showToast("Settings saved successfully.");

    }


    /* =========================================================
       TOAST
    ========================================================= */

    let toastTimer;

    function showToast(message) {

        if (!toast || !toastMessage) return;

        toastMessage.textContent = message;

        toast.classList.add("show");

        clearTimeout(toastTimer);

        toastTimer = setTimeout(() => {

            toast.classList.remove("show");

        }, 3000);

    }


    /* =========================================================
       SAVE BUTTON
    ========================================================= */

    saveButton?.addEventListener("click", () => {

        saveSettings();

    });


    /* =========================================================
       RESET SETTINGS
    ========================================================= */

    resetButton?.addEventListener("click", () => {

        const confirmed = confirm(
            "Are you sure you want to reset all FASH admin settings?"
        );

        if (!confirmed) return;

        localStorage.removeItem("fash_admin_settings");

        location.reload();

    });


    /* =========================================================
       LIVE MAINTENANCE MODE WARNING
    ========================================================= */

    const maintenanceMode =
        document.getElementById("maintenanceMode");

    maintenanceMode?.addEventListener("change", () => {

        if (maintenanceMode.checked) {

            showToast(
                "Maintenance mode enabled. Save changes to apply it."
            );

        }

    });


    /* =========================================================
       LOAD SAVED SETTINGS
    ========================================================= */

    loadSettings();

});