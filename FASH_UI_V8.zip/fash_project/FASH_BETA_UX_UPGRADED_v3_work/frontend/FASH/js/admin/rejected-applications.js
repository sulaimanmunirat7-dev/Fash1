(() => {
"use strict";
const esc=v=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function load(){
 const body=document.getElementById("rejectedBody"), empty=document.getElementById("rejectedEmpty");
 try{
  const d=await FASH_API.api("/api/admin/seller-applications/rejected");
  const a=d.applications||[]; body.innerHTML=a.map(x=>`<tr><td><strong>${esc(x.applicant_name)}</strong><br><small>${esc(x.email)}</small></td><td>${esc(x.business_name)}</td><td>${esc(x.category)}</td><td>${x.reviewed_at?new Date(x.reviewed_at).toLocaleDateString():"—"}</td><td>${esc(x.admin_notes||"No reason recorded")}</td></tr>`).join("");
  empty.hidden=a.length>0;
 }catch(e){body.innerHTML=`<tr><td colspan="5" style="text-align:center;padding:30px;">Could not load rejected applications. ${esc(e.message)}</td></tr>`;empty.hidden=true;}
}
document.addEventListener("DOMContentLoaded",load);
})();