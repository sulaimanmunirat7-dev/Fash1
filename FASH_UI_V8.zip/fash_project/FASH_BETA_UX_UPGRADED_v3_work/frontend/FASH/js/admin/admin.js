/* =========================================================
   FASH ADMIN DASHBOARD
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    /* =====================================================
       SALES CHART
    ===================================================== */

    const salesCanvas = document.getElementById("salesChart");

    if (salesCanvas && typeof Chart !== "undefined") {

        const ctx = salesCanvas.getContext("2d");

        const gradient = ctx.createLinearGradient(0, 0, 0, 260);

        gradient.addColorStop(0, "rgba(37, 99, 235, 0.22)");
        gradient.addColorStop(1, "rgba(37, 99, 235, 0)");

        new Chart(ctx, {

            type: "line",

            data: {

                labels: [
                    "1",
                    "5",
                    "10",
                    "15",
                    "20",
                    "25",
                    "30"
                ],

                datasets: [
                    {
                        label: "Revenue",

                        data: [
                            210000,
                            340000,
                            290000,
                            510000,
                            470000,
                            690000,
                            842000
                        ],

                        borderColor: "#2563eb",

                        backgroundColor: gradient,

                        borderWidth: 3,

                        fill: true,

                        tension: 0.4,

                        pointRadius: 3,

                        pointHoverRadius: 6,

                        pointBackgroundColor: "#ffffff",

                        pointBorderColor: "#2563eb",

                        pointBorderWidth: 2
                    }
                ]

            },

            options: {

                responsive: true,

                maintainAspectRatio: false,

                interaction: {
                    intersect: false,
                    mode: "index"
                },

                plugins: {

                    legend: {
                        display: false
                    },

                    tooltip: {

                        backgroundColor: "#111827",

                        titleColor: "#ffffff",

                        bodyColor: "#ffffff",

                        padding: 12,

                        displayColors: false,

                        callbacks: {

                            label: function(context) {

                                return " ₦" +
                                    Number(
                                        context.raw
                                    ).toLocaleString();

                            }

                        }

                    }

                },

                scales: {

                    x: {

                        grid: {
                            display: false
                        },

                        border: {
                            display: false
                        },

                        ticks: {

                            color: "#98a2b3",

                            font: {
                                size: 9
                            }

                        }

                    },

                    y: {

                        beginAtZero: true,

                        grid: {

                            color: "#eef1f5",

                            drawBorder: false

                        },

                        border: {
                            display: false
                        },

                        ticks: {

                            color: "#98a2b3",

                            font: {
                                size: 9
                            },

                            callback: function(value) {

                                if (value >= 1000000) {
                                    return "₦" +
                                        (value / 1000000) +
                                        "M";
                                }

                                if (value >= 1000) {
                                    return "₦" +
                                        (value / 1000) +
                                        "K";
                                }

                                return "₦" + value;

                            }

                        }

                    }

                }

            }

        });

    }


    /* =====================================================
       ADMIN SEARCH
    ===================================================== */

    const searchInput =
        document.getElementById("adminSearch");

    if (searchInput) {

        searchInput.addEventListener("input", () => {

            const query =
                searchInput.value
                    .trim()
                    .toLowerCase();

            const rows =
                document.querySelectorAll(
                    ".orders-table tbody tr"
                );

            rows.forEach(row => {

                const text =
                    row.textContent
                        .toLowerCase();

                row.style.display =
                    text.includes(query)
                        ? ""
                        : "none";

            });

        });

    }


    /* =====================================================
       NOTIFICATION BUTTON
    ===================================================== */

    const notificationBtn =
        document.getElementById(
            "notificationBtn"
        );

    if (notificationBtn) {

        notificationBtn.addEventListener(
            "click",
            () => {

                const existing =
                    document.querySelector(
                        ".notification-panel"
                    );

                if (existing) {
                    existing.remove();
                    return;
                }

                const panel =
                    document.createElement("div");

                panel.className =
                    "notification-panel";

                panel.innerHTML = `

                    <div class="notification-panel-header">
                        <strong>Notifications</strong>
                        <span>3 new</span>
                    </div>

                    <div class="notification-item">
                        <i class="fa-solid fa-bag-shopping"></i>

                        <div>
                            <strong>New order</strong>
                            <p>Order #FS10284 was placed.</p>
                        </div>
                    </div>

                    <div class="notification-item">
                        <i class="fa-solid fa-store"></i>

                        <div>
                            <strong>New seller</strong>
                            <p>A seller application needs review.</p>
                        </div>
                    </div>

                    <div class="notification-item">
                        <i class="fa-solid fa-rotate-left"></i>

                        <div>
                            <strong>Return request</strong>
                            <p>A customer submitted a return.</p>
                        </div>
                    </div>

                `;

                document.body.appendChild(panel);

                positionNotificationPanel(
                    panel,
                    notificationBtn
                );

            }
        );

    }


    /* =====================================================
       POSITION NOTIFICATION PANEL
    ===================================================== */

    function positionNotificationPanel(
        panel,
        button
    ) {

        const rect =
            button.getBoundingClientRect();

        panel.style.position = "fixed";

        panel.style.top =
            `${rect.bottom + 10}px`;

        panel.style.right =
            `${window.innerWidth - rect.right}px`;

    }


    /* =====================================================
       CLOSE NOTIFICATIONS WHEN CLICKING OUTSIDE
    ===================================================== */

    document.addEventListener(
        "click",
        event => {

            const panel =
                document.querySelector(
                    ".notification-panel"
                );

            if (!panel) return;

            const button =
                document.getElementById(
                    "notificationBtn"
                );

            if (
                !panel.contains(event.target) &&
                !button.contains(event.target)
            ) {

                panel.remove();

            }

        }
    );


    /* =====================================================
       SALES PERIOD BUTTON
    ===================================================== */

    const salesPeriod =
        document.getElementById(
            "salesPeriod"
        );

    if (salesPeriod) {

        salesPeriod.addEventListener(
            "click",
            () => {

                const periods = [
                    "Today",
                    "This Week",
                    "This Month",
                    "This Year"
                ];

                const current =
                    salesPeriod.dataset.period ||
                    "This Month";

                let index =
                    periods.indexOf(current);

                index++;

                if (index >= periods.length) {
                    index = 0;
                }

                salesPeriod.dataset.period =
                    periods[index];

                salesPeriod.innerHTML =
                    `${periods[index]}
                    <i class="fa-solid fa-chevron-down"></i>`;

            }
        );

    }


    /* =====================================================
       QUICK ACTIONS
    ===================================================== */

    const quickActions =
        document.querySelectorAll(
            ".quick-action"
        );

    quickActions.forEach(action => {

        action.addEventListener(
            "click",
            () => {

                action.classList.add("clicked");

                setTimeout(() => {

                    action.classList.remove(
                        "clicked"
                    );

                }, 250);

            }
        );

    });


    /* =====================================================
       LOGOUT
    ===================================================== */

    const logoutBtn =
        document.getElementById(
            "logoutBtn"
        );

    if (logoutBtn) {

        logoutBtn.addEventListener(
            "click",
            event => {

                event.preventDefault();

                const confirmed =
                    confirm(
                        "Are you sure you want to logout of the FASH Admin Dashboard?"
                    );

                if (!confirmed) return;

                /*
                 * Remove this if your authentication
                 * system handles logout elsewhere.
                 */

                localStorage.removeItem(
                    "fashAdminLoggedIn"
                );

                window.location.href =
                    "../index.html";

            }
        );

    }


    /* =====================================================
       MOBILE SIDEBAR
    ===================================================== */

    createMobileMenu();


    function createMobileMenu() {

        if (
            document.querySelector(
                ".mobile-menu-btn"
            )
        ) {
            return;
        }

        const button =
            document.createElement("button");

        button.className =
            "mobile-menu-btn";

        button.innerHTML =
            '<i class="fa-solid fa-bars"></i>';

        document.body.appendChild(button);

        const sidebar =
            document.querySelector(
                ".sidebar"
            );

        if (!sidebar) return;

        button.addEventListener(
            "click",
            () => {

                sidebar.classList.toggle(
                    "mobile-open"
                );

            }
        );

        document.addEventListener(
            "click",
            event => {

                if (
                    window.innerWidth > 800
                ) {
                    return;
                }

                if (
                    !sidebar.contains(
                        event.target
                    ) &&
                    !button.contains(
                        event.target
                    )
                ) {

                    sidebar.classList.remove(
                        "mobile-open"
                    );

                }

            }
        );

    }


    /* =====================================================
       LIVE CLOCK
    ===================================================== */

    createClock();


    function createClock() {

        const headerLeft =
            document.querySelector(
                ".header-left"
            );

        if (!headerLeft) return;

        let clock =
            document.querySelector(
                ".admin-clock"
            );

        if (!clock) {

            clock =
                document.createElement("span");

            clock.className =
                "admin-clock";

            headerLeft.appendChild(clock);

        }

        function updateClock() {

            const now = new Date();

            clock.textContent =
                now.toLocaleTimeString(
                    "en-NG",
                    {
                        hour: "2-digit",
                        minute: "2-digit"
                    }
                );

        }

        updateClock();

        setInterval(
            updateClock,
            1000
        );

    }


    /* =====================================================
       SMOOTH CARD ENTRY
    ===================================================== */

    const dashboardElements =
        document.querySelectorAll(
            ".kpi-card, .analytics-card, .dashboard-card"
        );

    dashboardElements.forEach(
        (element, index) => {

            element.style.opacity = "0";

            element.style.transform =
                "translateY(8px)";

            setTimeout(() => {

                element.style.transition =
                    "opacity .35s ease, transform .35s ease";

                element.style.opacity = "1";

                element.style.transform =
                    "translateY(0)";

            }, index * 60);

        }
    );

});