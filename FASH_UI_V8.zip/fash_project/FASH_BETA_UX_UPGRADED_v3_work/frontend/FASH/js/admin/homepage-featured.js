(() => {
"use strict";
const esc=v=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function load(){
 const list=document.getElementById("homepageFeatureList"), badge=document.getElementById("featuredCountBadge");
 if(!list)return;
 try{
  const d=await FASH_API.api("/api/products");
  const products=d.products||[];
  const featured=products.filter(p=>p.is_featured);
  badge.textContent=`${featured.length} / 8`;
  list.innerHTML=products.slice(0,30).map(p=>`<div style="display:flex;align-items:center;gap:14px;padding:12px;border:1px solid #e5e7eb;border-radius:12px;background:#fff;"><div style="flex:1"><strong>${esc(p.name)}</strong><div style="font-size:12px;color:#64748b">${esc(p.seller_name||"Seller")} · ₦${Number(p.price).toLocaleString()}</div></div><input type="number" min="1" max="8" value="${p.featured_position||""}" placeholder="Position" data-position="${esc(p.id)}" style="width:90px;padding:8px;border:1px solid #ddd;border-radius:8px"><button type="button" data-feature="${esc(p.id)}" data-state="${p.is_featured?'1':'0'}" style="padding:9px 14px;border:0;border-radius:9px;cursor:pointer;">${p.is_featured?"Remove":"Feature"}</button></div>`).join("")||"<p>No active seller products yet.</p>";
  list.querySelectorAll("[data-feature]").forEach(btn=>btn.addEventListener("click",async()=>{
   const id=btn.dataset.feature, featured=btn.dataset.state!=="1", pos=list.querySelector(`[data-position="${CSS.escape(id)}"]`)?.value||null;
   try{await FASH_API.api(`/api/admin/products/${encodeURIComponent(id)}/featured`,{method:"PATCH",body:JSON.stringify({featured,featuredPosition:pos})}); await load();}catch(e){alert(e.message);}
  }));
 }catch(e){list.innerHTML=`<p>Could not load products: ${esc(e.message)}</p>`;}
}
document.addEventListener("DOMContentLoaded",load);
})();