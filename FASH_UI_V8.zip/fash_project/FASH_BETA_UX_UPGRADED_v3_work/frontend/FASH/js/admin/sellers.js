/* =========================================================
   FASH ADMIN — SELLERS
   Seller Management JavaScript
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    /* =====================================================
       SELLER DATA
    ===================================================== */

    let sellers = JSON.parse(localStorage.getItem("fashSellers")) || [];

    const fallbackSellers = [
        { id: 1, name: "Aisha Bello", email: "aisha@example.com", phone: "+234 801 234 5678", store: "Aisha Fashion Hub", category: "fashion", products: 42, sales: 1285000, rating: 4.8, status: "active", joined: "12 Jan 2026" },
        { id: 2, name: "Daniel Okafor", email: "daniel@example.com", phone: "+234 803 456 7890", store: "TechZone NG", category: "electronics", products: 67, sales: 2450000, rating: 4.6, status: "active", joined: "18 Jan 2026" }
    ];

    async function loadDatabaseSellers() {
        try {
            if (!window.FASH_API) throw new Error("API client unavailable");
            const data = await FASH_API.api("/api/admin/sellers");
            if (Array.isArray(data.sellers)) {
                sellers = data.sellers.map(s => ({
                    id: s.id, name: s.name || "Unknown Seller", email: s.email || "", phone: s.phone || "",
                    store: s.store || "No store yet", category: s.category || "general", products: Number(s.products || 0),
                    sales: Number(s.sales || 0), rating: Number(s.rating || 0), status: s.status || "setup", verificationStatus: s.verificationStatus || "unverified", completedSales: Number(s.completedSales || 0), verificationEligible: Boolean(s.verificationEligible), storeId: s.storeId || null, storeStatus: s.storeStatus || "DRAFT", joined: s.joined || ""
                }));
                saveSellers();
                render();
                return;
            }
        } catch (error) {
            console.warn("FASH admin sellers API unavailable; using cached sellers:", error);
        }
        if (!sellers.length) sellers = fallbackSellers;
        render();
    }



    /* =====================================================
       DOM ELEMENTS
    ===================================================== */

    const tableBody =
        document.getElementById("sellersTableBody");

    const emptyState =
        document.getElementById("sellersEmpty");

    const searchInput =
        document.getElementById("sellerSearch");

    const categoryFilter =
        document.getElementById("sellerCategoryFilter");

    const statusFilter =
        document.getElementById("sellerStatusFilter");

    const selectAll =
        document.getElementById("selectAllSellers");

    const sellerMenu =
        document.getElementById("sellerMenu");

    const addSellerBtn =
        document.getElementById("addSellerBtn");

    const addSellerModal =
        document.getElementById("addSellerModal");

    const addSellerForm =
        document.getElementById("addSellerForm");

    const reviewModal =
        document.getElementById("sellerReviewModal");

    const rejectModal =
        document.getElementById("rejectSellerModal");

    let selectedSellerId = null;

    let currentTab = "all";


    /* =====================================================
       SAVE DATA
    ===================================================== */

    function saveSellers() {

        localStorage.setItem(
            "fashSellers",
            JSON.stringify(sellers)
        );

    }


    /* =====================================================
       FORMAT CURRENCY
    ===================================================== */

    function formatCurrency(value) {

        return new Intl.NumberFormat(
            "en-NG",
            {
                style: "currency",
                currency: "NGN",
                maximumFractionDigits: 0
            }
        ).format(value);

    }


    /* =====================================================
       FORMAT CATEGORY
    ===================================================== */

    function formatCategory(category) {

        const categories = {

            fashion: "Fashion",

            electronics: "Electronics",

            beauty: "Beauty",

            home: "Home & Living",

            sports: "Sports"

        };

        return categories[category] || category;

    }


    /* =====================================================
       FORMAT STATUS
    ===================================================== */

    function formatStatus(status) {

        return (
            status.charAt(0).toUpperCase() +
            status.slice(1)
        );

    }


    /* =====================================================
       SELLER INITIAL
       ===================================================== */

    function getInitials(name) {

        return name
            .split(" ")
            .map(word => word.charAt(0))
            .join("")
            .substring(0, 2)
            .toUpperCase();

    }


    /* =====================================================
       FILTER SELLERS
    ===================================================== */

    function getFilteredSellers() {

        const search =
            searchInput?.value
                .toLowerCase()
                .trim() || "";

        const category =
            categoryFilter?.value || "all";

        const status =
            statusFilter?.value || "all";


        return sellers.filter(seller => {

            const matchesSearch =
                !search ||

                seller.name
                    .toLowerCase()
                    .includes(search) ||

                seller.email
                    .toLowerCase()
                    .includes(search) ||

                seller.store
                    .toLowerCase()
                    .includes(search);


            const matchesCategory =
                category === "all" ||
                seller.category === category;


            const matchesStatus =
                status === "all" ||
                seller.status === status;


            const matchesTab =
                currentTab === "all" ||
                seller.status === currentTab;


            return (
                matchesSearch &&
                matchesCategory &&
                matchesStatus &&
                matchesTab
            );

        });

    }


    /* =====================================================
       RENDER SELLERS
    ===================================================== */

    function renderSellers() {

        if (!tableBody) return;

        const filtered =
            getFilteredSellers();


        tableBody.innerHTML = "";


        if (filtered.length === 0) {

            if (emptyState) {
                emptyState.hidden = false;
            }

            updatePagination(0);

            return;

        }


        if (emptyState) {
            emptyState.hidden = true;
        }


        filtered.forEach(seller => {

            const row =
                document.createElement("tr");

            row.innerHTML = `

                <td class="checkbox-column">

                    <input
                        type="checkbox"
                        class="seller-checkbox"
                        data-id="${seller.id}"
                    >

                </td>


                <td>

                    <div class="seller-info">

                        <div class="seller-avatar">
                            ${getInitials(seller.name)}
                        </div>

                        <div>

                            <strong>
                                ${escapeHTML(seller.name)}
                            </strong>

                            <span>
                                ${escapeHTML(seller.email)}
                            </span>

                        </div>

                    </div>

                </td>


                <td>

                    <span class="store-name">
                        ${escapeHTML(seller.store)}
                    </span>

                </td>


                <td>
                    <span class="verification-badge ${seller.verificationStatus}">
                        ${seller.verificationStatus === "verified" ? "Verified Seller" : "Seller"}
                    </span>
                    ${seller.verificationStatus !== "verified" && seller.verificationEligible ? `<button type="button" class="verify-seller-btn" data-verify-id="${seller.id}">Verify Seller</button>` : seller.verificationStatus !== "verified" ? `<small class="verification-progress">${seller.completedSales}/100 qualifying sales</small>` : ""}
                </td>

                <td>

                    <span class="category-label">
                        ${formatCategory(seller.category)}
                    </span>

                </td>


                <td>

                    <span class="products-count">
                        ${seller.products}
                    </span>

                </td>


                <td>

                    <span class="sales-value">
                        ${seller.completedSales} completed/delivered sales
                    </span>

                </td>


                <td>

                    <span class="rating">

                        <i class="fa-solid fa-star"></i>

                        ${Number(seller.rating).toFixed(1)}

                    </span>

                </td>


                <td>

                    <span
                        class="seller-status ${seller.status}"
                    >
                        ${formatStatus(seller.status)}
                    </span>

                </td>


                <td>
                    ${escapeHTML(seller.joined)}
                </td>


                <td>

                    ${seller.storeId ? `<a class="seller-action" href="../pages/store.html?id=${encodeURIComponent(seller.storeId)}" title="View Store"><i class="fa-solid fa-store"></i></a>` : ""}
                    <button
                        class="seller-action"
                        data-menu-id="${seller.id}"
                        aria-label="Seller actions"
                    >
                        <i class="fa-solid fa-ellipsis-vertical"></i>
                    </button>

                </td>

            `;

            tableBody.appendChild(row);

        });


        updatePagination(filtered.length);

        updateSelectAll();

    }


    /* =====================================================
       ESCAPE HTML
    ===================================================== */

    function escapeHTML(value) {

        const div =
            document.createElement("div");

        div.textContent =
            String(value ?? "");

        return div.innerHTML;

    }


    /* =====================================================
       UPDATE STATISTICS
    ===================================================== */

    function updateStats() {

        const total =
            sellers.length;

        const active =
            sellers.filter(
                seller => seller.status === "active"
            ).length;

        const pending =
            sellers.filter(
                seller => seller.status === "pending"
            ).length;

        const suspended =
            sellers.filter(
                seller => seller.status === "suspended"
            ).length;

        const rejected =
            sellers.filter(
                seller => seller.status === "rejected"
            ).length;


        setText(
            "totalSellers",
            total
        );

        setText(
            "activeSellers",
            active
        );

        setText(
            "pendingSellers",
            pending
        );

        setText(
            "suspendedSellers",
            suspended
        );


        setText(
            "allSellerCount",
            total
        );

        setText(
            "activeSellerCount",
            active
        );

        setText(
            "pendingSellerCount",
            pending
        );

        setText(
            "suspendedSellerCount",
            suspended
        );

        setText(
            "rejectedSellerCount",
            rejected
        );

    }


    function setText(id, value) {

        const element =
            document.getElementById(id);

        if (element) {
            element.textContent = value;
        }

    }


    /* =====================================================
       PAGINATION
    ===================================================== */

    function updatePagination(count) {

        const text =
            document.getElementById(
                "paginationText"
            );

        if (!text) return;

        if (count === 0) {

            text.textContent =
                "Showing 0 sellers";

        } else {

            text.textContent =
                `Showing ${count} seller${count === 1 ? "" : "s"}`;

        }

    }


    /* =====================================================
       SELECT ALL
    ===================================================== */

    function updateSelectAll() {

        if (!selectAll) return;

        const checkboxes =
            document.querySelectorAll(
                ".seller-checkbox"
            );

        if (checkboxes.length === 0) {

            selectAll.checked = false;

            return;

        }

        selectAll.checked =
            [...checkboxes].every(
                checkbox => checkbox.checked
            );

    }


    selectAll?.addEventListener(
        "change",
        () => {

            const checkboxes =
                document.querySelectorAll(
                    ".seller-checkbox"
                );

            checkboxes.forEach(
                checkbox => {
                    checkbox.checked =
                        selectAll.checked;
                }
            );

        }
    );


    tableBody?.addEventListener(
        "change",
        event => {

            if (
                event.target.classList
                    .contains("seller-checkbox")
            ) {

                updateSelectAll();

            }

        }
    );


    /* =====================================================
       SEARCH
    ===================================================== */

    searchInput?.addEventListener(
        "input",
        renderSellers
    );


    categoryFilter?.addEventListener(
        "change",
        renderSellers
    );


    statusFilter?.addEventListener(
        "change",
        renderSellers
    );


    /* =====================================================
       SELLER TABS
    ===================================================== */

    document.querySelectorAll(
        ".seller-tab"
    ).forEach(tab => {

        tab.addEventListener(
            "click",
            () => {

                document
                    .querySelectorAll(".seller-tab")
                    .forEach(item =>
                        item.classList.remove("active")
                    );


                tab.classList.add("active");


                currentTab =
                    tab.dataset.tab || "all";


                if (statusFilter) {
                    statusFilter.value =
                        "all";
                }


                renderSellers();

            }
        );

    });


    /* =====================================================
       ACTION MENU
    ===================================================== */

    tableBody?.addEventListener(
        "click",
        event => {

            const button =
                event.target.closest(
                    "[data-menu-id]"
                );

            if (!button) return;


            event.stopPropagation();


            selectedSellerId =
                Number(
                    button.dataset.menuId
                );


            const rect =
                button.getBoundingClientRect();


            sellerMenu.style.top =
                `${rect.bottom + 5}px`;

            sellerMenu.style.left =
                `${rect.right - 190}px`;


            sellerMenu.classList.add("show");

        }
    );


    document.addEventListener(
        "click",
        event => {

            if (
                sellerMenu &&
                !sellerMenu.contains(event.target) &&
                !event.target.closest("[data-menu-id]")
            ) {

                sellerMenu.classList.remove(
                    "show"
                );

            }

        }
    );


    /* =====================================================
       MENU ACTIONS
    ===================================================== */

    sellerMenu?.addEventListener(
        "click",
        event => {

            const button =
                event.target.closest("button");

            if (!button) return;


            const action =
                button.dataset.action;


            const seller =
                sellers.find(
                    item =>
                        item.id ===
                        selectedSellerId
                );


            if (!seller) return;


            sellerMenu.classList.remove(
                "show"
            );


            if (action === "view") {

                openReviewModal(seller);

            }


            if (action === "edit") {

                editSeller(seller);

            }


            if (action === "approve") {

                approveSeller(seller.id);

            }


            if (action === "reject") {

                openRejectModal(seller.id);

            }


            if (action === "suspend") {

                suspendSeller(seller.id);

            }

        }
    );


    /* =====================================================
       APPROVE SELLER
    ===================================================== */

    function approveSeller(id) {

        const seller =
            sellers.find(
                item => item.id === id
            );

        if (!seller) return;


        seller.status = "active";


        saveSellers();

        updateStats();

        renderSellers();

        showToast(
            `${seller.store} has been approved.`,
            "success"
        );

    }


    /* =====================================================
       SUSPEND SELLER
    ===================================================== */

    function suspendSeller(id) {

        const seller =
            sellers.find(
                item => item.id === id
            );

        if (!seller) return;


        const confirmed =
            confirm(
                `Suspend ${seller.store}?`
            );


        if (!confirmed) return;


        seller.status =
            "suspended";


        saveSellers();

        updateStats();

        renderSellers();


        showToast(
            `${seller.store} has been suspended.`,
            "warning"
        );

    }


    /* =====================================================
       OPEN REVIEW MODAL
    ===================================================== */

    function openReviewModal(seller) {

        selectedSellerId =
            seller.id;


        setText(
            "reviewSellerName",
            seller.name
        );

        setText(
            "reviewStoreName",
            seller.store
        );

        setText(
            "reviewSellerEmail",
            seller.email
        );

        setText(
            "reviewSellerPhone",
            seller.phone || "—"
        );

        setText(
            "reviewSellerCategory",
            formatCategory(
                seller.category
            )
        );

        setText(
            "reviewSellerStatus",
            formatStatus(
                seller.status
            )
        );

        setText(
            "reviewSellerProducts",
            seller.products
        );

        setText(
            "reviewSellerSales",
            formatCurrency(
                seller.sales
            )
        );

        setText(
            "reviewSellerRating",
            Number(
                seller.rating
            ).toFixed(1)
        );

        setText(
            "reviewSellerJoined",
            seller.joined
        );


        const avatar =
            document.getElementById(
                "reviewSellerAvatar"
            );

        if (avatar) {

            avatar.textContent =
                getInitials(
                    seller.name
                );

        }


        reviewModal?.classList.add(
            "show"
        );

    }


    /* =====================================================
       CLOSE MODALS
    ===================================================== */

    function closeModal(modal) {

        modal?.classList.remove(
            "show"
        );

    }


    document
        .getElementById(
            "closeSellerReviewModal"
        )
        ?.addEventListener(
            "click",
            () => closeModal(reviewModal)
        );


    document
        .getElementById(
            "closeSellerReviewBottom"
        )
        ?.addEventListener(
            "click",
            () => closeModal(reviewModal)
        );


    document
        .getElementById(
            "closeAddSellerModal"
        )
        ?.addEventListener(
            "click",
            () => closeModal(addSellerModal)
        );


    document
        .getElementById(
            "cancelAddSeller"
        )
        ?.addEventListener(
            "click",
            () => closeModal(addSellerModal)
        );


    document
        .getElementById(
            "closeRejectSellerModal"
        )
        ?.addEventListener(
            "click",
            () => closeModal(rejectModal)
        );


    document
        .getElementById(
            "cancelRejectSeller"
        )
        ?.addEventListener(
            "click",
            () => closeModal(rejectModal)
        );


    /* =====================================================
       CLOSE WHEN CLICKING OVERLAY
    ===================================================== */

    document.querySelectorAll(
        ".seller-modal .modal-overlay"
    ).forEach(overlay => {

        overlay.addEventListener(
            "click",
            () => {

                const modal =
                    overlay.parentElement;

                closeModal(modal);

            }
        );

    });


    /* =====================================================
       ESCAPE KEY
    ===================================================== */

    document.addEventListener(
        "keydown",
        event => {

            if (event.key !== "Escape")
                return;


            closeModal(reviewModal);

            closeModal(addSellerModal);

            closeModal(rejectModal);

            sellerMenu?.classList.remove(
                "show"
            );

        }
    );


    /* =====================================================
       ADD SELLER
    ===================================================== */

    addSellerBtn?.addEventListener(
        "click",
        () => {

            addSellerModal?.classList.add(
                "show"
            );

        }
    );


    addSellerForm?.addEventListener(
        "submit",
        event => {

            event.preventDefault();


            const name =
                document.getElementById(
                    "sellerFullName"
                ).value.trim();


            const store =
                document.getElementById(
                    "sellerStoreName"
                ).value.trim();


            const email =
                document.getElementById(
                    "sellerEmail"
                ).value.trim();


            const phone =
                document.getElementById(
                    "sellerPhone"
                ).value.trim();


            const category =
                document.getElementById(
                    "newSellerCategory"
                ).value;


            const status =
                document.getElementById(
                    "newSellerStatus"
                ).value;


            const address =
                document.getElementById(
                    "sellerAddress"
                ).value.trim();


            if (!name || !store || !email || !category) {

                showToast(
                    "Please complete the required fields.",
                    "error"
                );

                return;

            }


            const newSeller = {

                id:
                    Date.now(),

                name,

                email,

                phone,

                store,

                category,

                products: 0,

                sales: 0,

                rating: 0,

                status,

                joined:
                    new Date()
                        .toLocaleDateString(
                            "en-GB",
                            {
                                day: "2-digit",
                                month: "short",
                                year: "numeric"
                            }
                        ),

                address

            };


            sellers.push(
                newSeller
            );


            saveSellers();

            updateStats();

            renderSellers();


            addSellerForm.reset();

            closeModal(
                addSellerModal
            );


            showToast(
                `${store} has been added to FASH.`,
                "success"
            );

        }
    );


    /* =====================================================
       REVIEW APPROVE
    ===================================================== */

    document
        .getElementById(
            "reviewApproveSeller"
        )
        ?.addEventListener(
            "click",
            () => {

                if (
                    selectedSellerId === null
                ) return;


                approveSeller(
                    selectedSellerId
                );


                closeModal(
                    reviewModal
                );

            }
        );


    /* =====================================================
       REVIEW REJECT
    ===================================================== */

    document
        .getElementById(
            "reviewRejectSeller"
        )
        ?.addEventListener(
            "click",
            () => {

                if (
                    selectedSellerId === null
                ) return;


                closeModal(
                    reviewModal
                );


                openRejectModal(
                    selectedSellerId
                );

            }
        );


    /* =====================================================
       OPEN REJECT MODAL
    ===================================================== */

    function openRejectModal(id) {

        selectedSellerId = id;

        rejectModal?.classList.add(
            "show"
        );

    }


    /* =====================================================
       REJECT SELLER
    ===================================================== */

    document
        .getElementById(
            "rejectSellerForm"
        )
        ?.addEventListener(
            "submit",
            event => {

                event.preventDefault();


                const seller =
                    sellers.find(
                        item =>
                            item.id ===
                            selectedSellerId
                    );


                if (!seller) return;


                seller.status =
                    "rejected";


                saveSellers();

                updateStats();

                renderSellers();

                closeModal(
                    rejectModal
                );


                showToast(
                    `${seller.store} application was rejected.`,
                    "error"
                );

            }
        );


    /* =====================================================
       EDIT SELLER
    ===================================================== */

    function editSeller(seller) {

        const newStore =
            prompt(
                "Store name:",
                seller.store
            );


        if (
            newStore === null ||
            !newStore.trim()
        ) return;


        seller.store =
            newStore.trim();


        saveSellers();

        renderSellers();

        updateStats();


        showToast(
            "Seller information updated.",
            "success"
        );

    }


    /* =====================================================
       EXPORT SELLERS
    ===================================================== */

    document
        .getElementById(
            "exportSellersBtn"
        )
        ?.addEventListener(
            "click",
            () => {

                if (sellers.length === 0) {

                    showToast(
                        "There are no sellers to export.",
                        "warning"
                    );

                    return;

                }


                const headers = [
                    "Name",
                    "Email",
                    "Store",
                    "Category",
                    "Products",
                    "Sales",
                    "Rating",
                    "Status",
                    "Joined"
                ];


                const rows =
                    sellers.map(seller => [

                        seller.name,

                        seller.email,

                        seller.store,

                        formatCategory(
                            seller.category
                        ),

                        seller.products,

                        seller.sales,

                        seller.rating,

                        seller.status,

                        seller.joined

                    ]);


                const csv = [
                    headers,
                    ...rows
                ]
                    .map(row =>
                        row
                            .map(value =>
                                `"${String(value)
                                    .replace(/"/g, '""')}"`
                            )
                            .join(",")
                    )
                    .join("\n");


                const blob =
                    new Blob(
                        [csv],
                        {
                            type:
                                "text/csv;charset=utf-8;"
                        }
                    );


                const url =
                    URL.createObjectURL(
                        blob
                    );


                const link =
                    document.createElement(
                        "a"
                    );

                link.href = url;

                link.download =
                    "fash-sellers.csv";

                link.click();


                URL.revokeObjectURL(
                    url
                );


                showToast(
                    "Seller data exported.",
                    "success"
                );

            }
        );


    /* =====================================================
       MOBILE SIDEBAR
    ===================================================== */

    const mobileMenuBtn =
        document.getElementById(
            "mobileMenuBtn"
        );

    const sidebar =
        document.querySelector(
            ".sidebar"
        );


    mobileMenuBtn?.addEventListener(
        "click",
        () => {

            sidebar?.classList.toggle(
                "open"
            );

        }
    );


    /* =====================================================
       LOGOUT
    ===================================================== */

    document
        .getElementById(
            "logoutBtn"
        )
        ?.addEventListener(
            "click",
            event => {

                const confirmed =
                    confirm(
                        "Are you sure you want to logout?"
                    );


                if (!confirmed) {

                    event.preventDefault();

                }

            }
        );


    /* =====================================================
       NOTIFICATION
    ===================================================== */

    document
        .getElementById(
            "notificationBtn"
        )
        ?.addEventListener(
            "click",
            () => {

                showToast(
                    "You have new seller notifications.",
                    "info"
                );

            }
        );


    /* =====================================================
       TOAST NOTIFICATION
    ===================================================== */

    function showToast(
        message,
        type = "info"
    ) {

        const existing =
            document.querySelector(
                ".fash-toast"
            );


        if (existing) {
            existing.remove();
        }


        const toast =
            document.createElement(
                "div"
            );


        toast.className =
            `fash-toast ${type}`;


        const iconMap = {

            success:
                "fa-circle-check",

            error:
                "fa-circle-xmark",

            warning:
                "fa-triangle-exclamation",

            info:
                "fa-circle-info"

        };


        toast.innerHTML = `

            <i
                class="fa-solid ${iconMap[type] || iconMap.info}"
            ></i>

            <span>
                ${escapeHTML(message)}
            </span>

        `;


        Object.assign(
            toast.style,
            {

                position: "fixed",

                right: "25px",

                bottom: "25px",

                zIndex: "9999",

                display: "flex",

                alignItems: "center",

                gap: "10px",

                padding: "13px 17px",

                background: "#101828",

                color: "#ffffff",

                borderRadius: "10px",

                boxShadow:
                    "0 15px 35px rgba(16,24,40,.2)",

                fontSize: "11px",

                fontWeight: "650",

                maxWidth: "350px",

                animation:
                    "fashToastIn .25s ease"

            }
        );


        document.body.appendChild(
            toast
        );


        setTimeout(
            () => {

                toast.style.opacity =
                    "0";

                toast.style.transform =
                    "translateY(10px)";

                toast.style.transition =
                    "all .25s ease";


                setTimeout(
                    () => toast.remove(),
                    250
                );

            },
            3200
        );

    }


    /* =====================================================
       TOAST ANIMATION
    ===================================================== */

    if (
        !document.getElementById(
            "fashToastStyles"
        )
    ) {

        const style =
            document.createElement(
                "style"
            );


        style.id =
            "fashToastStyles";


        style.textContent = `

            @keyframes fashToastIn {

                from {

                    opacity: 0;

                    transform:
                        translateY(10px);

                }

                to {

                    opacity: 1;

                    transform:
                        translateY(0);

                }

            }

        `;


        document.head.appendChild(
            style
        );

    }


    /* =====================================================
       INITIAL LOAD
    ===================================================== */

    saveSellers();

    updateStats();

    renderSellers();
    
    tableBody?.addEventListener("click", async (event) => {
        const btn = event.target.closest(".verify-seller-btn");
        if (!btn) return;
        try {
            await FASH_API.api(`/api/admin/sellers/${encodeURIComponent(btn.dataset.verifyId)}/verification`, {
                method: "PATCH",
                body: JSON.stringify({status:"verified"})
            });
            loadDatabaseSellers();
        } catch (e) { alert(e.message || "Could not verify seller"); }
    });

loadDatabaseSellers();

});
