/* =========================================================
   FASH ADMIN — CUSTOMERS
   customers.js
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    /* =====================================================
       ELEMENTS
    ====================================================== */

    const tableBody =
        document.getElementById("customersTableBody");

    const emptyState =
        document.getElementById("customersEmpty");

    const searchInput =
        document.getElementById("customerSearch");

    const sortSelect =
        document.getElementById("customerSort");

    const refreshBtn =
        document.getElementById("refreshCustomersBtn");

    const exportBtn =
        document.getElementById("exportCustomersBtn");

    const actionMenu =
        document.getElementById("customerActionMenu");

    const modal =
        document.getElementById("customerViewModal");

    const closeModalBtn =
        document.getElementById("closeCustomerModal");

    const modalOverlay =
        modal?.querySelector(".modal-overlay");

    const mobileMenuBtn =
        document.getElementById("mobileMenuBtn");

    const sidebar =
        document.querySelector(".sidebar");


    /* =====================================================
       STATE
    ====================================================== */

    let customers = [];

    let filteredCustomers = [];

    let activeStatus = "all";

    let selectedCustomerId = null;

    let currentPage = 1;

    const customersPerPage = 8;


    /* =====================================================
       DEMO CUSTOMERS
       Used only when no customer data exists yet.
    ====================================================== */

    const demoCustomers = [
        {
            id: "CUS-1001",
            firstName: "David",
            lastName: "Johnson",
            email: "david.johnson@example.com",
            phone: "+234 801 234 5678",
            orders: 12,
            totalSpent: 450000,
            joined: "2026-07-15",
            status: "active"
        },

        {
            id: "CUS-1002",
            firstName: "Sarah",
            lastName: "Williams",
            email: "sarah.williams@example.com",
            phone: "+234 802 345 6789",
            orders: 8,
            totalSpent: 275000,
            joined: "2026-07-20",
            status: "active"
        },

        {
            id: "CUS-1003",
            firstName: "Michael",
            lastName: "Brown",
            email: "michael.brown@example.com",
            phone: "+234 803 456 7890",
            orders: 3,
            totalSpent: 98000,
            joined: "2026-07-29",
            status: "new"
        },

        {
            id: "CUS-1004",
            firstName: "Grace",
            lastName: "Okafor",
            email: "grace.okafor@example.com",
            phone: "+234 804 567 8901",
            orders: 17,
            totalSpent: 720000,
            joined: "2026-06-11",
            status: "active"
        },

        {
            id: "CUS-1005",
            firstName: "Daniel",
            lastName: "Adeyemi",
            email: "daniel.adeyemi@example.com",
            phone: "+234 805 678 9012",
            orders: 5,
            totalSpent: 165000,
            joined: "2026-07-27",
            status: "new"
        },

        {
            id: "CUS-1006",
            firstName: "Emily",
            lastName: "Smith",
            email: "emily.smith@example.com",
            phone: "+234 806 789 0123",
            orders: 21,
            totalSpent: 915000,
            joined: "2026-05-18",
            status: "active"
        },

        {
            id: "CUS-1007",
            firstName: "Ibrahim",
            lastName: "Musa",
            email: "ibrahim.musa@example.com",
            phone: "+234 807 890 1234",
            orders: 2,
            totalSpent: 57000,
            joined: "2026-08-02",
            status: "new"
        },

        {
            id: "CUS-1008",
            firstName: "Olivia",
            lastName: "Taylor",
            email: "olivia.taylor@example.com",
            phone: "+234 808 901 2345",
            orders: 14,
            totalSpent: 560000,
            joined: "2026-06-28",
            status: "active"
        },

        {
            id: "CUS-1009",
            firstName: "Samuel",
            lastName: "Peter",
            email: "samuel.peter@example.com",
            phone: "+234 809 012 3456",
            orders: 0,
            totalSpent: 0,
            joined: "2026-08-05",
            status: "new"
        },

        {
            id: "CUS-1010",
            firstName: "Aisha",
            lastName: "Bello",
            email: "aisha.bello@example.com",
            phone: "+234 810 123 4567",
            orders: 10,
            totalSpent: 340000,
            joined: "2026-06-03",
            status: "active"
        },

        {
            id: "CUS-1011",
            firstName: "Chris",
            lastName: "Wilson",
            email: "chris.wilson@example.com",
            phone: "+234 811 234 5678",
            orders: 7,
            totalSpent: 230000,
            joined: "2026-07-01",
            status: "suspended"
        }
    ];


    /* =====================================================
       STORAGE
    ====================================================== */

    function loadCustomers() {

        const storedCustomers =
            localStorage.getItem("fashCustomers");

        if (storedCustomers) {

            try {

                customers =
                    JSON.parse(storedCustomers);

                if (!Array.isArray(customers)) {
                    customers = [];
                }

            } catch (error) {

                console.error(
                    "FASH: Could not read customers:",
                    error
                );

                customers = [];
            }
        }

        /*
         * If the customer system has not been connected yet,
         * use demo data so the admin page isn't empty.
         */

        if (customers.length === 0) {
            customers = [...demoCustomers];
        }

        // Keep Admin Customers connected to the real registration system.
        try {
            const users = JSON.parse(
                localStorage.getItem("fashUsers") || "[]"
            );

            if (Array.isArray(users)) {
                const existingEmails = new Set(
                    customers.map(customer => String(customer.email || "").toLowerCase())
                );

                users
                    .filter(user => (user.role || "customer") === "customer")
                    .forEach(user => {
                        const email = String(user.email || "").toLowerCase();
                        if (!email || existingEmails.has(email)) return;

                        const parts = String(user.fullName || user.name || "FASH Customer").trim().split(/\s+/);
                        customers.push({
                            id: user.id || `CUS-${Date.now()}`,
                            firstName: parts.shift() || "FASH",
                            lastName: parts.join(" "),
                            email: user.email || "",
                            phone: user.phone || "",
                            orders: Number(user.orders) || 0,
                            totalSpent: Number(user.totalSpent) || 0,
                            joined: user.createdAt || new Date().toISOString(),
                            status: user.status === "blocked" ? "blocked" : "active"
                        });
                    });
            }
        } catch (error) {
            console.warn("FASH: Could not synchronize registered customers.", error);
        }

        saveCustomers();
    }


    function saveCustomers() {

        localStorage.setItem(
            "fashCustomers",
            JSON.stringify(customers)
        );
    }


    /* =====================================================
       FORMATTERS
    ====================================================== */

    function formatCurrency(value) {

        const amount =
            Number(value) || 0;

        return new Intl.NumberFormat(
            "en-NG",
            {
                style: "currency",
                currency: "NGN",
                maximumFractionDigits: 0
            }
        ).format(amount);
    }


    function formatDate(dateValue) {

        if (!dateValue) {
            return "—";
        }

        const date =
            new Date(dateValue);

        if (Number.isNaN(date.getTime())) {
            return dateValue;
        }

        return date.toLocaleDateString(
            "en-GB",
            {
                day: "2-digit",
                month: "short",
                year: "numeric"
            }
        );
    }


    function getCustomerName(customer) {

        const fullName =
            `${customer.firstName || ""} ${customer.lastName || ""}`
                .trim();

        return fullName || customer.name || "Unnamed Customer";
    }


    function getInitials(customer) {

        const name =
            getCustomerName(customer);

        const parts =
            name.split(/\s+/).filter(Boolean);

        if (parts.length === 1) {
            return parts[0].slice(0, 2).toUpperCase();
        }

        return (
            parts[0][0] +
            parts[parts.length - 1][0]
        ).toUpperCase();
    }


    function escapeHTML(value) {

        return String(value ?? "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }


    /* =====================================================
       STATUS
    ====================================================== */

    function getStatusLabel(status) {

        switch (status) {

            case "active":
                return "Active";

            case "new":
                return "New";

            case "suspended":
                return "Suspended";

            default:
                return "Active";
        }
    }


    /* =====================================================
       STATISTICS
    ====================================================== */

    function updateStatistics() {

        const total =
            customers.length;

        const active =
            customers.filter(
                customer =>
                    customer.status === "active"
            ).length;

        const suspended =
            customers.filter(
                customer =>
                    customer.status === "suspended"
            ).length;

        const newCustomers =
            customers.filter(
                customer =>
                    customer.status === "new"
            ).length;


        setText(
            "totalCustomers",
            total
        );

        setText(
            "activeCustomers",
            active
        );

        setText(
            "newCustomers",
            newCustomers
        );

        setText(
            "suspendedCustomers",
            suspended
        );


        setText(
            "allCustomerCount",
            total
        );

        setText(
            "activeCustomerCount",
            active
        );

        setText(
            "newCustomerCount",
            newCustomers
        );

        setText(
            "suspendedCustomerCount",
            suspended
        );
    }


    function setText(id, value) {

        const element =
            document.getElementById(id);

        if (element) {
            element.textContent = value;
        }
    }


    /* =====================================================
       FILTER + SEARCH
    ====================================================== */

    function applyFilters() {

        const search =
            searchInput?.value
                .trim()
                .toLowerCase() || "";


        filteredCustomers =
            customers.filter(customer => {

                const name =
                    getCustomerName(customer)
                        .toLowerCase();

                const email =
                    String(
                        customer.email || ""
                    ).toLowerCase();

                const phone =
                    String(
                        customer.phone || ""
                    ).toLowerCase();


                const matchesSearch =
                    !search ||
                    name.includes(search) ||
                    email.includes(search) ||
                    phone.includes(search);


                const matchesStatus =
                    activeStatus === "all" ||
                    customer.status === activeStatus;


                return (
                    matchesSearch &&
                    matchesStatus
                );
            });


        sortCustomers();

        currentPage = 1;

        renderCustomers();
    }


    /* =====================================================
       SORT
    ====================================================== */

    function sortCustomers() {

        const sort =
            sortSelect?.value || "newest";


        filteredCustomers.sort(
            (a, b) => {

                switch (sort) {

                    case "oldest":

                        return (
                            new Date(a.joined || 0) -
                            new Date(b.joined || 0)
                        );


                    case "orders-high":

                        return (
                            Number(b.orders || 0) -
                            Number(a.orders || 0)
                        );


                    case "spent-high":

                        return (
                            Number(b.totalSpent || 0) -
                            Number(a.totalSpent || 0)
                        );


                    case "newest":
                    default:

                        return (
                            new Date(b.joined || 0) -
                            new Date(a.joined || 0)
                        );
                }
            }
        );
    }


    /* =====================================================
       RENDER CUSTOMERS
    ====================================================== */

    function renderCustomers() {

        if (!tableBody) {
            return;
        }


        tableBody.innerHTML = "";


        const total =
            filteredCustomers.length;


        if (total === 0) {

            if (emptyState) {
                emptyState.hidden = false;
            }

            updatePagination(0);

            return;
        }


        if (emptyState) {
            emptyState.hidden = true;
        }


        const start =
            (currentPage - 1) *
            customersPerPage;


        const end =
            start + customersPerPage;


        const pageCustomers =
            filteredCustomers.slice(
                start,
                end
            );


        pageCustomers.forEach(
            customer => {

                const row =
                    document.createElement("tr");

                row.dataset.customerId =
                    customer.id;


                row.innerHTML = `

                    <td>

                        <div class="customer-info">

                            <div class="customer-avatar">
                                ${escapeHTML(
                                    getInitials(customer)
                                )}
                            </div>

                            <div>

                                <strong>
                                    ${escapeHTML(
                                        getCustomerName(customer)
                                    )}
                                </strong>

                                <span>
                                    ${escapeHTML(
                                        customer.id || "—"
                                    )}
                                </span>

                            </div>

                        </div>

                    </td>


                    <td>

                        <div class="customer-contact">

                            ${escapeHTML(
                                customer.email || "—"
                            )}

                        </div>

                    </td>


                    <td>

                        <div class="customer-contact">

                            ${escapeHTML(
                                customer.phone || "—"
                            )}

                        </div>

                    </td>


                    <td>

                        <span class="customer-orders">

                            ${Number(
                                customer.orders || 0
                            )}

                        </span>

                    </td>


                    <td>

                        <span class="customer-spending">

                            ${formatCurrency(
                                customer.totalSpent
                            )}

                        </span>

                    </td>


                    <td>

                        ${formatDate(
                            customer.joined
                        )}

                    </td>


                    <td>

                        <span
                            class="customer-status ${escapeHTML(
                                customer.status || "active"
                            )}"
                        >

                            ${escapeHTML(
                                getStatusLabel(
                                    customer.status
                                )
                            )}

                        </span>

                    </td>


                    <td>

                        <button
                            type="button"
                            class="customer-more-btn"
                            data-customer-id="${escapeHTML(
                                customer.id
                            )}"
                            aria-label="Customer actions"
                        >

                            <i class="fa-solid fa-ellipsis-vertical"></i>

                        </button>

                    </td>

                `;


                tableBody.appendChild(row);
            }
        );


        updatePagination(total);
    }


    /* =====================================================
       PAGINATION
    ====================================================== */

    function updatePagination(total) {

        const totalPages =
            Math.max(
                1,
                Math.ceil(
                    total / customersPerPage
                )
            );


        if (currentPage > totalPages) {
            currentPage = totalPages;
        }


        const start =
            total === 0
                ? 0
                : (currentPage - 1) *
                    customersPerPage +
                    1;


        const end =
            Math.min(
                currentPage *
                    customersPerPage,
                total
            );


        const text =
            total === 0
                ? "Showing 0 customers"
                : `Showing ${start}-${end} of ${total} customers`;


        setText(
            "customerPaginationText",
            text
        );


        const previous =
            document.getElementById(
                "previousCustomerPage"
            );

        const next =
            document.getElementById(
                "nextCustomerPage"
            );

        const current =
            document.getElementById(
                "currentCustomerPage"
            );


        if (previous) {
            previous.disabled =
                currentPage <= 1;
        }

        if (next) {
            next.disabled =
                currentPage >= totalPages;
        }

        if (current) {
            current.textContent =
                currentPage;
        }
    }


    /* =====================================================
       THREE-DOT MENU
    ====================================================== */

    function openActionMenu(button) {

        closeActionMenu();


        const customerId =
            button.dataset.customerId;

        selectedCustomerId =
            customerId;


        const rect =
            button.getBoundingClientRect();


        actionMenu.style.display =
            "block";


        let left =
            rect.right -
            actionMenu.offsetWidth;


        let top =
            rect.bottom + 6;


        /*
         * Prevent menu from leaving
         * the right side of the screen.
         */

        if (
            left +
            actionMenu.offsetWidth >
            window.innerWidth - 10
        ) {

            left =
                window.innerWidth -
                actionMenu.offsetWidth -
                10;
        }


        /*
         * If there isn't enough space
         * underneath, open upward.
         */

        if (
            top +
            actionMenu.offsetHeight >
            window.innerHeight - 10
        ) {

            top =
                rect.top -
                actionMenu.offsetHeight -
                6;
        }


        actionMenu.style.left =
            `${Math.max(10, left)}px`;

        actionMenu.style.top =
            `${Math.max(10, top)}px`;


        actionMenu.classList.add("show");

        button.classList.add("open");
    }


    function closeActionMenu() {

        if (!actionMenu) {
            return;
        }

        actionMenu.classList.remove("show");

        actionMenu.style.display = "none";

        document
            .querySelectorAll(
                ".customer-more-btn.open"
            )
            .forEach(button => {
                button.classList.remove("open");
            });
    }


    /* =====================================================
       FIND CUSTOMER
    ====================================================== */

    function getSelectedCustomer() {

        return customers.find(
            customer =>
                String(customer.id) ===
                String(selectedCustomerId)
        );
    }


    /* =====================================================
       VIEW CUSTOMER
    ====================================================== */

    function viewCustomer(customer) {

        if (!customer || !modal) {
            return;
        }


        setText(
            "modalCustomerName",
            getCustomerName(customer)
        );

        setText(
            "modalCustomerStatus",
            getStatusLabel(
                customer.status
            )
        );

        setText(
            "modalCustomerEmail",
            customer.email || "—"
        );

        setText(
            "modalCustomerPhone",
            customer.phone || "—"
        );

        setText(
            "modalCustomerOrders",
            customer.orders || 0
        );

        setText(
            "modalCustomerSpent",
            formatCurrency(
                customer.totalSpent
            )
        );

        setText(
            "modalCustomerJoined",
            formatDate(
                customer.joined
            )
        );

        setText(
            "modalCustomerId",
            customer.id || "—"
        );


        const avatar =
            document.getElementById(
                "customerLargeAvatar"
            );

        if (avatar) {
            avatar.textContent =
                getInitials(customer);
        }


        modal.classList.add("show");

        document.body.style.overflow =
            "hidden";
    }


    function closeCustomerModal() {

        if (!modal) {
            return;
        }

        modal.classList.remove("show");

        document.body.style.overflow = "";
    }


    /* =====================================================
       SUSPEND CUSTOMER
    ====================================================== */

    function suspendCustomer(customer) {

        if (!customer) {
            return;
        }


        if (
            customer.status ===
            "suspended"
        ) {

            customer.status =
                "active";

            showToast(
                "Customer account restored.",
                "success"
            );

        } else {

            const confirmed =
                window.confirm(
                    `Suspend ${getCustomerName(customer)}?`
                );

            if (!confirmed) {
                return;
            }

            customer.status =
                "suspended";

            showToast(
                "Customer suspended.",
                "warning"
            );
        }


        saveCustomers();

        updateStatistics();

        applyFilters();

        closeCustomerModal();
    }


    /* =====================================================
       DELETE CUSTOMER
    ====================================================== */

    function deleteCustomer(customer) {

        if (!customer) {
            return;
        }


        const confirmed =
            window.confirm(
                `Delete ${getCustomerName(customer)} from FASH customers? This cannot be undone.`
            );


        if (!confirmed) {
            return;
        }


        customers =
            customers.filter(
                item =>
                    String(item.id) !==
                    String(customer.id)
            );


        saveCustomers();

        updateStatistics();

        applyFilters();

        showToast(
            "Customer deleted.",
            "error"
        );
    }


    /* =====================================================
       EDIT CUSTOMER
    ====================================================== */

    function editCustomer(customer) {

        if (!customer) {
            return;
        }


        const name =
            window.prompt(
                "Customer name:",
                getCustomerName(customer)
            );


        if (
            name === null ||
            !name.trim()
        ) {
            return;
        }


        const parts =
            name.trim()
                .split(/\s+/);


        customer.firstName =
            parts.shift() || "";

        customer.lastName =
            parts.join(" ");


        saveCustomers();

        updateStatistics();

        applyFilters();

        showToast(
            "Customer updated.",
            "success"
        );
    }


    /* =====================================================
       VIEW ORDERS
    ====================================================== */

    function viewOrders(customer) {

        if (!customer) {
            return;
        }


        /*
         * For now we pass the customer ID
         * to the orders page.
         */

        window.location.href =
            `orders.html?customer=${encodeURIComponent(
                customer.id
            )}`;
    }


    /* =====================================================
       ACTION MENU EVENTS
    ====================================================== */

    if (tableBody) {

        tableBody.addEventListener(
            "click",
            event => {

                const button =
                    event.target.closest(
                        ".customer-more-btn"
                    );


                if (!button) {
                    return;
                }


                event.stopPropagation();


                if (
                    actionMenu.classList.contains(
                        "show"
                    ) &&
                    selectedCustomerId ===
                    button.dataset.customerId
                ) {

                    closeActionMenu();

                    return;
                }


                openActionMenu(button);
            }
        );
    }


    if (actionMenu) {

        actionMenu.addEventListener(
            "click",
            event => {

                const actionButton =
                    event.target.closest(
                        "button[data-action]"
                    );


                if (!actionButton) {
                    return;
                }


                const action =
                    actionButton.dataset.action;


                const customer =
                    getSelectedCustomer();


                closeActionMenu();


                if (!customer) {
                    return;
                }


                switch (action) {

                    case "view":

                        viewCustomer(
                            customer
                        );

                        break;


                    case "edit":

                        editCustomer(
                            customer
                        );

                        break;


                    case "orders":

                        viewOrders(
                            customer
                        );

                        break;


                    case "suspend":

                        suspendCustomer(
                            customer
                        );

                        break;


                    case "delete":

                        deleteCustomer(
                            customer
                        );

                        break;
                }
            }
        );
    }


    /* =====================================================
       SEARCH
    ====================================================== */

    if (searchInput) {

        searchInput.addEventListener(
            "input",
            applyFilters
        );
    }


    /* =====================================================
       SORT
    ====================================================== */

    if (sortSelect) {

        sortSelect.addEventListener(
            "change",
            applyFilters
        );
    }


    /* =====================================================
       STATUS TABS
    ====================================================== */

    document
        .querySelectorAll(
            ".customer-tab"
        )
        .forEach(tab => {

            tab.addEventListener(
                "click",
                () => {

                    document
                        .querySelectorAll(
                            ".customer-tab"
                        )
                        .forEach(item => {
                            item.classList.remove(
                                "active"
                            );
                        });


                    tab.classList.add(
                        "active"
                    );


                    activeStatus =
                        tab.dataset.status ||
                        "all";


                    applyFilters();
                }
            );
        });


    /* =====================================================
       PAGINATION BUTTONS
    ====================================================== */

    const previousPage =
        document.getElementById(
            "previousCustomerPage"
        );

    const nextPage =
        document.getElementById(
            "nextCustomerPage"
        );


    if (previousPage) {

        previousPage.addEventListener(
            "click",
            () => {

                if (currentPage > 1) {

                    currentPage--;

                    renderCustomers();
                }
            }
        );
    }


    if (nextPage) {

        nextPage.addEventListener(
            "click",
            () => {

                const totalPages =
                    Math.ceil(
                        filteredCustomers.length /
                        customersPerPage
                    );


                if (
                    currentPage <
                    totalPages
                ) {

                    currentPage++;

                    renderCustomers();
                }
            }
        );
    }


    /* =====================================================
       MODAL EVENTS
    ====================================================== */

    if (closeModalBtn) {

        closeModalBtn.addEventListener(
            "click",
            closeCustomerModal
        );
    }


    if (modalOverlay) {

        modalOverlay.addEventListener(
            "click",
            closeCustomerModal
        );
    }


    const modalSuspendBtn =
        document.getElementById(
            "modalSuspendCustomerBtn"
        );


    if (modalSuspendBtn) {

        modalSuspendBtn.addEventListener(
            "click",
            () => {

                const customer =
                    getSelectedCustomer();

                suspendCustomer(
                    customer
                );
            }
        );
    }


    const modalOrdersBtn =
        document.getElementById(
            "viewCustomerOrdersBtn"
        );


    if (modalOrdersBtn) {

        modalOrdersBtn.addEventListener(
            "click",
            () => {

                const customer =
                    getSelectedCustomer();

                viewOrders(
                    customer
                );
            }
        );
    }


    /* =====================================================
       REFRESH
    ====================================================== */

    if (refreshBtn) {

        refreshBtn.addEventListener(
            "click",
            () => {

                loadCustomers();

                updateStatistics();

                applyFilters();

                showToast(
                    "Customer data refreshed.",
                    "success"
                );
            }
        );
    }


    /* =====================================================
       EXPORT CUSTOMERS
    ====================================================== */

    if (exportBtn) {

        exportBtn.addEventListener(
            "click",
            exportCustomers
        );
    }


    function exportCustomers() {

        if (!customers.length) {

            showToast(
                "There are no customers to export.",
                "warning"
            );

            return;
        }


        const headers = [
            "Customer ID",
            "Name",
            "Email",
            "Phone",
            "Orders",
            "Total Spent",
            "Joined",
            "Status"
        ];


        const rows =
            customers.map(customer => [

                customer.id,

                getCustomerName(
                    customer
                ),

                customer.email || "",

                customer.phone || "",

                customer.orders || 0,

                customer.totalSpent || 0,

                customer.joined || "",

                customer.status || ""

            ]);


        const csv = [
            headers,
            ...rows
        ]
            .map(row =>
                row
                    .map(value =>
                        `"${String(value)
                            .replace(/"/g, '""')}"`
                    )
                    .join(",")
            )
            .join("\n");


        const blob =
            new Blob(
                [csv],
                {
                    type:
                        "text/csv;charset=utf-8;"
                }
            );


        const url =
            URL.createObjectURL(blob);


        const link =
            document.createElement("a");


        link.href = url;

        link.download =
            "fash-customers.csv";


        document.body.appendChild(link);

        link.click();

        link.remove();

        URL.revokeObjectURL(url);


        showToast(
            "Customer list exported.",
            "success"
        );
    }


    /* =====================================================
       MOBILE SIDEBAR
    ====================================================== */

    if (mobileMenuBtn && sidebar) {

        mobileMenuBtn.addEventListener(
            "click",
            () => {

                sidebar.classList.toggle(
                    "open"
                );
            }
        );
    }


    /* =====================================================
       CLOSE MENU WHEN CLICKING OUTSIDE
    ====================================================== */

    document.addEventListener(
        "click",
        event => {

            if (
                !event.target.closest(
                    ".customer-action-menu"
                ) &&
                !event.target.closest(
                    ".customer-more-btn"
                )
            ) {

                closeActionMenu();
            }
        }
    );


    /* =====================================================
       ESCAPE KEY
    ====================================================== */

    document.addEventListener(
        "keydown",
        event => {

            if (event.key !== "Escape") {
                return;
            }

            closeActionMenu();

            closeCustomerModal();
        }
    );


    /* =====================================================
       RESIZE
    ====================================================== */

    window.addEventListener(
        "resize",
        () => {
            closeActionMenu();
        }
    );


    /* =====================================================
       TOAST
    ====================================================== */

    function showToast(
        message,
        type = "success"
    ) {

        const existing =
            document.querySelector(
                ".fash-toast"
            );

        if (existing) {
            existing.remove();
        }


        const toast =
            document.createElement("div");


        toast.className =
            `fash-toast ${type}`;


        const icon =
            type === "success"
                ? "fa-circle-check"
                : type === "error"
                    ? "fa-circle-xmark"
                    : "fa-triangle-exclamation";


        toast.innerHTML = `

            <i class="fa-solid ${icon}"></i>

            <span>
                ${escapeHTML(message)}
            </span>

        `;


        document.body.appendChild(toast);


        setTimeout(
            () => {

                toast.style.opacity = "0";

                toast.style.transform =
                    "translateY(10px)";

                toast.style.transition =
                    "0.2s ease";


                setTimeout(
                    () => toast.remove(),
                    200
                );

            },
            2800
        );
    }


    /* =====================================================
       LOGOUT
    ====================================================== */

    const logoutBtn =
        document.getElementById(
            "logoutBtn"
        );


    if (logoutBtn) {

        logoutBtn.addEventListener(
            "click",
            event => {

                event.preventDefault();


                const confirmed =
                    window.confirm(
                        "Are you sure you want to log out?"
                    );


                if (!confirmed) {
                    return;
                }


                /*
                 * Remove this line if your
                 * authentication system uses
                 * a different storage key.
                 */

                localStorage.removeItem(
                    "fashAdminLoggedIn"
                );


                window.location.href =
                    "admin.html";
            }
        );
    }


    /* =====================================================
       INITIALIZE
    ====================================================== */

    loadCustomers();

    updateStatistics();

    applyFilters();

});