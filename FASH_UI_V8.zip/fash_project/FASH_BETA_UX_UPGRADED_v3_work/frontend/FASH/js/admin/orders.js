/* =========================================================
   FASH ADMIN — ORDERS
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    const searchInput = document.getElementById("orderSearch");
    const statusFilter = document.getElementById("statusFilter");
    const dateFilter = document.getElementById("dateFilter");
    const selectAll = document.getElementById("selectAll");
    const tableBody = document.getElementById("ordersTableBody");

    const modal = document.getElementById("orderModal");
    const modalClose = document.getElementById("modalClose");
    const modalCloseBottom =
        document.getElementById("modalCloseBottom");

    const modalOrderId =
        document.getElementById("modalOrderId");

    const modalCustomer =
        document.getElementById("modalCustomer");

    const modalSeller =
        document.getElementById("modalSeller");

    const modalDate =
        document.getElementById("modalDate");

    const modalItems =
        document.getElementById("modalItems");

    const modalTotal =
        document.getElementById("modalTotal");

    const exportOrders =
        document.getElementById("exportOrders");

    const logoutBtn =
        document.getElementById("logoutBtn");


    /* =====================================================
       FILTER ORDERS
    ===================================================== */

    function filterOrders() {

        const search =
            searchInput
                ? searchInput.value.toLowerCase().trim()
                : "";

        const selectedStatus =
            statusFilter
                ? statusFilter.value
                : "all";

        const selectedDate =
            dateFilter
                ? dateFilter.value
                : "all";

        const rows =
            tableBody.querySelectorAll("tr");

        let visibleCount = 0;

        rows.forEach(row => {

            const rowText =
                row.textContent.toLowerCase();

            const rowStatus =
                row.dataset.status || "";

            const rowDate =
                row.dataset.date || "";

            const matchesSearch =
                rowText.includes(search);

            const matchesStatus =
                selectedStatus === "all" ||
                rowStatus === selectedStatus;

            const matchesDate =
                selectedDate === "all" ||
                rowDate === selectedDate;

            const visible =
                matchesSearch &&
                matchesStatus &&
                matchesDate;

            row.style.display =
                visible ? "" : "none";

            if (visible) {
                visibleCount++;
            }

        });

        updateEmptyState(visibleCount);
        updateSelectAll();

    }


    /* =====================================================
       EMPTY SEARCH RESULT
    ===================================================== */

    function updateEmptyState(count) {

        const existing =
            document.getElementById(
                "ordersEmptyState"
            );

        if (count > 0) {

            if (existing) {
                existing.remove();
            }

            return;
        }

        if (existing) return;

        const row =
            document.createElement("tr");

        row.id =
            "ordersEmptyState";

        row.innerHTML = `
            <td colspan="9">
                <div class="orders-empty">
                    <i class="fa-solid fa-box-open"></i>
                    <strong>No orders found</strong>
                    <span>
                        Try changing your search or filters.
                    </span>
                </div>
            </td>
        `;

        tableBody.appendChild(row);

    }


    if (searchInput) {

        searchInput.addEventListener(
            "input",
            filterOrders
        );

    }


    if (statusFilter) {

        statusFilter.addEventListener(
            "change",
            filterOrders
        );

    }


    if (dateFilter) {

        dateFilter.addEventListener(
            "change",
            filterOrders
        );

    }


    /* =====================================================
       SELECT ALL
    ===================================================== */

    if (selectAll) {

        selectAll.addEventListener(
            "change",
            () => {

                const checkboxes =
                    tableBody.querySelectorAll(
                        'tr:not([style*="display: none"]) input[type="checkbox"]'
                    );

                checkboxes.forEach(
                    checkbox => {
                        checkbox.checked =
                            selectAll.checked;
                    }
                );

            }
        );

    }


    function updateSelectAll() {

        if (!selectAll) return;

        const checkboxes =
            tableBody.querySelectorAll(
                'tr:not([style*="display: none"]) input[type="checkbox"]'
            );

        if (!checkboxes.length) {

            selectAll.checked = false;
            selectAll.indeterminate = false;

            return;
        }

        const checked =
            [...checkboxes]
                .filter(
                    checkbox =>
                        checkbox.checked
                );

        selectAll.checked =
            checked.length === checkboxes.length;

        selectAll.indeterminate =
            checked.length > 0 &&
            checked.length < checkboxes.length;

    }


    tableBody.addEventListener(
        "change",
        event => {

            if (
                event.target.matches(
                    'input[type="checkbox"]'
                )
            ) {

                updateSelectAll();

            }

        }
    );


    /* =====================================================
       ORDER DATA
    ===================================================== */

    const orders = {

        "#FS10284": {
            customer: "David A.",
            seller: "Urban Style",
            date: "11 Aug 2026",
            items: "3",
            total: "₦84,500"
        },

        "#FS10283": {
            customer: "Sarah O.",
            seller: "Tech World",
            date: "11 Aug 2026",
            items: "2",
            total: "₦126,000"
        },

        "#FS10282": {
            customer: "Michael K.",
            seller: "FASH Fashion",
            date: "10 Aug 2026",
            items: "4",
            total: "₦43,200"
        },

        "#FS10281": {
            customer: "Grace T.",
            seller: "Home Hub",
            date: "10 Aug 2026",
            items: "1",
            total: "₦71,900"
        },

        "#FS10280": {
            customer: "Daniel M.",
            seller: "Smart Store",
            date: "09 Aug 2026",
            items: "5",
            total: "₦159,800"
        },

        "#FS10279": {
            customer: "James O.",
            seller: "Urban Style",
            date: "08 Aug 2026",
            items: "2",
            total: "₦62,400"
        }

    };


    /* =====================================================
       OPEN ORDER MODAL
    ===================================================== */

    tableBody.addEventListener(
        "click",
        event => {

            const button =
                event.target.closest(
                    ".view-btn"
                );

            if (!button) return;

            const orderId =
                button.dataset.order;

            openOrder(orderId);

        }
    );


    function openOrder(orderId) {

        const order =
            orders[orderId];

        if (!order) return;

        modalOrderId.textContent =
            orderId;

        modalCustomer.textContent =
            order.customer;

        modalSeller.textContent =
            order.seller;

        modalDate.textContent =
            order.date;

        modalItems.textContent =
            order.items;

        modalTotal.textContent =
            order.total;

        modal.classList.add("show");

        document.body.style.overflow =
            "hidden";

    }


    /* =====================================================
       CLOSE MODAL
    ===================================================== */

    function closeModal() {

        modal.classList.remove("show");

        document.body.style.overflow =
            "";

    }


    if (modalClose) {

        modalClose.addEventListener(
            "click",
            closeModal
        );

    }


    if (modalCloseBottom) {

        modalCloseBottom.addEventListener(
            "click",
            closeModal
        );

    }


    const modalOverlay =
        document.querySelector(
            ".modal-overlay"
        );

    if (modalOverlay) {

        modalOverlay.addEventListener(
            "click",
            closeModal
        );

    }


    document.addEventListener(
        "keydown",
        event => {

            if (
                event.key === "Escape" &&
                modal.classList.contains("show")
            ) {

                closeModal();

            }

        }
    );


    /* =====================================================
       EXPORT ORDERS
    ===================================================== */

    if (exportOrders) {

        exportOrders.addEventListener(
            "click",
            exportOrderData
        );

    }


    function exportOrderData() {

        const rows =
            tableBody.querySelectorAll(
                "tr[data-status]"
            );

        const csv = [];

        csv.push([
            "Order ID",
            "Customer",
            "Seller",
            "Date",
            "Items",
            "Total",
            "Status"
        ].join(","));


        rows.forEach(row => {

            if (
                row.style.display === "none"
            ) {
                return;
            }

            const cells =
                row.querySelectorAll("td");

            const orderId =
                cells[1]?.innerText.trim();

            const customer =
                cells[2]?.innerText.trim();

            const seller =
                cells[3]?.innerText.trim();

            const date =
                cells[4]?.innerText.trim();

            const items =
                cells[5]?.innerText.trim();

            const total =
                cells[6]?.innerText.trim();

            const status =
                cells[7]?.innerText.trim();

            csv.push([
                orderId,
                customer,
                seller,
                date,
                items,
                total,
                status
            ].map(value => {

                return `"${value.replace(
                    /"/g,
                    '""'
                )}"`;

            }).join(","));

        });


        const blob =
            new Blob(
                [csv.join("\n")],
                {
                    type:
                        "text/csv;charset=utf-8;"
                }
            );


        const url =
            URL.createObjectURL(blob);

        const link =
            document.createElement("a");

        link.href = url;

        link.download =
            "FASH-orders.csv";

        document.body.appendChild(link);

        link.click();

        link.remove();

        URL.revokeObjectURL(url);

    }


    /* =====================================================
       LOGOUT
    ===================================================== */

    if (logoutBtn) {

        logoutBtn.addEventListener(
            "click",
            event => {

                event.preventDefault();

                const confirmed =
                    confirm(
                        "Are you sure you want to logout?"
                    );

                if (!confirmed) return;

                localStorage.removeItem(
                    "fashAdminLoggedIn"
                );

                window.location.href =
                    "../index.html";

            }
        );

    }


    /* =====================================================
       MOBILE SIDEBAR
    ===================================================== */

    createMobileMenu();


    function createMobileMenu() {

        const sidebar =
            document.querySelector(
                ".sidebar"
            );

        if (!sidebar) return;

        const button =
            document.createElement("button");

        button.className =
            "mobile-menu-btn";

        button.innerHTML =
            '<i class="fa-solid fa-bars"></i>';

        document.body.appendChild(button);


        button.addEventListener(
            "click",
            () => {

                sidebar.classList.toggle(
                    "mobile-open"
                );

            }
        );


        document.addEventListener(
            "click",
            event => {

                if (
                    window.innerWidth > 800
                ) {
                    return;
                }

                if (
                    !sidebar.contains(
                        event.target
                    ) &&
                    !button.contains(
                        event.target
                    )
                ) {

                    sidebar.classList.remove(
                        "mobile-open"
                    );

                }

            }
        );

    }


    /* =====================================================
       INITIAL FILTER
    ===================================================== */

    filterOrders();

});