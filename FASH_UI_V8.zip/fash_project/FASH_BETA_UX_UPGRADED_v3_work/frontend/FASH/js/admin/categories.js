/* =========================================================
   FASH ADMIN — CATEGORIES
   categories.js
========================================================= */

"use strict";


/* =========================================================
   STORAGE
========================================================= */

const CATEGORY_STORAGE_KEY = "fash_categories";

const PRODUCTS_STORAGE_KEYS = [
    "fash_products",
    "products",
    "fashProducts"
];


/* =========================================================
   DEFAULT CATEGORIES
========================================================= */

const DEFAULT_CATEGORIES = [
    {
        id: "CAT-001",
        name: "Electronics",
        description: "Phones, computers, gadgets and electronic accessories.",
        status: "active",
        createdAt: "2026-01-10T10:00:00"
    },

    {
        id: "CAT-002",
        name: "Fashion",
        description: "Clothing, shoes, bags, accessories and fashion products.",
        status: "active",
        createdAt: "2026-01-12T10:00:00"
    },

    {
        id: "CAT-003",
        name: "Home & Living",
        description: "Furniture, home accessories, kitchen and household products.",
        status: "active",
        createdAt: "2026-01-15T10:00:00"
    },

    {
        id: "CAT-004",
        name: "Beauty",
        description: "Beauty, skincare, haircare and personal care products.",
        status: "active",
        createdAt: "2026-01-18T10:00:00"
    },

    {
        id: "CAT-005",
        name: "Sports",
        description: "Sports equipment, fitness products and sporting accessories.",
        status: "active",
        createdAt: "2026-01-20T10:00:00"
    }
];


/* =========================================================
   STATE
========================================================= */

let categories = [];

let filteredCategories = [];

let currentPage = 1;

const categoriesPerPage = 8;

let selectedCategoryId = null;

let actionMenuCategoryId = null;


/* =========================================================
   DOM
========================================================= */

const tableBody =
    document.getElementById("categoriesTableBody");

const emptyState =
    document.getElementById("categoriesEmpty");

const searchInput =
    document.getElementById("categorySearch");

const statusFilter =
    document.getElementById("categoryStatusFilter");

const sortSelect =
    document.getElementById("categorySort");

const addCategoryBtn =
    document.getElementById("addCategoryBtn");

const emptyAddCategoryBtn =
    document.getElementById("emptyAddCategoryBtn");

const refreshBtn =
    document.getElementById("refreshCategoriesBtn");

const modal =
    document.getElementById("categoryModal");

const viewModal =
    document.getElementById("viewCategoryModal");

const closeModalBtn =
    document.getElementById("closeCategoryModal");

const closeViewModalBtn =
    document.getElementById("closeViewCategoryModal");

const cancelCategoryBtn =
    document.getElementById("cancelCategoryBtn");

const categoryForm =
    document.getElementById("categoryForm");

const categoryIdInput =
    document.getElementById("categoryId");

const categoryNameInput =
    document.getElementById("categoryName");

const categoryDescriptionInput =
    document.getElementById("categoryDescription");

const categoryStatusInput =
    document.getElementById("categoryStatus");

const categoryModalTitle =
    document.getElementById("categoryModalTitle");

const categoryModalLabel =
    document.getElementById("categoryModalLabel");

const saveCategoryBtn =
    document.getElementById("saveCategoryBtn");

const actionMenu =
    document.getElementById("categoryActionMenu");

const closeViewCategoryBtn =
    document.getElementById("closeViewCategoryBtn");

const editViewedCategoryBtn =
    document.getElementById("editViewedCategoryBtn");

const previousPageBtn =
    document.getElementById("previousCategoryPage");

const nextPageBtn =
    document.getElementById("nextCategoryPage");

const currentPageBtn =
    document.getElementById("currentCategoryPage");

const paginationText =
    document.getElementById("categoryPaginationText");

const logoutBtn =
    document.getElementById("logoutBtn");


/* =========================================================
   STAT ELEMENTS
========================================================= */

const totalCategoriesEl =
    document.getElementById("totalCategories");

const activeCategoriesEl =
    document.getElementById("activeCategories");

const inactiveCategoriesEl =
    document.getElementById("inactiveCategories");

const assignedProductsEl =
    document.getElementById("assignedProducts");


/* =========================================================
   INITIALIZE
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    loadCategories();

    setupEvents();

    renderCategories();

});


/* =========================================================
   LOAD CATEGORIES
========================================================= */

function loadCategories() {

    try {

        const stored =
            localStorage.getItem(CATEGORY_STORAGE_KEY);

        if (stored) {

            const parsed =
                JSON.parse(stored);

            if (Array.isArray(parsed)) {

                categories = parsed;

                return;
            }
        }

    } catch (error) {

        console.error(
            "Could not load FASH categories:",
            error
        );
    }


    categories = [...DEFAULT_CATEGORIES];

    saveCategories();

}


/* =========================================================
   SAVE CATEGORIES
========================================================= */

function saveCategories() {

    localStorage.setItem(
        CATEGORY_STORAGE_KEY,
        JSON.stringify(categories)
    );

}


/* =========================================================
   EVENTS
========================================================= */

function setupEvents() {


    /* ADD */

    addCategoryBtn?.addEventListener(
        "click",
        () => openAddModal()
    );


    emptyAddCategoryBtn?.addEventListener(
        "click",
        () => openAddModal()
    );


    /* REFRESH */

    refreshBtn?.addEventListener(
        "click",
        () => {

            loadCategories();

            renderCategories();

            showToast(
                "Categories refreshed.",
                "success"
            );

        }
    );


    /* SEARCH */

    searchInput?.addEventListener(
        "input",
        () => {

            currentPage = 1;

            renderCategories();

        }
    );


    /* STATUS FILTER */

    statusFilter?.addEventListener(
        "change",
        () => {

            currentPage = 1;

            renderCategories();

        }
    );


    /* SORT */

    sortSelect?.addEventListener(
        "change",
        () => {

            currentPage = 1;

            renderCategories();

        }
    );


    /* FORM */

    categoryForm?.addEventListener(
        "submit",
        handleCategorySubmit
    );


    /* CLOSE MODAL */

    closeModalBtn?.addEventListener(
        "click",
        closeCategoryModal
    );

    cancelCategoryBtn?.addEventListener(
        "click",
        closeCategoryModal
    );


    /* CLOSE VIEW MODAL */

    closeViewModalBtn?.addEventListener(
        "click",
        closeViewModal
    );

    closeViewCategoryBtn?.addEventListener(
        "click",
        closeViewModal
    );


    /* EDIT FROM VIEW */

    editViewedCategoryBtn?.addEventListener(
        "click",
        () => {

            if (!selectedCategoryId) return;

            closeViewModal();

            openEditModal(selectedCategoryId);

        }
    );


    /* PAGINATION */

    previousPageBtn?.addEventListener(
        "click",
        () => {

            if (currentPage > 1) {

                currentPage--;

                renderCategories();

            }

        }
    );


    nextPageBtn?.addEventListener(
        "click",
        () => {

            const totalPages =
                Math.max(
                    1,
                    Math.ceil(
                        filteredCategories.length /
                        categoriesPerPage
                    )
                );

            if (currentPage < totalPages) {

                currentPage++;

                renderCategories();

            }

        }
    );


    /* ACTION MENU */

    actionMenu?.addEventListener(
        "click",
        handleActionMenu
    );


    /* CLOSE ACTION MENU */

    document.addEventListener(
        "click",
        event => {

            if (
                actionMenu &&
                !actionMenu.contains(event.target) &&
                !event.target.closest(".category-more-btn")
            ) {

                closeActionMenu();

            }

        }
    );


    /* ESCAPE */

    document.addEventListener(
        "keydown",
        event => {

            if (event.key !== "Escape") return;

            closeActionMenu();

            closeCategoryModal();

            closeViewModal();

        }
    );


    /* MODAL OVERLAYS */

    modal?.querySelector(
        ".modal-overlay"
    )?.addEventListener(
        "click",
        closeCategoryModal
    );


    viewModal?.querySelector(
        ".modal-overlay"
    )?.addEventListener(
        "click",
        closeViewModal
    );


    /* LOGOUT */

    logoutBtn?.addEventListener(
        "click",
        event => {

            event.preventDefault();

            const confirmed =
                confirm(
                    "Are you sure you want to logout?"
                );

            if (!confirmed) return;

            /*
             * Change this later when FASH
             * authentication is connected.
             */

            window.location.href =
                "../index.html";

        }
    );

}


/* =========================================================
   RENDER
========================================================= */

function renderCategories() {

    filteredCategories =
        getFilteredCategories();

    updateStatistics();

    renderTable();

    renderPagination();

}


/* =========================================================
   FILTER + SORT
========================================================= */

function getFilteredCategories() {

    let result = [...categories];


    /* SEARCH */

    const search =
        searchInput?.value
            ?.trim()
            .toLowerCase() || "";


    if (search) {

        result =
            result.filter(category => {

                return (
                    category.name
                        .toLowerCase()
                        .includes(search)
                    ||
                    category.description
                        .toLowerCase()
                        .includes(search)
                    ||
                    category.id
                        .toLowerCase()
                        .includes(search)
                );

            });

    }


    /* STATUS */

    const status =
        statusFilter?.value || "all";


    if (status !== "all") {

        result =
            result.filter(
                category =>
                    category.status === status
            );

    }


    /* SORT */

    const sort =
        sortSelect?.value || "name-asc";


    result.sort(
        (a, b) => {

            switch (sort) {

                case "name-desc":

                    return b.name.localeCompare(
                        a.name
                    );


                case "products-high":

                    return (
                        getProductCount(b) -
                        getProductCount(a)
                    );


                case "products-low":

                    return (
                        getProductCount(a) -
                        getProductCount(b)
                    );


                case "newest":

                    return (
                        new Date(b.createdAt) -
                        new Date(a.createdAt)
                    );


                case "oldest":

                    return (
                        new Date(a.createdAt) -
                        new Date(b.createdAt)
                    );


                case "name-asc":
                default:

                    return a.name.localeCompare(
                        b.name
                    );

            }

        }
    );


    return result;

}


/* =========================================================
   TABLE
========================================================= */

function renderTable() {

    if (!tableBody) return;


    tableBody.innerHTML = "";


    const total =
        filteredCategories.length;


    if (total === 0) {

        tableBody.innerHTML = "";

        if (emptyState) {

            emptyState.hidden = false;

        }

        return;

    }


    if (emptyState) {

        emptyState.hidden = true;

    }


    const start =
        (currentPage - 1) *
        categoriesPerPage;


    const end =
        start +
        categoriesPerPage;


    const pageItems =
        filteredCategories.slice(
            start,
            end
        );


    pageItems.forEach(
        category => {

            tableBody.appendChild(
                createCategoryRow(category)
            );

        }
    );

}


/* =========================================================
   CREATE TABLE ROW
========================================================= */

function createCategoryRow(category) {

    const row =
        document.createElement("tr");


    const productCount =
        getProductCount(category);


    const formattedDate =
        formatDate(category.createdAt);


    row.innerHTML = `

        <td>

            <div class="category-info">

                <div class="category-icon">

                    <i class="${getCategoryIcon(category.name)}"></i>

                </div>

                <div>

                    <strong>
                        ${escapeHTML(category.name)}
                    </strong>

                    <span>
                        ${escapeHTML(category.id)}
                    </span>

                </div>

            </div>

        </td>


        <td>

            <div class="category-description"
                 title="${escapeHTML(category.description)}">

                ${escapeHTML(
                    category.description ||
                    "No description"
                )}

            </div>

        </td>


        <td>

            <span class="category-product-count">

                ${productCount}

            </span>

        </td>


        <td>

            <span class="category-status ${category.status}">

                ${capitalize(category.status)}

            </span>

        </td>


        <td>

            ${formattedDate}

        </td>


        <td>

            <button
                type="button"
                class="category-more-btn"
                data-category-id="${escapeHTML(category.id)}"
                aria-label="Category actions"
            >

                <i class="fa-solid fa-ellipsis-vertical"></i>

            </button>

        </td>

    `;


    const moreBtn =
        row.querySelector(
            ".category-more-btn"
        );


    moreBtn?.addEventListener(
        "click",
        event => {

            event.stopPropagation();

            openActionMenu(
                category.id,
                moreBtn
            );

        }
    );


    return row;

}


/* =========================================================
   ACTION MENU
========================================================= */

function openActionMenu(
    categoryId,
    button
) {

    if (!actionMenu) return;


    actionMenuCategoryId =
        categoryId;


    actionMenu.classList.add("show");


    const rect =
        button.getBoundingClientRect();


    const menuWidth =
        actionMenu.offsetWidth;


    let left =
        rect.right -
        menuWidth;


    let top =
        rect.bottom + 6;


    if (
        left < 10
    ) {

        left = 10;

    }


    if (
        left + menuWidth >
        window.innerWidth - 10
    ) {

        left =
            window.innerWidth -
            menuWidth -
            10;

    }


    if (
        top +
        actionMenu.offsetHeight >
        window.innerHeight - 10
    ) {

        top =
            rect.top -
            actionMenu.offsetHeight -
            6;

    }


    actionMenu.style.left =
        `${left}px`;

    actionMenu.style.top =
        `${top}px`;

}


/* =========================================================
   CLOSE ACTION MENU
========================================================= */

function closeActionMenu() {

    if (!actionMenu) return;

    actionMenu.classList.remove(
        "show"
    );

    actionMenuCategoryId =
        null;

}


/* =========================================================
   ACTION MENU HANDLER
========================================================= */

function handleActionMenu(event) {

    const button =
        event.target.closest(
            "button[data-action]"
        );


    if (!button) return;


    const action =
        button.dataset.action;


    const categoryId =
        actionMenuCategoryId;


    closeActionMenu();


    if (!categoryId) return;


    switch (action) {

        case "view":

            viewCategory(categoryId);

            break;


        case "edit":

            openEditModal(categoryId);

            break;


        case "products":

            viewCategoryProducts(
                categoryId
            );

            break;


        case "toggle":

            toggleCategory(
                categoryId
            );

            break;


        case "delete":

            deleteCategory(
                categoryId
            );

            break;

    }

}


/* =========================================================
   ADD CATEGORY
========================================================= */

function openAddModal() {

    if (!modal) return;


    categoryForm?.reset();


    categoryIdInput.value = "";

    categoryStatusInput.value =
        "active";


    categoryModalLabel.textContent =
        "NEW CATEGORY";


    categoryModalTitle.textContent =
        "Add Category";


    saveCategoryBtn.innerHTML = `
        <i class="fa-solid fa-check"></i>
        Save Category
    `;


    modal.classList.add(
        "show"
    );


    setTimeout(
        () => {

            categoryNameInput?.focus();

        },
        100
    );

}


/* =========================================================
   EDIT CATEGORY
========================================================= */

function openEditModal(categoryId) {

    const category =
        findCategory(categoryId);


    if (!category) {

        showToast(
            "Category could not be found.",
            "error"
        );

        return;

    }


    categoryIdInput.value =
        category.id;

    categoryNameInput.value =
        category.name;

    categoryDescriptionInput.value =
        category.description || "";

    categoryStatusInput.value =
        category.status || "active";


    categoryModalLabel.textContent =
        "EDIT CATEGORY";


    categoryModalTitle.textContent =
        "Edit Category";


    saveCategoryBtn.innerHTML = `
        <i class="fa-solid fa-floppy-disk"></i>
        Update Category
    `;


    modal.classList.add(
        "show"
    );


    setTimeout(
        () => {

            categoryNameInput?.focus();

        },
        100
    );

}


/* =========================================================
   SUBMIT
========================================================= */

function handleCategorySubmit(event) {

    event.preventDefault();


    const id =
        categoryIdInput.value.trim();


    const name =
        categoryNameInput.value.trim();


    const description =
        categoryDescriptionInput.value.trim();


    const status =
        categoryStatusInput.value;


    if (!name) {

        showToast(
            "Please enter a category name.",
            "error"
        );

        categoryNameInput.focus();

        return;

    }


    /* CHECK DUPLICATE */

    const duplicate =
        categories.some(
            category => {

                return (
                    category.name
                        .toLowerCase() ===
                    name.toLowerCase()
                    &&
                    category.id !== id
                );

            }
        );


    if (duplicate) {

        showToast(
            "A category with that name already exists.",
            "error"
        );

        categoryNameInput.focus();

        return;

    }


    /* EDIT */

    if (id) {

        const category =
            findCategory(id);


        if (!category) {

            showToast(
                "Category could not be found.",
                "error"
            );

            return;

        }


        category.name =
            name;

        category.description =
            description;

        category.status =
            status;


        saveCategories();

        closeCategoryModal();

        renderCategories();


        showToast(
            "Category updated successfully.",
            "success"
        );


        return;

    }


    /* CREATE */

    const newCategory = {

        id:
            generateCategoryId(),

        name,

        description,

        status,

        createdAt:
            new Date().toISOString()

    };


    categories.unshift(
        newCategory
    );


    saveCategories();

    closeCategoryModal();

    currentPage = 1;

    renderCategories();


    showToast(
        "Category created successfully.",
        "success"
    );

}


/* =========================================================
   DELETE
========================================================= */

function deleteCategory(categoryId) {

    const category =
        findCategory(categoryId);


    if (!category) return;


    const productCount =
        getProductCount(category);


    let message =
        `Delete "${category.name}"?`;


    if (productCount > 0) {

        message +=
            `\n\nThis category currently has ${productCount} product(s) assigned to it.`;

        message +=
            `\n\nDeleting it may leave those products without a category.`;

    }


    message +=
        "\n\nThis action cannot be undone.";


    const confirmed =
        confirm(message);


    if (!confirmed) return;


    categories =
        categories.filter(
            item =>
                item.id !== categoryId
        );


    saveCategories();


    const totalPages =
        Math.max(
            1,
            Math.ceil(
                categories.length /
                categoriesPerPage
            )
        );


    if (
        currentPage >
        totalPages
    ) {

        currentPage =
            totalPages;

    }


    renderCategories();


    showToast(
        `"${category.name}" deleted.`,
        "success"
    );

}


/* =========================================================
   TOGGLE STATUS
========================================================= */

function toggleCategory(categoryId) {

    const category =
        findCategory(categoryId);


    if (!category) return;


    const newStatus =
        category.status === "active"
            ? "inactive"
            : "active";


    category.status =
        newStatus;


    saveCategories();

    renderCategories();


    showToast(
        `${category.name} is now ${newStatus}.`,
        "success"
    );

}


/* =========================================================
   VIEW CATEGORY
========================================================= */

function viewCategory(categoryId) {

    const category =
        findCategory(categoryId);


    if (!category) return;


    selectedCategoryId =
        category.id;


    const productCount =
        getProductCount(category);


    document.getElementById(
        "viewCategoryName"
    ).textContent =
        category.name;


    document.getElementById(
        "viewCategoryId"
    ).textContent =
        category.id;


    document.getElementById(
        "viewCategoryProducts"
    ).textContent =
        productCount;


    document.getElementById(
        "viewCategoryCreated"
    ).textContent =
        formatDate(category.createdAt);


    document.getElementById(
        "viewCategoryDescription"
    ).textContent =
        category.description ||
        "No description provided.";


    document.getElementById(
        "viewCategoryStatus"
    ).textContent =
        capitalize(category.status);


    document.getElementById(
        "viewCategoryStatusDetail"
    ).textContent =
        capitalize(category.status);


    const icon =
        document.getElementById(
            "viewCategoryIcon"
        );


    if (icon) {

        icon.innerHTML =
            `<i class="${getCategoryIcon(category.name)}"></i>`;

    }


    viewModal?.classList.add(
        "show"
    );

}


/* =========================================================
   VIEW CATEGORY PRODUCTS
========================================================= */

function viewCategoryProducts(categoryId) {

    const category =
        findCategory(categoryId);


    if (!category) return;


    /*
     * This is ready for the Products page.
     *
     * We pass the category ID through the URL
     * so products.js can later filter by it.
     */

    window.location.href =
        `products.html?category=${encodeURIComponent(category.id)}`;

}


/* =========================================================
   CLOSE CATEGORY MODAL
========================================================= */

function closeCategoryModal() {

    modal?.classList.remove(
        "show"
    );

}


/* =========================================================
   CLOSE VIEW MODAL
========================================================= */

function closeViewModal() {

    viewModal?.classList.remove(
        "show"
    );

}


/* =========================================================
   STATISTICS
========================================================= */

function updateStatistics() {

    const total =
        categories.length;


    const active =
        categories.filter(
            category =>
                category.status === "active"
        ).length;


    const inactive =
        total -
        active;


    const products =
        categories.reduce(
            (total, category) =>
                total +
                getProductCount(category),
            0
        );


    if (totalCategoriesEl) {

        totalCategoriesEl.textContent =
            total;

    }


    if (activeCategoriesEl) {

        activeCategoriesEl.textContent =
            active;

    }


    if (inactiveCategoriesEl) {

        inactiveCategoriesEl.textContent =
            inactive;

    }


    if (assignedProductsEl) {

        assignedProductsEl.textContent =
            products;

    }

}


/* =========================================================
   PRODUCT COUNT
========================================================= */

function getProductCount(category) {

    const products =
        getProducts();


    if (!products.length) {

        return 0;

    }


    return products.filter(
        product => {

            const productCategory =
                product.category ??
                product.categoryId ??
                product.categoryName ??
                "";


            if (
                productCategory ===
                category.id
            ) {

                return true;

            }


            if (
                typeof productCategory ===
                "string" &&
                productCategory.toLowerCase() ===
                category.name.toLowerCase()
            ) {

                return true;

            }


            return false;

        }
    ).length;

}


/* =========================================================
   GET PRODUCTS
========================================================= */

function getProducts() {

    for (
        const key of PRODUCTS_STORAGE_KEYS
    ) {

        try {

            const stored =
                localStorage.getItem(key);


            if (!stored) continue;


            const parsed =
                JSON.parse(stored);


            if (Array.isArray(parsed)) {

                return parsed;

            }

        } catch (error) {

            console.warn(
                `Could not read ${key}`,
                error
            );

        }

    }


    return [];

}


/* =========================================================
   FIND CATEGORY
========================================================= */

function findCategory(categoryId) {

    return categories.find(
        category =>
            category.id === categoryId
    );

}


/* =========================================================
   GENERATE CATEGORY ID
========================================================= */

function generateCategoryId() {

    let number = 1;

    let id;


    do {

        id =
            `CAT-${String(number).padStart(3, "0")}`;

        number++;

    } while (
        categories.some(
            category =>
                category.id === id
        )
    );


    return id;

}


/* =========================================================
   CATEGORY ICON
========================================================= */

function getCategoryIcon(name) {

    const value =
        name.toLowerCase();


    if (
        value.includes("electronic") ||
        value.includes("phone") ||
        value.includes("computer")
    ) {

        return "fa-solid fa-mobile-screen-button";

    }


    if (
        value.includes("fashion") ||
        value.includes("cloth") ||
        value.includes("wear")
    ) {

        return "fa-solid fa-shirt";

    }


    if (
        value.includes("beauty") ||
        value.includes("cosmetic")
    ) {

        return "fa-solid fa-sparkles";

    }


    if (
        value.includes("home") ||
        value.includes("living")
    ) {

        return "fa-solid fa-house";

    }


    if (
        value.includes("sport") ||
        value.includes("fitness")
    ) {

        return "fa-solid fa-dumbbell";

    }


    if (
        value.includes("food") ||
        value.includes("grocery")
    ) {

        return "fa-solid fa-basket-shopping";

    }


    if (
        value.includes("book") ||
        value.includes("education")
    ) {

        return "fa-solid fa-book";

    }


    if (
        value.includes("toy") ||
        value.includes("game")
    ) {

        return "fa-solid fa-gamepad";

    }


    return "fa-solid fa-layer-group";

}


/* =========================================================
   PAGINATION
========================================================= */

function renderPagination() {

    const total =
        filteredCategories.length;


    const totalPages =
        Math.max(
            1,
            Math.ceil(
                total /
                categoriesPerPage
            )
        );


    if (
        currentPage >
        totalPages
    ) {

        currentPage =
            totalPages;

    }


    const start =
        total === 0
            ? 0
            : (currentPage - 1) *
                categoriesPerPage +
                1;


    const end =
        Math.min(
            currentPage *
                categoriesPerPage,
            total
        );


    if (paginationText) {

        paginationText.textContent =
            total === 0
                ? "Showing 0 categories"
                : `Showing ${start}-${end} of ${total} categories`;

    }


    if (currentPageBtn) {

        currentPageBtn.textContent =
            currentPage;

    }


    if (previousPageBtn) {

        previousPageBtn.disabled =
            currentPage <= 1;

    }


    if (nextPageBtn) {

        nextPageBtn.disabled =
            currentPage >= totalPages;

    }

}


/* =========================================================
   FORMAT DATE
========================================================= */

function formatDate(value) {

    if (!value) return "—";


    const date =
        new Date(value);


    if (
        Number.isNaN(
            date.getTime()
        )
    ) {

        return "—";

    }


    return date.toLocaleDateString(
        "en-GB",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );

}


/* =========================================================
   CAPITALIZE
========================================================= */

function capitalize(value) {

    if (!value) return "";

    return (
        value.charAt(0).toUpperCase() +
        value.slice(1)
    );

}


/* =========================================================
   ESCAPE HTML
========================================================= */

function escapeHTML(value) {

    return String(value ?? "")
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );

}


/* =========================================================
   TOAST
========================================================= */

function showToast(
    message,
    type = "success"
) {

    const existing =
        document.querySelector(
            ".fash-toast"
        );


    existing?.remove();


    const toast =
        document.createElement(
            "div"
        );


    toast.className =
        `fash-toast ${type}`;


    toast.innerHTML = `

        <i class="${
            type === "success"
                ? "fa-solid fa-circle-check"
                : type === "error"
                    ? "fa-solid fa-circle-xmark"
                    : "fa-solid fa-circle-exclamation"
        }"></i>

        <span>
            ${escapeHTML(message)}
        </span>

    `;


    document.body.appendChild(
        toast
    );


    setTimeout(
        () => {

            toast.style.opacity = "0";

            toast.style.transform =
                "translateY(10px)";

            setTimeout(
                () => toast.remove(),
                250
            );

        },
        2800
    );

}


/* =========================================================
   WINDOW RESIZE
========================================================= */

window.addEventListener(
    "resize",
    () => {

        closeActionMenu();

    }
);


/* =========================================================
   END
========================================================= */