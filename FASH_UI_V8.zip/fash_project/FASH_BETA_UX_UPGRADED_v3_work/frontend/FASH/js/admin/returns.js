/* =========================================================
   FASH ADMIN — RETURNS
   returns.js
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    /* =====================================================
       ELEMENTS
    ===================================================== */

    const tableBody =
        document.getElementById("returnsTableBody");

    const emptyState =
        document.getElementById("returnsEmpty");

    const searchInput =
        document.getElementById("returnSearch");

    const statusFilter =
        document.getElementById("returnStatusFilter");

    const reasonFilter =
        document.getElementById("returnReasonFilter");

    const sortSelect =
        document.getElementById("returnSort");

    const actionMenu =
        document.getElementById("returnActionMenu");

    const refreshBtn =
        document.getElementById("refreshReturnsBtn");

    const exportBtn =
        document.getElementById("exportReturnsBtn");

    const clearFiltersBtn =
        document.getElementById("clearReturnFiltersBtn");

    const previousPageBtn =
        document.getElementById("previousReturnPage");

    const nextPageBtn =
        document.getElementById("nextReturnPage");

    const currentPageBtn =
        document.getElementById("currentReturnPage");

    const paginationText =
        document.getElementById("returnPaginationText");

    const pendingBadge =
        document.getElementById("pendingReturnsBadge");


    /* =====================================================
       STAT ELEMENTS
    ===================================================== */

    const totalReturns =
        document.getElementById("totalReturns");

    const pendingReturns =
        document.getElementById("pendingReturns");

    const approvedReturns =
        document.getElementById("approvedReturns");

    const refundedReturns =
        document.getElementById("refundedReturns");


    /* =====================================================
       MODAL ELEMENTS
    ===================================================== */

    const viewModal =
        document.getElementById("viewReturnModal");

    const confirmModal =
        document.getElementById("confirmReturnModal");

    const closeViewModalBtn =
        document.getElementById("closeViewReturnModal");

    const closeDetailsBtn =
        document.getElementById("closeReturnDetailsBtn");

    const approveViewedBtn =
        document.getElementById("approveViewedReturnBtn");

    const cancelConfirmBtn =
        document.getElementById("cancelConfirmReturn");

    const confirmActionBtn =
        document.getElementById("confirmReturnAction");

    const confirmTitle =
        document.getElementById("confirmReturnTitle");

    const confirmMessage =
        document.getElementById("confirmReturnMessage");


    /* =====================================================
       VIEW MODAL FIELDS
    ===================================================== */

    const viewReturnId =
        document.getElementById("viewReturnId");

    const viewReturnStatus =
        document.getElementById("viewReturnStatus");

    const viewReturnOrder =
        document.getElementById("viewReturnOrder");

    const viewReturnCustomer =
        document.getElementById("viewReturnCustomer");

    const viewReturnProduct =
        document.getElementById("viewReturnProduct");

    const viewReturnAmount =
        document.getElementById("viewReturnAmount");

    const viewReturnReason =
        document.getElementById("viewReturnReason");

    const viewReturnDate =
        document.getElementById("viewReturnDate");

    const viewReturnMessage =
        document.getElementById("viewReturnMessage");


    /* =====================================================
       TOAST
    ===================================================== */

    const toast =
        document.getElementById("fashToast");

    const toastMessage =
        document.getElementById("fashToastMessage");


    /* =====================================================
       STORAGE
    ===================================================== */

    const STORAGE_KEY =
        "fash_admin_returns";


    /* =====================================================
       DEMO DATA
       This is only used if localStorage is empty.
    ===================================================== */

    const demoReturns = [

        {
            id: "RET-1001",
            order: "FASH-58291",
            customer: "David Johnson",
            email: "david@example.com",
            product: "Nike Air Max 270",
            sku: "NK-270-BLK",
            reason: "damaged",
            reasonLabel: "Damaged",
            amount: 185000,
            status: "pending",
            date: "2026-08-10",
            message:
                "The shoe arrived with visible damage on the side."
        },

        {
            id: "RET-1002",
            order: "FASH-58274",
            customer: "Sarah Williams",
            email: "sarah@example.com",
            product: "Samsung Galaxy A55",
            sku: "SAM-A55",
            reason: "defective",
            reasonLabel: "Defective",
            amount: 485000,
            status: "approved",
            date: "2026-08-09",
            message:
                "The phone does not charge properly."
        },

        {
            id: "RET-1003",
            order: "FASH-58231",
            customer: "Michael Brown",
            email: "michael@example.com",
            product: "Adidas Hoodie",
            sku: "ADI-HOOD-01",
            reason: "wrong-item",
            reasonLabel: "Wrong Item",
            amount: 75000,
            status: "received",
            date: "2026-08-08",
            message:
                "I received a different colour from the one I ordered."
        },

        {
            id: "RET-1004",
            order: "FASH-58196",
            customer: "Grace Wilson",
            email: "grace@example.com",
            product: "Apple AirPods Pro",
            sku: "APL-APP2",
            reason: "not-as-described",
            reasonLabel: "Not as Described",
            amount: 320000,
            status: "refunded",
            date: "2026-08-07",
            message:
                "The product was not as described on the listing."
        },

        {
            id: "RET-1005",
            order: "FASH-58144",
            customer: "Daniel Smith",
            email: "daniel@example.com",
            product: "FASH Classic Sneakers",
            sku: "FASH-SNK-01",
            reason: "changed-mind",
            reasonLabel: "Changed Mind",
            amount: 95000,
            status: "rejected",
            date: "2026-08-06",
            message:
                "Customer requested a return because they changed their mind."
        }

    ];


    /* =====================================================
       STATE
    ===================================================== */

    let returns = loadReturns();

    let currentPage = 1;

    const itemsPerPage = 7;

    let activeReturnId = null;

    let pendingAction = null;


    /* =====================================================
       LOAD RETURNS
    ===================================================== */

    function loadReturns() {

        const saved =
            localStorage.getItem(STORAGE_KEY);

        if (saved) {

            try {

                return JSON.parse(saved);

            } catch (error) {

                console.error(
                    "Could not load FASH returns:",
                    error
                );

            }

        }

        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify(demoReturns)
        );

        return [...demoReturns];

    }


    /* =====================================================
       SAVE RETURNS
    ===================================================== */

    function saveReturns() {

        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify(returns)
        );

    }


    /* =====================================================
       INITIALIZE
    ===================================================== */

    render();

    updateStats();


    /* =====================================================
       RENDER
    ===================================================== */

    function render() {

        closeActionMenu();

        let filtered =
            getFilteredReturns();

        const totalPages =
            Math.max(
                1,
                Math.ceil(
                    filtered.length /
                    itemsPerPage
                )
            );


        if (currentPage > totalPages) {

            currentPage = totalPages;

        }


        const start =
            (currentPage - 1) *
            itemsPerPage;

        const end =
            start + itemsPerPage;

        const pageItems =
            filtered.slice(start, end);


        tableBody.innerHTML = "";


        if (pageItems.length === 0) {

            tableBody.style.display = "none";

            emptyState.hidden = false;

        } else {

            tableBody.style.display = "";

            emptyState.hidden = true;

            pageItems.forEach(returnItem => {

                tableBody.appendChild(
                    createReturnRow(returnItem)
                );

            });

        }


        updatePagination(
            filtered.length,
            totalPages
        );

    }


    /* =====================================================
       FILTER RETURNS
    ===================================================== */

    function getFilteredReturns() {

        let result = [...returns];


        const search =
            searchInput.value
                .trim()
                .toLowerCase();


        const status =
            statusFilter.value;


        const reason =
            reasonFilter.value;


        if (search) {

            result = result.filter(item => {

                return (

                    item.id
                        .toLowerCase()
                        .includes(search)

                    ||

                    item.order
                        .toLowerCase()
                        .includes(search)

                    ||

                    item.customer
                        .toLowerCase()
                        .includes(search)

                    ||

                    item.product
                        .toLowerCase()
                        .includes(search)

                );

            });

        }


        if (status !== "all") {

            result =
                result.filter(
                    item =>
                        item.status === status
                );

        }


        if (reason !== "all") {

            result =
                result.filter(
                    item =>
                        item.reason === reason
                );

        }


        switch (sortSelect.value) {

            case "oldest":

                result.sort(
                    (a, b) =>
                        new Date(a.date) -
                        new Date(b.date)
                );

                break;


            case "amount-high":

                result.sort(
                    (a, b) =>
                        b.amount -
                        a.amount
                );

                break;


            case "amount-low":

                result.sort(
                    (a, b) =>
                        a.amount -
                        b.amount
                );

                break;


            default:

                result.sort(
                    (a, b) =>
                        new Date(b.date) -
                        new Date(a.date)
                );

        }


        return result;

    }


    /* =====================================================
       CREATE TABLE ROW
    ===================================================== */

    function createReturnRow(item) {

        const row =
            document.createElement("tr");


        const initials =
            getInitials(item.customer);


        row.innerHTML = `

            <td>

                <div class="return-id">

                    <strong>
                        ${escapeHTML(item.id)}
                    </strong>

                    <span>
                        ${escapeHTML(item.sku)}
                    </span>

                </div>

            </td>


            <td>

                <div class="return-order">

                    <strong>
                        ${escapeHTML(item.order)}
                    </strong>

                    <span>
                        Customer return
                    </span>

                </div>

            </td>


            <td>

                <div class="return-customer">

                    <div class="customer-avatar">

                        ${escapeHTML(initials)}

                    </div>


                    <div class="customer-info">

                        <strong>
                            ${escapeHTML(item.customer)}
                        </strong>

                        <span>
                            ${escapeHTML(item.email || "")}
                        </span>

                    </div>

                </div>

            </td>


            <td>

                <div class="return-product">

                    <strong>
                        ${escapeHTML(item.product)}
                    </strong>

                    <span>
                        ${escapeHTML(item.sku)}
                    </span>

                </div>

            </td>


            <td>

                <span class="
                    return-reason
                    ${escapeHTML(item.reason)}
                ">

                    ${escapeHTML(item.reasonLabel)}

                </span>

            </td>


            <td>

                <strong class="return-amount">

                    ${formatCurrency(item.amount)}

                </strong>

            </td>


            <td>

                <span class="
                    return-status
                    ${escapeHTML(item.status)}
                ">

                    ${formatStatus(item.status)}

                </span>

            </td>


            <td>

                <span class="return-date">

                    ${formatDate(item.date)}

                </span>

            </td>


            <td>

                <button
                    type="button"
                    class="return-more-btn"
                    data-return-id="${escapeHTML(item.id)}"
                    aria-label="Return actions"
                    title="Actions"
                >

                    <i class="fa-solid fa-ellipsis-vertical"></i>

                </button>

            </td>

        `;


        const moreButton =
            row.querySelector(".return-more-btn");


        moreButton.addEventListener(
            "click",
            event => {

                event.stopPropagation();

                openActionMenu(
                    moreButton,
                    item.id
                );

            }
        );


        return row;

    }


    /* =====================================================
       OPEN THREE-DOT MENU
    ===================================================== */

    function openActionMenu(
        button,
        returnId
    ) {

        activeReturnId =
            returnId;


        const rect =
            button.getBoundingClientRect();


        actionMenu.classList.add("show");


        const menuWidth =
            actionMenu.offsetWidth;


        const menuHeight =
            actionMenu.offsetHeight;


        let left =
            rect.right -
            menuWidth;


        let top =
            rect.bottom + 6;


        if (
            left + menuWidth >
            window.innerWidth - 10
        ) {

            left =
                window.innerWidth -
                menuWidth -
                10;

        }


        if (
            top + menuHeight >
            window.innerHeight - 10
        ) {

            top =
                rect.top -
                menuHeight -
                6;

        }


        if (left < 10) {

            left = 10;

        }


        if (top < 10) {

            top = 10;

        }


        actionMenu.style.left =
            `${left}px`;

        actionMenu.style.top =
            `${top}px`;


        updateActionVisibility(
            returnId
        );

    }


    /* =====================================================
       ACTION VISIBILITY
    ===================================================== */

    function updateActionVisibility(
        returnId
    ) {

        const item =
            findReturn(returnId);


        if (!item) return;


        const approve =
            actionMenu.querySelector(
                '[data-action="approve"]'
            );

        const reject =
            actionMenu.querySelector(
                '[data-action="reject"]'
            );

        const received =
            actionMenu.querySelector(
                '[data-action="received"]'
            );

        const refund =
            actionMenu.querySelector(
                '[data-action="refund"]'
            );


        approve.style.display =
            item.status === "pending"
                ? "flex"
                : "none";


        reject.style.display =
            item.status === "pending"
                ? "flex"
                : "none";


        received.style.display =
            item.status === "approved"
                ? "flex"
                : "none";


        refund.style.display =
            (
                item.status === "approved" ||
                item.status === "received"
            )
                ? "flex"
                : "none";

    }


    /* =====================================================
       CLOSE ACTION MENU
    ===================================================== */

    function closeActionMenu() {

        actionMenu.classList.remove("show");

        activeReturnId = null;

    }


    /* =====================================================
       ACTION MENU CLICK
    ===================================================== */

    actionMenu.addEventListener(
        "click",
        event => {

            const button =
                event.target.closest(
                    "button"
                );


            if (!button) return;


            const action =
                button.dataset.action;


            const item =
                findReturn(activeReturnId);


            if (!item) return;


            closeActionMenu();


            switch (action) {

                case "view":

                    openViewModal(item);

                    break;


                case "approve":

                    requestAction(
                        "approve",
                        item
                    );

                    break;


                case "reject":

                    requestAction(
                        "reject",
                        item
                    );

                    break;


                case "received":

                    requestAction(
                        "received",
                        item
                    );

                    break;


                case "refund":

                    requestAction(
                        "refund",
                        item
                    );

                    break;


                case "customer":

                    showToast(
                        `Customer: ${item.customer}`,
                        "success"
                    );

                    break;


                case "archive":

                    requestAction(
                        "archive",
                        item
                    );

                    break;

            }

        }
    );


    /* =====================================================
       REQUEST ACTION
    ===================================================== */

    function requestAction(
        action,
        item
    ) {

        pendingAction = {
            action,
            id: item.id
        };


        const messages = {

            approve: {
                title: "Approve Return?",
                message:
                    `Approve ${item.id} for ${item.customer}?`
            },

            reject: {
                title: "Reject Return?",
                message:
                    `Reject the return request ${item.id}?`
            },

            received: {
                title: "Mark as Received?",
                message:
                    `Confirm that the returned ${item.product} has been received?`
            },

            refund: {
                title: "Issue Refund?",
                message:
                    `Issue a refund of ${formatCurrency(item.amount)} to ${item.customer}?`
            },

            archive: {
                title: "Archive Return?",
                message:
                    `Archive ${item.id}? It will no longer appear in the active returns list.`
            }

        };


        confirmTitle.textContent =
            messages[action].title;


        confirmMessage.textContent =
            messages[action].message;


        confirmActionBtn.textContent =
            action === "refund"
                ? "Issue Refund"
                : "Confirm";


        confirmModal.classList.add("show");

    }


    /* =====================================================
       CONFIRM ACTION
    ===================================================== */

    confirmActionBtn.addEventListener(
        "click",
        () => {

            if (!pendingAction) return;


            const {
                action,
                id
            } = pendingAction;


            const item =
                findReturn(id);


            if (!item) return;


            switch (action) {

                case "approve":

                    item.status =
                        "approved";

                    showToast(
                        `${item.id} has been approved.`,
                        "success"
                    );

                    break;


                case "reject":

                    item.status =
                        "rejected";

                    showToast(
                        `${item.id} has been rejected.`,
                        "warning"
                    );

                    break;


                case "received":

                    item.status =
                        "received";

                    showToast(
                        `${item.id} marked as received.`,
                        "success"
                    );

                    break;


                case "refund":

                    item.status =
                        "refunded";

                    item.refunded =
                        item.amount;

                    showToast(
                        `${formatCurrency(item.amount)} refund issued.`,
                        "success"
                    );

                    break;


                case "archive":

                    returns =
                        returns.filter(
                            returnItem =>
                                returnItem.id !== id
                        );

                    showToast(
                        `${id} has been archived.`,
                        "success"
                    );

                    break;

            }


            saveReturns();

            closeConfirmModal();

            updateStats();

            render();

        }
    );


    /* =====================================================
       VIEW RETURN MODAL
    ===================================================== */

    function openViewModal(item) {

        activeReturnId =
            item.id;


        viewReturnId.textContent =
            item.id;


        viewReturnStatus.textContent =
            formatStatus(item.status);


        viewReturnStatus.className =
            `return-status ${item.status}`;


        viewReturnOrder.textContent =
            item.order;


        viewReturnCustomer.textContent =
            item.customer;


        viewReturnProduct.textContent =
            item.product;


        viewReturnAmount.textContent =
            formatCurrency(item.amount);


        viewReturnReason.textContent =
            item.reasonLabel;


        viewReturnDate.textContent =
            formatDate(item.date);


        viewReturnMessage.textContent =
            item.message ||
            "No customer message provided.";


        approveViewedBtn.style.display =
            item.status === "pending"
                ? "inline-flex"
                : "none";


        viewModal.classList.add("show");

    }


    /* =====================================================
       APPROVE FROM VIEW MODAL
    ===================================================== */

    approveViewedBtn.addEventListener(
        "click",
        () => {

            const item =
                findReturn(activeReturnId);


            if (!item) return;


            closeViewModal();


            requestAction(
                "approve",
                item
            );

        }
    );


    /* =====================================================
       CLOSE VIEW MODAL
    ===================================================== */

    function closeViewModal() {

        viewModal.classList.remove("show");

        activeReturnId = null;

    }


    closeViewModalBtn.addEventListener(
        "click",
        closeViewModal
    );


    closeDetailsBtn.addEventListener(
        "click",
        closeViewModal
    );


    /* =====================================================
       CLOSE CONFIRM MODAL
    ===================================================== */

    function closeConfirmModal() {

        confirmModal.classList.remove("show");

        pendingAction = null;

    }


    cancelConfirmBtn.addEventListener(
        "click",
        closeConfirmModal
    );


    /* =====================================================
       MODAL OVERLAY CLICK
    ===================================================== */

    viewModal
        .querySelector(".modal-overlay")
        .addEventListener(
            "click",
            closeViewModal
        );


    confirmModal
        .querySelector(".modal-overlay")
        .addEventListener(
            "click",
            closeConfirmModal
        );


    /* =====================================================
       FILTER EVENTS
    ===================================================== */

    searchInput.addEventListener(
        "input",
        () => {

            currentPage = 1;

            render();

        }
    );


    statusFilter.addEventListener(
        "change",
        () => {

            currentPage = 1;

            render();

        }
    );


    reasonFilter.addEventListener(
        "change",
        () => {

            currentPage = 1;

            render();

        }
    );


    sortSelect.addEventListener(
        "change",
        () => {

            currentPage = 1;

            render();

        }
    );


    /* =====================================================
       CLEAR FILTERS
    ===================================================== */

    clearFiltersBtn.addEventListener(
        "click",
        () => {

            searchInput.value = "";

            statusFilter.value = "all";

            reasonFilter.value = "all";

            sortSelect.value = "newest";

            currentPage = 1;

            render();

        }
    );


    /* =====================================================
       PAGINATION
    ===================================================== */

    previousPageBtn.addEventListener(
        "click",
        () => {

            if (currentPage <= 1)
                return;

            currentPage--;

            render();

        }
    );


    nextPageBtn.addEventListener(
        "click",
        () => {

            const filtered =
                getFilteredReturns();


            const totalPages =
                Math.max(
                    1,
                    Math.ceil(
                        filtered.length /
                        itemsPerPage
                    )
                );


            if (currentPage >= totalPages)
                return;


            currentPage++;

            render();

        }
    );


    /* =====================================================
       UPDATE PAGINATION
    ===================================================== */

    function updatePagination(
        total,
        totalPages
    ) {

        if (total === 0) {

            paginationText.textContent =
                "Showing 0 returns";

        } else {

            const start =
                ((currentPage - 1) *
                    itemsPerPage) + 1;

            const end =
                Math.min(
                    currentPage *
                    itemsPerPage,
                    total
                );


            paginationText.textContent =
                `Showing ${start}-${end} of ${total} returns`;

        }


        currentPageBtn.textContent =
            currentPage;


        previousPageBtn.disabled =
            currentPage <= 1;


        nextPageBtn.disabled =
            currentPage >= totalPages;

    }


    /* =====================================================
       UPDATE STATISTICS
    ===================================================== */

    function updateStats() {

        const total =
            returns.length;


        const pending =
            returns.filter(
                item =>
                    item.status === "pending"
            ).length;


        const approved =
            returns.filter(
                item =>
                    item.status === "approved"
            ).length;


        const refunded =
            returns
                .filter(
                    item =>
                        item.status === "refunded"
                )
                .reduce(
                    (
                        total,
                        item
                    ) =>
                        total +
                        Number(item.amount || 0),
                    0
                );


        totalReturns.textContent =
            total;


        pendingReturns.textContent =
            pending;


        approvedReturns.textContent =
            approved;


        refundedReturns.textContent =
            formatCurrency(refunded);


        pendingBadge.textContent =
            pending;


        pendingBadge.style.display =
            pending > 0
                ? "inline-flex"
                : "none";

    }


    /* =====================================================
       REFRESH
    ===================================================== */

    refreshBtn.addEventListener(
        "click",
        () => {

            returns =
                loadReturns();

            currentPage = 1;

            updateStats();

            render();

            showToast(
                "Returns refreshed.",
                "success"
            );

        }
    );


    /* =====================================================
       EXPORT RETURNS
    ===================================================== */

    exportBtn.addEventListener(
        "click",
        () => {

            const data =
                getFilteredReturns();


            if (data.length === 0) {

                showToast(
                    "There are no returns to export.",
                    "warning"
                );

                return;

            }


            const headers = [

                "Return ID",
                "Order",
                "Customer",
                "Email",
                "Product",
                "SKU",
                "Reason",
                "Amount",
                "Status",
                "Date"

            ];


            const rows =
                data.map(item => [

                    item.id,
                    item.order,
                    item.customer,
                    item.email,
                    item.product,
                    item.sku,
                    item.reasonLabel,
                    item.amount,
                    item.status,
                    item.date

                ]);


            const csv = [

                headers,

                ...rows

            ]
                .map(
                    row =>
                        row
                            .map(value =>
                                `"${String(value)
                                    .replace(/"/g, '""')}"`
                            )
                            .join(",")
                )
                .join("\n");


            const blob =
                new Blob(
                    [csv],
                    {
                        type:
                            "text/csv;charset=utf-8;"
                    }
                );


            const url =
                URL.createObjectURL(blob);


            const link =
                document.createElement("a");


            link.href = url;

            link.download =
                `fash-returns-${Date.now()}.csv`;


            document.body.appendChild(link);

            link.click();

            link.remove();

            URL.revokeObjectURL(url);


            showToast(
                "Returns exported successfully.",
                "success"
            );

        }
    );


    /* =====================================================
       CLOSE MENU WHEN CLICKING ELSEWHERE
    ===================================================== */

    document.addEventListener(
        "click",
        event => {

            if (
                !event.target.closest(
                    ".return-action-menu"
                )
                &&
                !event.target.closest(
                    ".return-more-btn"
                )
            ) {

                closeActionMenu();

            }

        }
    );


    /* =====================================================
       ESCAPE KEY
    ===================================================== */

    document.addEventListener(
        "keydown",
        event => {

            if (event.key !== "Escape")
                return;


            closeActionMenu();

            closeViewModal();

            closeConfirmModal();

        }
    );


    /* =====================================================
       FIND RETURN
    ===================================================== */

    function findReturn(id) {

        return returns.find(
            item =>
                item.id === id
        );

    }


    /* =====================================================
       FORMAT CURRENCY
    ===================================================== */

    function formatCurrency(amount) {

        return new Intl.NumberFormat(
            "en-NG",
            {
                style: "currency",
                currency: "NGN",
                maximumFractionDigits: 0
            }
        ).format(
            Number(amount) || 0
        );

    }


    /* =====================================================
       FORMAT DATE
    ===================================================== */

    function formatDate(date) {

        if (!date)
            return "—";


        return new Intl.DateTimeFormat(
            "en-NG",
            {
                day: "2-digit",
                month: "short",
                year: "numeric"
            }
        ).format(
            new Date(date)
        );

    }


    /* =====================================================
       FORMAT STATUS
    ===================================================== */

    function formatStatus(status) {

        const labels = {

            pending: "Pending",

            approved: "Approved",

            rejected: "Rejected",

            received: "Received",

            refunded: "Refunded"

        };


        return labels[status] ||
            status;

    }


    /* =====================================================
       GET INITIALS
    ===================================================== */

    function getInitials(name) {

        if (!name)
            return "CU";


        return name
            .split(" ")
            .filter(Boolean)
            .slice(0, 2)
            .map(
                word =>
                    word.charAt(0)
                        .toUpperCase()
            )
            .join("");

    }


    /* =====================================================
       ESCAPE HTML
    ===================================================== */

    function escapeHTML(value) {

        return String(value ?? "")
            .replace(
                /&/g,
                "&amp;"
            )
            .replace(
                /</g,
                "&lt;"
            )
            .replace(
                />/g,
                "&gt;"
            )
            .replace(
                /"/g,
                "&quot;"
            )
            .replace(
                /'/g,
                "&#039;"
            );

    }


    /* =====================================================
       TOAST
    ===================================================== */

    function showToast(
        message,
        type = "success"
    ) {

        toastMessage.textContent =
            message;


        toast.className =
            `fash-toast ${type}`;


        toast.hidden = false;


        clearTimeout(
            showToast.timeout
        );


        showToast.timeout =
            setTimeout(
                () => {

                    toast.hidden = true;

                },
                3000
            );

    }


    /* =====================================================
       LOGOUT
    ===================================================== */

    const logoutBtn =
        document.getElementById("logoutBtn");


    if (logoutBtn) {

        logoutBtn.addEventListener(
            "click",
            () => {

                const confirmed =
                    confirm(
                        "Are you sure you want to logout of FASH Admin?"
                    );


                if (!confirmed)
                    return;


                /*
                 * Replace this with your real
                 * FASH authentication logout
                 * when authentication is connected.
                 */

                localStorage.removeItem(
                    "fash_admin_session"
                );


                window.location.href =
                    "login.html";

            }
        );

    }


    /* =====================================================
       NOTIFICATION
    ===================================================== */

    const notificationBtn =
        document.getElementById(
            "notificationBtn"
        );


    if (notificationBtn) {

        notificationBtn.addEventListener(
            "click",
            () => {

                showToast(
                    "You have pending return requests.",
                    "warning"
                );

            }
        );

    }

}); 