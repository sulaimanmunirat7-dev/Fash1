/* =========================================================
   FASH ADMIN — SELLER APPLICATIONS
   Real list page using the same storage as Applications.
========================================================= */

(() => {
    const APPLICATION_KEY = "fashSellerApplications";
    const SELLERS_KEY = "fashSellers";
    const LEGACY_KEYS = ["sellerApplications", "fash_seller_applications", "fashSellerApplication", "fashApplications"];

    const DEFAULTS = [
        { id:"APP-1001", applicant:"David Johnson", email:"david@example.com", phone:"+234 801 234 5678", business:"Urban Kicks", category:"Fashion", businessType:"Registered Business", location:"Lagos, Nigeria", submitted:"2026-08-10", status:"pending", documents:[{name:"Business Registration",status:"verified"},{name:"Government ID",status:"verified"},{name:"Address Verification",status:"pending"}], adminNote:"" },
        { id:"APP-1002", applicant:"Sarah Williams", email:"sarah@example.com", phone:"+234 809 555 1122", business:"Sarah Beauty Store", category:"Beauty", businessType:"Sole Proprietorship", location:"Abuja, Nigeria", submitted:"2026-08-09", status:"under-review", documents:[{name:"Government ID",status:"verified"},{name:"Business Registration",status:"verified"}], adminNote:"Checking business registration." },
        { id:"APP-1003", applicant:"Michael Ade", email:"michael@example.com", phone:"+234 803 222 4455", business:"Tech World NG", category:"Electronics", businessType:"Limited Company", location:"Lagos, Nigeria", submitted:"2026-08-08", status:"approved", approvedDate:"2026-08-08", documents:[{name:"CAC Registration",status:"verified"},{name:"Government ID",status:"verified"}], adminNote:"Verified successfully." },
        { id:"APP-1004", applicant:"Daniel Okafor", email:"daniel@example.com", phone:"+234 806 777 8899", business:"Home Essentials", category:"Home & Living", businessType:"Sole Proprietorship", location:"Port Harcourt, Nigeria", submitted:"2026-08-07", status:"rejected", documents:[{name:"Government ID",status:"missing"}], adminNote:"Required verification documents missing." }
    ];

    const $ = id => document.getElementById(id);
    let applications = load();
    let selectedId = null;

    document.addEventListener("DOMContentLoaded", init);

    function init() {
        populateCategories();
        bind();
        render();
    }

    function load() {
        for (const key of [APPLICATION_KEY, ...LEGACY_KEYS]) {
            const raw = localStorage.getItem(key);
            if (!raw) continue;
            try {
                const parsed = JSON.parse(raw);
                if (Array.isArray(parsed)) {
                    localStorage.setItem(APPLICATION_KEY, JSON.stringify(parsed));
                    return parsed;
                }
            } catch {}
        }
        localStorage.setItem(APPLICATION_KEY, JSON.stringify(DEFAULTS));
        return [...DEFAULTS];
    }

    function save() {
        localStorage.setItem(APPLICATION_KEY, JSON.stringify(applications));
        window.dispatchEvent(new StorageEvent("storage", { key: APPLICATION_KEY, newValue: JSON.stringify(applications) }));
    }

    function bind() {
        $("sellerSearch")?.addEventListener("input", render);
        $("statusFilter")?.addEventListener("change", render);
        $("categoryFilter")?.addEventListener("change", render);
        $("clearFilters")?.addEventListener("click", () => {
            $("sellerSearch").value = "";
            $("statusFilter").value = "all";
            $("categoryFilter").value = "all";
            render();
        });
        $("refreshApplications")?.addEventListener("click", () => {
            applications = load();
            populateCategories();
            render();
            toast("Seller applications refreshed.");
        });
        $("notificationBtn")?.addEventListener("click", () => {
            const count = applications.filter(a => a.status === "pending").length;
            toast(count ? `${count} seller application${count === 1 ? "" : "s"} need review.` : "No pending seller applications.");
        });
        $("closeReviewModal")?.addEventListener("click", closeModal);
        $("reviewModal")?.querySelector(".modal-backdrop")?.addEventListener("click", closeModal);
        $("approveSeller")?.addEventListener("click", () => changeSelected("approved"));
        $("rejectSeller")?.addEventListener("click", () => changeSelected("rejected"));
        $("requestChanges")?.addEventListener("click", () => changeSelected("changes-requested"));
        $("reviewNote")?.addEventListener("input", () => {
            const app = applications.find(a => a.id === selectedId);
            if (!app) return;
            app.adminNote = $("reviewNote").value;
            save();
        });
        window.addEventListener("storage", e => {
            if (e.key !== APPLICATION_KEY) return;
            applications = load();
            populateCategories();
            render();
        });
    }

    function populateCategories() {
        const select = $("categoryFilter");
        if (!select) return;
        const current = select.value;
        const categories = [...new Set(applications.map(a => a.category).filter(Boolean))].sort();
        select.innerHTML = `<option value="all">All Categories</option>`;
        categories.forEach(c => select.insertAdjacentHTML("beforeend", `<option value="${esc(c)}">${esc(c)}</option>`));
        select.value = categories.includes(current) ? current : "all";
    }

    function render() {
        const filtered = getFiltered();
        $("pendingCount").textContent = applications.filter(a => a.status === "pending").length;
        $("reviewCount").textContent = applications.filter(a => a.status === "under-review").length;
        $("approvedCount").textContent = applications.filter(a => a.status === "approved").length;
        $("rejectedCount").textContent = applications.filter(a => a.status === "rejected").length;
        $("resultSummary").textContent = `Showing ${filtered.length} of ${applications.length} seller application${applications.length === 1 ? "" : "s"}`;

        const body = $("sellerApplicationsBody");
        const empty = $("emptyState");
        body.innerHTML = "";
        empty.hidden = filtered.length !== 0;

        filtered.forEach(app => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td><div class="applicant-cell"><div class="applicant-avatar">${initials(app.applicant)}</div><div class="applicant-details"><strong>${esc(app.applicant)}</strong><span>${esc(app.email)}</span></div></div></td>
                <td><div class="business-cell"><strong>${esc(app.business)}</strong><span>${esc(app.location)}</span></div></td>
                <td><span class="category-label">${esc(app.category)}</span></td>
                <td>${date(app.submitted)}</td>
                <td>${badge(app.status)}</td>
                <td class="action-cell"><button class="more-btn" data-id="${esc(app.id)}"><i class="fa-solid fa-ellipsis-vertical"></i></button></td>
            `;
            body.appendChild(row);
        });

        body.querySelectorAll(".more-btn").forEach(btn => btn.addEventListener("click", e => {
            e.stopPropagation();
            closeMenus();
            const app = applications.find(a => a.id === btn.dataset.id);
            if (!app) return;
            const menu = document.createElement("div");
            menu.className = "application-actions-menu";
            menu.innerHTML = `
                <button data-action="view"><i class="fa-solid fa-eye"></i> View Application</button>
                ${app.status !== "under-review" && app.status !== "approved" ? `<button data-action="review"><i class="fa-solid fa-magnifying-glass"></i> Start Review</button>` : ""}
                ${app.status !== "approved" ? `<button data-action="approve"><i class="fa-solid fa-check"></i> Approve Seller</button>` : ""}
                ${app.status !== "changes-requested" && app.status !== "approved" ? `<button data-action="changes"><i class="fa-solid fa-pen-to-square"></i> Request Changes</button>` : ""}
                ${app.status !== "rejected" && app.status !== "approved" ? `<button data-action="reject" class="danger-action"><i class="fa-solid fa-xmark"></i> Reject Application</button>` : ""}
            `;
            btn.closest(".action-cell").appendChild(menu);
            btn.classList.add("active");
            menu.querySelectorAll("button").forEach(action => action.addEventListener("click", () => {
                closeMenus();
                handle(action.dataset.action, app.id);
            }));
        }));
    }

    function getFiltered() {
        const q = ($( "sellerSearch")?.value || "").trim().toLowerCase();
        const status = $("statusFilter")?.value || "all";
        const category = $("categoryFilter")?.value || "all";
        return applications.filter(a => {
            const text = [a.applicant, a.email, a.business, a.category, a.location].join(" ").toLowerCase();
            return (!q || text.includes(q)) && (status === "all" || a.status === status) && (category === "all" || a.category === category);
        });
    }

    function handle(action, id) {
        selectedId = id;
        const app = applications.find(a => a.id === id);
        if (!app) return;
        if (action === "view") openModal(app);
        if (action === "review") { app.status = "under-review"; save(); render(); openModal(app); toast("Application moved to review."); }
        if (action === "approve") changeSelected("approved");
        if (action === "changes") changeSelected("changes-requested");
        if (action === "reject") changeSelected("rejected");
    }

    function openModal(app) {
        selectedId = app.id;
        $("modalBusinessAvatar").textContent = initials(app.business);
        set("modalBusinessName", app.business);
        set("modalApplicant", app.applicant);
        set("modalEmail", app.email);
        set("modalPhone", app.phone);
        set("modalAccountId", app.id);
        set("modalBusiness", app.business);
        set("modalCategory", app.category);
        set("modalBusinessType", app.businessType);
        set("modalLocation", app.location);
        set("modalSubmitted", date(app.submitted));
        $("modalStatus").innerHTML = badge(app.status);
        $("reviewNote").value = app.adminNote || "";
        renderDocuments(app.documents || []);
        $("reviewModal").hidden = false;
    }

    function closeModal() {
        $("reviewModal").hidden = true;
        selectedId = null;
    }

    function changeSelected(status) {
        const app = applications.find(a => a.id === selectedId);
        if (!app) return;

        if (status === "approved") {
            if (!confirm(`Approve ${app.business} as a FASH seller?`)) return;
            app.status = "approved";
            app.approvedDate = today();
            addSeller(app);
            save(); render(); closeModal();
            toast(`${app.business} approved and added to Sellers.`);
            return;
        }

        const promptText = status === "rejected" ? "Why are you rejecting this application?" : "What changes should the seller make?";
        const reason = prompt(promptText, app.adminNote || "");
        if (!reason || !reason.trim()) return;
        app.status = status;
        app.adminNote = reason.trim();
        save(); render(); closeModal();
        toast(status === "rejected" ? "Seller application rejected." : "Changes requested from seller.");
    }

    function addSeller(app) {
        let sellers = [];
        try { sellers = JSON.parse(localStorage.getItem(SELLERS_KEY)) || []; } catch { sellers = []; }
        if (sellers.some(s => String(s.applicationId) === String(app.id))) return;
        sellers.push({ id: Date.now(), applicationId: app.id, name: app.applicant, email: app.email, phone: app.phone, store: app.business, category: categoryKey(app.category), products: 0, sales: 0, rating: 0, status: "active", joined: date(app.approvedDate || today()) });
        localStorage.setItem(SELLERS_KEY, JSON.stringify(sellers));
    }

    function renderDocuments(docs) {
        const el = $("documentsList");
        el.innerHTML = docs.length ? docs.map(doc => `<div class="verification-item"><div class="verification-document"><i class="fa-solid fa-file-lines"></i><span>${esc(doc.name)}</span></div><span class="verification-status ${esc(doc.status)}">${doc.status === "verified" ? "Verified" : doc.status === "missing" ? "Missing" : "Pending"}</span></div>`).join("") : `<div class="verification-item"><div class="verification-document"><i class="fa-solid fa-file"></i><span>No documents submitted</span></div></div>`;
    }

    function closeMenus() {
        document.querySelectorAll(".application-actions-menu").forEach(x => x.remove());
        document.querySelectorAll(".more-btn.active").forEach(x => x.classList.remove("active"));
    }
    document.addEventListener("click", closeMenus);

    function badge(status) {
        const labels = { pending:"Pending", "under-review":"Under Review", approved:"Approved", rejected:"Rejected", "changes-requested":"Changes Requested" };
        return `<span class="status-badge ${esc(status)}">${labels[status] || esc(status)}</span>`;
    }
    function categoryKey(value) { return String(value || "other").toLowerCase().replace(/\s*&\s*/g,"_").replace(/\s+/g,"_"); }
    function initials(name) { return String(name || "FA").split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join("").toUpperCase(); }
    function date(value) { const d = new Date(value); return Number.isNaN(d.getTime()) ? esc(value || "—") : d.toLocaleDateString("en-NG",{day:"2-digit",month:"short",year:"numeric"}); }
    function today() { return new Date().toISOString().split("T")[0]; }
    function set(id,value) { if ($(id)) $(id).textContent = value || "—"; }
    function esc(v) { return String(v ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c])); }
    function toast(message) { const t=$("fashToast"), m=$("toastMessage"); if(!t)return; if(m)m.textContent=message; t.hidden=false; clearTimeout(toast.timer); toast.timer=setTimeout(()=>t.hidden=true,3000); }
})();
