document.addEventListener("DOMContentLoaded", async()=>{
 const body=document.getElementById("productsTableBody"); if(!body||!window.FASH_API)return;
 try{
  const d=await FASH_API.api("/api/admin/products/all"); const ps=d.products||[];
  body.innerHTML=ps.map(p=>`<tr>
  <td><input type="checkbox"></td><td><strong>${esc(p.name)}</strong><br><small>${esc(p.store_name||"No store")}</small></td><td>${esc(p.id)}</td><td>${esc(p.seller_name||"FASH")}</td><td>${esc(p.category||"")}</td><td>₦${Number(p.price).toLocaleString()}</td><td>${p.stock}</td>
  <td><span class="seller-status ${p.status}">${p.status.replace("_"," ")}</span></td><td>${new Date(p.created_at).toLocaleDateString("en-NG")}</td>
  <td>${p.status==="pending_review"?`<button data-review="approved" data-id="${p.id}" class="primary-action">Approve</button> <button data-review="rejected" data-id="${p.id}" class="secondary-action">Reject</button>`:""}</td></tr>`).join("");
 }catch(e){console.warn("Admin products API unavailable",e)}
 body.addEventListener("click",async e=>{const b=e.target.closest("[data-review]");if(!b)return;try{await FASH_API.api(`/api/admin/products/${b.dataset.id}/review`,{method:"PATCH",body:JSON.stringify({status:b.dataset.review})});location.reload()}catch(err){alert(err.message||"Could not review product")}});
 function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
});