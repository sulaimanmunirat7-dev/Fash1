/* FASH ADMIN — SELLER APPLICATIONS — BACKEND SOURCE OF TRUTH */
(() => {
  "use strict";
  const PER_PAGE = 8;
  let applications = [], filtered = [], currentPage = 1, openApplicationId = null, toastTimer;
  const $ = id => document.getElementById(id);
  const first = (...ids) => ids.map($).find(Boolean);
  const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const text = (id,v) => { const e=$(id); if(e)e.textContent=v==null||v===""?"—":String(v); };
  const normalizeStatus = s => { const v=String(s||"pending").toLowerCase().replace(/_/g,"-"); return ["approved","rejected","pending","under-review","changes-requested"].includes(v)?v:"pending"; };
  const label = s => ({pending:"Pending","under-review":"Under Review",approved:"Approved","changes-requested":"Changes Requested",rejected:"Rejected"}[s]||"Pending");
  const normalize = a => ({...a,id:a.id,userId:a.user_id||a.userId||"",name:a.applicant_name||a.name||"Unknown Applicant",email:a.email||"",phone:a.phone||"",businessName:a.business_name||a.businessName||"Business",category:a.category||"General",location:a.location||"",description:a.business_description||a.description||"",submittedAt:a.submitted_at||a.submittedAt,status:normalizeStatus(a.status),reviewedAt:a.reviewed_at||a.reviewedAt,adminNotes:a.admin_notes||a.adminNotes||""});

  async function loadApplications(){
    try{
      const data=await FASH_API.api("/api/admin/seller-applications");
      return Array.isArray(data.applications)?data.applications.map(normalize):[];
    }catch(e){ console.error(e); throw e; }
  }
  async function refresh(){
    try { applications=await loadApplications(); currentPage=1; render(); clearLoadError(); }
    catch(e){ applications=[]; currentPage=1; renderLoadError(e); }
  }
  function filteredApps(){
    const q=(first("applicationSearch")?.value||"").trim().toLowerCase(), st=first("statusFilter")?.value||"all", ty=first("applicationTypeFilter","typeFilter")?.value||"all";
    return applications.filter(a=>{const hay=[a.id,a.name,a.email,a.phone,a.businessName,a.category,a.location].join(" ").toLowerCase(); return (!q||hay.includes(q))&&(st==="all"||a.status===st)&&(ty==="all"||String(a.type||"seller").toLowerCase()===ty);});
  }
  function render(){ filtered=filteredApps(); renderStats(); renderTable(); renderPagination(); }
  function renderStats(){ text("totalApplications",applications.length); text("pendingApplications",applications.filter(a=>a.status==="pending").length); text("reviewApplications",applications.filter(a=>a.status==="under-review").length); text("approvedApplications",applications.filter(a=>a.status==="approved").length); text("rejectedApplications",applications.filter(a=>a.status==="rejected").length); text("changesApplications",applications.filter(a=>a.status==="changes-requested").length); text("applicationNavCount",applications.filter(a=>a.status==="pending"||a.status==="under-review").length); text("sidebarPendingBadge",applications.filter(a=>a.status==="pending"||a.status==="under-review").length); }
  function renderTable(){
    const body=$("applicationsTableBody"), empty=$("applicationsEmpty"); if(!body)return; body.innerHTML="";
    const start=(currentPage-1)*PER_PAGE, items=filtered.slice(start,start+PER_PAGE); if(empty)empty.hidden=items.length!==0;
    items.forEach(a=>{ const tr=document.createElement("tr"); tr.dataset.applicationId=a.id; tr.innerHTML=`<td><div class="applicant-cell"><div class="applicant-avatar">${esc(String(a.name||"?").trim().split(/\s+/).slice(0,2).map(x=>x[0]).join("").toUpperCase())}</div><div class="applicant-info"><strong>${esc(a.name)}</strong><span>${esc(a.email||"No email")}</span></div></div></td><td><strong>${esc(a.businessName)}</strong><small>${esc(a.id)}</small></td><td>${esc(a.category)}</td><td>${new Date(a.submittedAt).toLocaleDateString()}</td><td><span class="status-pill ${esc(a.status)}">${esc(label(a.status))}</span></td><td><button type="button" class="application-dots more-btn" data-application-id="${esc(a.id)}" aria-label="Application actions"><span></span><span></span><span></span></button></td>`; body.appendChild(tr); });
    text("applicationResultsCount",`Showing ${items.length} of ${filtered.length} applications`); text("applicationResults",`Showing ${items.length} of ${filtered.length} applications`);
  }
  function renderPagination(){ const pages=Math.max(1,Math.ceil(filtered.length/PER_PAGE)); currentPage=Math.min(currentPage,pages); text("currentPage",currentPage); const p=$("previousPage"),n=$("nextPage"); if(p)p.disabled=currentPage<=1;if(n)n.disabled=currentPage>=pages; }
  function openMenu(btn){ const menu=$("applicationActionMenu"),a=applications.find(x=>String(x.id)===String(btn.dataset.applicationId));if(!menu||!a)return;openApplicationId=a.id;["approve","changes","reject"].forEach(k=>{const e=menu.querySelector(`[data-action="${k}"]`);if(e)e.hidden=!(["pending","under-review","changes-requested"].includes(a.status));});menu.hidden=false;const r=btn.getBoundingClientRect();menu.style.position="fixed";menu.style.left=Math.max(8,Math.min(innerWidth-228,r.right-220))+"px";menu.style.top=Math.min(innerHeight-menu.offsetHeight-8,r.bottom+8)+"px";}
  function closeMenu(){const m=$("applicationActionMenu");if(m){m.hidden=true;m.style.left="";m.style.top="";}openApplicationId=null;}
  function closeModal(){const m=$("applicationModal");if(m)m.hidden=true;document.body.style.overflow="";}
  function view(a){ const m=$("applicationModal"); if(!m)return; text("reviewApplicationId",a.id);text("reviewApplicationType",a.type||"Seller");text("reviewSubmittedDate",new Date(a.submittedAt).toLocaleString());text("reviewApplicationStatus",label(a.status));text("reviewSellerName",a.name);text("reviewSellerEmail",a.email);text("reviewSellerPhone",a.phone);text("reviewSellerLocation",a.location);text("reviewBusinessName",a.businessName);text("reviewBusinessType",a.category);text("reviewBusinessRegistration","Not provided");text("reviewBusinessLocation",a.location);const notes=$("adminApplicationNotes");if(notes)notes.value=a.adminNotes||"";m.hidden=false;document.body.style.overflow="hidden";openApplicationId=a.id; }
  async function update(a,status,notes){ try{const data=await FASH_API.api(`/api/admin/seller-applications/${encodeURIComponent(a.id)}`,{method:"PATCH",body:JSON.stringify({status,adminNotes:notes||null})});await refresh();closeMenu();closeModal();showToast(data.message||"Application updated.");}catch(e){console.error(e);showToast(e.message||"Could not update application.");} }
  function approve(a){if(!confirm(`Approve ${a.businessName} as a FASH seller?`))return;update(a,"approved",$("adminApplicationNotes")?.value||"");}
  function changes(a){const v=prompt("Enter the changes required:");if(v&&v.trim())update(a,"changes_requested",v.trim());}
  function reject(a){const v=prompt("Enter the reason for rejection:");if(v&&v.trim()&&confirm("Reject this application?"))update(a,"rejected",v.trim());}
  function action(e){const b=e.target.closest("[data-action]");if(!b||!openApplicationId)return;const a=applications.find(x=>String(x.id)===String(openApplicationId));closeMenu();if(!a)return;const k=b.dataset.action;if(k==="view")view(a);else if(k==="approve")approve(a);else if(k==="changes")changes(a);else if(k==="reject")reject(a);else if(k==="review")update(a,"under_review",$("adminApplicationNotes")?.value||"");}
  function showToast(msg){const t=first("adminToast","fashToast");if(!t)return;const s=first("adminToastMessage","toastMessage");if(s)s.textContent=msg;t.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove("show"),3000);}
  function bind(){
    $("applicationSearch")?.addEventListener("input",()=>{currentPage=1;render();}); $("statusFilter")?.addEventListener("change",()=>{currentPage=1;render();}); first("applicationTypeFilter","typeFilter")?.addEventListener("change",()=>{currentPage=1;render();}); $("refreshApplications")?.addEventListener("click",refresh); $("previousPage")?.addEventListener("click",()=>{if(currentPage>1){currentPage--;render();}}); $("nextPage")?.addEventListener("click",()=>{if(currentPage<Math.ceil(filtered.length/PER_PAGE)){currentPage++;render();}}); $("closeApplicationModal")?.addEventListener("click",closeModal); $("applicationActionMenu")?.addEventListener("click",action); $("approveApplicationBtn")?.addEventListener("click",()=>{const a=applications.find(x=>String(x.id)===String(openApplicationId));if(a)approve(a);}); $("rejectApplicationBtn")?.addEventListener("click",()=>{const a=applications.find(x=>String(x.id)===String(openApplicationId));if(a)reject(a);}); $("requestChangesBtn")?.addEventListener("click",()=>{const a=applications.find(x=>String(x.id)===String(openApplicationId));if(a)changes(a);}); document.querySelector("#applicationsTableBody")?.addEventListener("click",e=>{const b=e.target.closest(".application-dots,.more-btn");if(b){e.stopPropagation();openMenu(b);}}); document.addEventListener("click",e=>{if(!e.target.closest("#applicationActionMenu,.application-dots,.more-btn"))closeMenu();}); document.addEventListener("keydown",e=>{if(e.key==="Escape"){closeMenu();closeModal();}});
  }
  function renderLoadError(error){
    const body=$("applicationsTableBody"), empty=$("applicationsEmpty");
    if(body) body.innerHTML="";
    if(empty){ empty.hidden=false; empty.innerHTML=`<div class="empty-icon"><i class="fa-solid fa-triangle-exclamation"></i></div><h3>Applications couldn't load</h3><p>${esc(error?.message||"Check your admin login and backend connection.")}</p><button type="button" class="secondary-btn" id="retryApplications">Retry</button>`; empty.querySelector("#retryApplications")?.addEventListener("click",refresh); }
    renderStats();
  }
  function clearLoadError(){}
  async function init(){ bind(); await refresh(); }
  document.addEventListener("DOMContentLoaded",init);
})();
