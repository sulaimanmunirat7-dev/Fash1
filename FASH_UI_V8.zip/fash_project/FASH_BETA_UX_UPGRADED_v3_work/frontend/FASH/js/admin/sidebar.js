
(() => {
    "use strict";

    const host = document.getElementById("adminSidebar");
    if (!host) return;

    const current = (location.pathname.split("/").pop() || "admin.html").toLowerCase();

    const sections = [
        {
            title: "ADMINISTRATION", key: "administration", open: true,
            items: [
                ["admin.html","fa-chart-pie","Dashboard"],
                ["orders.html","fa-bag-shopping","Orders"],
                ["products.html","fa-box","Products"],
                ["sellers.html","fa-store","Sellers"],
                ["customers.html","fa-users","Customers"],
                ["categories.html","fa-layer-group","Categories"],
                ["returns.html","fa-rotate-left","Returns","pendingReturnsBadge"]
            ]
        },
        {
            title: "BUSINESS", key: "business",
            open: localStorage.getItem("fash_admin_business_open") !== "false",
            items: [
                ["reports.html","fa-chart-column","Reports"],
                ["applications.html","fa-file-circle-check","Applications","sidebarPendingBadge"],
                ["rejected-applications.html","fa-file-circle-xmark","Rejected Applications"]
            ]
        },
        {
            title: "SYSTEM", key: "system",
            open: localStorage.getItem("fash_admin_system_open") !== "false",
            items: [["settings.html","fa-gear","Settings"]]
        }
    ];

    const esc = v => String(v).replace(/[&<>"]/g, c => ({
        "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"
    }[c]));

    host.outerHTML = `
        <aside class="sidebar" id="sidebar">
            <div class="brand">
                <a href="admin.html" class="brand-link">
                    <div class="brand-logo"><img src="../assets/images/fash-logo-mark.png" alt="FASH" class="fash-brand-mark"></div>
                    <div class="brand-info">
                        <h2>FASH</h2>
                        <span>ADMINISTRATION</span>
                    </div>
                </a>
            </div>

            <nav class="sidebar-nav" aria-label="FASH Administration">
                ${sections.map(section => `
                    <div class="sidebar-section" data-section="${section.key}">
                        <button type="button"
                                class="sidebar-section-toggle"
                                aria-expanded="${section.open}">
                            <span>${section.title}</span>
                            <i class="fa-solid fa-chevron-down"></i>
                        </button>

                        <div class="sidebar-section-items" ${section.open ? "" : "hidden"}>
                            ${section.items.map(([href, icon, label, badge]) => `
                                <a href="${href}"
                                   class="sidebar-link${href.toLowerCase() === current ? " active" : ""}"
                                   data-admin-link>
                                    <i class="fa-solid ${icon}"></i>
                                    <span>${label}</span>
                                    ${badge ? `<span class="nav-badge" id="${badge}">0</span>` : ""}
                                </a>
                            `).join("")}
                        </div>
                    </div>
                `).join("")}
            </nav>

            <div class="sidebar-bottom">
                <a href="../index.html" data-admin-link>
                    <i class="fa-solid fa-arrow-left"></i>
                    <span>Back to FASH</span>
                </a>
                <button type="button" class="logout" id="logoutBtn">
                    <i class="fa-solid fa-right-from-bracket"></i>
                    <span>Logout</span>
                </button>
            </div>
        </aside>

        <button class="mobile-menu-btn"
                id="adminMobileMenu"
                type="button"
                aria-label="Open admin menu"
                aria-expanded="false">
            <i class="fa-solid fa-bars"></i>
        </button>
    `;

    const sidebar = document.getElementById("sidebar");
    const mobile = document.getElementById("adminMobileMenu");

    // window.scrollTo(0, 0);

    document.querySelectorAll(".sidebar-section-toggle").forEach(button => {
        button.addEventListener("click", e => {
            e.preventDefault();

            const section = button.closest(".sidebar-section");
            const items = section.querySelector(".sidebar-section-items");
            const key = section.dataset.section;
            const open = button.getAttribute("aria-expanded") === "true";

            button.setAttribute("aria-expanded", String(!open));
            items.hidden = open;

            localStorage.setItem(
                `fash_admin_${key}_open`,
                String(!open)
            );
        });
    });

    document.querySelectorAll("[data-admin-link]").forEach(link => {
        link.addEventListener("click", () => {
            sidebar?.classList.remove("mobile-open");
            mobile?.setAttribute("aria-expanded", "false");
        });
    });

    mobile?.addEventListener("click", e => {
        e.stopPropagation();
        const open = sidebar.classList.toggle("mobile-open");
        mobile.setAttribute("aria-expanded", String(open));
    });

    document.addEventListener("click", e => {
        if (!sidebar.contains(e.target) && e.target !== mobile) {
            sidebar.classList.remove("mobile-open");
            mobile?.setAttribute("aria-expanded", "false");
        }
    });

    document.getElementById("logoutBtn")?.addEventListener("click", () => {
        if (!confirm("Are you sure you want to logout of FASH Admin?")) return;
        localStorage.removeItem("fash_admin_session");
        location.href = "../index.html";
    });
})();
