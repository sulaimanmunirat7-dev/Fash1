"use strict";

document.addEventListener("DOMContentLoaded", () => {

    const startSelling =
        document.getElementById("startSelling");

    const learnSales =
        document.getElementById("learnSales");

    const ctaStartSelling =
        document.getElementById("ctaStartSelling");

    const footerYear =
        document.getElementById("footerYear");


    /*==================================================
    START SELLING
    ==================================================*/

    if (startSelling) {

        startSelling.addEventListener("click", () => {

            window.location.href =
                "../pages/register.html";

        });

    }


    /*==================================================
    LEARN HOW IT WORKS
    ==================================================*/

    if (learnSales) {

        learnSales.addEventListener("click", () => {

            const salesSection =
                document.querySelector(".sales-section");

            if (salesSection) {

                salesSection.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });

            }

        });

    }


    /*==================================================
    CTA
    ==================================================*/

    if (ctaStartSelling) {

        ctaStartSelling.addEventListener("click", () => {

            window.location.href =
                "../pages/register.html";

        });

    }


    /*==================================================
    FOOTER YEAR
    ==================================================*/

    if (footerYear) {

        footerYear.textContent =
            `© ${new Date().getFullYear()} FLASH. All rights reserved.`;

    }

});