
window.addEventListener(
    "fash:navbar-ready",
    function () {
        updateCartCounter();
        renderFashCart();
    }
);

/*========================================================*
 FASH MARKETPLACE — CART.JS
 REAL CART SYSTEM
 Uses existing fash_cart localStorage
 Works with shop.js + wishlist-style persistence
*========================================================*/

"use strict";


/*========================================================
 CONFIG
========================================================*/

const CART_CONFIG = {

    storageKey: "fash_cart",

    currencyLocale: "en-NG",

    currency: "NGN",

    deliveryFee: 0

};


/*========================================================
 HELPERS
========================================================*/

function cartMoney(value) {

    return new Intl.NumberFormat(
        CART_CONFIG.currencyLocale,
        {
            style: "currency",
            currency: CART_CONFIG.currency,
            maximumFractionDigits: 0
        }
    ).format(Number(value) || 0);

}


/*========================================================
 GET CART
========================================================*/

function getFashCart() {

    try {

        const saved =
            localStorage.getItem(CART_CONFIG.storageKey);

        if (!saved) return [];

        const cart = JSON.parse(saved);

        return Array.isArray(cart) ? cart : [];

    } catch (error) {

        console.error("FASH Cart: Could not read cart.", error);

        return [];

    }

}


/*========================================================
 SAVE CART
========================================================*/

function saveFashCart(cart, detail = {}) {

    localStorage.setItem(
        CART_CONFIG.storageKey,
        JSON.stringify(cart)
    );

    window.dispatchEvent(
        new CustomEvent("fash:cart-updated", { detail })
    );

}


/*========================================================
 UPDATE NAVBAR COUNTER
========================================================*/

function updateCartCounter() {

    const cart = getFashCart();

    const count = cart.reduce(
        (total, item) => {

            return total + (
                Number(item.quantity) || 0
            );

        },
        0
    );


    document
        .querySelectorAll(
            "#cartCount, .cart-count"
        )
        .forEach(element => {

            element.textContent = count;

        });

}


/*========================================================
 ESCAPE HTML
========================================================*/

function escapeCartHTML(value) {

    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");

}


/*========================================================
 CART ITEM
========================================================*/

function renderCartItem(item) {

    const quantity =
        Math.max(
            1,
            Number(item.quantity) || 1
        );


    const price =
        Number(item.price) || 0;


    const total =
        price * quantity;


    return `

        <article
            class="cart-item"
            data-cart-id="${escapeCartHTML(item.id)}"
        >


            <!-- PRODUCT IMAGE -->

            <div class="cart-item-image">

                <img
                    src="${escapeCartHTML(item.image || "../assets/images/logos/Logo.png")}"
                    alt="${escapeCartHTML(item.title)}"
                    onerror="this.src='../assets/images/logos/Logo.png'"
                >

            </div>


            <!-- PRODUCT INFORMATION -->

            <div class="cart-item-content">

                <span class="cart-item-category">

                    ${escapeCartHTML(
                        item.category ||
                        "FASH Marketplace"
                    )}

                </span>


                <h3 class="cart-item-title">

                    ${escapeCartHTML(
                        item.title ||
                        "FASH Product"
                    )}

                </h3>


                ${
                    item.seller
                    ?
                    `
                    <span class="cart-item-seller">

                        Sold by
                        ${escapeCartHTML(item.seller)}

                    </span>
                    `
                    :
                    ""
                }


                <div class="cart-item-price">

                    <strong class="cart-current-price">

                        ${cartMoney(price)}

                    </strong>

                </div>

            </div>


            <!-- CONTROLS -->

            <div class="cart-item-controls">


                <!-- REMOVE -->

                <button
                    type="button"
                    class="cart-remove"
                    data-cart-remove="${escapeCartHTML(item.id)}"
                    aria-label="Remove ${escapeCartHTML(item.title)}"
                >

                    <i class="fa-solid fa-trash"></i>

                </button>


                <!-- QUANTITY -->

                <div class="cart-quantity">


                    <button
                        type="button"
                        data-cart-minus="${escapeCartHTML(item.id)}"
                        aria-label="Decrease quantity"
                    >

                        <i class="fa-solid fa-minus"></i>

                    </button>


                    <span class="cart-quantity-value">

                        ${quantity}

                    </span>


                    <button
                        type="button"
                        data-cart-plus="${escapeCartHTML(item.id)}"
                        aria-label="Increase quantity"
                    >

                        <i class="fa-solid fa-plus"></i>

                    </button>


                </div>


                <!-- TOTAL -->

                <strong class="cart-item-total">

                    ${cartMoney(total)}

                </strong>


            </div>

        </article>

    `;

}


/*========================================================
 RENDER CART
========================================================*/

function renderFashCart() {

    const cartContainer =
        document.getElementById("cartItems");

    const emptyState =
        document.getElementById("cartEmpty");


    if (!cartContainer) return;


    const cart = getFashCart();


    /*--------------------------------------------
      EMPTY CART
    --------------------------------------------*/

    if (!cart.length) {

        cartContainer.innerHTML = "";

        if (emptyState) {

            emptyState.hidden = false;

        }

        updateCartSummary([]);

        return;

    }


    /*--------------------------------------------
      CART HAS ITEMS
    --------------------------------------------*/

    if (emptyState) {

        emptyState.hidden = true;

    }


    cartContainer.innerHTML =
        cart
            .map(renderCartItem)
            .join("");


    updateCartSummary(cart);

}


/*========================================================
 SUMMARY
========================================================*/

function updateCartSummary(cart) {

    const subtotal =
        cart.reduce(
            (total, item) => {

                return total +
                    (
                        (Number(item.price) || 0) *
                        (Number(item.quantity) || 1)
                    );

            },
            0
        );


    const delivery =
        cart.length
            ? CART_CONFIG.deliveryFee
            : 0;


    const total =
        subtotal + delivery;


    const subtotalElement =
        document.getElementById("cartSubtotal");

    const deliveryElement =
        document.getElementById("cartDelivery");

    const totalElement =
        document.getElementById("cartTotal");


    if (subtotalElement) {

        subtotalElement.textContent =
            cartMoney(subtotal);

    }


    if (deliveryElement) {

        deliveryElement.textContent =
            cartMoney(delivery);

    }


    if (totalElement) {

        totalElement.textContent =
            cartMoney(total);

    }


    /*--------------------------------------------
      ITEM COUNT
    --------------------------------------------*/

    const itemCount =
        cart.reduce(
            (total, item) => {

                return total +
                    (
                        Number(item.quantity) || 0
                    );

            },
            0
        );


    const countElement =
        document.getElementById("cartPageCount");


    if (countElement) {

        countElement.textContent =
            `${itemCount} ${
                itemCount === 1
                    ? "item"
                    : "items"
            }`;

    }


    /*--------------------------------------------
      CHECKOUT BUTTON
    --------------------------------------------*/

    const checkout =
        document.getElementById("checkoutBtn");


    if (checkout) {

        checkout.disabled =
            cart.length === 0;

    }

}


/*========================================================
 FIND CART ITEM
========================================================*/

function findCartItem(id) {

    const cart = getFashCart();

    return cart.find(
        item =>
            String(item.id) === String(id)
    );

}


/*========================================================
 CHANGE QUANTITY
========================================================*/

function changeCartQuantity(id, amount) {

    const cart = getFashCart();


    const item =
        cart.find(
            product =>
                String(product.id) === String(id)
        );


    if (!item) return;


    const current =
        Number(item.quantity) || 1;


    const newQuantity =
        current + amount;


    if (newQuantity <= 0) {

        removeFromFashCart(id);

        return;

    }


    item.quantity = newQuantity;


    saveFashCart(cart, {
        action: "quantity",
        productId: item.id,
        productTitle: item.title
    });

    renderFashCart();

    updateCartCounter();

}


/*========================================================
 REMOVE ITEM
========================================================*/

function removeFromFashCart(id) {

    const cart = getFashCart();


    const updatedCart =
        cart.filter(
            item =>
                String(item.id) !== String(id)
        );


    const removedItem = cart.find(
        item => String(item.id) === String(id)
    );

    saveFashCart(updatedCart, {
        action: "remove",
        productId: id,
        productTitle: removedItem ? removedItem.title : ""
    });

    renderFashCart();

    updateCartCounter();

}


/*========================================================
 CLEAR CART
========================================================*/

function clearFashCart() {

    const cart = getFashCart();

    if (!cart.length) {
        showCartMessage("Your cart is already empty.");
        return;
    }

    localStorage.removeItem(CART_CONFIG.storageKey);

    window.dispatchEvent(
        new CustomEvent("fash:cart-updated", {
            detail: { action: "clear", itemCount: cart.length }
        })
    );

    renderFashCart();
    updateCartCounter();
    showCartMessage("Cart was cleared.");

}


/*========================================================
 CART MESSAGE
========================================================*/

function showCartMessage(message) {

    let toast = document.querySelector(".cart-action-message");

    if (!toast) {
        toast = document.createElement("div");
        toast.className = "cart-action-message";
        document.body.appendChild(toast);
    }

    toast.textContent = message;
    toast.classList.add("show");

    clearTimeout(window.__fashCartMessageTimer);
    window.__fashCartMessageTimer = setTimeout(
        () => toast.classList.remove("show"), 2200
    );
}


/*========================================================
 CART EVENTS
========================================================*/

function setupCartEvents() {


    document.addEventListener(
        "click",
        function (event) {


            /*------------------------------------
              PLUS
            ------------------------------------*/

            const plus =
                event.target.closest(
                    "[data-cart-plus]"
                );


            if (plus) {

                changeCartQuantity(
                    plus.dataset.cartPlus,
                    1
                );

                return;

            }


            /*------------------------------------
              MINUS
            ------------------------------------*/

            const minus =
                event.target.closest(
                    "[data-cart-minus]"
                );


            if (minus) {

                changeCartQuantity(
                    minus.dataset.cartMinus,
                    -1
                );

                return;

            }


            /*------------------------------------
              REMOVE
            ------------------------------------*/

            const remove =
                event.target.closest(
                    "[data-cart-remove]"
                );


            if (remove) {

                removeFromFashCart(
                    remove.dataset.cartRemove
                );

                return;

            }


            /*------------------------------------
              CLEAR CART
            ------------------------------------*/

            if (
                event.target.closest(
                    "#clearCart"
                )
            ) {

                clearFashCart();

                return;

            }


            /*------------------------------------
              CHECKOUT
              Let the real anchor navigate to
              pages/checkout.html. Only block it
              when the cart is empty.
            ------------------------------------*/

            const checkoutButton =
                event.target.closest("#checkoutBtn");

            if (checkoutButton) {

                const cart = getFashCart();

                if (!cart.length) {

                    event.preventDefault();

                    alert("Your cart is empty.");

                    return;

                }

                // Cart has items: navigate to checkout.
                // cart.html and checkout.html are in the same /pages/ folder.
                window.location.href = "checkout.html";

                return;
            }

        }
    );

}


/*========================================================
 LISTEN FOR CART CHANGES
========================================================*/

function setupCartStorageSync() {


    /*
     * When another page changes the cart,
     * refresh this page automatically.
     */

    window.addEventListener(
        "fash:cart-updated",
        function () {

            renderFashCart();

            updateCartCounter();

        }
    );


    /*
     * Handles changes made from another tab.
     */

    window.addEventListener(
        "storage",
        function (event) {

            if (
                event.key ===
                CART_CONFIG.storageKey
            ) {

                renderFashCart();

                updateCartCounter();

            }

        }
    );

}


/*========================================================
 INITIALIZE CART
========================================================*/

function setupFashCart() {

    /*
     * IMPORTANT:
     * Render immediately when the page loads.
     * This prevents the cart showing 0 until
     * the user manually refreshes.
     */

    renderFashCart();

    updateCartCounter();

    setupCartEvents();

    setupCartStorageSync();


    /*
     * Public API
     */

    window.FASHCart = {

        getCart: getFashCart,

        saveCart: saveFashCart,

        render: renderFashCart,

        addQuantity: id =>
            changeCartQuantity(id, 1),

        remove: removeFromFashCart,

        clear: clearFashCart,

        updateCounter: updateCartCounter

    };

}


/*========================================================
 START
========================================================*/

if (
    document.readyState === "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        setupFashCart,
        { once: true }
    );

} else {

    setupFashCart();

}