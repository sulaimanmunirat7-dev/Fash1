document.addEventListener("DOMContentLoaded",()=>console.log("FASH Seller Payouts ready"));
