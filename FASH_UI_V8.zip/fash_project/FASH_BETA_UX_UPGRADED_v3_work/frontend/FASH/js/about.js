"use strict";

document.addEventListener("DOMContentLoaded", () => {

    const sections = document.querySelectorAll(
        ".about-section, .future-section"
    );

    const observer = new IntersectionObserver(
        entries => {

            entries.forEach(entry => {

                if (!entry.isIntersecting) {
                    return;
                }

                entry.target.classList.add("visible");

                observer.unobserve(entry.target);

            });

        },
        {
            threshold: 0.12
        }
    );

    sections.forEach(section => {

        section.classList.add("about-reveal");

        observer.observe(section);

    });

});