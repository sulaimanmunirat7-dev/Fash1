"use strict";

document.addEventListener("DOMContentLoaded", () => {

    const shopArrivals =
        document.getElementById("shopArrivals");

    const browseCategories =
        document.getElementById("browseCategories");

    const ctaShopArrivals =
        document.getElementById("ctaShopArrivals");

    const footerYear =
        document.getElementById("footerYear");

    const productButtons =
        document.querySelectorAll(".product-btn");

    const categoryCards =
        document.querySelectorAll(".category-card");


    /*==================================================
    SHOP NEW ARRIVALS
    ==================================================*/

    if (shopArrivals) {

        shopArrivals.addEventListener("click", () => {

            const products =
                document.querySelector(".arrival-grid");

            if (products) {

                products.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });

            }

        });

    }


    /*==================================================
    BROWSE CATEGORIES
    ==================================================*/

    if (browseCategories) {

        browseCategories.addEventListener("click", () => {

            const categories =
                document.querySelector(".category-grid");

            if (categories) {

                categories.scrollIntoView({
                    behavior: "smooth",
                    block: "center"
                });

            }

        });

    }


    /*==================================================
    PRODUCT BUTTONS
    ==================================================*/

    productButtons.forEach((button) => {

        button.addEventListener("click", () => {

            const card =
                button.closest(".arrival-card");

            if (!card) return;

            const productName =
                card.querySelector("h3")?.textContent.trim();

            if (productName) {

                console.log(
                    `Selected product: ${productName}`
                );

            }

        });

    });


    /*==================================================
    CATEGORY BUTTONS
    ==================================================*/

    categoryCards.forEach((card) => {

        card.addEventListener("click", () => {

            const category =
                card.dataset.category;

            if (!category) return;

            /*
                Change this later to your real
                marketplace category URL.
            */

            window.location.href =
                `../pages/category.html?category=${encodeURIComponent(category)}`;

        });

    });


    /*==================================================
    CTA
    ==================================================*/

    if (ctaShopArrivals) {

        ctaShopArrivals.addEventListener("click", () => {

            const products =
                document.querySelector(".arrival-grid");

            if (products) {

                products.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });

            }

        });

    }


    /*==================================================
    FOOTER YEAR
    ==================================================*/

    if (footerYear) {

        footerYear.textContent =
            `© ${new Date().getFullYear()} FLASH. All rights reserved.`;

    }

});