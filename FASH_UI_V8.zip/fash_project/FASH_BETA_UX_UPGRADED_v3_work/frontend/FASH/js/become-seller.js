/* FASH SELLER REGISTRATION — 3 STEP */
(()=>{"use strict";
document.addEventListener("DOMContentLoaded",async()=>{
 const form=document.getElementById("sellerRegistrationForm"); if(!form)return;
 const $=id=>document.getElementById(id), steps=[...document.querySelectorAll(".seller-step")], dots=[...document.querySelectorAll(".step-dot")];
 let current=0;
 const setStep=n=>{current=Math.max(0,Math.min(steps.length-1,n));steps.forEach((x,i)=>x.classList.toggle("active",i===current));dots.forEach((x,i)=>x.classList.toggle("active",i<=current));};
 const required=(ids)=>ids.every(id=>String($(id)?.value||"").trim());
 document.querySelectorAll("[data-next]").forEach(b=>b.onclick=()=>{
   const ids=current===0?["legalName","sellerPhone","sellerCountry","sellerAddress","sellerCategory","idType","idNumber"]:["sellerDescription"];
   if(!required(ids))return alert("Please complete the required fields before continuing.");
   setStep(current+1);
 });
 document.querySelectorAll("[data-prev]").forEach(b=>b.onclick=()=>setStep(current-1));
 const type=$("sellerType"); const syncBusiness=()=>document.querySelectorAll(".business-only").forEach(x=>x.style.display=type.value==="business"?"flex":"none"); type?.addEventListener("change",syncBusiness);syncBusiness();
 try{
   const {user}=await FASH_API.api("/api/auth/me");
   $("sellerEmail").value=user.email||""; $("legalName").value=user.full_name||"";
   const existing=await FASH_API.api("/api/seller-applications/me").catch(()=>null);
   if(existing?.application){
     const a=existing.application;
     if(a.status==="rejected"){ alert("Your previous application was rejected. Your previous details can be reused and corrected before reapplying."); }
     if(a.status==="changes_requested"){
       alert("FASH requested changes to your seller application. Review the requested changes and resubmit.");
     }
     $("sellerBusiness").value=a.business_name||"";$("sellerDescription").value=a.business_description||"";
     $("sellerCategory").value=a.category||"";$("sellerPhone").value=a.phone||"";
     $("sellerAddress").value=a.address||a.location||"";$("sellerCountry").value=a.country||"Nigeria";
     $("storeName").value=a.store_name||"";$("storeDescription").value=a.store_description||"";$("storeLocation").value=a.store_location||"";
   }
 }catch(e){
   // BUGFIX (two bugs here): "fashAuthToken" is never set anywhere in the app,
   // so `!localStorage.getItem("fashAuthToken")` was always true — meaning this
   // redirected to register.html on ANY failure of /api/auth/me, including a
   // transient network hiccup, even for a genuinely logged-in seller applicant.
   // It should only redirect when the backend actually says "not authenticated".
   if(e.status===401||e.status===403)location.href="register.html";
   return;
 }
 form.addEventListener("submit",async e=>{
   e.preventDefault();
   if(!required(["storeName","storeDescription","storeLocation"]))return alert("Complete your store setup.");
   const b=$("sellerSubmit");b.disabled=true;
   try{
     const data=await FASH_API.api("/api/seller-applications",{method:"POST",body:JSON.stringify({
       sellerType:type.value,businessName:$("sellerBusiness").value.trim()||$("storeName").value.trim(),
       legalName:$("legalName").value.trim(),phone:$("sellerPhone").value.trim(),category:$("sellerCategory").value.trim(),
       address:$("sellerAddress").value.trim(),location:$("sellerAddress").value.trim(),country:$("sellerCountry").value.trim(),
       idType:$("idType").value,idNumber:$("idNumber").value.trim(),businessRegistrationNumber:$("businessRegistrationNumber").value.trim(),
       businessDescription:$("sellerDescription").value.trim(),achievementNotes:$("achievementNotes").value.trim(),
       storeName:$("storeName").value.trim(),storeDescription:$("storeDescription").value.trim(),storeLocation:$("storeLocation").value.trim()
     })});
     localStorage.setItem("fashWelcomeMessage",`Welcome to FASH, ${$("legalName").value.trim()}!`);
     alert("Application submitted. You are Seller — Pending. Admin verification is separate.");
     location.href="../seller/dashboard.html";
   }catch(err){alert(err.message||"Could not submit application.");}finally{b.disabled=false;}
 });
});
})();