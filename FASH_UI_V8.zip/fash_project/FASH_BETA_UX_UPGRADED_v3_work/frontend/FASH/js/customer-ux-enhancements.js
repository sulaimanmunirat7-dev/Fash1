/* FASH Customer Experience v8 — search, saved items, feedback and resilience */
(function(){
  'use strict';
  const CART='fash_cart', WISH='fash_wishlist', RECENT='fash_recent_searches';
  const safe=(k,d=[])=>{try{const v=JSON.parse(localStorage.getItem(k));return Array.isArray(v)?v:d}catch{return d}};
  const notify=(msg)=>{let e=document.querySelector('.fash-global-toast');if(!e){e=document.createElement('div');e.className='fash-global-toast';document.body.appendChild(e);Object.assign(e.style,{position:'fixed',right:'18px',bottom:'18px',zIndex:99999,background:'#111',color:'#fff',padding:'12px 16px',borderRadius:'12px',boxShadow:'0 10px 30px rgba(0,0,0,.18)',opacity:'0',transition:'opacity .2s'});}e.textContent=msg;e.style.opacity='1';clearTimeout(window.__fashGlobalToast);window.__fashGlobalToast=setTimeout(()=>e.style.opacity='0',2200)};
  window.FASHUX={notify};
  async function sync(){
    if(!window.FASH_API) return;
    try{
      /* BUGFIX: FASH_API.me() doesn't exist (only getCurrentUser() does), so this
         optional-chained call always silently returned undefined, meaning guest
         cart/wishlist items never got synced to the account after login. */
      const me=await window.FASH_API.getCurrentUser?.().catch(()=>null); if(!me) return;
      for(const item of safe(CART)) try{await window.FASH_API.addCartItem(item.id,item.quantity||1)}catch{}
      for(const id of safe(WISH)) try{await window.FASH_API.addWishlistItem(typeof id==='object'?id.id:id)}catch{}
      const remote=await window.FASH_API.getWishlist?.(); const ids=(remote?.items||[]).map(x=>x.product_id||x.id); if(ids.length)localStorage.setItem(WISH,JSON.stringify([...new Set([...safe(WISH).map(x=>typeof x==='object'?x.id:x),...ids])]))
      window.dispatchEvent(new CustomEvent('fash:data-synced'));
    }catch{}
  }
  window.addEventListener('fash:navbar-ready',()=>setTimeout(sync,300));
  document.addEventListener('click',e=>{
    const w=e.target.closest('[data-wishlist-toggle]');
    if(w) setTimeout(()=>{const saved=localStorage.getItem(WISH);if(saved) sync();},0);
  });
})();
