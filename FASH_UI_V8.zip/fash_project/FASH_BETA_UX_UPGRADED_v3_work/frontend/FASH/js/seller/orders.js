/*==================================================
FASH SELLER
ORDERS PAGE
PART 1
INITIALIZATION & STATISTICS
==================================================*/

/*==============================
ELEMENTS
==============================*/

const ordersTable =
document.getElementById("ordersTable");

const totalOrders =
document.getElementById("totalOrders");

const pendingOrders =
document.getElementById("pendingOrders");

const completedOrders =
document.getElementById("completedOrders");

const totalRevenue =
document.getElementById("totalRevenue");

const totalOrdersFooter =
document.getElementById("totalOrdersFooter");

const showingOrders =
document.getElementById("showingOrders");

const searchOrder =
document.getElementById("searchOrder");

const statusFilter =
document.getElementById("statusFilter");

const paymentFilter =
document.getElementById("paymentFilter");

const sortOrders =
document.getElementById("sortOrders");

/*==============================
VARIABLES
==============================*/

let orders = JSON.parse(

    localStorage.getItem("fashOrders")

) || [];

let filteredOrders = [...orders];

let currentPage = 1;

const rowsPerPage = 10;

/*==============================
INITIALIZE
==============================*/

document.addEventListener(

    "DOMContentLoaded",

    initializeOrders

);

function initializeOrders(){

    updateStatistics();

    renderOrders();

    console.log(

        "FASH Orders Ready 🚀"

    );

}

/*==============================
STATISTICS
==============================*/

function updateStatistics(){

    totalOrders.textContent =

        orders.length;

    pendingOrders.textContent =

        orders.filter(

            order =>

            order.status === "pending"

        ).length;

    completedOrders.textContent =

        orders.filter(

            order =>

            order.status === "delivered"

        ).length;

    const revenue = orders.reduce(

        (sum, order) =>

        sum + Number(order.total || 0),

        0

    );

    totalRevenue.textContent =

        "₦" +

        revenue.toLocaleString();

}
/*==================================================
FASH SELLER
ORDERS PAGE
PART 2
RENDER ORDERS
==================================================*/

/*==============================
RENDER ORDERS
==============================*/

function renderOrders(){

    if(!ordersTable) return;

    ordersTable.innerHTML = "";

    const start =

        (currentPage - 1) * rowsPerPage;

    const end =

        start + rowsPerPage;

    const pageOrders =

        filteredOrders.slice(start, end);

    if(pageOrders.length === 0){

        ordersTable.innerHTML = `

        <tr>

            <td colspan="9"

            class="empty-state">

                <i class="fa-solid fa-cart-shopping"></i>

                <h3>

                    No Orders Found

                </h3>

                <p>

                    Orders will appear here when customers place them.

                </p>

            </td>

        </tr>

        `;

        showingOrders.textContent = "0";

        totalOrdersFooter.textContent = "0";

        return;

    }

    pageOrders.forEach(order=>{

        createOrderRow(order);

    });

    showingOrders.textContent =

        pageOrders.length;

    totalOrdersFooter.textContent =

        filteredOrders.length;

}

/*==============================
CREATE ORDER ROW
==============================*/

function createOrderRow(order){

    const row = document.createElement("tr");

    row.innerHTML = `

    <td>

        <input

        type="checkbox"

        class="order-check"

        data-id="${order.id}">

    </td>

    <td>

        <span class="order-id">

            #${order.id}

        </span>

    </td>

    <td>

        <div class="customer-info">

            <img

            src="${order.customerImage || '../images/avatar.png'}"

            class="customer-avatar"

            alt="Customer">

            <div class="customer-details">

                <h4>

                    ${order.customerName}

                </h4>

                <span>

                    ${order.customerEmail}

                </span>

            </div>

        </div>

    </td>

    <td>

        ${order.items}

    </td>

    <td class="order-price">

        ₦${Number(order.total).toLocaleString()}

    </td>

    <td>

        <span class="status-badge status-${order.status}">

            ${order.status}

        </span>

    </td>

    <td>

        <span class="status-badge payment-${order.payment}">

            ${order.payment}

        </span>

    </td>

    <td>

        ${formatDate(order.date)}

    </td>

    <td>

        <div class="action-buttons">

            <button

            class="view-btn"

            onclick="viewOrder(${order.id})">

                <i class="fa-solid fa-eye"></i>

            </button>

            <button

            class="edit-btn"

            onclick="editOrder(${order.id})">

                <i class="fa-solid fa-pen"></i>

            </button>

            <button

            class="delete-btn"

            onclick="deleteOrder(${order.id})">

                <i class="fa-solid fa-trash"></i>

            </button>

        </div>

    </td>

    `;

    ordersTable.appendChild(row);

}

/*==============================
FORMAT DATE
==============================*/

function formatDate(date){

    return new Date(date)

    .toLocaleDateString(

        "en-GB",

        {

            day:"2-digit",

            month:"short",

            year:"numeric"

        }

    );

}
/*==================================================
FASH SELLER
ORDERS PAGE
PART 3
SEARCH • FILTER • SORT • REFRESH
==================================================*/

/*==============================
FILTER ORDERS
==============================*/

function filterOrders(){

    const search =

        searchOrder.value

        .trim()

        .toLowerCase();

    const status =

        statusFilter.value;

    const payment =

        paymentFilter.value;

    filteredOrders = orders.filter(order=>{

        const matchesSearch =

            order.customerName

            .toLowerCase()

            .includes(search)

            ||

            order.customerEmail

            .toLowerCase()

            .includes(search)

            ||

            String(order.id)

            .includes(search);

        const matchesStatus =

            status === ""

            ||

            order.status === status;

        const matchesPayment =

            payment === ""

            ||

            order.payment === payment;

        return(

            matchesSearch &&

            matchesStatus &&

            matchesPayment

        );

    });

    currentPage = 1;

    sortCurrentOrders();

}

/*==============================
SORT ORDERS
==============================*/

function sortCurrentOrders(){

    if(!sortOrders){

        renderOrders();

        return;

    }

    switch(sortOrders.value){

        case "oldest":

            filteredOrders.sort(

                (a,b)=>

                new Date(a.date)-

                new Date(b.date)

            );

            break;

        case "highest":

            filteredOrders.sort(

                (a,b)=>

                b.total-a.total

            );

            break;

        case "lowest":

            filteredOrders.sort(

                (a,b)=>

                a.total-b.total

            );

            break;

        case "customer":

            filteredOrders.sort(

                (a,b)=>

                a.customerName.localeCompare(

                    b.customerName

                )

            );

            break;

        default:

            filteredOrders.sort(

                (a,b)=>

                new Date(b.date)-

                new Date(a.date)

            );

    }

    renderOrders();

}

/*==============================
SEARCH
==============================*/

if(searchOrder){

    searchOrder.addEventListener(

        "input",

        filterOrders

    );

}

/*==============================
STATUS FILTER
==============================*/

if(statusFilter){

    statusFilter.addEventListener(

        "change",

        filterOrders

    );

}

/*==============================
PAYMENT FILTER
==============================*/

if(paymentFilter){

    paymentFilter.addEventListener(

        "change",

        filterOrders

    );

}

/*==============================
SORT
==============================*/

if(sortOrders){

    sortOrders.addEventListener(

        "change",

        sortCurrentOrders

    );

}

/*==============================
REFRESH
==============================*/

const refreshBtn =

document.querySelector(

    ".refresh-btn"

);

if(refreshBtn){

    refreshBtn.addEventListener(

        "click",

        function(){

            orders = JSON.parse(

                localStorage.getItem(

                    "fashOrders"

                )

            ) || [];

            filteredOrders =

            [...orders];

            currentPage = 1;

            updateStatistics();

            renderOrders();

            console.log(

                "Orders refreshed."

            );

        }

    );

}
/*==================================================
FASH SELLER
ORDERS PAGE
PART 4
VIEW • EDIT • DELETE • BULK ACTIONS
==================================================*/

/*==============================
VIEW ORDER
==============================*/

function viewOrder(id){

    const order = orders.find(

        order => order.id === id

    );

    if(!order){

        alert(

            "Order not found."

        );

        return;

    }

    alert(

`Order #${order.id}

Customer: ${order.customerName}

Email: ${order.customerEmail}

Items: ${order.items}

Total: ₦${Number(order.total).toLocaleString()}

Status: ${order.status}

Payment: ${order.payment}`

    );

}

/*==============================
EDIT ORDER
==============================*/

function editOrder(id){

    localStorage.setItem(

        "editingOrder",

        id

    );

    window.location.href =

    "edit-order.html";

}

/*==============================
DELETE ORDER
==============================*/

function deleteOrder(id){

    if(

        !confirm(

            "Delete this order?"

        )

    ){

        return;

    }

    orders = orders.filter(

        order => order.id !== id

    );

    filteredOrders = [...orders];

    localStorage.setItem(

        "fashOrders",

        JSON.stringify(orders)

    );

    updateStatistics();

    renderOrders();

}

/*==============================
SELECT ALL
==============================*/

const selectAll =

document.getElementById(

    "selectAll"

);

if(selectAll){

    selectAll.addEventListener(

        "change",

        function(){

            document

            .querySelectorAll(

                ".order-check"

            )

            .forEach(box=>{

                box.checked =

                this.checked;

            });

        }

    );

}

/*==============================
DELETE SELECTED
==============================*/

const deleteSelected =

document.getElementById(

    "deleteSelected"

);

if(deleteSelected){

    deleteSelected.addEventListener(

        "click",

        function(){

            const checked =

            document.querySelectorAll(

                ".order-check:checked"

            );

            if(

                checked.length===0

            ){

                alert(

                    "Select orders first."

                );

                return;

            }

            if(

                !confirm(

                    "Delete selected orders?"

                )

            ){

                return;

            }

            const ids = [];

            checked.forEach(box=>{

                ids.push(

                    Number(

                        box.dataset.id

                    )

                );

            });

            orders = orders.filter(

                order=>

                !ids.includes(

                    order.id

                )

            );

            filteredOrders =

            [...orders];

            localStorage.setItem(

                "fashOrders",

                JSON.stringify(orders)

            );

            updateStatistics();

            renderOrders();

        }

    );

}
/*==================================================
FASH SELLER
ORDERS PAGE
PART 5
PAGINATION
==================================================*/

/*==============================
ELEMENTS
==============================*/

const pageNumbers =

document.getElementById(

    "pageNumbers"

);

const previousPage =

document.getElementById(

    "previousPage"

);

const nextPage =

document.getElementById(

    "nextPage"

);

/*==============================
RENDER PAGINATION
==============================*/

function renderPagination(){

    if(!pageNumbers) return;

    pageNumbers.innerHTML = "";

    const totalPages = Math.ceil(

        filteredOrders.length /

        rowsPerPage

    );

    if(totalPages <= 1){

        return;

    }

    for(

        let i = 1;

        i <= totalPages;

        i++

    ){

        pageNumbers.innerHTML += `

        <button

        class="page-number

        ${currentPage===i?"active":""}"

        onclick="goToPage(${i})">

            ${i}

        </button>

        `;

    }

}

/*==============================
GO TO PAGE
==============================*/

function goToPage(page){

    currentPage = page;

    renderOrders();

}

/*==============================
PREVIOUS PAGE
==============================*/

if(previousPage){

    previousPage.addEventListener(

        "click",

        function(){

            if(currentPage > 1){

                currentPage--;

                renderOrders();

            }

        }

    );

}

/*==============================
NEXT PAGE
==============================*/

if(nextPage){

    nextPage.addEventListener(

        "click",

        function(){

            const totalPages = Math.ceil(

                filteredOrders.length /

                rowsPerPage

            );

            if(

                currentPage < totalPages

            ){

                currentPage++;

                renderOrders();

            }

        }

    );

}

/*==============================
UPDATE RENDER
==============================*/

const oldRenderOrders = renderOrders;

renderOrders = function(){

    oldRenderOrders();

    renderPagination();

};
/*==================================================
FASH SELLER
ORDERS PAGE
PART 6
FINAL IMPROVEMENTS
==================================================*/

/*==============================
REFRESH ORDERS
==============================*/

function refreshOrders(){

    orders = JSON.parse(

        localStorage.getItem(

            "fashOrders"

        )

    ) || [];

    filteredOrders = [...orders];

    currentPage = 1;

    updateStatistics();

    renderOrders();

}

/*==============================
RESET FILTERS
==============================*/

function resetFilters(){

    if(searchOrder)

        searchOrder.value = "";

    if(statusFilter)

        statusFilter.value = "";

    if(paymentFilter)

        paymentFilter.value = "";

    if(sortOrders)

        sortOrders.value = "newest";

    filteredOrders = [...orders];

    currentPage = 1;

    renderOrders();

}

/*==============================
UPDATE FOOTER
==============================*/

function updateFooter(){

    if(showingOrders)

        showingOrders.textContent =

        filteredOrders.length;

    if(totalOrdersFooter)

        totalOrdersFooter.textContent =

        orders.length;

}

/*==============================
AUTO REFRESH AFTER DELETE
==============================*/

const oldDeleteOrder = deleteOrder;

deleteOrder = function(id){

    oldDeleteOrder(id);

    refreshOrders();

};

/*==============================
AUTO REFRESH AFTER BULK DELETE
==============================*/

if(deleteSelected){

    deleteSelected.addEventListener(

        "click",

        function(){

            setTimeout(

                refreshOrders,

                200

            );

        }

    );

}

/*==============================
WINDOW FOCUS
==============================*/

window.addEventListener(

    "focus",

    refreshOrders

);

/*==============================
KEYBOARD SHORTCUTS
==============================*/

document.addEventListener(

    "keydown",

    function(e){

        if(

            e.ctrlKey &&

            e.key === "f"

        ){

            e.preventDefault();

            if(searchOrder){

                searchOrder.focus();

            }

        }

        if(

            e.key === "Escape"

        ){

            resetFilters();

        }

        if(

            e.key === "F5"

        ){

            e.preventDefault();

            refreshOrders();

        }

    }

);

/*==============================
INITIAL LOAD
==============================*/

refreshOrders();

console.log(

    "FASH Orders Ready 🚀"

);


/*==================================================
CANCEL ORDER
==================================================*/

function cancelFashOrder(orderId) {

    const orders = getFashOrders();

    const index = orders.findIndex(
        order =>
            String(order.id) === String(orderId)
    );

    if (index === -1) {

        alert("Order could not be found.");

        return;

    }

    const order = orders[index];

    const status =
        String(order.status || "processing").toLowerCase();

    /*
     * Orders can only be cancelled while
     * they are still processing or confirmed.
     */

    if (
        status !== "processing" &&
        status !== "confirmed"
    ) {

        alert(
            "This order can no longer be cancelled."
        );

        return;

    }

    const confirmed =
        window.confirm(
            `Cancel order ${order.id}?\n\n` +
            "This action cannot be undone."
        );

    if (!confirmed) {
        return;
    }

    order.status = "cancelled";

    order.cancelledAt =
        new Date().toISOString();

    localStorage.setItem(
        "fash_orders",
        JSON.stringify(orders)
    );

    renderOrders();

    alert(
        `Order ${order.id} has been cancelled.`
    );

}


/*==================================================
CANCEL ORDER BUTTONS
==================================================*/

function setupCancelOrderButtons() {

    const buttons =
        document.querySelectorAll(
            ".cancel-order-button"
        );

    buttons.forEach(
        button => {

            button.addEventListener(
                "click",
                () => {

                    cancelFashOrder(
                        button.dataset.orderId
                    );

                }
            );

        }
    );

}
