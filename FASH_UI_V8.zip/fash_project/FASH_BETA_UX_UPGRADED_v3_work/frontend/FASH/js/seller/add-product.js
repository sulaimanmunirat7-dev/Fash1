/* FASH SELLER — STORE-FIRST PRODUCT CREATION */
(function(){
"use strict";
document.addEventListener("DOMContentLoaded", async ()=>{
 const form=document.getElementById("productForm"); if(!form)return;
 const $=id=>document.getElementById(id); let imageUrl=""; let saveMode="approved";
 const buttons=[...form.querySelectorAll("button")];
 const publishButtons=[...document.querySelectorAll('[type="submit"],[data-product-action="publish"]')];
 const storeBanner=document.createElement("div"); storeBanner.id="sellerStoreGate"; storeBanner.style.cssText="margin:0 0 20px;padding:16px 18px;border-radius:14px;background:#eff6ff;border:1px solid #bfdbfe;color:#0f172a;font-weight:700";
 form.parentElement.insertBefore(storeBanner,form);
 let store=null;
 try{const d=await FASH_API.api("/api/seller/store");store=d.store||null;}catch(e){}
 if(store){
  storeBanner.innerHTML=`<strong>STORE: ${store.name}</strong><br><small>Status: ${store.status}</small>`;
 }else{
  storeBanner.innerHTML='⚠️ <strong>Create your store first.</strong> <a href="store.html">Create Store →</a>';
  publishButtons.forEach(b=>{b.disabled=true;b.title="Create a store before publishing"});
 }
 const img=document.getElementById("productImages"), preview=document.getElementById("imagePreview");
 img?.addEventListener("change",()=>{
 const f=img.files?.[0]; if(!f)return;
 if(!f.type.startsWith("image/"))return alert("Please choose an image.");
 if(f.size>12*1024*1024)return alert("Image must be 12MB or smaller.");
 const reader=new FileReader();
 reader.onload=()=>{const im=new Image();im.onload=()=>{
   const max=900, scale=Math.min(1,max/Math.max(im.width,im.height));
   const c=document.createElement("canvas");c.width=Math.max(1,Math.round(im.width*scale));c.height=Math.max(1,Math.round(im.height*scale));
   c.getContext("2d").drawImage(im,0,0,c.width,c.height);
   imageUrl=c.toDataURL("image/jpeg",.78);
   if(preview)preview.innerHTML=`<img src="${imageUrl}" alt="Product preview" style="width:220px;height:220px;object-fit:contain;border-radius:14px">`;
 };
 im.onerror=()=>alert("Could not process this image. Try JPG, PNG or WEBP.");im.src=reader.result;};
 reader.onerror=()=>alert("Could not read image.");reader.readAsDataURL(f);
});
 document.querySelectorAll("[data-save-product]").forEach(b=>b.addEventListener("click",()=>saveMode=b.dataset.saveProduct));
 document.querySelectorAll("button").forEach(b=>{if(/save draft/i.test(b.textContent))b.dataset.saveProduct="draft";if(/hidden/i.test(b.textContent))b.dataset.saveProduct="hidden";if(/publish/i.test(b.textContent))b.dataset.saveProduct="approved";if(/schedule/i.test(b.textContent))b.dataset.saveProduct="scheduled"});
 form.addEventListener("submit",async e=>{e.preventDefault();const mode=saveMode||"pending_review";if(["approved","scheduled","pending_review"].includes(mode)&&!store)return alert("Your store must exist before publishing a product.");
 const name=$("productName")?.value.trim()||"",cat=$("category")?.value.trim()||"",price=Number($("price")?.value||0),stock=Number($("stock")?.value||0),description=$("description")?.value.trim()||$("shortDescription")?.value.trim()||"";
 if(!name||!cat||price<=0||stock<0)return alert("Complete the required product information.");
 buttons.forEach(b=>b.disabled=true);
 const scheduledAt=$("scheduledAt")?.value||null; if(mode==="scheduled"&&!scheduledAt)return alert("Choose a future publish date and time."); try{await FASH_API.api("/api/products",{method:"POST",body:JSON.stringify({name,category:cat,price,stock,description,imageUrl,status:mode,scheduledAt})});alert(mode==="approved"?"Product published and is now LIVE.":mode==="scheduled"?"Product scheduled for publication.":`Product saved as ${mode}.`);location.href="products.html"}catch(err){alert(err.message||"Could not save product.")}finally{buttons.forEach(b=>b.disabled=false)}});
});
})();