/* FASH SELLER — PRODUCTS */
(function () {
  "use strict";

  const table = document.getElementById("productsTable");
  if (!table) return;

  const total = document.getElementById("totalProducts");
  const inStock = document.getElementById("inStockProducts");
  const lowStock = document.getElementById("lowStockProducts");
  const inventoryValue = document.getElementById("inventoryValue");
  const showing = document.getElementById("showingProducts");
  const footer = document.getElementById("totalProductsFooter");
  const search = document.getElementById("searchProduct");
  const category = document.getElementById("categoryFilter");
  const status = document.getElementById("statusFilter");
  const sort = document.getElementById("sortProducts");
  const selectAll = document.getElementById("selectAll");
  const deleteSelected = document.getElementById("deleteSelected");
  const exportBtn = document.getElementById("exportProducts");
  const previous = document.getElementById("previousPage");
  const next = document.getElementById("nextPage");
  const pageNumbers = document.getElementById("pageNumbers");

  let products = [];
  let filtered = [];
  let page = 1;
  const perPage = 10;

  document.addEventListener("DOMContentLoaded", init);

  async function init() {
    bind();
    await loadProducts();
  }

  async function loadProducts() {
    try {
      const data = await FASH_API.api("/api/products/my");
      products = Array.isArray(data.products) ? data.products : [];
      render();
    } catch (error) {
      console.error(error);
      table.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:30px;color:#c00">${escapeHtml(error.message)}</td></tr>`;
    }
  }

  function bind() {
    search?.addEventListener("input", () => { page = 1; render(); });
    category?.addEventListener("change", () => { page = 1; render(); });
    status?.addEventListener("change", () => { page = 1; render(); });
    sort?.addEventListener("change", () => { page = 1; render(); });
    document.querySelector(".refresh-btn")?.addEventListener("click", loadProducts);
    previous?.addEventListener("click", () => { if (page > 1) { page--; render(); } });
    next?.addEventListener("click", () => {
      const max = Math.max(1, Math.ceil(filtered.length / perPage));
      if (page < max) { page++; render(); }
    });
    selectAll?.addEventListener("change", () => {
      table.querySelectorAll('input[data-product-select]').forEach(x => x.checked = selectAll.checked);
    });
    deleteSelected?.addEventListener("click", deleteSelectedProducts);
    exportBtn?.addEventListener("click", exportProducts);
  }

  function render() {
    filtered = products.filter(p => {
      const q = (search?.value || "").trim().toLowerCase();
      const matchesSearch = !q || [p.name,p.category,p.description].some(v => String(v || "").toLowerCase().includes(q));
      const matchesCategory = !category?.value || category.value === "all" || p.category === category.value;
      const wantedStatus = status?.value || "all";
      const matchesStatus = wantedStatus === "all" || p.status === wantedStatus || (wantedStatus === "published" && p.status === "active");
      return matchesSearch && matchesCategory && matchesStatus;
    });

    const mode = sort?.value || "newest";
    filtered.sort((a,b) => {
      if (mode === "price-low") return Number(a.price)-Number(b.price);
      if (mode === "price-high") return Number(b.price)-Number(a.price);
      if (mode === "stock-low") return Number(a.stock)-Number(b.stock);
      if (mode === "stock-high") return Number(b.stock)-Number(a.stock);
      return new Date(b.created_at)-new Date(a.created_at);
    });

    const max = Math.max(1, Math.ceil(filtered.length / perPage));
    page = Math.min(page, max);
    const rows = filtered.slice((page-1)*perPage, page*perPage);

    table.innerHTML = rows.length ? rows.map(row).join("") :
      `<tr><td colspan="8" style="text-align:center;padding:35px">No products found.</td></tr>`;

    updateStats();
    updatePages(max);
    selectAll && (selectAll.checked = false);

    table.querySelectorAll("[data-edit]").forEach(btn => btn.addEventListener("click", () => editProduct(btn.dataset.edit)));
    table.querySelectorAll("[data-delete]").forEach(btn => btn.addEventListener("click", () => deleteProduct(btn.dataset.delete)));
  }

  function row(p) {
    const image = p.image_url || "../assets/images/product-placeholder.jpg";
    return `<tr>
      <td><input type="checkbox" data-product-select value="${escapeHtml(p.id)}"></td>
      <td><div style="display:flex;align-items:center;gap:10px">
        <img src="${escapeHtml(image)}" alt="" style="width:42px;height:42px;object-fit:cover;border-radius:8px">
        <div><strong>${escapeHtml(p.name)}</strong><small style="display:block">${escapeHtml(p.description || "")}</small></div>
      </div></td>
      <td>${escapeHtml(p.category)}</td>
      <td>₦${Number(p.price || 0).toLocaleString()}</td>
      <td>${Number(p.stock || 0)}</td>
      <td>${escapeHtml(p.status)}</td>
      <td>${new Date(p.created_at).toLocaleDateString()}</td>
      <td>
        <button type="button" data-edit="${escapeHtml(p.id)}">Edit</button>
        <button type="button" data-delete="${escapeHtml(p.id)}">Delete</button>
      </td>
    </tr>`;
  }

  function updateStats() {
    const stock = products.filter(p => Number(p.stock) > 0).length;
    const low = products.filter(p => Number(p.stock) > 0 && Number(p.stock) <= 10).length;
    const value = products.reduce((sum,p) => sum + Number(p.price || 0) * Number(p.stock || 0), 0);
    if (total) total.textContent = products.length;
    if (inStock) inStock.textContent = stock;
    if (lowStock) lowStock.textContent = low;
    if (inventoryValue) inventoryValue.textContent = `₦${value.toLocaleString()}`;
    if (showing) showing.textContent = filtered.length;
    if (footer) footer.textContent = products.length;
  }

  function updatePages(max) {
    if (previous) previous.disabled = page <= 1;
    if (next) next.disabled = page >= max;
    if (pageNumbers) pageNumbers.innerHTML = Array.from({length:max},(_,i) =>
      `<button type="button" class="${i+1===page?'active':''}" data-page="${i+1}">${i+1}</button>`
    ).join("");
    pageNumbers?.querySelectorAll("[data-page]").forEach(b => b.addEventListener("click",()=>{page=Number(b.dataset.page);render();}));
  }

  async function deleteProduct(id) {
    if (!confirm("Delete this product?")) return;
    try {
      await FASH_API.api(`/api/products/${encodeURIComponent(id)}`, { method:"DELETE" });
      await loadProducts();
    } catch(e) { alert(e.message); }
  }

  async function deleteSelectedProducts() {
    const ids = [...table.querySelectorAll('input[data-product-select]:checked')].map(x=>x.value);
    if (!ids.length) return alert("Select at least one product.");
    if (!confirm(`Delete ${ids.length} product(s)?`)) return;
    for (const id of ids) {
      try { await FASH_API.api(`/api/products/${encodeURIComponent(id)}`, {method:"DELETE"}); }
      catch(e) { console.error(e); }
    }
    await loadProducts();
  }

  function editProduct(id) {
    const p = products.find(x => String(x.id) === String(id));
    if (!p) return;
    localStorage.setItem("editingProduct", JSON.stringify(p));
    location.href = "add-product.html";
  }

  function exportProducts() {
    const header = ["id","name","description","price","stock","category","status","created_at"];
    const csv = [header.join(","), ...filtered.map(p => header.map(k => `"${String(p[k] ?? "").replace(/"/g,'""')}"`).join(","))].join("\n");
    const blob = new Blob([csv], {type:"text/csv;charset=utf-8"});
    const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download="fash-products.csv"; a.click(); URL.revokeObjectURL(a.href);
  }

  function escapeHtml(v) {
    return String(v ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  }
})();
