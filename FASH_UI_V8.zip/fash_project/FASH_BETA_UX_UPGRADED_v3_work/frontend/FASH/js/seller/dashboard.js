/*==================================================
FASH SELLER DASHBOARD
PART 1
LOADER • GREETING • CLOCK • CHART
==================================================*/

document.addEventListener("DOMContentLoaded", () => {

    /*=================================
    GREETING
    =================================*/

    const greeting =
        document.querySelector(".header-left h1");

    const hour =
        new Date().getHours();

    let message =
        "Welcome back 👋";

    if(hour < 12){

        message =
            "Good Morning ☀️";

    }

    else if(hour < 18){

        message =
            "Good Afternoon 🌤";

    }

    else{

        message =
            "Good Evening 🌙";

    }

    if(greeting){

        greeting.innerHTML = message;

    }

    /*=================================
    LIVE CLOCK
    =================================*/

    const clock =
        document.createElement("span");

    clock.className =
        "live-clock";

    const headerLeft = document.querySelector(".header-left");

    if(headerLeft){
        headerLeft.appendChild(clock);
    }

    function updateClock(){

        const now =
            new Date();

        clock.textContent =
            now.toLocaleString();

    }

    updateClock();

    setInterval(updateClock,1000);

    /*=================================
    SALES CHART
    =================================*/

    const chart =
        document.getElementById("salesChart");

    if(chart && typeof Chart !== "undefined"){

        new Chart(chart,{

            type:"line",

            data:{

                labels:[
                    "Jan",
                    "Feb",
                    "Mar",
                    "Apr",
                    "May",
                    "Jun",
                    "Jul",
                    "Aug",
                    "Sep",
                    "Oct",
                    "Nov",
                    "Dec"
                ],

                datasets:[{

                    label:"Revenue",

                    data:[
                        1200,
                        1800,
                        2200,
                        2800,
                        3100,
                        4000,
                        4800,
                        5500,
                        6200,
                        6900,
                        7600,
                        8500
                    ],

                    borderColor:"#7c3aed",

                    backgroundColor:"rgba(124,58,237,.12)",

                    borderWidth:4,

                    fill:true,

                    tension:.45,

                    pointRadius:5,

                    pointBackgroundColor:"#7c3aed"

                }]

            },

            options:{

                responsive:true,

                maintainAspectRatio:false,

                plugins:{

                    legend:{

                        display:false

                    }

                },

                scales:{

                    x:{

                        grid:{

                            display:false

                        }

                    },

                    y:{

                        beginAtZero:true,

                        grid:{

                            color:"#eef2f7"

                        }

                    }

                }

            }

        });

    }

});
/*==================================================
FASH SELLER DASHBOARD
PART 2
COUNTERS • SEARCH • BUTTONS • ANIMATIONS
==================================================*/

/*=================================
ANIMATED KPI COUNTERS
==================================*/

const counters =
    document.querySelectorAll(".kpi-content h2");

counters.forEach(counter => {

    const text =
        counter.innerText;

    const value =
        parseInt(text.replace(/[^0-9]/g,""));

    if(isNaN(value)) return;

    const prefix =
        text.includes("$") ? "$" : "";

    const suffix =
        text.includes("%") ? "%" :
        text.includes("+") ? "+" : "";

    let current = 0;

    const increment =
        Math.ceil(value / 80);

    const update = () => {

        current += increment;

        if(current >= value){

            current = value;

        }

        counter.innerText =
            prefix +
            current.toLocaleString() +
            suffix;

        if(current < value){

            requestAnimationFrame(update);

        }

    };

    update();

});

/*=================================
SEARCH BAR
==================================*/

const searchInput =
    document.querySelector(".search-box input");

if(searchInput){

    searchInput.addEventListener("keyup", () => {

        const value =
            searchInput.value.toLowerCase();

        document.querySelectorAll(".product-item").forEach(item => {

            const name =
                item.innerText.toLowerCase();

            item.style.display =
                name.includes(value)
                ? "flex"
                : "none";

        });

    });

}

/*=================================
HEADER BUTTONS
==================================*/

const headerButtons =
    document.querySelectorAll(".header-btn");

headerButtons.forEach((button,index)=>{

    button.addEventListener("click",()=>{

        if(index===0){

            alert("No new notifications.");

        }

        else{

            alert("No new messages.");

        }

    });

});

/*=================================
QUICK ACTIONS
==================================*/

document.querySelectorAll(".quick-card").forEach(card=>{

    card.addEventListener("mouseenter",()=>{

        card.style.transform="translateY(-8px) scale(1.03)";

    });

    card.addEventListener("mouseleave",()=>{

        card.style.transform="translateY(0) scale(1)";

    });

});

/*=================================
FADE IN CARDS
==================================*/

const observer =
    new IntersectionObserver(entries=>{

        entries.forEach(entry=>{

            if(entry.isIntersecting){

                entry.target.style.opacity="1";

                entry.target.style.transform="translateY(0)";

            }

        });

    });

document.querySelectorAll(

    ".kpi-card,.dashboard-card,.analytics-card"

).forEach(card=>{

    card.style.opacity="0";

    card.style.transform="translateY(30px)";

    card.style.transition=".6s ease";

    observer.observe(card);

});
/*==================================================
FASH SELLER DASHBOARD
PART 3
LIVE DASHBOARD FEATURES
==================================================*/

/*=================================
LAST LOGIN
==================================*/

const footer =
    document.querySelector(".dashboard-footer p");

if(footer){

    const now =
        new Date();

    footer.innerHTML +=
        `<br><small>Last Login: ${now.toLocaleString()}</small>`;

}

/*=================================
WELCOME SELLER
==================================*/

const sellerName =
    localStorage.getItem("sellerName");

if(sellerName){

    const profile =
        document.querySelector(".seller-profile h4");

    if(profile){

        profile.textContent =
            sellerName;

    }

}

/*=================================
STORE ONLINE STATUS
==================================*/

const online =
    document.querySelector(".online");

if(online){

    let status = true;

    setInterval(()=>{

        status = !status;

        if(status){

            online.innerHTML =
                "● Online";

            online.style.color =
                "#10b981";

        }

        else{

            online.innerHTML =
                "● Syncing";

            online.style.color =
                "#f59e0b";

        }

    },8000);

}

/*=================================
LIVE ACTIVITY
==================================*/

const activityList =
    document.querySelector(".activity-list");

const activities = [

    "A customer purchased iPhone 16 Pro Max.",

    "MacBook Pro inventory updated.",

    "New 5-star review received.",

    "Payout successfully processed.",

    "New customer registered.",

    "Samsung Store followed your shop."

];

if(activityList){

    setInterval(()=>{

        const first =
            activityList.firstElementChild;

        if(first){

            first.remove();

        }

        const item =
            document.createElement("div");

        item.className =
            "activity-item";

        item.innerHTML = `

            <div class="activity-icon green">

                <i class="fa-solid fa-bolt"></i>

            </div>

            <div class="activity-content">

                <h4>

                    Live Activity

                </h4>

                <p>

                    ${activities[Math.floor(Math.random()*activities.length)]}

                </p>

            </div>

            <span>

                Just Now

            </span>

        `;

        activityList.appendChild(item);

    },7000);

}

/*=================================
SAVE SEARCH
==================================*/

if(searchInput){

    searchInput.value =
        localStorage.getItem("dashboardSearch") || "";

    searchInput.addEventListener("input",()=>{

        localStorage.setItem(

            "dashboardSearch",

            searchInput.value

        );

    });

}

/*=================================
PAGE VISITS
==================================*/

let visits =
    Number(localStorage.getItem("dashboardVisits")) || 0;

visits++;

localStorage.setItem(

    "dashboardVisits",

    visits

);

console.log(

    "Dashboard Visits:",

    visits

);

/*=================================
REFRESH DATA
==================================*/

setInterval(()=>{

    console.log(

        "Refreshing dashboard data..."

    );

},30000);

/*=================================
LOGOUT
==================================*/

const logout =
    document.querySelector(

        '.sidebar-bottom a[href="../pages/login.html"]'

    );

if(logout){

    logout.addEventListener("click",(e)=>{

        e.preventDefault();

        if(confirm("Are you sure you want to logout?")){

            localStorage.removeItem("loggedIn");

            window.location.href =
                "../pages/login.html";

        }

    });

}

/*=================================
END
==================================*/

console.log(

    "FASH Seller Dashboard Loaded Successfully."

);
/*==================================================
FASH SELLER DASHBOARD
PART 4
REAL DASHBOARD INTERACTIONS
==================================================*/

/*=================================
TODAY'S DATE
==================================*/

const dateElement = document.querySelector(".current-date");

if(dateElement){

    const today = new Date();

    dateElement.textContent =
        today.toLocaleDateString(undefined,{
            weekday:"long",
            year:"numeric",
            month:"long",
            day:"numeric"
        });

}

/*=================================
NOTIFICATION BADGE
==================================*/

const notificationBadge =
    document.querySelector(".notification-count");

if(notificationBadge){

    let notifications = 3;

    notificationBadge.textContent = notifications;

    notificationBadge.parentElement.addEventListener("click",()=>{

        notifications = 0;

        notificationBadge.textContent = "";

        alert("All notifications marked as read.");

    });

}

/*=================================
RANDOM REVENUE UPDATE
==================================*/

const revenueCard =
    document.querySelector(".revenue h2");

if(revenueCard){

    setInterval(()=>{

        const current = Number(
            revenueCard.textContent.replace(/[^0-9]/g,"")
        );

        const increase =
            Math.floor(Math.random()*40)+10;

        revenueCard.textContent =
            "$" + (current + increase).toLocaleString();

    },15000);

}

/*=================================
TABLE ROW HIGHLIGHT
==================================*/

document.querySelectorAll(".orders-table tbody tr")
.forEach(row=>{

    row.addEventListener("click",()=>{

        document.querySelectorAll(".orders-table tbody tr")
        .forEach(r=>r.classList.remove("selected"));

        row.classList.add("selected");

    });

});

/*=================================
WELCOME MESSAGE
==================================*/

setTimeout(()=>{

    console.log(
        "Welcome to the FASH Seller Dashboard."
    );

},1000);

/*=================================
END
==================================*/

console.log("Dashboard Ready.");