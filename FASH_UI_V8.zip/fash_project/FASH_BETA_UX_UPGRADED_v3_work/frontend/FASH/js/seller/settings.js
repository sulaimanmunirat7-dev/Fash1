/*==================================================
FASH SELLER
SETTINGS
PART 1
INITIALIZATION
==================================================*/

/*==============================
ELEMENTS
==============================*/

const settingsForm =
document.getElementById("settingsForm");

const saveButton =
document.getElementById("saveSettings");

const logoInput =
document.getElementById("storeLogo");

const logoPreview =
document.getElementById("logoPreview");

/*==============================
THEME
==============================*/

const themeButtons =
document.querySelectorAll(".theme-btn");

const themeThumb =
document.querySelector(".theme-thumb");

const themePositions={

    system:"5px",

    light:"111px",

    dark:"217px"

};

/*==============================
LOAD SETTINGS
==============================*/

let settings=

JSON.parse(

localStorage.getItem(

"fashSettings"

)

)||{};

let currentTheme=

localStorage.getItem(

"fashTheme"

)||"system";

/*==============================
INITIALIZE
==============================*/

document.addEventListener(

"DOMContentLoaded",

initializeSettings

);

async function initializeSettings(){

    loadSettings();

    applyTheme(currentTheme);

    if (window.FASH_API) {
        try {
            const result = await window.FASH_API.api("/api/seller/store");
            if (result.store) {
                const store = result.store;
                const map = {
                    storeName: store.name || "",
                    storeDescription: store.description || "",
                    businessAddress: store.location || ""
                };
                Object.entries(map).forEach(([id,value]) => {
                    const field=document.getElementById(id);
                    if(field && value) field.value=value;
                });
                localStorage.setItem("fashStoreProfile", JSON.stringify(store));
            }
        } catch (error) {
            // Pending/non-approved sellers may not have store access yet.
            console.info("No synced store profile yet.");
        }
    }

    console.log("Settings Ready 🚀");

}
/*==================================================
FASH SELLER
SETTINGS
PART 2
LOAD & SAVE SETTINGS
==================================================*/

/*==============================
LOAD SETTINGS
==============================*/

function loadSettings(){

    if(!settings) return;

    document.querySelectorAll(

        "#settingsForm input, #settingsForm textarea, #settingsForm select"

    ).forEach(field=>{

        if(field.type==="file") return;

        if(field.type==="checkbox"){

            if(settings[field.id]!==undefined){

                field.checked=settings[field.id];

            }

        }

        else{

            if(settings[field.id]!==undefined){

                field.value=settings[field.id];

            }

        }

    });

    if(settings.storeLogo){

        logoPreview.innerHTML=`

            <img

            src="${settings.storeLogo}"

            alt="Store Logo">

        `;

    }

}

/*==============================
SAVE SETTINGS
==============================*/

async function saveSettings(){

    const data={};

    document.querySelectorAll(

        "#settingsForm input, #settingsForm textarea, #settingsForm select"

    ).forEach(field=>{

        if(field.type==="file") return;

        if(field.type==="checkbox"){

            data[field.id]=field.checked;

        }

        else{

            data[field.id]=field.value;

        }

    });

    if(settings.storeLogo){

        data.storeLogo=settings.storeLogo;

    }

    localStorage.setItem(

        "fashSettings",

        JSON.stringify(data)

    );

    settings=data;

    // Persist the seller's public store profile in PostgreSQL.
    if (window.FASH_API && (data.storeName || data.store_name)) {
        try {
            const store = await window.FASH_API.api("/api/seller/store", {
                method: "POST",
                body: JSON.stringify({
                    name: data.storeName || data.store_name,
                    description: data.storeDescription || data.description || "",
                    location: data.businessAddress || data.storeLocation || data.location || "",
                    logoUrl: data.storeLogo || null,
                    bannerUrl: data.storeBanner || null
                })
            });
            if (store?.store) localStorage.setItem("fashStoreProfile", JSON.stringify(store.store));
        } catch (error) {
            console.error("STORE PROFILE SAVE ERROR:", error);
            alert("Store settings were saved locally, but the public store could not be synced. Please try again.");
            return;
        }
    }

    alert("✅ Settings Saved Successfully!");

}

/*==============================
SAVE BUTTON
==============================*/

saveButton.addEventListener(

    "click",

    function(e){

        e.preventDefault();

        saveSettings();

    }

);
/*==================================================
FASH SELLER
SETTINGS
PART 3
LOGO UPLOAD & PREVIEW
==================================================*/

/*==============================
UPLOAD LOGO
==============================*/

if(logoInput){

    logoInput.addEventListener(

        "change",

        function(e){

            const file =

            e.target.files[0];

            if(!file){

                return;

            }

            if(

                !file.type.startsWith(

                    "image/"

                )

            ){

                alert(

                    "Please select an image."

                );

                return;

            }

            const reader =

            new FileReader();

            reader.onload =

            function(event){

                const image =

                event.target.result;

                settings.storeLogo =

                image;

                logoPreview.innerHTML =

                `

                <img

                src="${image}"

                alt="Store Logo">

                `;

            };

            reader.readAsDataURL(

                file

            );

        }

    );

}

/*==============================
REMOVE LOGO
==============================*/

const removeLogoButton =

document.getElementById(

    "removeLogo"

);

if(removeLogoButton){

    removeLogoButton.addEventListener(

        "click",

        function(){

            delete settings.storeLogo;

            logoInput.value = "";

            logoPreview.innerHTML =

            `

            <i class="fa-solid fa-store"></i>

            `;

        }

    );

}

/*==============================
AUTO SAVE LOGO
==============================*/

window.addEventListener(

    "beforeunload",

    function(){

        localStorage.setItem(

            "fashSettings",

            JSON.stringify(settings)

        );

    }

);

console.log(

    "Logo Upload Ready 🚀"

);
/*==================================================
FASH SELLER
SETTINGS
PART 4
THEME TOGGLE
==================================================*/

/*==============================
THEME TOGGLE
==============================*/

const positions = themePositions;

/*==============================
LOAD SAVED THEME
==============================*/

const savedTheme=

localStorage.getItem(

    "fashTheme"

)||"system";

applyTheme(savedTheme);

/*==============================
BUTTON EVENTS
==============================*/

themeButtons.forEach(button=>{

    button.addEventListener(

        "click",

        function(){

            applyTheme(

                this.dataset.theme

            );

        }

    );

});

/*==============================
APPLY THEME
==============================*/

function applyTheme(theme){

    themeButtons.forEach(btn=>{

        btn.classList.remove(

            "active"

        );

    });

    const activeButton=

    document.querySelector(

        `.theme-btn[data-theme="${theme}"]`

    );

    if(activeButton){

        activeButton.classList.add(

            "active"

        );

    }

    if(themeThumb){

        themeThumb.style.left=

        themePositions[theme];

    }

    document.body.classList.remove(

        "dark-theme"

    );

    if(theme==="dark"){

        document.body.classList.add(

            "dark-theme"

        );

    }

    if(theme==="system"){

        if(

            window.matchMedia(

                "(prefers-color-scheme: dark)"

            ).matches

        ){

            document.body.classList.add(

                "dark-theme"

            );

        }

    }

    localStorage.setItem(

        "fashTheme",

        theme

    );

}

/*==============================
SYSTEM THEME CHANGE
==============================*/

window.matchMedia(

    "(prefers-color-scheme: dark)"

).addEventListener(

    "change",

    function(){

        if(

            localStorage.getItem(

                "fashTheme"

            )==="system"

        ){

            applyTheme("system");

        }

    }

);

console.log(

    "Theme Toggle Ready 🚀"

);
/*==================================================
FASH SELLER
SETTINGS
PART 5
RESET • EXPORT • CLEAR DATA
==================================================*/

/*==============================
BUTTONS
==============================*/

const resetSettingsBtn =
document.getElementById("resetSettings");

const exportSettingsBtn =
document.getElementById("exportSettings");

const clearDataBtn =
document.getElementById("clearSellerData");

/*==============================
RESET SETTINGS
==============================*/

if(resetSettingsBtn){

    resetSettingsBtn.addEventListener(

        "click",

        function(){

            if(

                !confirm(

                    "Reset all settings to default?"

                )

            ){

                return;

            }

            localStorage.removeItem(

                "fashSettings"

            );

            localStorage.removeItem(

                "fashTheme"

            );

            location.reload();

        }

    );

}

/*==============================
EXPORT SETTINGS
==============================*/

if(exportSettingsBtn){

    exportSettingsBtn.addEventListener(

        "click",

        function(){

            const settingsData =

            localStorage.getItem(

                "fashSettings"

            ) || "{}";

            const blob =

            new Blob(

                [settingsData],

                {

                    type:"application/json"

                }

            );

            const url =

            URL.createObjectURL(blob);

            const link =

            document.createElement("a");

            link.href = url;

            link.download =

            "fash-settings.json";

            link.click();

            URL.revokeObjectURL(url);

        }

    );

}

/*==============================
CLEAR SELLER DATA
==============================*/

if(clearDataBtn){

    clearDataBtn.addEventListener(

        "click",

        function(){

            const answer =

            confirm(

                "Delete ALL seller data?\n\nProducts, Orders, Customers, Analytics, Payouts and Settings will be removed."

            );

            if(!answer){

                return;

            }

            localStorage.removeItem(

                "fashProducts"

            );

            localStorage.removeItem(

                "fashOrders"

            );

            localStorage.removeItem(

                "fashCustomers"

            );

            localStorage.removeItem(

                "fashPayouts"

            );

            localStorage.removeItem(

                "fashAnalytics"

            );

            localStorage.removeItem(

                "fashSettings"

            );

            localStorage.removeItem(

                "fashTheme"

            );

            alert(

                "Seller data cleared successfully."

            );

            location.reload();

        }

    );

}

/*==============================
FINISH
==============================*/

console.log(

    "FASH Settings Loaded Successfully 🚀"

);