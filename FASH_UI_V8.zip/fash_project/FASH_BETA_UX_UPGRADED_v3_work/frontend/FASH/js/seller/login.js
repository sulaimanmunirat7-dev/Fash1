document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("sellerLoginForm");
  const email = document.getElementById("sellerLoginEmail");
  const password = document.getElementById("sellerLoginPassword");
  const button = document.getElementById("sellerLoginButton");
  const message = document.getElementById("sellerLoginMessage");

  form?.addEventListener("submit", async (e) => {
    e.preventDefault();

    if (message) message.textContent = "";
    if (button) {
      button.disabled = true;
      button.textContent = "Signing in...";
    }

    try {
      // The backend uses the normal login endpoint.
      const data = await FASH_API.api("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({
          email: email?.value.trim() || "",
          password: password?.value || ""
        })
      });

      FASH_API.saveSession(data.user, data.token);

      const role = String(data.user?.role || "").toLowerCase();
      const sellerStatus = String(data.user?.seller_status || "none").toLowerCase();

      if (role === "admin" || (role === "seller" && sellerStatus === "approved")) {
        window.location.href = "../seller/dashboard.html";
        return;
      }

      if (role === "seller") {
        window.location.href = "../seller/dashboard.html";
        return;
      }

      if (message) {
        message.textContent = "This account does not have seller access.";
      }
      FASH_API.clearSession();

    } catch (err) {
      console.error("SELLER LOGIN ERROR:", err);
      if (message) {
        message.textContent = err.message || "Seller login failed.";
      }
    } finally {
      if (button) {
        button.disabled = false;
        button.textContent = "Sign in as Seller";
      }
    }
  });
});
