/*==================================================
FASH SELLER
CUSTOMERS PAGE
PART 1
INITIALIZATION
==================================================*/

/*==============================
ELEMENTS
==============================*/

const customersTable =
document.getElementById("customersTable");

const totalCustomers =
document.getElementById("totalCustomers");

const activeCustomers =
document.getElementById("activeCustomers");

const vipCustomers =
document.getElementById("vipCustomers");

const totalRevenue =
document.getElementById("totalRevenue");

const showingCustomers =
document.getElementById("showingCustomers");

const totalCustomersFooter =
document.getElementById("totalCustomersFooter");

const searchCustomer =
document.getElementById("searchCustomer");

const statusFilter =
document.getElementById("statusFilter");

const sortCustomers =
document.getElementById("sortCustomers");

/*==============================
VARIABLES
==============================*/

let customers =
JSON.parse(
localStorage.getItem("fashCustomers")
) || [];

let filteredCustomers =
[...customers];

let currentPage = 1;

const rowsPerPage = 10;

/*==============================
INITIALIZE
==============================*/

document.addEventListener(
"DOMContentLoaded",
initializeCustomers
);

function initializeCustomers(){

    updateStatistics();

    renderCustomers();

    console.log(
        "FASH Customers Ready 🚀"
    );

}

/*==============================
STATISTICS
==============================*/

function updateStatistics(){

    totalCustomers.textContent =
    customers.length;

    activeCustomers.textContent =
    customers.filter(
        customer =>
        customer.status === "active"
    ).length;

    vipCustomers.textContent =
    customers.filter(
        customer =>
        customer.status === "vip"
    ).length;

    const revenue =
    customers.reduce(

        (sum, customer)=>

        sum +

        (Number(customer.totalSpent)||0),

        0

    );

    totalRevenue.textContent =
    "₦" + revenue.toLocaleString();

}
/*==================================================
FASH SELLER
CUSTOMERS PAGE
PART 2
RENDER CUSTOMERS
==================================================*/

/*==============================
RENDER CUSTOMERS
==============================*/

function renderCustomers(){

    if(!customersTable) return;

    customersTable.innerHTML = "";

    const start =
    (currentPage - 1) * rowsPerPage;

    const end =
    start + rowsPerPage;

    const pageCustomers =
    filteredCustomers.slice(start, end);

    if(pageCustomers.length === 0){

        customersTable.innerHTML = `

        <tr>

            <td colspan="8" class="empty-state">

                <i class="fa-solid fa-users"></i>

                <h3>

                    No Customers Found

                </h3>

                <p>

                    Customers will appear here when they place orders.

                </p>

            </td>

        </tr>

        `;

        showingCustomers.textContent = 0;

        totalCustomersFooter.textContent = 0;

        return;

    }

    pageCustomers.forEach(customer=>{

        createCustomerRow(customer);

    });

    showingCustomers.textContent =
    pageCustomers.length;

    totalCustomersFooter.textContent =
    filteredCustomers.length;

}

/*==============================
CREATE CUSTOMER ROW
==============================*/

function createCustomerRow(customer){

    const statusClass =

        customer.status === "vip"

        ? "status-vip"

        : customer.status === "active"

        ? "status-active"

        : "status-inactive";

    const avatar =

        customer.avatar ||

        "../images/avatar.png";

    customersTable.innerHTML += `

    <tr>

        <td>

            <input

            type="checkbox"

            class="customer-check"

            data-id="${customer.id}">

        </td>

        <td>

            <div class="customer-info">

                <img

                src="${avatar}"

                class="customer-avatar"

                alt="${customer.name}">

                <div class="customer-details">

                    <h4>

                        ${customer.name}

                    </h4>

                    <span>

                        ${customer.email}

                    </span>

                    <small>

                        ${customer.phone || "-"}

                    </small>

                </div>

            </div>

        </td>

        <td>

            ${customer.orders || 0}

        </td>

        <td class="spent">

            ₦${Number(customer.totalSpent || 0).toLocaleString()}

        </td>

        <td>

            <span class="status-badge ${statusClass}">

                ${customer.status}

            </span>

        </td>

        <td>

            ${formatDate(customer.createdAt)}

        </td>

        <td>

            <div class="action-buttons">

                <button

                class="view-btn"

                onclick="viewCustomer(${customer.id})">

                    <i class="fa-solid fa-eye"></i>

                </button>

                <button

                class="edit-btn"

                onclick="editCustomer(${customer.id})">

                    <i class="fa-solid fa-pen"></i>

                </button>

                <button

                class="delete-btn"

                onclick="deleteCustomer(${customer.id})">

                    <i class="fa-solid fa-trash"></i>

                </button>

            </div>

        </td>

    </tr>

    `;

}

/*==============================
FORMAT DATE
==============================*/

function formatDate(date){

    if(!date) return "-";

    return new Date(date)

    .toLocaleDateString(

        "en-GB",

        {

            day:"2-digit",

            month:"short",

            year:"numeric"

        }

    );

}
/*==================================================
FASH SELLER
CUSTOMERS PAGE
PART 3
SEARCH • FILTER • SORT • REFRESH
==================================================*/

/*==============================
SEARCH / FILTER
==============================*/

function filterCustomers(){

    const search =

    searchCustomer.value
    .trim()
    .toLowerCase();

    const status =

    statusFilter.value;

    filteredCustomers = customers.filter(customer=>{

        const matchesSearch =

            customer.name
            .toLowerCase()
            .includes(search)

            ||

            customer.email
            .toLowerCase()
            .includes(search)

            ||

            (customer.phone || "")
            .toLowerCase()
            .includes(search);

        const matchesStatus =

            status === ""

            ||

            customer.status === status;

        return (

            matchesSearch &&

            matchesStatus

        );

    });

    currentPage = 1;

    sortCurrentCustomers();

}

/*==============================
SORT
==============================*/

function sortCurrentCustomers(){

    switch(sortCustomers.value){

        case "name":

            filteredCustomers.sort(

                (a,b)=>

                a.name.localeCompare(b.name)

            );

            break;

        case "spent-high":

            filteredCustomers.sort(

                (a,b)=>

                (b.totalSpent||0) -

                (a.totalSpent||0)

            );

            break;

        case "spent-low":

            filteredCustomers.sort(

                (a,b)=>

                (a.totalSpent||0) -

                (b.totalSpent||0)

            );

            break;

        case "orders":

            filteredCustomers.sort(

                (a,b)=>

                (b.orders||0) -

                (a.orders||0)

            );

            break;

        case "oldest":

            filteredCustomers.sort(

                (a,b)=>

                new Date(a.createdAt) -

                new Date(b.createdAt)

            );

            break;

        default:

            filteredCustomers.sort(

                (a,b)=>

                new Date(b.createdAt) -

                new Date(a.createdAt)

            );

    }

    renderCustomers();

}

/*==============================
EVENTS
==============================*/

if(searchCustomer){

    searchCustomer.addEventListener(

        "input",

        filterCustomers

    );

}

if(statusFilter){

    statusFilter.addEventListener(

        "change",

        filterCustomers

    );

}

if(sortCustomers){

    sortCustomers.addEventListener(

        "change",

        sortCurrentCustomers

    );

}

/*==============================
REFRESH BUTTON
==============================*/

const refreshBtn =

document.querySelector(

".refresh-btn"

);

if(refreshBtn){

    refreshBtn.addEventListener(

        "click",

        function(){

            customers = JSON.parse(

                localStorage.getItem(

                    "fashCustomers"

                )

            ) || [];

            filteredCustomers =

            [...customers];

            currentPage = 1;

            updateStatistics();

            renderCustomers();

            console.log(

                "Customers refreshed."

            );

        }

    );

}
/*==================================================
FASH SELLER
CUSTOMERS PAGE
PART 4
VIEW • EDIT • DELETE • EXPORT
==================================================*/

/*==============================
VIEW CUSTOMER
==============================*/

function viewCustomer(id){

    const customer = customers.find(

        customer => customer.id === id

    );

    if(!customer){

        alert("Customer not found.");

        return;

    }

    alert(

`Customer Details

Name: ${customer.name}

Email: ${customer.email}

Phone: ${customer.phone || "-"}

Orders: ${customer.orders || 0}

Total Spent: ₦${Number(customer.totalSpent || 0).toLocaleString()}

Status: ${customer.status}`

    );

}

/*==============================
EDIT CUSTOMER
==============================*/

function editCustomer(id){

    localStorage.setItem(

        "editingCustomer",

        id

    );

    alert(

        "Customer editing will be available soon."

    );

}

/*==============================
DELETE CUSTOMER
==============================*/

function deleteCustomer(id){

    if(

        !confirm(

            "Delete this customer?"

        )

    ){

        return;

    }

    customers = customers.filter(

        customer => customer.id !== id

    );

    filteredCustomers = [...customers];

    localStorage.setItem(

        "fashCustomers",

        JSON.stringify(customers)

    );

    updateStatistics();

    renderCustomers();

}

/*==============================
SELECT ALL
==============================*/

const selectAll =

document.getElementById(

    "selectAll"

);

if(selectAll){

    selectAll.addEventListener(

        "change",

        function(){

            document

            .querySelectorAll(

                ".customer-check"

            )

            .forEach(box=>{

                box.checked =

                this.checked;

            });

        }

    );

}

/*==============================
DELETE SELECTED
==============================*/

const deleteSelected =

document.getElementById(

    "deleteSelected"

);

if(deleteSelected){

    deleteSelected.addEventListener(

        "click",

        function(){

            const checked =

            document.querySelectorAll(

                ".customer-check:checked"

            );

            if(

                checked.length===0

            ){

                alert(

                    "Select customers first."

                );

                return;

            }

            if(

                !confirm(

                    "Delete selected customers?"

                )

            ){

                return;

            }

            const ids = [];

            checked.forEach(box=>{

                ids.push(

                    Number(

                        box.dataset.id

                    )

                );

            });

            customers = customers.filter(

                customer=>

                !ids.includes(

                    customer.id

                )

            );

            filteredCustomers =

            [...customers];

            localStorage.setItem(

                "fashCustomers",

                JSON.stringify(customers)

            );

            updateStatistics();

            renderCustomers();

        }

    );

}

/*==============================
EXPORT CSV
==============================*/

const exportBtn =

document.getElementById(

    "exportCustomers"

);

if(exportBtn){

    exportBtn.addEventListener(

        "click",

        function(){

            if(

                customers.length===0

            ){

                alert(

                    "No customers to export."

                );

                return;

            }

            let csv =

"Name,Email,Phone,Orders,TotalSpent,Status\n";

            customers.forEach(customer=>{

                csv +=

`"${customer.name}","${customer.email}","${customer.phone || ""}","${customer.orders || 0}","${customer.totalSpent || 0}","${customer.status}"\n`;

            });

            const blob =

            new Blob(

                [csv],

                {

                    type:"text/csv"

                }

            );

            const url =

            URL.createObjectURL(blob);

            const link =

            document.createElement("a");

            link.href = url;

            link.download =

            "customers.csv";

            link.click();

            URL.revokeObjectURL(url);

        }

    );

}
/*==================================================
FASH SELLER
CUSTOMERS PAGE
PART 5
PAGINATION • RESET • AUTO REFRESH • FINISH
==================================================*/

/*==============================
PAGINATION ELEMENTS
==============================*/

const pageNumbers =
document.getElementById(
"pageNumbers"
);

const previousPage =
document.getElementById(
"previousPage"
);

const nextPage =
document.getElementById(
"nextPage"
);

/*==============================
RENDER PAGINATION
==============================*/

function renderPagination(){

    if(!pageNumbers) return;

    pageNumbers.innerHTML = "";

    const totalPages = Math.ceil(

        filteredCustomers.length /

        rowsPerPage

    );

    if(totalPages <= 1){

        return;

    }

    for(

        let i = 1;

        i <= totalPages;

        i++

    ){

        pageNumbers.innerHTML += `

        <button

        class="page-number ${currentPage===i?"active":""}"

        onclick="goToPage(${i})">

            ${i}

        </button>

        `;

    }

}

/*==============================
GO TO PAGE
==============================*/

function goToPage(page){

    currentPage = page;

    renderCustomers();

}

/*==============================
PREVIOUS PAGE
==============================*/

if(previousPage){

    previousPage.addEventListener(

        "click",

        function(){

            if(currentPage > 1){

                currentPage--;

                renderCustomers();

            }

        }

    );

}

/*==============================
NEXT PAGE
==============================*/

if(nextPage){

    nextPage.addEventListener(

        "click",

        function(){

            const totalPages = Math.ceil(

                filteredCustomers.length /

                rowsPerPage

            );

            if(currentPage < totalPages){

                currentPage++;

                renderCustomers();

            }

        }

    );

}

/*==============================
REFRESH DATA
==============================*/

function refreshCustomers(){

    customers = JSON.parse(

        localStorage.getItem(

            "fashCustomers"

        )

    ) || [];

    filteredCustomers = [...customers];

    updateStatistics();

    renderCustomers();

}

/*==============================
RESET FILTERS
==============================*/

function resetFilters(){

    if(searchCustomer)

        searchCustomer.value = "";

    if(statusFilter)

        statusFilter.value = "";

    if(sortCustomers)

        sortCustomers.value = "newest";

    filteredCustomers = [...customers];

    currentPage = 1;

    renderCustomers();

}

/*==============================
WINDOW FOCUS
==============================*/

window.addEventListener(

    "focus",

    refreshCustomers

);

/*==============================
KEYBOARD SHORTCUTS
==============================*/

document.addEventListener(

    "keydown",

    function(e){

        if(

            e.ctrlKey &&

            e.key === "f"

        ){

            e.preventDefault();

            if(searchCustomer){

                searchCustomer.focus();

            }

        }

        if(e.key === "Escape"){

            resetFilters();

        }

    }

);

/*==============================
UPDATE RENDER
==============================*/

const originalRenderCustomers = renderCustomers;

renderCustomers = function(){

    originalRenderCustomers();

    renderPagination();

};

/*==============================
INITIAL REFRESH
==============================*/

refreshCustomers();

/*==============================
FINISH
==============================*/

console.log(

    "FASH Customers Ready 🚀"

);
