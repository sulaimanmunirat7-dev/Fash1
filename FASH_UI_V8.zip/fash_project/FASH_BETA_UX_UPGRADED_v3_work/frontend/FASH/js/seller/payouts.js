/*==================================================
FASH SELLER
PAYOUTS PAGE
PART 1
INITIALIZATION
==================================================*/

/*==============================
TABLE
==============================*/

const payoutsTable =
document.getElementById("payoutsTable");

/*==============================
STATISTICS
==============================*/

const totalEarnings =
document.getElementById("totalEarnings");

const availableBalance =
document.getElementById("availableBalance");

const pendingBalance =
document.getElementById("pendingBalance");

const paidOut =
document.getElementById("paidOut");

/*==============================
FOOTER
==============================*/

const showingPayouts =
document.getElementById("showingPayouts");

const totalPayoutsFooter =
document.getElementById("totalPayoutsFooter");

/*==============================
SEARCH & FILTER
==============================*/

const searchPayout =
document.getElementById("searchPayout");

const statusFilter =
document.getElementById("statusFilter");

/*==============================
BUTTONS
==============================*/

const requestPayout =
document.getElementById("requestPayout");

const refreshBtn =
document.querySelector(".refresh-btn");

/*==============================
PAGINATION
==============================*/

const previousPage =
document.getElementById("previousPage");

const nextPage =
document.getElementById("nextPage");

const pageNumbers =
document.getElementById("pageNumbers");

/*==============================
VARIABLES
==============================*/

let payouts = JSON.parse(

    localStorage.getItem(

        "fashPayouts"

    )

) || [];

let filteredPayouts = [...payouts];

let currentPage = 1;

const rowsPerPage = 10;

/*==============================
INITIALIZE
==============================*/

updateStatistics();

renderPayouts();

console.log(

    "FASH Payouts Ready 💰"

);
/*==================================================
FASH SELLER
PAYOUTS PAGE
PART 2
STATISTICS • RENDER TABLE
==================================================*/

/*==============================
UPDATE STATISTICS
==============================*/

function updateStatistics(){

    const total = payouts.reduce(

        (sum,payout)=>sum+payout.amount,

        0

    );

    const available = payouts

    .filter(

        payout=>payout.status==="completed"

    )

    .reduce(

        (sum,payout)=>sum+payout.amount,

        0

    );

    const pending = payouts

    .filter(

        payout=>payout.status==="pending"

    )

    .reduce(

        (sum,payout)=>sum+payout.amount,

        0

    );

    const paid = payouts

    .filter(

        payout=>payout.status==="paid"

    )

    .reduce(

        (sum,payout)=>sum+payout.amount,

        0

    );

    totalEarnings.textContent =

        "₦"+total.toLocaleString();

    availableBalance.textContent =

        "₦"+available.toLocaleString();

    pendingBalance.textContent =

        "₦"+pending.toLocaleString();

    paidOut.textContent =

        "₦"+paid.toLocaleString();

}

/*==============================
RENDER PAYOUTS
==============================*/

function renderPayouts(){

    payoutsTable.innerHTML = "";

    const start =

        (currentPage-1)*rowsPerPage;

    const end =

        start+rowsPerPage;

    const pagePayouts =

        filteredPayouts.slice(

            start,

            end

        );

    if(pagePayouts.length===0){

        payoutsTable.innerHTML = `

        <tr>

            <td

            colspan="8"

            class="empty-state">

                <i class="fa-solid fa-wallet"></i>

                <h3>

                    No Payouts Found

                </h3>

                <p>

                    Your payout history will appear here.

                </p>

            </td>

        </tr>

        `;

    }

    else{

        pagePayouts.forEach(

            payout=>{

                createPayoutRow(

                    payout

                );

            }

        );

    }

    showingPayouts.textContent =

        pagePayouts.length;

    totalPayoutsFooter.textContent =

        filteredPayouts.length;

}

/*==============================
CREATE ROW
==============================*/

function createPayoutRow(payout){

    payoutsTable.innerHTML += `

    <tr>

        <td>

            <input

            type="checkbox"

            class="payout-check"

            data-id="${payout.id}">

        </td>

        <td>

            <strong>

                ${payout.id}

            </strong>

        </td>

        <td>

            <span class="amount">

                ₦${Number(

                    payout.amount

                ).toLocaleString()}

            </span>

        </td>

        <td>

            <div class="bank-info">

                <strong>

                    ${payout.bank}

                </strong>

                <span>

                    ${payout.account}

                </span>

            </div>

        </td>

        <td>

            ${payout.accountName}

        </td>

        <td>

            <span

            class="status-badge ${getStatusClass(

                payout.status

            )}">

                ${payout.status}

            </span>

        </td>

        <td>

            ${formatDate(

                payout.date

            )}

        </td>

        <td>

            <div

            class="action-buttons">

                <button

                class="view-btn"

                onclick="viewPayout('${payout.id}')">

                    <i class="fa-solid fa-eye"></i>

                </button>

                <button

                class="delete-btn"

                onclick="deletePayout('${payout.id}')">

                    <i class="fa-solid fa-trash"></i>

                </button>

            </div>

        </td>

    </tr>

    `;

}

/*==============================
STATUS CLASS
==============================*/

function getStatusClass(status){

    switch(status){

        case "completed":

            return "status-completed";

        case "pending":

            return "status-pending";

        case "failed":

            return "status-failed";

        case "paid":

            return "status-completed";

        default:

            return "status-pending";

    }

}

/*==============================
FORMAT DATE
==============================*/

function formatDate(date){

    return new Date(date)

    .toLocaleDateString(

        "en-GB",

        {

            day:"2-digit",

            month:"short",

            year:"numeric"

        }

    );

}
/*==================================================
FASH SELLER
PAYOUTS PAGE
PART 3
SEARCH • FILTER • PAGINATION
==================================================*/

/*==============================
SEARCH & FILTER
==============================*/

function filterPayouts(){

    const search =

        searchPayout.value

        .trim()

        .toLowerCase();

    const status =

        statusFilter.value;

    filteredPayouts = payouts.filter(

        payout=>{

            const matchesSearch =

                payout.id

                .toString()

                .toLowerCase()

                .includes(search)

                ||

                payout.bank

                .toLowerCase()

                .includes(search)

                ||

                payout.accountName

                .toLowerCase()

                .includes(search);

            const matchesStatus =

                status===""

                ||

                payout.status===status;

            return(

                matchesSearch

                &&

                matchesStatus

            );

        }

    );

    currentPage = 1;

    renderPayouts();

    renderPagination();

}

/*==============================
SEARCH EVENTS
==============================*/

searchPayout.addEventListener(

    "input",

    filterPayouts

);

statusFilter.addEventListener(

    "change",

    filterPayouts

);

/*==============================
PAGINATION
==============================*/

function renderPagination(){

    if(!pageNumbers) return;

    pageNumbers.innerHTML = "";

    const totalPages = Math.ceil(

        filteredPayouts.length /

        rowsPerPage

    );

    for(

        let i=1;

        i<=totalPages;

        i++

    ){

        pageNumbers.innerHTML += `

        <button

        class="page-number

        ${currentPage===i?"active":""}"

        onclick="goToPage(${i})">

            ${i}

        </button>

        `;

    }

}

/*==============================
GO TO PAGE
==============================*/

function goToPage(page){

    currentPage = page;

    renderPayouts();

    renderPagination();

}

/*==============================
PREVIOUS PAGE
==============================*/

if(previousPage){

    previousPage.addEventListener(

        "click",

        function(){

            if(currentPage>1){

                currentPage--;

                renderPayouts();

                renderPagination();

            }

        }

    );

}

/*==============================
NEXT PAGE
==============================*/

if(nextPage){

    nextPage.addEventListener(

        "click",

        function(){

            const totalPages = Math.ceil(

                filteredPayouts.length/

                rowsPerPage

            );

            if(currentPage<totalPages){

                currentPage++;

                renderPayouts();

                renderPagination();

            }

        }

    );

}

/*==============================
INITIAL PAGINATION
==============================*/

renderPagination();
/*==================================================
FASH SELLER
PAYOUTS PAGE
PART 4
REQUEST • VIEW • DELETE • REFRESH
==================================================*/

/*==============================
REQUEST PAYOUT
==============================*/

if(requestPayout){

    requestPayout.addEventListener(

        "click",

        function(){

            const amount = prompt(

                "Enter payout amount (₦):"

            );

            if(

                amount===null ||

                amount.trim()===""

            ){

                return;

            }

            const value = Number(amount);

            if(

                isNaN(value) ||

                value<=0

            ){

                alert(

                    "Enter a valid amount."

                );

                return;

            }

            const payout = {

                id:

                    "PAY-"+

                    Date.now(),

                amount:

                    value,

                bank:

                    "First Bank",

                account:

                    "0123456789",

                accountName:

                    "FASH Seller",

                status:

                    "pending",

                date:

                    new Date()

                    .toISOString()

            };

            payouts.unshift(

                payout

            );

            filteredPayouts =

                [...payouts];

            localStorage.setItem(

                "fashPayouts",

                JSON.stringify(

                    payouts

                )

            );

            updateStatistics();

            renderPayouts();

            renderPagination();

            alert(

                "Payout request submitted successfully."

            );

        }

    );

}

/*==============================
VIEW PAYOUT
==============================*/

function viewPayout(id){

    const payout = payouts.find(

        p=>p.id===id

    );

    if(!payout) return;

    alert(

`Payout ID: ${payout.id}

Amount: ₦${payout.amount.toLocaleString()}

Bank: ${payout.bank}

Account: ${payout.account}

Account Name: ${payout.accountName}

Status: ${payout.status}

Date: ${formatDate(payout.date)}`

    );

}

/*==============================
DELETE PAYOUT
==============================*/

function deletePayout(id){

    if(

        !confirm(

            "Delete this payout?"

        )

    ){

        return;

    }

    payouts = payouts.filter(

        payout=>

        payout.id!==id

    );

    filteredPayouts =

        [...payouts];

    localStorage.setItem(

        "fashPayouts",

        JSON.stringify(

            payouts

        )

    );

    updateStatistics();

    renderPayouts();

    renderPagination();

}

/*==============================
REFRESH
==============================*/

if(refreshBtn){

    refreshBtn.addEventListener(

        "click",

        function(){

            payouts = JSON.parse(

                localStorage.getItem(

                    "fashPayouts"

                )

            ) || [];

            filteredPayouts =

                [...payouts];

            currentPage = 1;

            updateStatistics();

            renderPayouts();

            renderPagination();

            console.log(

                "Payouts refreshed."

            );

        }

    );

}

/*==============================
SELECT ALL
==============================*/

const selectAll =

document.getElementById(

    "selectAll"

);

if(selectAll){

    selectAll.addEventListener(

        "change",

        function(){

            document

            .querySelectorAll(

                ".payout-check"

            )

            .forEach(box=>{

                box.checked =

                this.checked;

            });

        }

    );

}
/*==================================================
FASH SELLER
PAYOUTS PAGE
PART 5
BULK ACTIONS • EXPORT • AUTO REFRESH
==================================================*/

/*==============================
DELETE SELECTED
==============================*/

const deleteSelected =

document.getElementById(

    "deleteSelected"

);

if(deleteSelected){

    deleteSelected.addEventListener(

        "click",

        function(){

            const checked =

            document.querySelectorAll(

                ".payout-check:checked"

            );

            if(checked.length===0){

                alert(

                    "Select payouts first."

                );

                return;

            }

            if(

                !confirm(

                    "Delete selected payouts?"

                )

            ){

                return;

            }

            const ids = [];

            checked.forEach(box=>{

                ids.push(

                    box.dataset.id

                );

            });

            payouts = payouts.filter(

                payout=>

                !ids.includes(

                    payout.id

                )

            );

            filteredPayouts =

            [...payouts];

            localStorage.setItem(

                "fashPayouts",

                JSON.stringify(

                    payouts

                )

            );

            updateStatistics();

            renderPayouts();

            renderPagination();

        }

    );

}

/*==============================
EXPORT CSV
==============================*/

const exportBtn =

document.getElementById(

    "exportPayouts"

);

if(exportBtn){

    exportBtn.addEventListener(

        "click",

        function(){

            if(

                payouts.length===0

            ){

                alert(

                    "No payouts to export."

                );

                return;

            }

            let csv =

            "Payout ID,Amount,Bank,Account,Account Name,Status,Date\n";

            payouts.forEach(payout=>{

                csv +=

                `"${payout.id}",`+

                `"${payout.amount}",`+

                `"${payout.bank}",`+

                `"${payout.account}",`+

                `"${payout.accountName}",`+

                `"${payout.status}",`+

                `"${formatDate(payout.date)}"\n`;

            });

            const blob =

            new Blob(

                [csv],

                {

                    type:"text/csv"

                }

            );

            const url =

            URL.createObjectURL(

                blob

            );

            const link =

            document.createElement(

                "a"

            );

            link.href = url;

            link.download =

            "fash-payouts.csv";

            link.click();

            URL.revokeObjectURL(

                url

            );

        }

    );

}

/*==============================
AUTO REFRESH
==============================*/

function refreshPayouts(){

    payouts = JSON.parse(

        localStorage.getItem(

            "fashPayouts"

        )

    ) || [];

    filteredPayouts =

    [...payouts];

    updateStatistics();

    renderPayouts();

    renderPagination();

}

/*==============================
WINDOW FOCUS
==============================*/

window.addEventListener(

    "focus",

    refreshPayouts

);

/*==============================
AFTER DELETE
==============================*/

const oldDeletePayout =

deletePayout;

deletePayout = function(id){

    oldDeletePayout(id);

    refreshPayouts();

};

console.log(

    "Bulk Actions Ready 🚀"

);
/*==================================================
FASH SELLER
PAYOUTS PAGE
PART 6
FINAL POLISH
==================================================*/

/*==============================
KEYBOARD SHORTCUTS
==============================*/

document.addEventListener(

    "keydown",

    function(e){

        /* Ctrl + F */

        if(

            e.ctrlKey &&

            e.key==="f"

        ){

            e.preventDefault();

            searchPayout.focus();

        }

        /* Escape */

        if(

            e.key==="Escape"

        ){

            searchPayout.value = "";

            statusFilter.value = "";

            filteredPayouts = [...payouts];

            currentPage = 1;

            renderPayouts();

            renderPagination();

        }

        /* F5 */

        if(

            e.key==="F5"

        ){

            e.preventDefault();

            refreshPayouts();

        }

    }

);

/*==============================
CREATE DEMO DATA
(ONLY FIRST TIME)
==============================*/

if(

    payouts.length===0

){

    payouts = [

        {

            id:"PAY-100001",

            amount:85000,

            bank:"First Bank",

            account:"0123456789",

            accountName:"FASH Seller",

            status:"completed",

            date:new Date().toISOString()

        },

        {

            id:"PAY-100002",

            amount:125000,

            bank:"GTBank",

            account:"0987654321",

            accountName:"FASH Seller",

            status:"pending",

            date:new Date().toISOString()

        },

        {

            id:"PAY-100003",

            amount:50000,

            bank:"Access Bank",

            account:"1234567890",

            accountName:"FASH Seller",

            status:"failed",

            date:new Date().toISOString()

        }

    ];

    localStorage.setItem(

        "fashPayouts",

        JSON.stringify(

            payouts

        )

    );

}

/*==============================
LOAD EVERYTHING
==============================*/

refreshPayouts();

/*==============================
READY
==============================*/

console.log(

    "===================================="

);

console.log(

    "FASH PAYOUTS LOADED SUCCESSFULLY 💰"

);

console.log(

    "Total Payouts:",

    payouts.length

);

console.log(

    "===================================="

);