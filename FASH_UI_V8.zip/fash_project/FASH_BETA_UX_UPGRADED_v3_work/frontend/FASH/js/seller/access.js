/* FASH SELLER PORTAL ACCESS */
(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", async () => {
    try {
      if (!window.FASH_API || typeof window.FASH_API.api !== "function") {
        throw new Error("FASH API client is not loaded.");
      }

      const data = await FASH_API.api("/api/auth/me");
      const user = data?.user;
      const application = data?.sellerApplication || null;

      if (!user) {
        throw new Error("No authenticated user was returned.");
      }

      const role = String(user.role || "").toLowerCase();
      const status = String(user.seller_status || "none").toLowerCase();

      // Only approved sellers get Seller Dashboard access. Pending/rejected/changes-requested stay in the normal customer account with a clear application banner.
      if (role !== "admin" && !(role === "seller" && status === "approved")) {
        renderApplicationBanner(status, user, application);
        return;
      }

      if (status === "suspended") {
        alert("Your seller account is suspended.");
        window.location.href = "../pages/shop.html";
        return;
      }

      const session = {
        id: user.id,
        name: user.full_name || "Seller",
        fullName: user.full_name || "Seller",
        email: user.email || "",
        role,
        sellerStatus: status,
        emailVerified: Boolean(user.email_verified)
      };

      localStorage.setItem("fashCurrentUser", JSON.stringify(session));

      document.documentElement.dataset.sellerStatus = status;
      document.documentElement.dataset.sellerApproved =
        String(status === "approved" || role === "admin");

      document.querySelectorAll(".seller-profile h4").forEach(el => {
        el.textContent = user.full_name || "Seller";
      });

      document.querySelectorAll("[data-user-email]").forEach(el => {
        el.textContent = user.email || "";
      });

      renderAccountState(status, role);
      applyFeatureLocks(status, role);

    } catch (error) {
      console.error("Seller access error:", error);

      // Do not leave the page looking blank if authentication fails.
      const main = document.querySelector(".main-content");
      if (main) {
        const notice = document.createElement("div");
        notice.style.cssText =
          "margin:20px;padding:16px 20px;background:#fff1f2;color:#991b1b;border:1px solid #fecdd3;border-radius:12px;font-family:Inter,sans-serif;";
        notice.innerHTML =
          "<strong>Seller session could not be verified.</strong><br>" +
          escapeHtml(error.message || "Please log in again.") +
          '<br><a href="../pages/seller-login.html" style="display:inline-block;margin-top:10px;font-weight:700;color:#7c3aed;">Go to Seller Login</a>';
        main.prepend(notice);
      }

      FASH_API?.clearSession?.();
    }
  });

  function renderApplicationBanner(status, user, application) {
    const existing=document.getElementById("sellerAccountState");
    const box=existing || document.createElement("div");
    if(!existing){box.id="sellerAccountState";box.className="seller-account-state";document.body.prepend(box);}
    const s=String(status||"pending").toLowerCase();
    if(s==="rejected") { box.innerHTML='<strong>❌ Seller application rejected</strong><span>Reason: '+escapeHtml(application?.admin_notes || "No reason was provided.")+'</span><a class="seller-reapply-btn" href="../pages/become-seller.html">Reapply</a>'; box.className="seller-account-state rejected"; }
    else if(s==="changes_requested") { box.innerHTML='<strong>⚠️ Changes requested</strong><span>Requested changes: '+escapeHtml(application?.admin_notes || "Please review your application details.")+'</span><a class="seller-reapply-btn" href="../pages/become-seller.html">Update application</a>'; box.className="seller-account-state changes"; }
    else { box.innerHTML='<strong>🕒 Seller application pending</strong><span>Your seller application is being reviewed. Seller Dashboard access will appear after Admin approval.</span>'; box.className="seller-account-state pending"; }
  }

  function renderAccountState(status, role) {
    const box = document.getElementById("sellerAccountState");
    if (!box) return;

    if (role === "admin" || status === "approved") {
      box.hidden = true;
      return;
    }

    box.hidden = false;

    if (status === "rejected") {
      box.innerHTML =
        "<strong><i class=\"fa-solid fa-circle-xmark\"></i> Application rejected</strong>" +
        "<span>Your application was rejected by FASH Admin. You can update your details and reapply.</span>" +
        '<a class="seller-reapply-btn" href="../pages/become-seller.html">Reapply here</a>';
      box.className = "seller-account-state rejected";
      return;
    }

    if (status === "changes_requested") {
      box.innerHTML =
        "<strong><i class=\"fa-solid fa-pen-to-square\"></i> Changes requested</strong>" +
        "<span>FASH Admin requested changes to your application. Update your application to continue.</span>" +
        '<a class="seller-reapply-btn" href="../pages/become-seller.html">Update application</a>';
      box.className = "seller-account-state changes";
      return;
    }

    box.innerHTML =
      "<strong><i class=\"fa-solid fa-clock\"></i> Seller application pending</strong>" +
      "<span>Your seller application is pending FASH Admin approval. Seller Dashboard access will appear after approval.</span>";
    box.className = "seller-account-state pending";
  }

  function applyFeatureLocks(status, role) {
    if (role === "admin" || status === "approved") return;

    const locked = new Set([
      "products.html",
      "add-product.html",
      "orders.html",
      "customers.html",
      "analytics.html",
      "payouts.html"
    ]);

    document.querySelectorAll(".sidebar-nav a[href]").forEach(link => {
      const file = (link.getAttribute("href") || "")
        .split("?")[0]
        .split("/")
        .pop();

      if (!locked.has(file)) return;

      link.classList.add("seller-access-locked");
      link.setAttribute("aria-disabled", "true");
      link.title = "Available after seller approval";

      link.addEventListener("click", e => {
        e.preventDefault();
        showLockedToast();
      });
    });
  }

  function showLockedToast() {
    let toast = document.querySelector(".seller-locked-toast");

    if (!toast) {
      toast = document.createElement("div");
      toast.className = "seller-locked-toast";
      toast.innerHTML =
        '<i class="fa-solid fa-lock"></i><span>FASH Admin approval is required for this seller tool.</span>';
      document.body.appendChild(toast);
    }

    toast.classList.add("show");
    clearTimeout(window.__fashLockTimer);

    window.__fashLockTimer = setTimeout(() => {
      toast.classList.remove("show");
    }, 2800);
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, char => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    }[char]));
  }
})();

document.addEventListener("click", function (e) {
  const logout = e.target.closest("[data-fash-logout]");
  if (!logout) return;

  e.preventDefault();
  window.FASH_API?.clearSession?.();
  window.location.href = "../pages/shop.html";
});
