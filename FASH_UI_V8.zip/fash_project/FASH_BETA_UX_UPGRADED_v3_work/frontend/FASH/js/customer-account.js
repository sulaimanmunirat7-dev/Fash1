/* FASH v6.9 — Profile, Notifications & Settings */
(function () {
  "use strict";

  function api() {
    if (!window.FASH_API) throw new Error("FASH API client is unavailable");
    return window.FASH_API;
  }

  window.FASH_ACCOUNT = {
    getProfile() {
      return api().get("/api/account");
    },

    updateProfile(payload) {
      return api().patch("/api/account", payload || {});
    },

    getNotifications() {
      return api().get("/api/notifications");
    },

    markNotificationRead(notificationId) {
      return api().patch(
        `/api/notifications/${encodeURIComponent(notificationId)}/read`,
        {}
      );
    },

    markAllNotificationsRead() {
      return api().post("/api/notifications/read-all", {});
    },

    getSettings() {
      return api().get("/api/account/settings");
    },

    updateSettings(payload) {
      return api().patch("/api/account/settings", payload || {});
    }
  };
})();
