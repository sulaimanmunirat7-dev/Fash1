"use strict";

document.addEventListener("DOMContentLoaded", () => {

    const footerYear =
        document.getElementById("footerYear");

    const policyLinks =
        document.querySelectorAll(".privacy-nav a");


    /*==================================================
    FOOTER YEAR
    ==================================================*/

    if (footerYear) {
        footerYear.textContent =
            `© ${new Date().getFullYear()} FLASH. All rights reserved.`;
    }


    /*==================================================
    SMOOTH POLICY NAVIGATION
    ==================================================*/

    policyLinks.forEach((link) => {

        link.addEventListener("click", (event) => {

            const targetId =
                link.getAttribute("href");

            if (!targetId || !targetId.startsWith("#")) {
                return;
            }

            const target =
                document.querySelector(targetId);

            if (!target) {
                return;
            }

            event.preventDefault();

            target.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });

            /*
             * Update the URL without reloading
             * or leaving the privacy-policy page.
             */
            history.replaceState(
                null,
                "",
                targetId
            );

        });

    });


    /*==================================================
    ACTIVE SECTION
    ==================================================*/

    const sections =
        document.querySelectorAll(".policy-section");

    if (sections.length && policyLinks.length) {

        const observer =
            new IntersectionObserver(
                (entries) => {

                    entries.forEach((entry) => {

                        if (!entry.isIntersecting) {
                            return;
                        }

                        const id =
                            entry.target.id;

                        policyLinks.forEach((link) => {

                            const isActive =
                                link.getAttribute("href") === `#${id}`;

                            link.classList.toggle(
                                "active",
                                isActive
                            );

                        });

                    });

                },
                {
                    root: null,
                    threshold: 0.15,
                    rootMargin: "-15% 0px -65% 0px"
                }
            );

        sections.forEach((section) => {
            observer.observe(section);
        });

    }


    /*==================================================
    BACK TO TOP WHEN LOGO IS CLICKED
    ==================================================*/

    const logo =
        document.querySelector(".privacy-logo");

    if (logo) {

        logo.addEventListener("click", () => {

            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });

        });

    }

});