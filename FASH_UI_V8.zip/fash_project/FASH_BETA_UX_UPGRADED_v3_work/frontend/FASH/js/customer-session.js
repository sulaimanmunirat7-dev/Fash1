/* FASH Customer Session Bootstrap */
(function () {
  "use strict";

  async function restore() {
    if (!window.FASH_API || typeof window.FASH_API.restoreSession !== "function") return;
    try {
      await window.FASH_API.restoreSession();
    } catch (_) {}
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", restore, { once: true });
  } else {
    restore();
  }
})();
