"use strict";

document.addEventListener("DOMContentLoaded", () => {

    /*==================================================
    FAQ ACCORDION
    ==================================================*/

    const faqQuestions = document.querySelectorAll(
        ".faq-question"
    );

    faqQuestions.forEach((question) => {

        question.addEventListener("click", () => {

            const currentItem =
                question.closest(".faq-item");

            document
                .querySelectorAll(".faq-item.open")
                .forEach((item) => {

                    if (item !== currentItem) {
                        item.classList.remove("open");
                    }

                });

            currentItem.classList.toggle("open");

        });

    });


    /*==================================================
    START RETURN
    ==================================================*/

    const startReturn =
        document.getElementById("startReturn");

    if (startReturn) {

        startReturn.addEventListener("click", () => {

            /*
             * Change this path if your actual
             * return-request page has a different name.
             */

            window.location.href =
                "../pages/orders.html";

        });

    }


    /*==================================================
    CONTACT SUPPORT
    ==================================================*/

    const contactSupport =
        document.getElementById("contactSupport");

    if (contactSupport) {

        contactSupport.addEventListener("click", () => {

            window.location.href =
                "mailto:support@fash.com?subject=FASH%20Returns%20Support";

        });

    }


    /*==================================================
    BUTTON HOVER FEEDBACK
    ==================================================*/

    const buttons =
        document.querySelectorAll("button");

    buttons.forEach((button) => {

        button.addEventListener("keydown", (event) => {

            if (event.key === "Enter" ||
                event.key === " ") {

                button.classList.add("button-active");

            }

        });

        button.addEventListener("keyup", () => {

            button.classList.remove(
                "button-active"
            );

        });

    });

});