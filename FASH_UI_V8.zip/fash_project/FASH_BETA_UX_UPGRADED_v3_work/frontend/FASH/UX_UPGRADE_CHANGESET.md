# FASH UX UPGRADE CHANGESET

## Version: Beta UX v2
### Global frontend upgrades
- Added `frontend/FASH/css/ux-upgrade.css`
- Applied the UX design system to 65 HTML pages
- Standardized color tokens, typography, radius, shadows and focus states
- Improved cards, forms, buttons, tables, dropdowns, modals, badges and empty states
- Added mobile touch-target improvements
- Added reduced-motion support
- Added loading shimmer utility
- Added premium interaction transitions
- Added responsive table behavior
- Added `UX_UI_DESIGN_SYSTEM.md` with the complete palette and UX rules

## Notes
This release is intentionally a global polish layer rather than a destructive rewrite of page-specific CSS. Existing functionality and page layouts are preserved while shared visual behavior is upgraded.
