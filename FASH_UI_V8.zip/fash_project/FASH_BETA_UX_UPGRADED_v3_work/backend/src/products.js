import { query } from "./db.js";

// BUGFIX: several handlers below returned `debug: e.message` (raw internal
// error text, e.g. SQL details) directly to API clients on every 500 error.
// That is an information-disclosure risk in production. This helper only
// includes the debug field outside production.
function debugInfo(e) {
  return process.env.NODE_ENV === "production" ? {} : { debug: e.message };
}

export async function createProduct(req, res) {
  try {
    const { name, description, price, stock, category, imageUrl, status, scheduledAt } = req.body || {};
    if (!name || price === undefined || stock === undefined || !category) return res.status(400).json({error:"Name, price, stock and category are required"});
    const store = await query(`SELECT id,status FROM stores WHERE seller_id=$1`,[req.user.sub]);
    const numericPrice=Number(price), numericStock=Number(stock);
    if(!Number.isFinite(numericPrice)||numericPrice<=0) return res.status(400).json({error:"Price must be greater than 0"});
    if(!Number.isInteger(numericStock)||numericStock<0) return res.status(400).json({error:"Stock must be a whole number of 0 or more"});
    const requested=String(status||"draft").toLowerCase();
    const finalStatus=["draft","hidden","pending_review","approved","scheduled"].includes(requested)?requested:"draft";
    if(["pending_review","approved","scheduled"].includes(finalStatus) && !store.rowCount) return res.status(409).json({error:"STORE_REQUIRED",message:"Your store must exist before publishing a product"});
    if(finalStatus==="scheduled" && (!scheduledAt || Number.isNaN(new Date(scheduledAt).getTime()))) return res.status(400).json({error:"A valid scheduled publish date/time is required"});
    if(finalStatus==="scheduled" && new Date(scheduledAt).getTime() <= Date.now()) return res.status(400).json({error:"Scheduled publish time must be in the future"});
    if(finalStatus==="approved" && store.rowCount && store.rows[0].status !== "LIVE") await query(`UPDATE stores SET status='LIVE',is_active=TRUE,updated_at=NOW() WHERE id=$1`,[store.rows[0].id]);
    const r=await query(`INSERT INTO products
      (seller_id,store_id,name,description,price,stock,category,image_url,status,scheduled_at)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
      [req.user.sub,store.rows[0]?.id||null,name.trim(),description?.trim()||null,numericPrice,numericStock,category.trim(),imageUrl||null,finalStatus,finalStatus==="scheduled"?new Date(scheduledAt):null]);
    res.status(201).json({message:"Product saved",product:r.rows[0]});
  } catch(e){console.error("CREATE PRODUCT ERROR:",e);res.status(500).json({error:"Could not save product",...debugInfo(e)});}
}

export async function getMyProducts(req, res) {
  try {
    const result = await query(
      `SELECT p.*, s.name AS store_name, s.status AS store_status FROM products p LEFT JOIN stores s ON s.id=p.store_id WHERE p.seller_id = $1 ORDER BY p.created_at DESC`,
      [req.user.sub]
    );
    res.json({ products: result.rows });
  } catch (error) {
    console.error("GET PRODUCTS ERROR:", error);
    res.status(500).json({ error: "Could not load products", ...debugInfo(error) });
  }
}

export async function updateProduct(req,res){
  try{
    const {name,description,price,stock,category,imageUrl,status,scheduledAt}=req.body||{};
    const numericPrice=price===undefined||price===""?null:Number(price);
    const numericStock=stock===undefined||stock===""?null:Number(stock);
    if(numericPrice!==null&&(!Number.isFinite(numericPrice)||numericPrice<=0)) return res.status(400).json({error:"Price must be greater than 0"});
    if(numericStock!==null&&(!Number.isInteger(numericStock)||numericStock<0)) return res.status(400).json({error:"Stock must be a whole number"});
    const requested=status===undefined?null:String(status).toLowerCase();
    if(requested && !["draft","hidden","pending_review","approved","scheduled"].includes(requested)) return res.status(400).json({error:"Invalid product status"});
    if(["pending_review","approved","scheduled"].includes(requested)){
      const store=await query(`SELECT id,status FROM stores WHERE seller_id=$1`,[req.user.sub]);
      if(!store.rowCount) return res.status(409).json({error:"STORE_REQUIRED",message:"Create your store before submitting a product"});
    }
    const r=await query(`UPDATE products SET name=COALESCE($1,name),description=COALESCE($2,description),price=COALESCE($3,price),stock=COALESCE($4,stock),category=COALESCE($5,category),image_url=COALESCE($6,image_url),status=COALESCE($7,status),scheduled_at=CASE WHEN $7='scheduled' THEN $10 WHEN $7 IS NOT NULL THEN NULL ELSE scheduled_at END,updated_at=NOW() WHERE id=$8 AND seller_id=$9 RETURNING *`,
      [name?.trim(),description?.trim(),numericPrice,numericStock,category?.trim(),imageUrl||null,requested,req.params.id,req.user.sub,requested==="scheduled"?new Date(scheduledAt):null]);
    if(!r.rowCount) return res.status(404).json({error:"Product not found"});
    res.json({message:"Product updated",product:r.rows[0]});
  }catch(e){console.error("UPDATE PRODUCT ERROR:",e);res.status(500).json({error:"Could not update product",...debugInfo(e)});}
}

export async function deleteProduct(req, res) {
  try {
    const result = await query(
      `DELETE FROM products
       WHERE id=$1 AND seller_id=$2
       RETURNING id`,
      [req.params.id, req.user.sub]
    );

    if (!result.rowCount) {
      return res.status(404).json({ error: "Product not found" });
    }

    res.json({ message: "Product deleted successfully" });
  } catch (error) {
    console.error("DELETE PRODUCT ERROR:", error);
    res.status(500).json({ error: "Could not delete product", ...debugInfo(error) });
  }
}

export async function getAllProducts(_req, res) {
  try {
    const result = await query(
      `SELECT p.id,p.seller_id,p.name,p.description,p.price,p.stock,p.category,
              p.image_url,p.status,p.is_featured,p.featured_until,p.featured_position,p.created_at,p.updated_at,
              u.full_name AS seller_name
       FROM products p
       JOIN users u ON p.seller_id=u.id
       WHERE p.status='approved' AND p.stock>0 AND EXISTS (SELECT 1 FROM stores s WHERE s.id=p.store_id AND s.status='LIVE')
         AND (
           (u.seller_status='approved' AND u.role='seller')
           OR EXISTS (
             SELECT 1 FROM seller_applications sa
             WHERE sa.user_id = u.id AND sa.status='approved'
           )
         )
         AND (p.featured_until IS NULL OR p.featured_until > NOW() OR p.is_featured = FALSE)
       ORDER BY p.created_at DESC`
    );

    res.json({ products: result.rows });
  } catch (error) {
    console.error("GET ALL PRODUCTS ERROR:", error);
    res.status(500).json({ error: "Could not load products", ...debugInfo(error) });
  }
}


export async function getFeaturedProducts(_req, res) {
  try {
    const result = await query(`
      SELECT p.id,p.seller_id,p.name,p.description,p.price,p.stock,p.category,
             p.image_url,p.status,p.is_featured,p.featured_until,p.featured_position,
             u.full_name AS seller_name
      FROM products p
      JOIN users u ON p.seller_id=u.id
      WHERE p.status='approved' AND p.stock>0 AND EXISTS (SELECT 1 FROM stores s WHERE s.id=p.store_id AND s.status='LIVE')
        AND p.is_featured=TRUE
        AND (
          (u.seller_status='approved' AND u.role='seller')
          OR EXISTS (
            SELECT 1 FROM seller_applications sa
            WHERE sa.user_id = u.id AND sa.status='approved'
          )
        )
        AND (p.featured_until IS NULL OR p.featured_until > NOW())
      ORDER BY COALESCE(p.featured_position, 999999), p.created_at DESC
      LIMIT 12
    `);
    res.json({ products: result.rows });
  } catch (error) {
    console.error("GET FEATURED PRODUCTS ERROR:", error);
    res.status(500).json({ error: "Could not load featured products" });
  }
}

export async function setProductFeatured(req, res) {
  try {
    const { featured, featuredUntil, featuredPosition } = req.body || {};
    if (Boolean(featured)) {
      const eligible = await query(`SELECT 1 FROM products p JOIN stores s ON s.id=p.store_id WHERE p.id=$1 AND p.status='approved' AND s.status='LIVE'`,[req.params.id]);
      if (!eligible.rowCount) return res.status(409).json({error:"Only approved products from LIVE stores can be featured"});
    }
    if (Boolean(featured)) {
      const count = await query(`SELECT COUNT(*)::int AS count FROM products WHERE is_featured=TRUE AND (featured_until IS NULL OR featured_until > NOW()) AND id <> $1`, [req.params.id]);
      if (count.rows[0].count >= 8) {
        return res.status(409).json({ error: "Homepage already has 8 featured products. Unfeature one before adding another." });
      }
    }
    const result = await query(`
      UPDATE products
      SET is_featured=$1, featured_until=$2, featured_position=$3, updated_at=NOW()
      WHERE id=$4
      RETURNING *
    `, [Boolean(featured), featuredUntil || null, featuredPosition === undefined || featuredPosition === null || featuredPosition === '' ? null : Number(featuredPosition), req.params.id]);
    if (!result.rowCount) return res.status(404).json({ error: "Product not found" });
    res.json({ message: Boolean(featured) ? "Product featured" : "Product removed from homepage", product: result.rows[0] });
  } catch (error) {
    console.error("FEATURE PRODUCT ERROR:", error);
    res.status(500).json({ error: "Could not update featured placement" });
  }
}
