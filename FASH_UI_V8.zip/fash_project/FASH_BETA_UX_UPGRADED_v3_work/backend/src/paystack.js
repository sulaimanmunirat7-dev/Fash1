/**
 * Paystack helpers for FASH (Nigeria / NGN)
 * Docs: https://paystack.com/docs/api
 */
const PAYSTACK_BASE = "https://api.paystack.co";

function getSecret() {
  const key = process.env.PAYSTACK_SECRET_KEY;
  if (!key || key.includes("xxxxxxxx")) {
    throw new Error("PAYSTACK_SECRET_KEY is not configured");
  }
  return key;
}

export async function initializeTransaction({ email, amountKobo, reference, callbackUrl, metadata = {} }) {
  const res = await fetch(`${PAYSTACK_BASE}/transaction/initialize`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${getSecret()}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      email,
      amount: amountKobo, // Paystack expects amount in kobo (NGN * 100)
      reference,
      currency: process.env.CURRENCY || "NGN",
      callback_url: callbackUrl,
      metadata,
    }),
  });
  const data = await res.json();
  if (!data.status) {
    throw new Error(data.message || "Paystack initialize failed");
  }
  return data.data; // { authorization_url, access_code, reference }
}

export async function verifyTransaction(reference) {
  const res = await fetch(`${PAYSTACK_BASE}/transaction/verify/${encodeURIComponent(reference)}`, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${getSecret()}`,
    },
  });
  const data = await res.json();
  if (!data.status) {
    throw new Error(data.message || "Paystack verify failed");
  }
  return data.data;
}

export function toKobo(nairaAmount) {
  return Math.round(Number(nairaAmount) * 100);
}
