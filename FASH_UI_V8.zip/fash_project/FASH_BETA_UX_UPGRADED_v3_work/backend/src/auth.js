import jwt from "jsonwebtoken";

export function createToken(user) {
  return jwt.sign(
    {
      sub: user.id,
      role: user.role,
      email: user.email,
      sellerStatus: user.seller_status || "none"
    },
    process.env.JWT_SECRET,
    { expiresIn: "7d" }
  );
}

export function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const [scheme, bearerToken] = header.split(" ");

  // Prefer the Authorization header when present, but also support the
  // HttpOnly FASH auth cookie for normal browser sessions.
  let token = scheme === "Bearer" && bearerToken ? bearerToken : "";

  if (!token) {
    const cookieHeader = req.headers.cookie || "";
    const match = cookieHeader
      .split(";")
      .map(part => part.trim())
      .find(part => part.startsWith("fash_auth="));
    if (match) token = decodeURIComponent(match.slice("fash_auth=".length));
  }

  if (!token) {
    return res.status(401).json({
      error: "Authentication required"
    });
  }

  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({
      error: "Invalid or expired token"
    });
  }
}

export function requireRole(...roles) {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        error: "You do not have permission to access this resource"
      });
    }
    next();
  };
}
