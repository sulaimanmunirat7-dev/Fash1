import express from "express";
import cors from "cors";
import bcrypt from "bcryptjs";
import "dotenv/config";
import path from "path";
import { fileURLToPath } from "url";

import { query, pool } from "./db.js";
import { createToken, requireAuth } from "./auth.js";

import {
  createProduct,
  getMyProducts,
  updateProduct,
  deleteProduct,
  getAllProducts,
  getFeaturedProducts,
  setProductFeatured
} from "./products.js";

import {
  createApplication,
  getMyApplication,
  getAllApplications,
  getRejectedApplications,
  reviewApplication
} from "./sellerApplications.js";

import { requireAdmin, requireAdminOrSeller, requireSellerPortal, requireApprovedSeller } from "./admin.js";
import { initializeTransaction, verifyTransaction, toKobo } from "./paystack.js";

const app = express();
const PORT = Number(process.env.PORT || 5000);


// Customer browser session cookie.
// HttpOnly means browser JavaScript cannot read the authentication token.
// In local development it works over HTTP; production requires HTTPS.
const isProduction = process.env.NODE_ENV === "production";
const authCookieOptions = {
  httpOnly: true,
  secure: isProduction,
  sameSite: isProduction ? "none" : "lax",
  maxAge: 7 * 24 * 60 * 60 * 1000,
  path: "/"
};

function setAuthCookie(res, token) {
  res.cookie("fash_auth", token, authCookieOptions);
}

function clearAuthCookie(res) {
  res.clearCookie("fash_auth", {
    httpOnly: true,
    secure: isProduction,
    sameSite: isProduction ? "none" : "lax",
    path: "/"
  });
}

// ==========================================
// MIDDLEWARE
// ==========================================

// BETA SECURITY HARDENING
const allowedOrigins = String(process.env.CLIENT_URL || '')
  .split(',').map(v => v.trim()).filter(Boolean);
app.use(cors({
  origin(origin, callback) {
    // Requests without an Origin header (for example, API tools)
    if (!origin) return callback(null, true);

    // Explicitly configured origins
    if (allowedOrigins.includes(origin)) return callback(null, true);

    // Local development: support VS Code Live Server and any localhost port.
    // Production remains restricted to CLIENT_URL / configured origins.
    if (
      process.env.NODE_ENV !== 'production' &&
      /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)
    ) {
      return callback(null, true);
    }

    return callback(new Error('Origin not allowed by CORS'));
  },
  credentials: true
}));
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
});
app.use(express.json({ limit: '1mb' }));

// Simple in-memory rate limiter. Replace with Redis before multi-instance scaling.
const rateBuckets = new Map();
function rateLimit({ windowMs, max, message }) {
  return (req, res, next) => {
    const key = `${req.ip}:${req.path}`; const now = Date.now();
    const bucket = rateBuckets.get(key) || { count: 0, reset: now + windowMs };
    if (now > bucket.reset) { bucket.count = 0; bucket.reset = now + windowMs; }
    bucket.count += 1; rateBuckets.set(key, bucket);
    res.setHeader('RateLimit-Limit', max);
    res.setHeader('RateLimit-Remaining', Math.max(0, max - bucket.count));
    if (bucket.count > max) return res.status(429).json({ error: message || 'Too many requests. Please try again later.' });
    next();
  };
}
const authRateLimit = rateLimit({ windowMs: 15 * 60 * 1000, max: 20, message: 'Too many authentication attempts. Please wait and try again.' });
const apiRateLimit = rateLimit({ windowMs: 60 * 1000, max: 180 });
app.use('/api', apiRateLimit);

function validEmail(value) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || '').trim()); }
function validPassword(value) { return typeof value === 'string' && value.length >= 8 && value.length <= 128; }
function isUuid(value) { return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(value || '')); }

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const frontendPath = path.resolve(__dirname, "../../frontend/FASH");
app.use(express.static(frontendPath));

// ==========================================
// HEALTH
// ==========================================

app.get("/api/health", async (_req, res) => {
  try {
    await query("SELECT 1");

    res.json({
      ok: true,
      database: "connected"
    });

  } catch (error) {
    console.error(error);

    res.status(500).json({
      ok: false,
      database: "disconnected"
    });
  }
});


async function getAdminSellers(req, res) {
  try {
    const result = await query(`
      SELECT
        u.id,
        u.full_name,
        u.email,
        u.seller_status,
        u.seller_verification_status,
        u.created_at,
        s.id AS store_id,
        COALESCE(s.name, '') AS store_name,
        COALESCE(s.status, 'DRAFT') AS store_status,
        COUNT(p.id)::int AS products,
        COALESCE((SELECT SUM(oi.quantity)::int FROM order_items oi JOIN orders oo ON oo.id=oi.order_id WHERE oi.seller_id=u.id AND LOWER(oo.status) IN ('delivered','completed')),0)::int AS completed_sales
      FROM users u
      LEFT JOIN stores s ON s.seller_id = u.id
      LEFT JOIN products p ON p.seller_id = u.id
      WHERE u.role = 'seller' AND u.seller_status IN ('approved','suspended')
      GROUP BY u.id, u.full_name, u.email, u.seller_status, u.seller_verification_status, u.created_at, s.id, s.name, s.status
      ORDER BY u.created_at DESC
    `);
    res.json({ sellers: result.rows.map(seller => ({
      id: seller.id,
      name: seller.full_name,
      email: seller.email,
      store: seller.store_name || 'No store yet',
      storeId: seller.store_id || null,
      products: seller.products,
      status: seller.seller_status === 'suspended' ? 'suspended' : (seller.store_name ? (seller.store_status || 'DRAFT').toLowerCase() : 'setup'),
      verificationStatus: seller.seller_verification_status || 'unverified',
      storeStatus: seller.store_status || 'DRAFT',
      completedSales: Number(seller.completed_sales || 0),
      verificationEligible: Number(seller.completed_sales || 0) >= 100,
      joined: seller.created_at
    })) });
  } catch (error) {
    console.error('GET ADMIN SELLERS ERROR:', error);
    res.status(500).json({ error: 'Could not load sellers' });
  }
}

async function updateAdminSellerStatus(req, res) {
  try {
    const { status } = req.body || {};
    if (!['active','suspended'].includes(status)) {
      return res.status(400).json({ error: 'Invalid seller status' });
    }
    const sellerStatus = status === 'suspended' ? 'suspended' : 'approved';
    const result = await query(
      `UPDATE users SET role='seller', seller_status=$1, updated_at=NOW() WHERE id=$2 RETURNING id, full_name, email, role, seller_status`,
      [sellerStatus, req.params.id]
    );
    if (!result.rowCount) return res.status(404).json({ error: 'Seller not found' });
    res.json({ message: status === 'suspended' ? 'Seller suspended' : 'Seller reactivated', seller: result.rows[0] });
  } catch (error) {
    console.error('UPDATE ADMIN SELLER STATUS ERROR:', error);
    res.status(500).json({ error: 'Could not update seller status' });
  }
}


// ==========================================
// ADMIN — APPLICATION ANALYTICS & STORES
// ==========================================
app.get("/api/admin/analytics/applications", requireAuth, requireAdmin, async (req,res) => {
  try {
    const period = String(req.query.period || "today").toLowerCase();
    const allowed = ["today","7d","1m","3m","6m","1y","all"];
    if (!allowed.includes(period)) return res.status(400).json({error:"Invalid period"});
    const days = {today:1,"7d":7,"1m":30,"3m":90,"6m":180,"1y":365,all:null}[period];
    const where = days ? `WHERE submitted_at >= NOW() - INTERVAL '${days} days'` : "";
    const totals = await query(`
      SELECT COUNT(*)::int AS total,
        COUNT(*) FILTER (WHERE status='approved')::int AS approved,
        COUNT(*) FILTER (WHERE status='pending' OR status='under_review')::int AS pending,
        COUNT(*) FILTER (WHERE status='rejected')::int AS rejected,
        COUNT(*) FILTER (WHERE status='changes_requested')::int AS changes_requested
      FROM seller_applications ${where}
    `);
    const trend = await query(`
      SELECT DATE(submitted_at) AS day, COUNT(*)::int AS applications
      FROM seller_applications ${where}
      GROUP BY DATE(submitted_at) ORDER BY day ASC
    `);
    res.json({period, ...totals.rows[0], trend: trend.rows});
  } catch(e) {
    console.error("APPLICATION ANALYTICS ERROR:",e);
    res.status(500).json({error:"Could not load application analytics"});
  }
});

app.get("/api/stores", async (_req,res) => {
  try {
    const result = await query(`
      SELECT s.id, s.name, s.description, s.logo_url, s.banner_url, s.location,
             s.is_featured, s.featured_until, s.featured_position,
             u.full_name AS seller_name,
             COUNT(p.id)::int AS products
      FROM stores s
      JOIN users u ON u.id=s.seller_id
      LEFT JOIN products p ON p.seller_id=s.seller_id AND p.status='active'
      WHERE s.is_active=TRUE AND u.seller_status='approved'
      GROUP BY s.id,u.full_name
      ORDER BY s.is_featured DESC, s.featured_position ASC NULLS LAST, s.created_at DESC
    `);
    res.json({stores:result.rows});
  } catch(e) { console.error("PUBLIC STORES ERROR:",e); res.status(500).json({error:"Could not load stores"}); }
});

app.post("/api/seller/store", requireAuth, requireApprovedSeller, async (req,res)=>{
  try {
    const {name,description,logoUrl,bannerUrl,location}=req.body||{};
    if(!name?.trim()) return res.status(400).json({error:"Store name is required"});
    const result=await query(`
      INSERT INTO stores (seller_id,name,description,logo_url,banner_url,location,status,is_active)
      VALUES ($1,$2,$3,$4,$5,$6,'DRAFT',FALSE)
      ON CONFLICT (seller_id) DO UPDATE SET
        name=EXCLUDED.name, description=EXCLUDED.description, logo_url=EXCLUDED.logo_url,
        banner_url=EXCLUDED.banner_url, location=EXCLUDED.location, updated_at=NOW()
      RETURNING *`,
      [req.user.sub,name.trim(),description?.trim()||null,logoUrl||null,bannerUrl||null,location?.trim()||null]);
    res.status(201).json({store:result.rows[0]});
  } catch(e){ console.error("STORE SAVE ERROR:",e); res.status(500).json({error:"Could not save store"}); }
});
app.get("/api/seller/store", requireAuth, requireApprovedSeller, async (req,res)=>{
  const result=await query("SELECT * FROM stores WHERE seller_id=$1",[req.user.sub]);
  res.json({store:result.rows[0]||null});
});

// ==========================================
// AUTH — REGISTER
// ==========================================

app.post("/api/auth/register", authRateLimit, async (req, res) => {
  try {

    const {
      fullName,
      email,
      password
    } = req.body;

    if (!fullName || !email || !password || !validEmail(email)) {
      return res.status(400).json({
        error: "Full name, email and password are required"
      });
    }

    if (!validPassword(password)) {
      return res.status(400).json({
        error: "Password must contain at least 8 characters"
      });
    }

    const normalizedEmail =
      email.trim().toLowerCase();

    const existing = await query(
      "SELECT id FROM users WHERE email = $1",
      [normalizedEmail]
    );

    if (existing.rowCount > 0) {
      return res.status(409).json({
        error: "An account with this email already exists"
      });
    }

    const passwordHash =
      await bcrypt.hash(password, 12);

    const result = await query(
      `INSERT INTO users
        (full_name, email, password_hash)
       VALUES ($1, $2, $3)
       RETURNING
        id,
        full_name,
        email,
        role,
        email_verified,
        seller_status,
        created_at`,
      [
        fullName.trim(),
        normalizedEmail,
        passwordHash
      ]
    );

    const user = result.rows[0];

    const token = createToken(user);
    setAuthCookie(res, token);

    res.status(201).json({
      message: "Account created successfully",
      token,
      user
    });

  } catch (error) {

    console.error(error);

    res.status(500).json({
      error: "Registration failed"
    });
  }
});

// ==========================================
// AUTH — LOGIN
// ==========================================

app.post("/api/auth/login", authRateLimit, async (req, res) => {
  try {

    const {
      email,
      password
    } = req.body;
    if (!email || !password || !validEmail(email)) {
      return res.status(400).json({
        error: "A valid email and password are required"
      });
    }

    const normalizedEmail =
      email.trim().toLowerCase();

    const result = await query(
      `SELECT
        id,
        full_name,
        email,
        password_hash,
        role,
        email_verified,
        seller_status,
        created_at
       FROM users
       WHERE email = $1`,
      [normalizedEmail]
    );

    if (result.rowCount === 0) {
      return res.status(401).json({
        error: "Invalid email or password"
      });
    }

    const user = result.rows[0];

    const passwordMatches =
      await bcrypt.compare(
        password,
        user.password_hash
      );

    if (!passwordMatches) {
      return res.status(401).json({
        error: "Invalid email or password"
      });
    }

    delete user.password_hash;

    const token = createToken(user);
    setAuthCookie(res, token);

    res.json({
      message: "Login successful",
      token,
      user
    });

  } catch (error) {

    console.error(error);

    res.status(500).json({
      error: "Login failed"
    });
  }
});

// ==========================================
// AUTH — SELLER LOGIN
// ==========================================

app.post("/api/auth/seller-login", authRateLimit, async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password || !validEmail(email)) {
      return res.status(400).json({ error: "A valid email and password are required" });
    }

    const normalizedEmail = email.trim().toLowerCase();
    const result = await query(
      `SELECT id, full_name, email, password_hash, role, email_verified, seller_status, created_at
       FROM users WHERE email = $1`,
      [normalizedEmail]
    );

    if (!result.rowCount) return res.status(401).json({ error: "Invalid email or password" });

    const user = result.rows[0];
    const passwordMatches = await bcrypt.compare(password, user.password_hash);
    if (!passwordMatches) return res.status(401).json({ error: "Invalid email or password" });

    if (user.seller_status === "suspended") {
      return res.status(403).json({ error: "Seller account suspended" });
    }

    // A seller application is the source of truth for portal access before approval.
    // This lets a customer who has just applied log in immediately as a seller.
    const application = await query(
      `SELECT status, id
       FROM seller_applications
       WHERE user_id = $1
       ORDER BY submitted_at DESC
       LIMIT 1`,
      [user.id]
    );

    if (!application.rowCount) {
      return res.status(403).json({ error: "No seller application found. Use your normal customer account to apply." });
    }

    const appStatus = application.rows[0].status;
    if (appStatus === "suspended" || user.seller_status === "suspended") {
      return res.status(403).json({ error: "Seller account suspended" });
    }

    const normalizedSellerStatus = appStatus === "under_review" ? "pending" : appStatus;
    if (normalizedSellerStatus !== "approved") {
      const banner = normalizedSellerStatus === "changes_requested" ? "Changes requested on your seller application." : normalizedSellerStatus === "rejected" ? "Your seller application was rejected." : "Your seller application is pending review.";
      return res.status(403).json({ error: banner, sellerApplicationStatus: normalizedSellerStatus, sellerPortalAccess: false });
    }

    // Keep the user record in sync with the application so the dashboard sees the same status.
    const syncedRole = normalizedSellerStatus === "approved" ? "seller" : "customer";
    const synced = await query(
      `UPDATE users
       SET seller_status = $1, role = CASE WHEN $1 = 'approved' THEN 'seller' ELSE role END
       WHERE id = $2
       RETURNING id, full_name, email, role, email_verified, seller_status, created_at`,
      [normalizedSellerStatus, user.id]
    );

    const safeUser = synced.rows[0];
    delete user.password_hash;
    const token = createToken(safeUser);
    res.json({
      message: "Seller login successful",
      token,
      user: safeUser,
      applicationId: application.rows[0].id
    });
  } catch (error) {
    console.error("SELLER LOGIN ERROR:", error);
    res.status(500).json({ error: "Seller login failed" });
  }
});

// ==========================================
// AUTH — CURRENT USER
// ==========================================


app.get(
  "/api/auth/me",
  requireAuth,
  async (req, res) => {

    try {

      const result = await query(
        `SELECT
          id,
          full_name,
          email,
          role,
          email_verified,
          seller_status,
          seller_verification_status,
          created_at
         FROM users
         WHERE id = $1`,
        [req.user.sub]
      );

      if (result.rowCount === 0) {
        return res.status(404).json({
          error: "User not found"
        });
      }

      const application = await query(`SELECT status,admin_notes,submitted_at,reviewed_at FROM seller_applications WHERE user_id=$1 ORDER BY submitted_at DESC LIMIT 1`,[req.user.sub]);
      res.json({
        user: result.rows[0],
        sellerApplication: application.rows[0] || null
      });

    } catch (error) {

      console.error(error);

      res.status(500).json({
        error: "Could not load account"
      });
    }
  }
);

// ==========================================
// PRODUCTS — PUBLIC
// ==========================================

app.get("/api/admin/sellers", requireAuth, requireAdmin, getAdminSellers);
app.patch("/api/admin/sellers/:id/status", requireAuth, requireAdmin, updateAdminSellerStatus);

app.get("/api/products", getAllProducts);
app.get("/api/products/featured", getFeaturedProducts);

// ==========================================
// PRODUCTS — SELLER
// ==========================================

app.post("/api/products", requireAuth, requireApprovedSeller, createProduct);
app.get("/api/products/my", requireAuth, requireApprovedSeller, getMyProducts);
app.patch("/api/products/:id", requireAuth, requireApprovedSeller, updateProduct);
app.delete("/api/products/:id", requireAuth, requireApprovedSeller, deleteProduct);

app.patch("/api/admin/products/:id/featured", requireAuth, requireAdmin, setProductFeatured);

// ==========================================
// AUTH — LOGOUT
// ==========================================


// ==========================================
// AUTH — CURRENT CUSTOMER
// ==========================================

app.post("/api/auth/logout", (_req, res) => {

  clearAuthCookie(res);
  res.json({
    message: "Logged out successfully"
  });

});

// ==========================================
// SELLER APPLICATIONS
// ==========================================

// Customer submits seller application

app.post(
  "/api/seller-applications",
  requireAuth,
  createApplication
);

// Customer views their own application

app.get(
  "/api/seller-applications/me",
  requireAuth,
  getMyApplication
);

// ==========================================
// ADMIN — SELLER APPLICATIONS
// ==========================================

// Admin views ALL applications

app.get(
  "/api/admin/seller-applications",
  requireAuth,
  requireAdmin,
  getAllApplications
);
app.get(
  "/api/admin/seller-applications/rejected",
  requireAuth,
  requireAdmin,
  getRejectedApplications
);

// Admin approves / rejects / requests changes

app.patch(
  "/api/admin/seller-applications/:id",
  requireAuth,
  requireAdmin,
  reviewApplication
);


// ==========================================
// STORE + PRODUCT LIFECYCLE
// ==========================================
app.get("/api/stores/:id", async (req,res)=>{
  try {
    const r=await query(`
      SELECT s.*, u.full_name AS seller_name, u.seller_verification_status
      FROM stores s JOIN users u ON u.id=s.seller_id
      WHERE s.id=$1`,[req.params.id]);
    if(!r.rowCount) return res.status(404).json({error:"Store not found"});
    const store=r.rows[0];
    const products=await query(`
      SELECT id,name,description,price,stock,category,image_url,status
      FROM products WHERE store_id=$1 AND status='approved' ORDER BY created_at DESC`,[req.params.id]);
    res.json({store,products:products.rows});
  } catch(e){console.error(e);res.status(500).json({error:"Could not load store"});}
});

app.post("/api/seller/store/publish", requireAuth, requireApprovedSeller, async(req,res)=>{
  try{
    const r=await query(`UPDATE stores SET status='LIVE',is_active=TRUE,updated_at=NOW() WHERE seller_id=$1 RETURNING *`,[req.user.sub]);
    if(!r.rowCount) return res.status(404).json({error:"Create your store first"});
    res.json({store:r.rows[0]});
  }catch(e){res.status(500).json({error:"Could not publish store"});}
});

app.patch("/api/seller/store/status", requireAuth, requireApprovedSeller, async(req,res)=>{
  const allowed=["DRAFT","LIVE","SUSPENDED","CLOSED"];
  const status=String(req.body?.status||"").toUpperCase();
  if(!allowed.includes(status)) return res.status(400).json({error:"Invalid store status"});
  try{
    const r=await query(`UPDATE stores SET status=$1,is_active=($1='LIVE'),updated_at=NOW() WHERE seller_id=$2 RETURNING *`,[status,req.user.sub]);
    if(!r.rowCount) return res.status(404).json({error:"Store not found"});
    res.json({store:r.rows[0]});
  }catch(e){res.status(500).json({error:"Could not update store status"});}
});

// Admin: seller verification is a separate achievement-based action.
app.patch("/api/admin/sellers/:id/verification", requireAuth, requireAdmin, async(req,res)=>{
  const status=String(req.body?.status||"").toLowerCase();
  if(!["verified","unverified","needs_info"].includes(status)) return res.status(400).json({error:"Invalid verification status"});
  try{
    const sales=await query(`SELECT COALESCE(SUM(oi.quantity),0)::int AS completed_sales FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.seller_id=$1 AND LOWER(o.status) IN ('delivered','completed')`,[req.params.id]);
    const completedSales=Number(sales.rows[0]?.completed_sales||0);
    if(status==='verified' && completedSales < 100) return res.status(409).json({error:`Seller needs 100 completed/delivered sales. Current qualifying sales: ${completedSales}.`});
    const r=await query(`UPDATE users SET seller_verification_status=$1,updated_at=NOW() WHERE id=$2 AND seller_status='approved' RETURNING id,full_name,email,seller_status,seller_verification_status`,[status,req.params.id]);
    if(!r.rowCount) return res.status(404).json({error:"Approved seller not found"});
    res.json({seller:r.rows[0]});
  }catch(e){res.status(500).json({error:"Could not update seller verification"});}
});

// Admin product review
app.patch("/api/admin/products/:id/review", requireAuth, requireAdmin, async(req,res)=>{
  const status=String(req.body?.status||"").toLowerCase();
  if(!["approved","rejected","hidden"].includes(status)) return res.status(400).json({error:"Invalid product review status"});
  try{
    const r=await query(`UPDATE products SET status=$1,rejection_reason=$2,reviewed_at=NOW(),reviewed_by=$3,updated_at=NOW() WHERE id=$4 RETURNING *`,
      [status,req.body?.reason?.trim()||null,req.user.sub,req.params.id]);
    if(!r.rowCount) return res.status(404).json({error:"Product not found"});
    res.json({product:r.rows[0]});
  }catch(e){console.error(e);res.status(500).json({error:"Could not review product"});}
});

// Customer favorite stores
app.post("/api/stores/:id/follow", requireAuth, async(req,res)=>{
  try{
    await query(`INSERT INTO store_followers(store_id,user_id) VALUES($1,$2) ON CONFLICT DO NOTHING`,[req.params.id,req.user.sub]);
    res.json({following:true});
  }catch(e){res.status(500).json({error:"Could not follow store"});}
});
app.delete("/api/stores/:id/follow", requireAuth, async(req,res)=>{
  try{ await query(`DELETE FROM store_followers WHERE store_id=$1 AND user_id=$2`,[req.params.id,req.user.sub]); res.json({following:false}); }
  catch(e){res.status(500).json({error:"Could not unfollow store"});}
});
app.get("/api/me/favorite-stores", requireAuth, async(req,res)=>{
  try{
    const r=await query(`SELECT s.*,s.rating,s.rating_count FROM stores s JOIN store_followers f ON f.store_id=s.id WHERE f.user_id=$1 ORDER BY f.created_at DESC`,[req.user.sub]);
    res.json({stores:r.rows});
  }catch(e){res.status(500).json({error:"Could not load favorite stores"});}
});

// Store ratings: only customers with an order item for that store can review.
app.post("/api/stores/:id/reviews", requireAuth, async(req,res)=>{
  const rating=Number(req.body?.rating);
  if(!Number.isFinite(rating)||rating<1||rating>5) return res.status(400).json({error:"Rating must be between 1 and 5"});
  try{
    const eligible=await query(`SELECT o.id FROM orders o JOIN order_items oi ON oi.order_id=o.id WHERE o.customer_id=$1 AND oi.store_id=$2 AND o.status IN ('completed','delivered') LIMIT 1`,[req.user.sub,req.params.id]);
    if(!eligible.rowCount) return res.status(403).json({error:"You can rate a store after purchasing from it"});
    const orderId=req.body.orderId||eligible.rows[0].id;
    const r=await query(`INSERT INTO store_reviews(store_id,user_id,order_id,rating,review) VALUES($1,$2,$3,$4,$5) RETURNING *`,
      [req.params.id,req.user.sub,orderId,rating,req.body?.review?.trim()||null]);
    await query(`UPDATE stores SET rating=ROUND((SELECT AVG(rating) FROM store_reviews WHERE store_id=$1)::numeric,1),rating_count=(SELECT COUNT(*) FROM store_reviews WHERE store_id=$1),updated_at=NOW() WHERE id=$1`,[req.params.id]);
    res.status(201).json({review:r.rows[0]});
  }catch(e){
    if(e.code==="23505") return res.status(409).json({error:"You already rated this store for this order"});
    res.status(500).json({error:"Could not save store rating"});
  }
});

app.get("/api/admin/products/all", requireAuth, requireAdmin, async(_req,res)=>{
  try{
    const r=await query(`SELECT p.*,u.full_name seller_name,s.name store_name FROM products p JOIN users u ON u.id=p.seller_id LEFT JOIN stores s ON s.id=p.store_id ORDER BY p.created_at DESC`);
    res.json({products:r.rows});
  }catch(e){res.status(500).json({error:"Could not load admin products"});}
});


app.get("/api/customers", requireAuth, async(req,res)=>{try{let r;if(req.user.role==="admin")r=await query(`SELECT id,full_name,email,created_at FROM users WHERE role='customer' ORDER BY created_at DESC`);else r=await query(`SELECT DISTINCT u.id,u.full_name,u.email,u.created_at FROM users u JOIN orders o ON o.customer_id=u.id JOIN order_items oi ON oi.order_id=o.id WHERE oi.seller_id=$1 ORDER BY u.created_at DESC`,[req.user.sub]);res.json({customers:r.rows});}catch(e){res.status(500).json({error:"Could not load customers"});}});
// ==========================================
// ORDERS — CUSTOMER / SELLER / ADMIN
// ==========================================
app.post("/api/orders", requireAuth, async(req,res)=>{
  const items=Array.isArray(req.body?.items)?req.body.items:[];
  if(!items.length)return res.status(400).json({error:"Order items are required"});
  const client=await (await import("./db.js")).pool.connect();
  try{
    await client.query("BEGIN");
    const ids=items.map(i=>i.productId||i.id);
    const r=await client.query(`SELECT p.id,p.price,p.stock,p.store_id,p.seller_id,s.status store_status FROM products p JOIN stores s ON s.id=p.store_id WHERE p.id=ANY($1::uuid[]) AND p.status='approved' AND s.status='LIVE' FOR UPDATE`,[ids]);
    if(r.rows.length!==items.length){await client.query("ROLLBACK");return res.status(400).json({error:"One or more products are unavailable"});}
    let total=0;
    for(const i of items){const p=r.rows.find(x=>x.id===String(i.productId||i.id));const q=Math.max(1,Number(i.quantity||1));if(q>p.stock)throw new Error("Insufficient stock");total+=Number(p.price)*q;}
    const o=await client.query(`INSERT INTO orders(customer_id,total) VALUES($1,$2) RETURNING *`,[req.user.sub,total]);
    for(const i of items){const p=r.rows.find(x=>x.id===String(i.productId||i.id));const q=Math.max(1,Number(i.quantity||1));await client.query(`INSERT INTO order_items(order_id,product_id,store_id,seller_id,quantity,unit_price) VALUES($1,$2,$3,$4,$5,$6)`,[o.rows[0].id,p.id,p.store_id,p.seller_id,q,p.price]);await client.query(`UPDATE products SET stock=stock-$1 WHERE id=$2`,[q,p.id]);}
    await client.query("COMMIT");res.status(201).json({order:o.rows[0]});
  }catch(e){await client.query("ROLLBACK");res.status(500).json({error:e.message||"Could not create order"});}finally{client.release();}
});
app.patch("/api/orders/:id/status",requireAuth,async(req,res)=>{
  if (!isUuid(req.params.id)) return res.status(400).json({error:"Invalid order id"});
  const status=String(req.body?.status||"").toLowerCase();
  if(!["pending","processing","confirmed","shipped","delivered","completed","cancelled"].includes(status)) return res.status(400).json({error:"Invalid order status"});
  try{
    const r=await query(`UPDATE orders o SET status=$1,updated_at=NOW() WHERE o.id=$2 AND ($3='admin' OR EXISTS(SELECT 1 FROM order_items oi WHERE oi.order_id=o.id AND oi.seller_id=$4)) RETURNING *`,[status,req.params.id,req.user.role,req.user.sub]);
    if(!r.rowCount)return res.status(404).json({error:"Order not found or not permitted"});
    res.json({order:r.rows[0]});
  }catch(e){res.status(500).json({error:"Could not update order"});}
});
app.get("/api/orders",requireAuth,async(req,res)=>{
 try{
  let r;
  if(req.user.role==="admin") r=await query(`SELECT o.*,u.full_name customer_name,u.email customer_email FROM orders o JOIN users u ON u.id=o.customer_id ORDER BY o.created_at DESC`);
  else r=await query(`SELECT DISTINCT o.*,u.full_name customer_name FROM orders o JOIN users u ON u.id=o.customer_id JOIN order_items oi ON oi.order_id=o.id WHERE o.customer_id=$1 OR oi.seller_id=$1 ORDER BY o.created_at DESC`,[req.user.sub]);
  res.json({orders:r.rows});
 }catch(e){res.status(500).json({error:"Could not load orders"});}
});

// ==========================================
// CATEGORIES
// ==========================================
app.get("/api/categories", async (_req,res)=>{
  try{
    const r=await query(`SELECT id,name,slug FROM categories WHERE is_active=TRUE ORDER BY name`);
    res.json({categories:r.rows});
  }catch(e){res.status(500).json({error:"Could not load categories"});}
});
app.post("/api/admin/categories", requireAuth, requireAdmin, async(req,res)=>{
  try{
    const name=String(req.body?.name||"").trim();
    if(!name) return res.status(400).json({error:"Category name is required"});
    const slug=name.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");
    const r=await query(`INSERT INTO categories(name,slug) VALUES($1,$2) ON CONFLICT(name) DO UPDATE SET is_active=TRUE RETURNING *`,[name,slug]);
    res.status(201).json({category:r.rows[0]});
  }catch(e){res.status(500).json({error:"Could not create category"});}
});

// ==========================================
// ORDER DETAILS / CANCELLATION
// ==========================================
app.get("/api/orders/:id", requireAuth, async(req,res)=>{
  try{
    const r=await query(`
      SELECT o.*,u.full_name customer_name,u.email customer_email,
        COALESCE(json_agg(json_build_object(
          'id',oi.id,'productId',oi.product_id,'productName',p.name,'imageUrl',p.image_url,
          'storeId',oi.store_id,'storeName',st.name,'sellerId',oi.seller_id,
          'sellerName',su.full_name,'quantity',oi.quantity,'unitPrice',oi.unit_price
        ) ORDER BY p.name) FILTER (WHERE oi.id IS NOT NULL),'[]') items
      FROM orders o
      JOIN users u ON u.id=o.customer_id
      LEFT JOIN order_items oi ON oi.order_id=o.id
      LEFT JOIN products p ON p.id=oi.product_id
      LEFT JOIN stores st ON st.id=oi.store_id
      LEFT JOIN users su ON su.id=oi.seller_id
      WHERE o.id=$1 AND (
        o.customer_id=$2 OR $3='admin' OR EXISTS(SELECT 1 FROM order_items x WHERE x.order_id=o.id AND x.seller_id=$2)
      )
      GROUP BY o.id,u.full_name,u.email
    `,[req.params.id,req.user.sub,req.user.role]);
    if(!r.rowCount)return res.status(404).json({error:"Order not found"});
    res.json({order:r.rows[0]});
  }catch(e){console.error(e);res.status(500).json({error:"Could not load order details"});}
});

app.post("/api/orders/:id/cancel", requireAuth, async(req,res)=>{
  try{
    const r=await query(`UPDATE orders SET status='cancelled',updated_at=NOW() WHERE id=$1 AND customer_id=$2 AND status IN ('pending','processing','confirmed') RETURNING *`,[req.params.id,req.user.sub]);
    if(!r.rowCount)return res.status(409).json({error:"Order cannot be cancelled at this stage"});
    await query(`INSERT INTO notifications(user_id,type,title,message) SELECT u.id,'order_cancelled','Order cancelled','A customer cancelled order '||$1 FROM users u WHERE u.role='admin'`,[r.rows[0].id]);
    res.json({order:r.rows[0]});
  }catch(e){res.status(500).json({error:"Could not cancel order"});}
});

// ==========================================
// RETURNS
// ==========================================
app.post("/api/returns", requireAuth, async(req,res)=>{
  try{
    const orderId=req.body?.orderId, reason=String(req.body?.reason||"").trim();
    if(!orderId||!reason)return res.status(400).json({error:"Order and return reason are required"});
    const item=await query(`SELECT oi.store_id,oi.seller_id FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.order_id=$1 AND o.customer_id=$2 AND o.status IN ('delivered','completed') LIMIT 1`,[orderId,req.user.sub]);
    if(!item.rowCount)return res.status(403).json({error:"Only delivered/completed orders can be returned"});
    const r=await query(`INSERT INTO returns(order_id,customer_id,store_id,seller_id,reason,details) VALUES($1,$2,$3,$4,$5,$6) RETURNING *`,[orderId,req.user.sub,item.rows[0].store_id,item.rows[0].seller_id,reason,String(req.body?.details||"").trim()||null]);
    await query(`INSERT INTO notifications(user_id,type,title,message) SELECT u.id,'return_pending','New return request','Return request '||$1||' is pending' FROM users u WHERE u.role='admin'`,[r.rows[0].id]);
    res.status(201).json({returnRequest:r.rows[0]});
  }catch(e){console.error(e);res.status(500).json({error:"Could not create return request"});}
});
app.get("/api/returns", requireAuth, async(req,res)=>{
  try{
    let r;
    if(req.user.role==="admin") r=await query(`SELECT r.*,u.full_name customer_name,s.name store_name FROM returns r JOIN users u ON u.id=r.customer_id LEFT JOIN stores s ON s.id=r.store_id ORDER BY r.created_at DESC`);
    else r=await query(`SELECT r.*,u.full_name customer_name,s.name store_name FROM returns r JOIN users u ON u.id=r.customer_id LEFT JOIN stores s ON s.id=r.store_id WHERE r.customer_id=$1 OR r.seller_id=$1 ORDER BY r.created_at DESC`,[req.user.sub]);
    res.json({returns:r.rows,pendingCount:r.rows.filter(x=>x.status==='pending').length});
  }catch(e){res.status(500).json({error:"Could not load returns"});}
});
app.patch("/api/returns/:id/status", requireAuth, async(req,res)=>{
  const status=String(req.body?.status||"").toLowerCase();
  if(!["approved","rejected","received","refunded"].includes(status))return res.status(400).json({error:"Invalid return status"});
  try{
    const r=await query(`UPDATE returns SET status=$1,updated_at=NOW() WHERE id=$2 AND ($3='admin' OR seller_id=$4) RETURNING *`,[status,req.params.id,req.user.role,req.user.sub]);
    if(!r.rowCount)return res.status(404).json({error:"Return not found"});
    res.json({returnRequest:r.rows[0]});
  }catch(e){res.status(500).json({error:"Could not update return"});}
});

// ==========================================
// v6.3.2 CUSTOMER DATABASE — CART & WISHLIST
// ==========================================
async function getOrCreateCart(userId){const r=await query(`INSERT INTO carts(user_id) VALUES($1) ON CONFLICT(user_id) DO UPDATE SET updated_at=NOW() RETURNING id`,[userId]);return r.rows[0].id;}
async function getOrCreateWishlist(userId){const r=await query(`INSERT INTO wishlists(user_id) VALUES($1) ON CONFLICT(user_id) DO UPDATE SET updated_at=NOW() RETURNING id`,[userId]);return r.rows[0].id;}
app.get("/api/cart",requireAuth,async(req,res)=>{try{const id=await getOrCreateCart(req.user.sub);const r=await query(`SELECT ci.id,ci.product_id,ci.quantity,p.name,p.price,p.image_url,p.stock FROM cart_items ci JOIN products p ON p.id=ci.product_id WHERE ci.cart_id=$1 ORDER BY ci.created_at DESC`,[id]);res.json({items:r.rows});}catch(e){console.error("GET CART ERROR:",e);res.status(500).json({error:"Could not load cart"});}});
app.post("/api/cart/items",requireAuth,async(req,res)=>{try{const productId=req.body?.product_id,quantity=Math.max(1,Number(req.body?.quantity||1));if(!productId)return res.status(400).json({error:"product_id is required"});const p=await query(`SELECT id,stock FROM products WHERE id=$1`,[productId]);if(!p.rowCount)return res.status(404).json({error:"Product not found"});if(Number(p.rows[0].stock||0)<quantity)return res.status(400).json({error:"Requested quantity is not available"});const id=await getOrCreateCart(req.user.sub);const r=await query(`INSERT INTO cart_items(cart_id,product_id,quantity) VALUES($1,$2,$3) ON CONFLICT(cart_id,product_id) DO UPDATE SET quantity=LEAST(cart_items.quantity+EXCLUDED.quantity,(SELECT stock FROM products WHERE id=EXCLUDED.product_id)),updated_at=NOW() RETURNING *`,[id,productId,quantity]);res.status(201).json({item:r.rows[0]});}catch(e){console.error("ADD CART ITEM ERROR:",e);res.status(500).json({error:"Could not add item"});}});
app.patch("/api/cart/items/:itemId",requireAuth,async(req,res)=>{try{const q=Number(req.body?.quantity);if(!Number.isInteger(q)||q<1)return res.status(400).json({error:"Positive quantity required"});const r=await query(`UPDATE cart_items ci SET quantity=LEAST($1,p.stock),updated_at=NOW() FROM carts c,products p WHERE ci.id=$2 AND ci.cart_id=c.id AND c.user_id=$3 AND p.id=ci.product_id RETURNING ci.*`,[q,req.params.itemId,req.user.sub]);if(!r.rowCount)return res.status(404).json({error:"Cart item not found"});res.json({item:r.rows[0]});}catch(e){res.status(500).json({error:"Could not update cart item"});}});
app.delete("/api/cart/items/:itemId",requireAuth,async(req,res)=>{try{const r=await query(`DELETE FROM cart_items ci USING carts c WHERE ci.id=$1 AND ci.cart_id=c.id AND c.user_id=$2 RETURNING ci.id`,[req.params.itemId,req.user.sub]);if(!r.rowCount)return res.status(404).json({error:"Cart item not found"});res.json({success:true});}catch(e){res.status(500).json({error:"Could not remove cart item"});}});
app.get("/api/wishlist",requireAuth,async(req,res)=>{try{const id=await getOrCreateWishlist(req.user.sub);const r=await query(`SELECT wi.id,wi.product_id,wi.created_at,p.name,p.price,p.image_url,p.stock FROM wishlist_items wi JOIN products p ON p.id=wi.product_id WHERE wi.wishlist_id=$1 ORDER BY wi.created_at DESC`,[id]);res.json({items:r.rows});}catch(e){res.status(500).json({error:"Could not load wishlist"});}});
app.post("/api/wishlist/items",requireAuth,async(req,res)=>{try{const productId=req.body?.product_id;if(!productId)return res.status(400).json({error:"product_id is required"});const p=await query(`SELECT id FROM products WHERE id=$1`,[productId]);if(!p.rowCount)return res.status(404).json({error:"Product not found"});const id=await getOrCreateWishlist(req.user.sub);const r=await query(`INSERT INTO wishlist_items(wishlist_id,product_id) VALUES($1,$2) ON CONFLICT(wishlist_id,product_id) DO NOTHING RETURNING *`,[id,productId]);res.status(r.rowCount?201:200).json({success:true,already_saved:!r.rowCount,item:r.rows[0]||null});}catch(e){res.status(500).json({error:"Could not save item"});}});
app.delete("/api/wishlist/items/:productId",requireAuth,async(req,res)=>{try{const r=await query(`DELETE FROM wishlist_items wi USING wishlists w WHERE wi.wishlist_id=w.id AND wi.product_id=$1 AND w.user_id=$2 RETURNING wi.id`,[req.params.productId,req.user.sub]);res.json({success:true,removed:!!r.rowCount});}catch(e){res.status(500).json({error:"Could not remove saved item"});}});

// ==========================================
// NOTIFICATIONS
// ==========================================
app.get("/api/notifications", requireAuth, async(req,res)=>{
  try{const r=await query(`SELECT * FROM notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50`,[req.user.sub]);res.json({notifications:r.rows});}
  catch(e){res.status(500).json({error:"Could not load notifications"});}
});
app.post("/api/notifications/read-all", requireAuth, async(req,res)=>{
  try{await query(`UPDATE notifications SET is_read=TRUE WHERE user_id=$1`,[req.user.sub]);res.json({ok:true});}
  catch(e){res.status(500).json({error:"Could not update notifications"});}
});

// ==========================================
// SAFE ERROR HANDLER
// ==========================================
app.use((error, _req, res, _next) => {
  console.error('REQUEST ERROR:', error);
  if (error.message === 'Origin not allowed by CORS') return res.status(403).json({ error: 'Origin not allowed' });
  res.status(500).json({ error: 'An unexpected server error occurred' });
});

// ==========================================
// 404
// ==========================================

app.use((_req, res) => {

  res.status(404).json({
    error: "Route not found"
  });

});

// ==========================================
// START SERVER
// ==========================================

async function startServer() {
  try {
    await query(`ALTER TABLE users DROP CONSTRAINT IF EXISTS users_seller_status_check`);
    await query(`ALTER TABLE users ADD CONSTRAINT users_seller_status_check CHECK (seller_status IN ('none','pending','approved','rejected','changes_requested','suspended'))`);
    await query(`ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS location VARCHAR(180)`);
    await query(`ALTER TABLE seller_applications DROP CONSTRAINT IF EXISTS seller_applications_status_check`);
    await query(`ALTER TABLE seller_applications ADD CONSTRAINT seller_applications_status_check CHECK (status IN ('pending','under_review','approved','rejected','changes_requested'))`);
    await query(`CREATE UNIQUE INDEX IF NOT EXISTS ux_one_active_seller_application ON seller_applications(user_id) WHERE status IN ('pending','under_review','changes_requested')`);
    await query(`CREATE TABLE IF NOT EXISTS products (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      seller_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name VARCHAR(180) NOT NULL,
      description TEXT,
      price NUMERIC(14,2) NOT NULL CHECK (price > 0),
      stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
      category VARCHAR(100) NOT NULL,
      image_url TEXT,
      status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','hidden','pending_review','approved','rejected')),
      is_featured BOOLEAN NOT NULL DEFAULT FALSE,
      featured_until TIMESTAMPTZ,
      featured_position INTEGER,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )`);
    await query(`CREATE TABLE IF NOT EXISTS stores (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      seller_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name VARCHAR(150) NOT NULL,
      description TEXT,
      logo_url TEXT,
      banner_url TEXT,
      location VARCHAR(180),
      is_active BOOLEAN NOT NULL DEFAULT TRUE,
      is_featured BOOLEAN NOT NULL DEFAULT FALSE,
      featured_until TIMESTAMPTZ,
      featured_position INTEGER,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )`);
    await query(`CREATE INDEX IF NOT EXISTS idx_stores_featured ON stores(is_featured, featured_position)`);
    await query(`CREATE INDEX IF NOT EXISTS idx_stores_active ON stores(is_active)`);
    await query(`CREATE INDEX IF NOT EXISTS idx_products_seller_id ON products(seller_id)`);
    await query(`CREATE INDEX IF NOT EXISTS idx_products_status ON products(status)`);
    await query(`CREATE INDEX IF NOT EXISTS idx_products_category ON products(category)`);
    await query(`ALTER TABLE products ADD COLUMN IF NOT EXISTS is_featured BOOLEAN NOT NULL DEFAULT FALSE`);
    await query(`ALTER TABLE products ADD COLUMN IF NOT EXISTS featured_until TIMESTAMPTZ`);
    await query(`ALTER TABLE products ADD COLUMN IF NOT EXISTS featured_position INTEGER`);
    await query(`CREATE INDEX IF NOT EXISTS idx_products_featured ON products(is_featured, featured_position)`);
    await query(`CREATE INDEX IF NOT EXISTS idx_products_created_at ON products(created_at DESC)`);
    await query(`DROP TRIGGER IF EXISTS products_updated_at ON products`);
    await query(`CREATE TRIGGER products_updated_at BEFORE UPDATE ON products FOR EACH ROW EXECUTE FUNCTION set_updated_at()`);

    await query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS seller_type VARCHAR(20) NOT NULL DEFAULT 'individual'`);
    await query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS seller_verification_status VARCHAR(30) NOT NULL DEFAULT 'unverified'`);
    await query(`ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS seller_type VARCHAR(20) NOT NULL DEFAULT 'individual'`);
    await query(`ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS legal_name VARCHAR(180)`);
    await query(`ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS business_registration_number VARCHAR(120)`);
    await query(`ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS address VARCHAR(250)`);
    await query(`ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS country VARCHAR(100)`);
    await query(`ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS id_type VARCHAR(80)`);
    await query(`ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS id_number VARCHAR(120)`);
    await query(`ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS id_document_url TEXT`);
    await query(`ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS registration_document_url TEXT`);
    await query(`ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS achievement_notes TEXT`);
    await query(`ALTER TABLE stores ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'DRAFT'`);
    await query(`ALTER TABLE stores ADD COLUMN IF NOT EXISTS rating NUMERIC(3,1) NOT NULL DEFAULT 0`);
    await query(`ALTER TABLE stores ADD COLUMN IF NOT EXISTS rating_count INTEGER NOT NULL DEFAULT 0`);
    await query(`UPDATE stores SET status=CASE WHEN is_active THEN 'LIVE' ELSE 'DRAFT' END WHERE status IS NULL OR (status='DRAFT' AND is_active=TRUE)`);
    await query(`ALTER TABLE stores DROP CONSTRAINT IF EXISTS stores_status_check`);
    await query(`ALTER TABLE stores ADD CONSTRAINT stores_status_check CHECK (status IN ('DRAFT','LIVE','SUSPENDED','CLOSED'))`);
    await query(`ALTER TABLE stores ADD COLUMN IF NOT EXISTS rating_count INTEGER NOT NULL DEFAULT 0`);
    await query(`ALTER TABLE products ADD COLUMN IF NOT EXISTS store_id UUID REFERENCES stores(id) ON DELETE CASCADE`);
    await query(`ALTER TABLE products ADD COLUMN IF NOT EXISTS rejection_reason TEXT`);
    await query(`ALTER TABLE products ADD COLUMN IF NOT EXISTS reviewed_at TIMESTAMPTZ`);
    await query(`ALTER TABLE products ADD COLUMN IF NOT EXISTS reviewed_by UUID REFERENCES users(id)`);
    await query(`ALTER TABLE products ADD COLUMN IF NOT EXISTS scheduled_at TIMESTAMPTZ`);
    // IMPORTANT: drop the old constraint BEFORE converting legacy active/inactive rows.
    await query(`ALTER TABLE products DROP CONSTRAINT IF EXISTS products_status_check`);
    await query(`UPDATE products SET status='approved' WHERE status='active'`);
    await query(`UPDATE products SET status='hidden' WHERE status='inactive'`);
    await query(`UPDATE products SET status='approved' WHERE status='live'`);
    await query(`UPDATE products SET status='draft' WHERE status IS NULL OR status NOT IN ('draft','hidden','pending_review','approved','rejected','scheduled')`);
    await query(`ALTER TABLE products ADD CONSTRAINT products_status_check CHECK (status IN ('draft','hidden','pending_review','approved','rejected','scheduled'))`);
    await query(`ALTER TABLE products ALTER COLUMN status SET DEFAULT 'draft'`);
    await query(`ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS store_name VARCHAR(150)`);
    await query(`ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS store_description TEXT`);
    await query(`ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS store_logo_url TEXT`);
    await query(`ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS store_banner_url TEXT`);
    await query(`ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS store_location VARCHAR(180)`);
    await query(`CREATE TABLE IF NOT EXISTS categories (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),name VARCHAR(100) UNIQUE NOT NULL,slug VARCHAR(120) UNIQUE NOT NULL,is_active BOOLEAN NOT NULL DEFAULT TRUE,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
    await query(`CREATE TABLE IF NOT EXISTS returns (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,customer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,store_id UUID REFERENCES stores(id) ON DELETE SET NULL,seller_id UUID REFERENCES users(id) ON DELETE SET NULL,reason VARCHAR(180) NOT NULL,details TEXT,status VARCHAR(30) NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','received','refunded')),created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
    await query(`CREATE TABLE IF NOT EXISTS notifications (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,type VARCHAR(50) NOT NULL,title VARCHAR(180) NOT NULL,message TEXT NOT NULL,is_read BOOLEAN NOT NULL DEFAULT FALSE,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
    await query(`CREATE TABLE IF NOT EXISTS orders (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),customer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,status VARCHAR(30) NOT NULL DEFAULT 'pending',total NUMERIC(14,2) NOT NULL DEFAULT 0,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
    await query(`CREATE TABLE IF NOT EXISTS order_items (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,product_id UUID NOT NULL REFERENCES products(id) ON DELETE RESTRICT,store_id UUID NOT NULL REFERENCES stores(id) ON DELETE RESTRICT,seller_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,quantity INTEGER NOT NULL CHECK(quantity>0),unit_price NUMERIC(14,2) NOT NULL CHECK(unit_price>=0))`);
    await query(`DROP TRIGGER IF EXISTS orders_updated_at ON orders`);
    await query(`CREATE TRIGGER orders_updated_at BEFORE UPDATE ON orders FOR EACH ROW EXECUTE FUNCTION set_updated_at()`);
    await query(`CREATE INDEX IF NOT EXISTS idx_orders_customer_status ON orders(customer_id,status,created_at DESC)`);
    await query(`CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id)`);
    await query(`CREATE TABLE IF NOT EXISTS store_followers (store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),PRIMARY KEY(store_id,user_id))`);
    await query(`CREATE TABLE IF NOT EXISTS store_reviews (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,rating NUMERIC(2,1) NOT NULL CHECK(rating>=1 AND rating<=5),review TEXT,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),UNIQUE(store_id,user_id,order_id))`);

    // v6.3.2 customer persistence
    // v6.3.2.1 safe upgrade: support existing legacy cart/wishlist tables.
    // CREATE TABLE IF NOT EXISTS alone is not enough when an older table already exists
    // with different columns, so add the new ownership columns before creating indexes.
    await query(`CREATE TABLE IF NOT EXISTS carts (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )`);

    await query(`CREATE TABLE IF NOT EXISTS cart_items (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      cart_id UUID,
      product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      quantity INTEGER NOT NULL DEFAULT 1 CHECK(quantity>0),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )`);

    // Upgrade a legacy cart_items table that stores user_id directly.
    await query(`ALTER TABLE cart_items ADD COLUMN IF NOT EXISTS cart_id UUID`);
    await query(`INSERT INTO carts (user_id)
      SELECT DISTINCT user_id FROM cart_items
      WHERE user_id IS NOT NULL
      ON CONFLICT (user_id) DO NOTHING`);
    await query(`UPDATE cart_items ci
      SET cart_id = c.id
      FROM carts c
      WHERE ci.cart_id IS NULL AND ci.user_id = c.user_id`);

    await query(`CREATE TABLE IF NOT EXISTS wishlists (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )`);

    await query(`CREATE TABLE IF NOT EXISTS wishlist_items (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      wishlist_id UUID,
      product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )`);

    // Upgrade a legacy wishlist_items table that stores user_id directly.
    await query(`ALTER TABLE wishlist_items ADD COLUMN IF NOT EXISTS wishlist_id UUID`);
    await query(`INSERT INTO wishlists (user_id)
      SELECT DISTINCT user_id FROM wishlist_items
      WHERE user_id IS NOT NULL
      ON CONFLICT (user_id) DO NOTHING`);
    await query(`UPDATE wishlist_items wi
      SET wishlist_id = w.id
      FROM wishlists w
      WHERE wi.wishlist_id IS NULL AND wi.user_id = w.user_id`);

    // Indexes are created only after the required columns are guaranteed to exist.
    await query(`CREATE INDEX IF NOT EXISTS idx_cart_items_cart ON cart_items(cart_id)`);
    await query(`CREATE INDEX IF NOT EXISTS idx_wishlist_items_wishlist ON wishlist_items(wishlist_id)`);

    const publishScheduledProducts = async () => { try { await query(`UPDATE products SET status='approved',scheduled_at=NULL,updated_at=NOW() WHERE status='scheduled' AND scheduled_at IS NOT NULL AND scheduled_at <= NOW()`); } catch (e) { console.error('SCHEDULED PRODUCT PUBLISH ERROR:', e); } };
    await publishScheduledProducts();
    setInterval(publishScheduledProducts, 30000);



// ==========================================
// PAYSTACK CHECKOUT (Nigeria / NGN)
// ==========================================
app.get("/api/payments/public-key", (_req, res) => {
  res.json({ publicKey: process.env.PAYSTACK_PUBLIC_KEY || "" });
});

app.post("/api/checkout/initialize", requireAuth, async (req, res) => {
  try {
    const cartId = await getOrCreateCart(req.user.sub);
    const itemsRes = await query(
      `SELECT ci.product_id, ci.quantity, p.name, p.price, p.stock, p.store_id, p.seller_id, p.status
       FROM cart_items ci
       JOIN products p ON p.id = ci.product_id
       WHERE ci.cart_id = $1`,
      [cartId]
    );
    if (!itemsRes.rowCount) {
      return res.status(400).json({ error: "Your cart is empty" });
    }
    for (const row of itemsRes.rows) {
      if (row.status !== "approved") {
        return res.status(400).json({ error: `Product "${row.name}" is no longer available` });
      }
      if (Number(row.stock) < Number(row.quantity)) {
        return res.status(400).json({ error: `Insufficient stock for "${row.name}"` });
      }
    }
    let total = 0;
    for (const row of itemsRes.rows) {
      total += Number(row.price) * Number(row.quantity);
    }
    if (total <= 0) return res.status(400).json({ error: "Invalid order total" });

    const userRes = await query(`SELECT email, full_name FROM users WHERE id = $1`, [req.user.sub]);
    if (!userRes.rowCount) return res.status(401).json({ error: "User not found" });
    const { email, full_name } = userRes.rows[0];

    const reference = `FASH-${Date.now()}-${Math.random().toString(36).slice(2, 10).toUpperCase()}`;
    const callbackUrl = (process.env.CLIENT_URL || "http://localhost:5173").split(",")[0].trim() + "/checkout/success";

    // Create pending order first
    const client = await pool.connect();
    let orderId;
    try {
      await client.query("BEGIN");
      const o = await client.query(
        `INSERT INTO orders (customer_id, total, status, payment_reference, payment_status)
         VALUES ($1, $2, 'pending', $3, 'pending') RETURNING id`,
        [req.user.sub, total, reference]
      );
      orderId = o.rows[0].id;
      for (const row of itemsRes.rows) {
        await client.query(
          `INSERT INTO order_items (order_id, product_id, store_id, seller_id, quantity, unit_price)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [orderId, row.product_id, row.store_id, row.seller_id, row.quantity, row.price]
        );
      }
      await client.query("COMMIT");
    } catch (e) {
      await client.query("ROLLBACK");
      throw e;
    } finally {
      client.release();
    }

    const paystackData = await initializeTransaction({
      email,
      amountKobo: toKobo(total),
      reference,
      callbackUrl,
      metadata: {
        order_id: orderId,
        customer_name: full_name,
        custom_fields: [
          { display_name: "Order ID", variable_name: "order_id", value: orderId }
        ]
      }
    });

    res.json({
      orderId,
      reference,
      authorizationUrl: paystackData.authorization_url,
      accessCode: paystackData.access_code,
      amount: total,
      currency: process.env.CURRENCY || "NGN"
    });
  } catch (e) {
    console.error("CHECKOUT INIT ERROR:", e);
    res.status(500).json({ error: e.message || "Could not start checkout" });
  }
});

app.get("/api/checkout/verify/:reference", requireAuth, async (req, res) => {
  try {
    const { reference } = req.params;
    const orderRes = await query(
      `SELECT * FROM orders WHERE payment_reference = $1 AND customer_id = $2`,
      [reference, req.user.sub]
    );
    if (!orderRes.rowCount) {
      return res.status(404).json({ error: "Order not found" });
    }
    const order = orderRes.rows[0];
    if (order.payment_status === "paid") {
      return res.json({ success: true, order, alreadyPaid: true });
    }

    const verified = await verifyTransaction(reference);
    if (verified.status !== "success") {
      await query(`UPDATE orders SET payment_status = 'failed', updated_at = NOW() WHERE id = $1`, [order.id]);
      return res.status(400).json({ error: "Payment was not successful", status: verified.status });
    }

    // Mark paid, reduce stock, clear cart
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      await client.query(
        `UPDATE orders SET status = 'paid', payment_status = 'paid', paid_at = NOW(), updated_at = NOW() WHERE id = $1`,
        [order.id]
      );
      const items = await client.query(`SELECT product_id, quantity FROM order_items WHERE order_id = $1`, [order.id]);
      for (const item of items.rows) {
        await client.query(`UPDATE products SET stock = GREATEST(0, stock - $1) WHERE id = $2`, [item.quantity, item.product_id]);
      }
      const cartId = await getOrCreateCart(req.user.sub);
      await client.query(`DELETE FROM cart_items WHERE cart_id = $1`, [cartId]);
      await client.query("COMMIT");
    } catch (e) {
      await client.query("ROLLBACK");
      throw e;
    } finally {
      client.release();
    }

    // Optional notification
    try {
      await query(
        `INSERT INTO notifications (user_id, type, title, message)
         VALUES ($1, 'order', 'Payment received', $2)`,
        [req.user.sub, `Your order has been paid successfully. Reference: ${reference}`]
      );
    } catch (_) {}

    const updated = await query(`SELECT * FROM orders WHERE id = $1`, [order.id]);
    res.json({ success: true, order: updated.rows[0] });
  } catch (e) {
    console.error("CHECKOUT VERIFY ERROR:", e);
    res.status(500).json({ error: e.message || "Could not verify payment" });
  }
});


    // Payment columns for Paystack
    await query(`ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_reference VARCHAR(100)`);
    await query(`ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_status VARCHAR(30) NOT NULL DEFAULT 'unpaid'`);
    await query(`ALTER TABLE orders ADD COLUMN IF NOT EXISTS paid_at TIMESTAMPTZ`);
    await query(`CREATE UNIQUE INDEX IF NOT EXISTS idx_orders_payment_reference ON orders(payment_reference) WHERE payment_reference IS NOT NULL`);

    app.listen(PORT, () => console.log(`FASH backend running on http://localhost:${PORT}`));
  } catch (error) { console.error('FASH startup/database migration failed:', error); process.exit(1); }
}
startServer();

/* FASH v6.7 cart and wishlist persistence schema */
async function ensureCustomerPersistenceSchema() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS carts (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL UNIQUE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS cart_items (
      id BIGSERIAL PRIMARY KEY,
      cart_id BIGINT NOT NULL REFERENCES carts(id) ON DELETE CASCADE,
      product_id BIGINT NOT NULL,
      quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE(cart_id, product_id)
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS wishlist_items (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL,
      product_id BIGINT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE(user_id, product_id)
    )
  `);
}


/* =========================================================
   FASH v6.9 — Profile, Notifications & Settings
   ========================================================= */

app.get("/api/account", requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id, full_name, email, created_at
       FROM users
       WHERE id = $1
       LIMIT 1`,
      [req.user.id]
    );

    if (!result.rows[0]) {
      return res.status(404).json({ message: "Account not found" });
    }

    res.json({ user: result.rows[0] });
  } catch (error) {
    next(error);
  }
});

app.patch("/api/account", requireAuth, async (req, res, next) => {
  try {
    const fullName = String(req.body?.full_name || "").trim();

    if (!fullName) {
      return res.status(400).json({ message: "Full name is required" });
    }

    const result = await pool.query(
      `UPDATE users
       SET full_name = $1
       WHERE id = $2
       RETURNING id, full_name, email, created_at`,
      [fullName, req.user.id]
    );

    res.json({ user: result.rows[0] });
  } catch (error) {
    next(error);
  }
});

app.get("/api/notifications", requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT *
       FROM notifications
       WHERE user_id = $1
       ORDER BY created_at DESC`,
      [req.user.id]
    );

    res.json({ notifications: result.rows });
  } catch (error) {
    next(error);
  }
});

app.patch("/api/notifications/:notificationId/read", requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      `UPDATE notifications
       SET read_at = NOW()
       WHERE id::text = $1
         AND user_id = $2
       RETURNING *`,
      [req.params.notificationId, req.user.id]
    );

    if (!result.rows[0]) {
      return res.status(404).json({ message: "Notification not found" });
    }

    res.json({ notification: result.rows[0] });
  } catch (error) {
    next(error);
  }
});

app.post("/api/notifications/read-all", requireAuth, async (req, res, next) => {
  try {
    await pool.query(
      `UPDATE notifications
       SET read_at = NOW()
       WHERE user_id = $1
         AND read_at IS NULL`,
      [req.user.id]
    );

    res.json({ success: true });
  } catch (error) {
    next(error);
  }
});

app.get("/api/account/settings", requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT notification_email, notification_push
       FROM user_settings
       WHERE user_id = $1
       LIMIT 1`,
      [req.user.id]
    );

    res.json({
      settings: result.rows[0] || {
        notification_email: true,
        notification_push: true
      }
    });
  } catch (error) {
    next(error);
  }
});

app.patch("/api/account/settings", requireAuth, async (req, res, next) => {
  try {
    const email = req.body?.notification_email !== false;
    const push = req.body?.notification_push !== false;

    const result = await pool.query(
      `INSERT INTO user_settings (
        user_id,
        notification_email,
        notification_push
      )
      VALUES ($1, $2, $3)
      ON CONFLICT (user_id)
      DO UPDATE SET
        notification_email = EXCLUDED.notification_email,
        notification_push = EXCLUDED.notification_push
      RETURNING *`,
      [req.user.id, email, push]
    );

    res.json({ settings: result.rows[0] });
  } catch (error) {
    next(error);
  }
});
