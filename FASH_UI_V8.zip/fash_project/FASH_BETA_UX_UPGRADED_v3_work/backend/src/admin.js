import { query } from "./db.js";

export function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== "admin") {
    return res.status(403).json({ error: "Administrator access required" });
  }
  next();
}

export function requireAdminOrSeller(req, res, next) {
  if (!req.user || !["admin", "seller"].includes(req.user.role)) {
    return res.status(403).json({ error: "Administrator or seller access required" });
  }
  next();
}

// Seller portal access is intentionally available before approval.
// The UI can expose only limited tools while the application is pending/rejected.
export async function requireSellerPortal(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ error: "Authentication required" });
  }

  try {
    const result = await query(
      `SELECT role, seller_status FROM users WHERE id = $1`,
      [req.user.sub]
    );
    if (!result.rowCount) {
      return res.status(401).json({ error: "User account not found" });
    }

    const { role, seller_status: sellerStatus } = result.rows[0];
    if (role === "admin" || (role === "seller" && sellerStatus === "approved") || ["pending", "rejected", "changes_requested"].includes(sellerStatus)) {
      req.sellerStatus = sellerStatus;
      req.sellerRole = role;
      return next();
    }

    if (sellerStatus === "suspended") {
      return res.status(403).json({ error: "Seller account suspended" });
    }

    return res.status(403).json({ error: "Seller access required" });
  } catch (error) {
    console.error("SELLER PORTAL ACCESS ERROR:", error);
    return res.status(500).json({ error: "Could not verify seller access" });
  }
}

export async function requireApprovedSeller(req, res, next) {
  if (!req.user) return res.status(401).json({ error: "Authentication required" });
  try {
    const result = await query(`SELECT role, seller_status FROM users WHERE id = $1`, [req.user.sub]);
    if (!result.rowCount) return res.status(401).json({ error: "User account not found" });
    const { role, seller_status: sellerStatus } = result.rows[0];
    if (role === "admin" || (role === "seller" && sellerStatus === "approved")) return next();
    return res.status(403).json({ error: "Seller approval is required for this feature" });
  } catch (error) {
    console.error("APPROVED SELLER ACCESS ERROR:", error);
    return res.status(500).json({ error: "Could not verify seller approval" });
  }
}
