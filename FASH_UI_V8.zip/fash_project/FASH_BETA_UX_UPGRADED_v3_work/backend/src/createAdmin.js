import "dotenv/config";
import bcrypt from "bcryptjs";
import readline from "readline";
import { query } from "./db.js";

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (question) => new Promise(resolve => rl.question(question, resolve));

try {
  console.log("\nFASH — Create Administrator\n");
  console.log("This is a private setup tool. There is NO public admin signup.\n");

  const fullName = (await ask("Admin full name: ")).trim();
  const email = (await ask("Admin email: ")).trim().toLowerCase();
  const password = await ask("Admin password (min 8 chars): ");

  if (!fullName || !email || password.length < 8) {
    throw new Error("Full name and email are required, and the password must be at least 8 characters.");
  }

  const passwordHash = await bcrypt.hash(password, 12);

  const existing = await query("SELECT id, role FROM users WHERE email = $1", [email]);

  if (existing.rowCount) {
    const existingUser = existing.rows[0];
    if (existingUser.role === "admin") {
      await query(
        `UPDATE users SET full_name = $1, password_hash = $2, updated_at = NOW() WHERE id = $3`,
        [fullName, passwordHash, existingUser.id]
      );
      console.log("\nAdmin account updated successfully.");
    } else {
      await query(
        `UPDATE users SET full_name = $1, password_hash = $2, role = 'admin', seller_status = 'none', updated_at = NOW() WHERE id = $3`,
        [fullName, passwordHash, existingUser.id]
      );
      console.log("\nExisting account promoted to administrator successfully.");
    }
  } else {
    await query(
      `INSERT INTO users (full_name, email, password_hash, role, seller_status)
       VALUES ($1, $2, $3, 'admin', 'none')`,
      [fullName, email, passwordHash]
    );
    console.log("\nAdministrator account created successfully.");
  }

  console.log(`Login at: http://localhost:${process.env.PORT || 5000}/admin/login.html\n`);
} catch (error) {
  console.error("\nCould not create administrator:", error.message);
  process.exitCode = 1;
} finally {
  rl.close();
}
