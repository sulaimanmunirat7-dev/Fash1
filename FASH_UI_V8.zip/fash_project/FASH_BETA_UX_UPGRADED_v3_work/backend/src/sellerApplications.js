import { pool, query } from "./db.js";

// BUGFIX: see products.js — avoids leaking raw internal error text to clients in production.
function debugInfo(e) {
  return process.env.NODE_ENV === "production" ? {} : { debug: e.message };
}

export async function createApplication(req,res){
  try{
    const b=req.body||{};
    const sellerType=b.sellerType==="business"?"business":"individual";
    const required=sellerType==="business"
      ? ["businessName","legalName","businessRegistrationNumber","phone","category","address","country"]
      : ["legalName","phone","category","address","country"];
    for(const key of required){ if(!String(b[key]||"").trim()) return res.status(400).json({error:`${key} is required`}); }
    const existing=await query(`SELECT id,status FROM seller_applications WHERE user_id=$1 AND status IN ('pending','under_review','changes_requested') LIMIT 1`,[req.user.sub]);
    if(existing.rowCount) return res.status(409).json({error:"You already have an active seller application",application:existing.rows[0]});
    const r=await query(`INSERT INTO seller_applications
      (user_id,business_name,business_description,phone,category,location,seller_type,legal_name,business_registration_number,address,country,id_type,id_number,id_document_url,registration_document_url,achievement_notes,store_name,store_description,store_logo_url,store_banner_url,store_location,status)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,'pending') RETURNING *`,
      [req.user.sub,String(b.businessName||b.legalName).trim(),String(b.businessDescription||"").trim()||null,String(b.phone).trim(),String(b.category).trim(),String(b.location||b.address).trim(),sellerType,String(b.legalName).trim(),String(b.businessRegistrationNumber||"").trim()||null,String(b.address).trim(),String(b.country).trim(),String(b.idType||"").trim()||null,String(b.idNumber||"").trim()||null,b.idDocumentUrl||null,b.registrationDocumentUrl||null,String(b.achievementNotes||"").trim()||null,String(b.storeName||"").trim()||null,String(b.storeDescription||"").trim()||null,b.storeLogoUrl||null,b.storeBannerUrl||null,String(b.storeLocation||b.location||b.address).trim()||null]);
    await query(`UPDATE users SET seller_status='pending',seller_type=$1 WHERE id=$2`,[sellerType,req.user.sub]);
    res.status(201).json({message:"Seller application submitted",application:r.rows[0]});
  }catch(e){console.error("SELLER APPLICATION ERROR:",e);res.status(500).json({error:"Could not submit seller application",...debugInfo(e)});}
}

export async function getMyApplication(req, res) {
  try {
    const result = await query(
      `SELECT sa.*, u.full_name AS applicant_name, u.email
       FROM seller_applications sa
       JOIN users u ON u.id = sa.user_id
       WHERE sa.user_id = $1
       ORDER BY sa.submitted_at DESC
       LIMIT 1`,
      [req.user.sub]
    );

    if (!result.rowCount) {
      return res.status(404).json({ error: "No seller application found" });
    }

    res.json({ application: result.rows[0] });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Could not load seller application" });
  }
}

export async function getAllApplications(req, res) {
  try {
    const result = await query(
      `SELECT sa.*, u.full_name AS applicant_name, u.email
       FROM seller_applications sa
       JOIN users u ON u.id = sa.user_id
       WHERE sa.status IN ('pending','under_review','changes_requested')
       ORDER BY sa.submitted_at DESC`
    );

    res.json({ applications: result.rows });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Could not load applications" });
  }
}

export async function reviewApplication(req, res) {
  const client = await pool.connect();

  try {
    const { status, adminNotes } = req.body;
    const allowed = ["approved", "rejected", "changes_requested", "under_review"];

    if (!allowed.includes(status)) {
      return res.status(400).json({ error: "Invalid application decision" });
    }

    await client.query("BEGIN");

    const found = await client.query(
      "SELECT user_id FROM seller_applications WHERE id = $1 FOR UPDATE",
      [req.params.id]
    );

    if (!found.rowCount) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "Application not found" });
    }

    const userId = found.rows[0].user_id;

    await client.query(
      `UPDATE seller_applications
       SET status=$1, admin_notes=$2, reviewed_at=NOW()
       WHERE id=$3`,
      [status, adminNotes?.trim() || null, req.params.id]
    );

    if (status === "approved") {
      const appRow = await client.query(`SELECT * FROM seller_applications WHERE id=$1`,[req.params.id]);
      await client.query(
        `UPDATE users
         SET role='seller', seller_status='approved', seller_verification_status='unverified'
         WHERE id=$1`,
        [userId]
      );
      const a=appRow.rows[0];
      if(a?.store_name){
        await client.query(`
          INSERT INTO stores(seller_id,name,description,logo_url,banner_url,location,status,is_active)
          VALUES($1,$2,$3,$4,$5,$6,'DRAFT',FALSE)
          ON CONFLICT(seller_id) DO UPDATE SET
            name=EXCLUDED.name,description=EXCLUDED.description,logo_url=EXCLUDED.logo_url,
            banner_url=EXCLUDED.banner_url,location=EXCLUDED.location
        `,[userId,a.store_name,a.store_description,a.store_logo_url,a.store_banner_url,a.store_location]);
      }
    } else if (status === 'under_review') {
      await client.query(`UPDATE users SET seller_status='pending' WHERE id=$1`, [userId]);
    } else {
      await client.query(`UPDATE users SET role='customer', seller_status=$1 WHERE id=$2`, [status, userId]);
    }

    await client.query("COMMIT");

    res.json({ message: `Application ${status}`, status });
  } catch (error) {
    await client.query("ROLLBACK");
    console.error(error);
    res.status(500).json({ error: "Could not review application" });
  } finally {
    client.release();
  }
}


export async function getRejectedApplications(req, res) {
  try {
    const result = await query(
      `SELECT sa.*, u.full_name AS applicant_name, u.email
       FROM seller_applications sa
       JOIN users u ON u.id = sa.user_id
       WHERE sa.status = 'rejected'
       ORDER BY sa.reviewed_at DESC NULLS LAST, sa.submitted_at DESC`
    );
    res.json({ applications: result.rows });
  } catch (error) {
    console.error("GET REJECTED APPLICATIONS ERROR:", error);
    res.status(500).json({ error: "Could not load rejected applications" });
  }
}
