# FASH verification snapshot

## Verified statically in this package

- Customer registration writes `full_name` to `users.full_name`.
- Seller applications link to `users` by `user_id`; the admin application query returns applicant name/email from the user record.
- Seller Login uses the existing customer account email/password and checks the latest seller application.
- Pending, rejected and changes-requested applicants can enter the seller portal; suspended accounts are blocked.
- Admin approval changes the user to `role=seller` and `seller_status=approved`.
- Products are stored with `seller_id` and approved sellers can create/update/delete their own products.
- Public `/api/products` returns active, in-stock products for approved sellers.
- Homepage loads live seller products and featured products from the backend.
- Admin-only product featuring fields exist: `is_featured`, `featured_until`, `featured_position`.
- Stores include future featured-placement fields.
- Admin Applications has no permanent loading overlay; API failure renders a Retry state.
- The supplied FASH F logo is included as a transparent asset and wired into the main navbar, admin login/sidebar, seller portal/sidebar, seller login, customer login/register, and favicon.

## Local live verification required

This build environment cannot connect to your local PostgreSQL instance, so the following must be tested on your PC:

1. Start the backend and confirm `http://localhost:5000` responds.
2. Submit a seller application and confirm it appears in Admin > Applications with the customer's full name.
3. Log in through Seller Login using the same customer account.
4. Approve the application in Admin and confirm the seller moves to the approved Sellers view.
5. Add a product as the approved seller.
6. Confirm the product exists in PostgreSQL and `GET /api/products` returns it.
7. Confirm the product appears in Shop and the homepage's live seller-products section.
8. Use the Admin feature action to place a product in Featured Products.
