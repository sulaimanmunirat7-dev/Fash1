import test from "node:test";
import assert from "node:assert/strict";

const email = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(v || '').trim());
const password = v => typeof v === "string" && v.length >= 8 && v.length <= 128;

test("accepts valid beta signup credentials", () => {
  assert.equal(email("beta@example.com"), true);
  assert.equal(password("StrongPass123!"), true);
});
test("rejects invalid beta signup credentials", () => {
  assert.equal(email("not-an-email"), false);
  assert.equal(password("short"), false);
});
