# FASH Backend — Phase 1

Phase 1 establishes:

- Node.js + Express API
- PostgreSQL database
- Customer/seller/admin role field
- Secure password hashing with bcrypt
- JWT authentication
- Registration
- Login
- Current-user endpoint
- Basic logout endpoint
- Database health check

## Requirements

Install:

- Node.js LTS
- PostgreSQL

## 1. Create the database

Create a PostgreSQL database named:

fash

Then run:

schema.sql

If PostgreSQL reports that `gen_random_uuid()` is unavailable,
enable pgcrypto:

CREATE EXTENSION IF NOT EXISTS pgcrypto;

Then run schema.sql again.

## 2. Configure environment

Copy:

.env.example

to:

.env

Then set your PostgreSQL password and a strong JWT secret.

Example:

DATABASE_URL=postgresql://postgres:password@localhost:5432/fash
JWT_SECRET=use-a-long-random-secret

## 3. Install dependencies

npm install

## 4. Start the API

Development:

npm run dev

Production-style:

npm start

## 5. Test

Open:

http://localhost:5000/api/health

Expected:

{
  "ok": true,
  "database": "connected"
}

## API

POST /api/auth/register

{
  "fullName": "Ramoz",
  "email": "ramoz@example.com",
  "password": "password123"
}

POST /api/auth/login

{
  "email": "ramoz@example.com",
  "password": "password123"
}

GET /api/auth/me

Header:

Authorization: Bearer YOUR_TOKEN

## Important

Do NOT delete the current FASH LocalStorage system yet.

Phase 1 runs beside the existing frontend.

Next phases can migrate:

users → seller applications → products → orders → sales → reports → returns.

The database should become the source of truth only after each area has been tested.
