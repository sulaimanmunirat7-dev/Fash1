CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'customer'
        CHECK (role IN ('customer', 'seller', 'admin')),
    email_verified BOOLEAN NOT NULL DEFAULT FALSE,
    seller_status VARCHAR(30) NOT NULL DEFAULT 'none'
        CHECK (seller_status IN ('none', 'pending', 'approved', 'rejected', 'changes_requested', 'suspended')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS users_updated_at ON users;

CREATE TRIGGER users_updated_at
BEFORE UPDATE ON users
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();
-- ==========================================
-- SELLER APPLICATIONS
-- ==========================================

CREATE TABLE IF NOT EXISTS seller_applications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    user_id UUID NOT NULL
        REFERENCES users(id)
        ON DELETE CASCADE,

    business_name VARCHAR(150) NOT NULL,

    business_description TEXT,

    phone VARCHAR(30),

    category VARCHAR(100) NOT NULL,

    location VARCHAR(180),

    status VARCHAR(30) NOT NULL DEFAULT 'pending'
        CHECK (status IN ('draft','hidden','pending_review','approved','rejected','scheduled')),

    admin_notes TEXT,

    submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    reviewed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_seller_applications_user_id
    ON seller_applications(user_id);

CREATE INDEX IF NOT EXISTS idx_seller_applications_status
    ON seller_applications(status);

CREATE INDEX IF NOT EXISTS idx_seller_applications_submitted_at
    ON seller_applications(submitted_at);

-- ==========================================
-- PRODUCTS
-- ==========================================
CREATE TABLE IF NOT EXISTS products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    seller_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(180) NOT NULL,
    description TEXT,
    price NUMERIC(14,2) NOT NULL CHECK (price > 0),
    stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
    category VARCHAR(100) NOT NULL,
    image_url TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'active'
        CHECK (status IN ('active','draft','inactive')),
    is_featured BOOLEAN NOT NULL DEFAULT FALSE,
    featured_until TIMESTAMPTZ,
    featured_position INTEGER,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_products_seller_id ON products(seller_id);
CREATE INDEX IF NOT EXISTS idx_products_status ON products(status);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_products_created_at ON products(created_at DESC);

DROP TRIGGER IF EXISTS products_updated_at ON products;
CREATE TRIGGER products_updated_at
BEFORE UPDATE ON products
FOR EACH ROW
EXECUTE FUNCTION set_updated_at();


-- ==========================================
-- SELLER STORES (future-ready)
-- A store becomes publicly visible only when its seller is approved.
-- ==========================================
CREATE TABLE IF NOT EXISTS stores (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    seller_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    logo_url TEXT,
    banner_url TEXT,
    location VARCHAR(180),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    is_featured BOOLEAN NOT NULL DEFAULT FALSE,
    featured_until TIMESTAMPTZ,
    featured_position INTEGER,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_stores_featured ON stores(is_featured, featured_position);
CREATE INDEX IF NOT EXISTS idx_stores_active ON stores(is_active);


-- FASH marketplace lifecycle extensions
ALTER TABLE users ADD COLUMN IF NOT EXISTS seller_type VARCHAR(20) NOT NULL DEFAULT 'individual'
  CHECK (seller_type IN ('individual','business'));
ALTER TABLE users ADD COLUMN IF NOT EXISTS seller_verification_status VARCHAR(30) NOT NULL DEFAULT 'unverified'
  CHECK (seller_verification_status IN ('unverified','verified','needs_info'));

ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS seller_type VARCHAR(20) NOT NULL DEFAULT 'individual';
ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS legal_name VARCHAR(180);
ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS business_registration_number VARCHAR(120);
ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS address VARCHAR(250);
ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS country VARCHAR(100);
ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS id_type VARCHAR(80);
ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS id_number VARCHAR(120);
ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS id_document_url TEXT;
ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS registration_document_url TEXT;
ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS achievement_notes TEXT;

ALTER TABLE stores ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'DRAFT';
ALTER TABLE stores ADD COLUMN IF NOT EXISTS rating NUMERIC(3,1) NOT NULL DEFAULT 0;
ALTER TABLE stores ADD COLUMN IF NOT EXISTS rating_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE stores DROP CONSTRAINT IF EXISTS stores_status_check;
ALTER TABLE stores ADD CONSTRAINT stores_status_check CHECK (status IN ('DRAFT','LIVE','SUSPENDED','CLOSED'));
UPDATE stores SET status = CASE WHEN is_active THEN 'LIVE' ELSE 'DRAFT' END WHERE status IS NULL OR status='DRAFT';
UPDATE stores SET is_active = (status='LIVE');

ALTER TABLE products ADD COLUMN IF NOT EXISTS store_id UUID REFERENCES stores(id) ON DELETE CASCADE;
ALTER TABLE products DROP CONSTRAINT IF EXISTS products_status_check;
UPDATE products SET status='approved' WHERE status='active';
UPDATE products SET status='hidden' WHERE status='inactive';
ALTER TABLE products ADD CONSTRAINT products_status_check CHECK (status IN ('draft','hidden','pending_review','approved','rejected'));
ALTER TABLE products ALTER COLUMN status SET DEFAULT 'draft';
ALTER TABLE products ADD COLUMN IF NOT EXISTS rejection_reason TEXT;
ALTER TABLE products ADD COLUMN IF NOT EXISTS scheduled_at TIMESTAMPTZ;
ALTER TABLE products ADD COLUMN IF NOT EXISTS reviewed_at TIMESTAMPTZ;
ALTER TABLE products ADD COLUMN IF NOT EXISTS reviewed_by UUID REFERENCES users(id);
CREATE INDEX IF NOT EXISTS idx_products_store_id ON products(store_id);

CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status VARCHAR(30) NOT NULL DEFAULT 'pending',
  total NUMERIC(14,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  store_id UUID NOT NULL REFERENCES stores(id) ON DELETE RESTRICT,
  seller_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  quantity INTEGER NOT NULL CHECK(quantity>0),
  unit_price NUMERIC(14,2) NOT NULL CHECK(unit_price>=0)
);
DROP TRIGGER IF EXISTS orders_updated_at ON orders;
CREATE TRIGGER orders_updated_at BEFORE UPDATE ON orders FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE IF NOT EXISTS store_followers (
  store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY(store_id,user_id)
);
CREATE TABLE IF NOT EXISTS store_reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  rating NUMERIC(2,1) NOT NULL CHECK(rating>=1 AND rating<=5),
  review TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(store_id,user_id,order_id)
);


-- FASH MASTER CHANGESET
ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS store_name VARCHAR(150);
ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS store_description TEXT;
ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS store_logo_url TEXT;
ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS store_banner_url TEXT;
ALTER TABLE seller_applications ADD COLUMN IF NOT EXISTS store_location VARCHAR(180);

CREATE TABLE IF NOT EXISTS categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(100) UNIQUE NOT NULL,
  slug VARCHAR(120) UNIQUE NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS returns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  customer_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  store_id UUID REFERENCES stores(id) ON DELETE SET NULL,
  seller_id UUID REFERENCES users(id) ON DELETE SET NULL,
  reason VARCHAR(180) NOT NULL,
  details TEXT,
  status VARCHAR(30) NOT NULL DEFAULT 'pending'
    CHECK(status IN ('pending','approved','rejected','received','refunded')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_returns_status ON returns(status);
CREATE INDEX IF NOT EXISTS idx_returns_created ON returns(created_at DESC);

CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type VARCHAR(50) NOT NULL,
  title VARCHAR(180) NOT NULL,
  message TEXT NOT NULL,
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id,created_at DESC);

CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_order_items_seller ON order_items(seller_id);
CREATE INDEX IF NOT EXISTS idx_order_items_store ON order_items(store_id);
