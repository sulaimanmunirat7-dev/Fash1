# FASH Admin / Seller Analytics Update

Implemented in this build:
- Approved sellers are represented by `users.role='seller'` and appear in Admin > Sellers.
- Admin Applications endpoint now shows only active applications (pending, under review, changes requested).
- Rejected applications are moved to Admin > Applications > Rejected.
- Approved/rejected applications therefore disappear from the active Applications list.
- Rejected applications remain stored for history and can be re-applied through the existing reapply flow.
- Admin dashboard includes Application Analytics with Today, 7 Days, 1 Month, 3 Months, 6 Months, 1 Year, and All Time.
- Analytics counts every application submission, including repeat submissions.
- Analytics returns totals and a daily trend.
- Admin Products includes Homepage Featured Products with a maximum of 8 and optional position.
- Featured products use the existing `is_featured`, `featured_until`, and `featured_position` database fields.
- Approved sellers can save a public store profile to PostgreSQL.
- Public Stores loads database stores and only displays stores belonging to approved sellers.
- Seller store profile is visible publicly after the seller is approved and creates/saves a store.


Correction: application analytics UI belongs on Admin > Reports, not the Admin dashboard. The dashboard widget was removed; Reports now contains the application reporting period selector and chart.
